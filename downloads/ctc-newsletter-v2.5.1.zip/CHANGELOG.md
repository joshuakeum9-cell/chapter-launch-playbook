# Changelog

## 2.5.1 (2026-10-01): skills locate their own files

Installed as a plugin, the five skills' scripts and reference files land under the account's synced-plugins folder, not in the session's working directory, so a relative path like `scripts/build_registry.py` found nothing and a run stopped with "files missing" even though every file was present. Each skill now opens with a "Find your files first" block: one `find` command that locates the skill's own folder inside the installed plugin, after which every `scripts/`, `references/` and `../ctc-<sibling>/` path resolves against it. If the search returns nothing the skill says so and stops rather than rebuilding a script by hand. No other change; tested against the installed 2.5.0 by running `build_registry.py` from the located folder.


## 2.5.0 (2026-10-01): faster research, same checks

The research stages (harvest, source map, opportunities) were slow because every event page was opened one at a time, read as rendered text, and then opened again by the verifier. This release changes how pages are read and in what order, not which checks run. Every rule from 2.4.1 is still in force (including asking before the browser is opened the first time in a session); several moved from prose to a field the build script reads.

### ctc-harvest
- **Phased sweep.** Enumerate every source first (candidates only), then plan which pages to open, then open them in batches, then write rows. Previously the sweep opened each source's events as it went, so duplicates were opened twice and out-of-window events were opened before their date was known.
- **`scripts/harvest_helpers.js`** (new): browser helpers injected once per tab. `__ENUM_LUMA` reads every registered Luma calendar from one tab (vanity slugs and `cal-...` ids); `__PULL_LUMA` reads ten Luma event payloads per call (UTC times with timezone, street address, hosts, ticket info, the full rich description, which 2.4.1 could not read). `__ENUM_EB` / `__PULL_EB` do the same for Eventbrite organizers and events from the page's `__NEXT_DATA__` and JSON-LD, which 2.4.1 had no structured path for. `__EXTRACT_CURRENT` and `__PULL_SAME_ORIGIN` read JSON-LD off any other page. Requests are paced inside the helpers. **Verified live in Chrome on 1 Oct 2026**: three Luma calendar forms, ten Luma events in 17 seconds, two Eventbrite organizer URL forms, one Eventbrite event; the transport came back byte-identical on all of it.
- **`scripts/decode_transport.py`** (new): decodes the helpers' output, keeping record order and refusing to drop a record it cannot parse. Record framing cannot collide with event text (an earlier draft split on `====`, which real descriptions contain).
- **`scripts/plan_candidates.py`** (new): windows and URL dedupe before any page is opened; flags same-day name overlaps for the venue check; never drops a candidate without a date or a submitted or lead row. Optional `--previous` takes last week's companion file (`CTC_Events_<City>_<date>.json`, now written next to the sheet) and marks rows harvested last week; prose is reused only when date, start time, location and the page's own description text all come back unchanged, and every such row is still re-fetched and re-checked.
- **`scripts/build_sheet.py`**: every row now carries `page_checks` (is this event, date matches, not passed, landed URL). A missing or failed check is a named warning. A Registration Link that differs from the page the extractor landed on is a warning.
- **Verifier**: every link is re-fetched and compared as data; pages are opened in the tab by eye for every mismatch, every submitted row, every off-platform row without structured data, every build warning, three Luma and three Eventbrite rows for the rendered local time (independent of the sweep's conversion), at least three carried rows, plus a random sample (at least five rows or fifteen percent). Can be split across subagents; browser work stays with one.
- **Parallel row writing** from `events_raw.json`, ten to fifteen events per subagent (no browser involved, so the batch limit does not apply), with voice.md section 6 in front of each.
- `platform-notes.md` rewritten around the helpers; Eventbrite section added.
- Two failure modes added: two agents in the browser; a half-empty batch.

### ctc-source-map
- Step 2 research runs as three parallel subagents (three categories each) returning candidates; the five gates still run centrally.
- Gate checks for Luma and Eventbrite candidates are batched through the harvest helpers from one tab; a calendar that comes back failed or with zero upcoming items is opened by eye before any gate ruling.
- Verifier re-fetches every row in batches and opens by eye the failed, manual, unverified and relationship rows plus three random auto rows.

### ctc-opportunities
- Tiers 1, 2 and 4 run as parallel subagents; Tier 3 (LinkedIn, the lead's signed-in browser) stays alone and consent-gated as before.
- Verifier re-fetches every URL (splittable across subagents) and uses the browser only where the fetch cannot settle the deadline.

### ctc-newsletter-cycle
- House rule added: one agent in the browser, many for everything else.
- Stage 1 mentions the harvest's companion file and the one optional lead-facing line about it (new lead-facing text; not a time estimate).

### Unchanged
- ctc-assemble, voice.md, house-style.md, the ten-block order, the cut, the three rewrite blocks, every quoted lead-facing prompt, the no-time-estimates rule.

### Verification notes
- Live testing found and fixed three things the sandbox could not: Luma serves its payload at two different depths depending on the calendar URL form; Luma's plain description field is empty and the real text is a rich-text tree; Eventbrite's organizer `showmore` endpoint is gone (403) and the organizer list lives in `__NEXT_DATA__`. The transport also now encodes non-breaking spaces, which the extension's page-text reader normalizes.

### Known trade-off
- A chapter with five sources and ten events gains little from batching and pays a small fixed cost (inject, decode, plan). Quality is unchanged there; the saving grows with the event count.
