---
name: ctc-harvest
description: Harvest this week's climate events for a Climate Tech Cities chapter. Sweep the city's source list (Luma calendars, Eventbrite organizers, other verified sources, and the CTC event submission form) and produce the standard events spreadsheet the newsletter is built from. Use this skill whenever the user wants to collect, pull, gather, or sweep events for a city's newsletter, asks "get this week's events for [city]", wants the events sheet or events spreadsheet built, or is starting the weekly newsletter cycle. Always use this skill even if the user only wants one source swept or a single day's events. Do NOT use it to find new sources, which is the source-map skill's job.
---

# CTC Harvest

Sweep a city's registered sources and the CTC event submission form, and produce the events spreadsheet. This is the collection half of the weekly newsletter cycle: collection only, no judgment, no writing.

## Find your files first

Every path in this skill (`scripts/...`, `references/...`, `../ctc-<other skill>/...`) is relative to **this skill's own folder inside the installed plugin**, not to the working directory. Locate it before anything else, once per session:

```bash
find / -xdev -type d -path "*/ctc-newsletter*/skills/ctc-harvest" -not -path "*/.trash/*" 2>/dev/null | head -1
```

Call the result `$SKILL`. The plugin's other skills are its siblings (`$SKILL/../ctc-assemble`, `$SKILL/../ctc-harvest`, and so on). Run scripts as `python3 $SKILL/scripts/<name>.py` and read references as `$SKILL/references/<name>.md`. If the search returns nothing, the plugin's files did not install; say so and stop, rather than rebuilding any script by hand or inventing a URL the files were supposed to carry.

## What you will get back

One spreadsheet, `CTC_Events_<City>_<send date>.xlsx`, one sheet named `Events`, one row per event, the fourteen standard columns, then `Block` and `Source`, then `Missing Info`. A three-row excerpt (columns cut for width):

| Event Name | Date | Start Time (PDT) | Registration Link | Event Type | Access | Location | Block | Source |
|---|---|---|---|---|---|---|---|---|
| Grid Interconnection 101 | 2026-08-12 | 17:30 | https://luma.com/... | In-person | Free | Ecotrust Building, 721 NW 9th Ave, Portland | this_week | registry |
| Repair Cafe: Small Appliances | 2026-08-13 | 10:00 | https://... | In-person | Not stated | St. Johns Community Center... | this_week | submitted |
| Green Drinks Portland | 2026-08-25 | 17:30 | https://www.eventbrite.com/... | In-person | Ticketed (Paid) | Loyal Legion, 710 SE 6th Ave, Portland | upcoming | submitted |

Any cell that should have a value and does not is shaded red and named in `Missing Info`. The chat report says how many sources were swept, which returned nothing, which failed, and how many rows came from the submission form. A full sample is `references/sample-output/CTC_Events_SAMPLE.xlsx`; `references/example-events.csv` is the same data as text (without the `Missing Info` column, which the script derives).

## What this is for

The sheet is a worksheet for one person, the chapter lead, who will delete rows from it and hand it to `ctc-assemble`. That reader wants three things: **every event that exists**, so nothing good is missed; **enough detail per row to decide**, so they are not opening twenty tabs; and **no invented data**, because anything guessed at gets published under their name.

Over-collection is cheap, because a row is easy to delete. Under-collection is expensive, because it is invisible.

## Input

- **The source list**, `CTC_Source_Registry_<City>.xlsx` from `ctc-source-map`. If none exists, stop and say so. Harvesting without one means guessing at sources and the result cannot be trusted for completeness.
- **The chapter settings file**, if it is in the project: city and timezone from section 1, scope rule and cadence from section 2. Read it rather than asking.
- **The date windows.** For a weekly chapter: `this_week` is the 7 days from the send day, `upcoming` is days 8 to 28, four weeks out and no further. For a chapter that has moved to every two weeks (decided in `ctc-newsletter-cycle`, recorded in the settings file's `Cadence` row): `this_week` is 14 days, `upcoming` is days 15 to 42. Both windows, every run. Anything past the window is not collected; it enters the sheet naturally on a later week's sweep as its date comes into range.

## What this skill does not do

No filtering for quality, no cutting, no picking, no prose. Collection and judgment are separate stages on purpose; mixing them is what turns a short sitting into a long one. Harvest everything in the windows and let the lead cut afterward in the sheet.

Do not tell the lead how long any of this will take.

## Read this first

- `references/platform-notes.md`: how to pull structured data out of Luma and Eventbrite in batches, how to read the CTC submission view, and the traps that produce wrong times or out-of-scope events.
- `references/verifier.md`: the second-pass check run on the finished sheet before it is handed over.
- `scripts/harvest_helpers.js`, `scripts/decode_transport.py`, `scripts/plan_candidates.py`: the batch extraction helpers that Steps 1 and 3 run. The header comment of each says how.
- `references/example-events.csv`: a complete valid 21-row sheet, the same fictional week as the assemble skill's example issue, to calibrate description length and what a filled row looks like. Illustrative data; never copy its rows into a live sheet.

## Environment

| Dependency | Needed for | If it is missing |
|---|---|---|
| Code execution and `openpyxl` | `build_sheet.py` | `pip install openpyxl --break-system-packages`. If code execution is off, ask the lead to enable it in Claude settings; without it, output a CSV with the same columns and say the .xlsx step was skipped |
| Claude in Chrome extension | Luma and Eventbrite | Say so before sweeping. Without it Luma returns titles with no dates. Offer the three options in `references/platform-notes.md`, "When the browser is not available" |
| An Airtable tool or connector, **or** the browser | The CTC submission form | Either reads it. The connector is the better path where the session has one, and is the only way to read the table without the extension |

The browser is not optional for this skill. A harvest run without it produces a sheet of names with empty date cells, which looks like a data problem and is a missing tool. Check once, at the start, before the first fetch.

The sandbox only reaches an allowlisted set of domains, so `curl` and Python `requests` fail on event sites that are fine. Use the fetch tool or the browser for anything on the open web, and never conclude a source is dead because a shell command could not reach it.

## Step 0. Anything the lead already knows

Ask once, in the opening message:

> Sweeping your source list and the submission form now. Anything you already know about that will not be on a calendar? Paste it in and I will add it to the sheet.

Anything they add goes into the sheet with `Source = lead`. Never drop a lead-supplied event, even when a field is missing: name the missing field and keep the row.

If what they actually want is new sources rather than new events, that is `ctc-source-map`. Point them there.

## How the sweep is shaped

The sweep runs in phases, breadth first, and the browser is never the place where thinking happens. Enumerate every source cheaply, decide which event pages to open, open them in batches as data, then write rows. The old shape, open a source, open each of its events, write each row, open the next source, read every page twice and opened duplicates twice. Nothing below removes a check; it moves each check to the point where it costs the least.

**Ask before opening the browser the first time in a session.** Then: **two rules that make this safe.** The browser is one shared, rate-limited tab: everything that touches Luma or Eventbrite runs through it one call at a time, paced, and never from more than one agent. Everything that does not need the browser (plain-fetch sources, writing rows, the verifier) can be split across subagents, because a plain fetch has no shared state and a subagent that sees twelve events writes better rows than one that is holding sixty pages in its head. Where the session has no subagent tool, the same phases run in sequence; the order still saves the duplicate opens.

## Step 1. Enumerate every registered source

**Every registered source gets opened, every run.** Not a sample, not the ones that produced events last week. The sources that usually return nothing are exactly where a missed event hides, and "usually empty" is the state a broken source hides in.

This step collects **candidates**, not rows: for each event a source lists, its name, its own URL, the listing's date if the listing carries one, and the source it came from. Nothing is written to the sheet from here. Write everything into `candidates.json` (the shape is in the header of `scripts/plan_candidates.py`).

The registry's `platform` column decides the path. Do not try a plain fetch on a platform that is known to need the browser; the escalation ladder exists for the `web` rows.

- **Luma, all calendars at once.** Open one tab on any `luma.com` page, inject `scripts/harvest_helpers.js`, then call `__ENUM_LUMA([...])` with every registered Luma calendar slug in one call (two calls if there are more than fifteen). It fetches each calendar same-origin and reads the structured `__NEXT_DATA__` payload, so every event comes back with its UTC start time and city. No per-calendar navigation. Read the result with `__SHOW(i)` and `get_page_text`, decode with `scripts/decode_transport.py`.
- **Eventbrite, all organizers at once.** Open one tab on any `eventbrite.com` page, inject the helpers, call `__ENUM_EB([...])` with every registered organizer URL. It tries the organizer's structured future-events list first and the page's JSON-LD second, and says which path worked per organizer. An organizer on a country domain (`.ca`, `.co.uk`) is a different origin: navigate there once and inject again for those.
- **Web sources (universities, government, utilities, professional groups, arts).** Plain fetch, Tier 1. Where the session has a subagent tool, split the `web` rows into groups of five to eight and run the groups in parallel; each subagent returns candidates for its sources and names any source that returned an empty shell, a JavaScript placeholder, a 403, or truncated content. Those escalate to **Tier 2**: navigate the browser to the source, read it, or call `__EXTRACT_CURRENT()` if it is an event page. Tier 2 for web sources runs after the Luma and Eventbrite enumeration, in the same single tab, paced. **Tier 3, paste**, is unchanged: if a source still fails, ask the lead to open it and paste the contents, and record the failure. A source needing this every week should be reclassified `manual` in the registry.
- **The submission form.** Step 2, below, runs here as a source. Its rows enter `candidates.json` with `origin = submitted` and the submitter's description attached.
- **Anything the lead pasted in Step 0** enters with `origin = lead`.

**Hard stops.** A CAPTCHA or bot challenge: report it and move on, never solve or route around it. A login wall: skip it and note it. Never enter credentials. If a helper call comes back with HTTP 429 or a challenge page for a platform, stop that platform's batch, wait, and continue with smaller batches; do not open a second tab to go faster.

**Pacing.** The helpers pause between requests on purpose. Ten events per `__PULL_*` call is the default and stays under the extension's time limit; fifteen is the most that is safe, and only for `__ENUM_EB`. Thirty organizer pages in a burst trips rate limiting; that was true before and the helpers do not change it.

Account for every row before moving on. A source that could not be reached is a fact to report, not a row to skip quietly. **A source returning nothing and a source failing are different things and are never reported the same way**: the first is information about the week, the second is a broken registry row.

If the week's candidate total comes in far below the chapter's normal, a source broke rather than the city going quiet. Check the zero-return sources by eye before concluding anything.

## Step 2. Read the CTC event submission form

Climate Tech Cities runs one event intake form for every chapter. Anyone can submit an event; the table behind it is internal and readers never see it. The registry carries it as a standing row (`platform = airtable`, `category = submissions`), and it is swept every week like any other source, with these differences:

1. Open the table (the URL is in the registry row; `platform-notes.md` says how to reach it and how to read its columns, which are read live rather than assumed). Take only this chapter's rows, dated inside either window. Ignore every other chapter's rows. A submitted row for this chapter whose date falls outside both windows is not shipped, but it is not forgotten either: the planner keeps it aside and the run report names it, so the lead knows a reader sent something for a later week.
2. **Open the registration link on every submitted row**, the same as for any other source. Submitters make mistakes and a submitted link is no more trusted than a scraped one. Fill the sheet from the event's own page; where the form and the page disagree, the page wins, and say so in the report.
3. The submitter's `Description` goes into the `Description` column, tidied to the standard length. It was written by a person who knows the event, so prefer it to the page's copy where both exist.
4. Rows get `Source = submitted`. **Never drop a submitted event**, even with a missing field. Name the field, keep the row, and tell the lead a reader sent it in, so they can decide.
5. **Fill the sheet's columns and use nothing else.** The form carries fields meant for the chapter lead rather than for readers, and may carry columns added since this skill was written. Take only what a sheet column plainly corresponds to; anything else stays in the table, and in particular is never appended to `Description`. `platform-notes.md` states the rule in full.
6. Report the count: "3 events came in through the submission form this week, all in scope."

A submitted event that is already in the sheet from a registry source is a duplicate; merge per the dedupe rules below, keep `Source = submitted` on the merged row so the lead knows a reader asked for it, and prefer the submitter's description. `plan_candidates.py` does the URL half of that merge for you and keeps `submitted` on the merged candidate.

If the table cannot be opened, say so and carry on with the registry. The form is a source, not the sheet.

## Step 2b. Decide what to open, before opening anything

```
python3 scripts/plan_candidates.py candidates.json plan.json \
    --send-date <YYYY-MM-DD> --tz <IANA zone> [--cadence biweekly] [--previous <last week's CTC_Events_<City>_<send date>.json>]
```

It puts every candidate in a window from its listing date (converted to the city's timezone), drops the ones a listing date places outside the window, collapses exact duplicates by URL so the same event on two calendars is opened once, and flags same-day pairs whose names overlap so the venue check happens after extraction. Three things it will not do, on purpose: it never drops a candidate with no listing date (the page decides), it never drops a `submitted` or `lead` row, and it never merges on name alone. Read its summary before Step 3. If most candidates have no listing date, a source was read as page text instead of its structured list; fix that first.

The `--previous` flag is optional. It takes last week's companion file (`CTC_Events_<City>_<send date>.json`, written next to last week's sheet) and marks candidates that were fully harvested then. They are still re-fetched in Step 3 and still re-checked; the flag only lets Step 4 reuse last week's Description, Format and Categories when the fresh page comes back with the same date, start time, location **and the same description text** (`source_description`). Anything different is rewritten. The lead has to drop that file into the conversation for it to be used; it is a convenience, not a requirement, and a week without it loses nothing but the reuse.

## Step 3. Open the event's own page, always, as data

**A calendar tells you an event exists. Only the event's own page tells you when and where it is.**

The rule: never write a row from a listing page. Every candidate in `plan.json` gets its own page read, and the row is written from that read. What changes is how the page is read: as its structured payload, in batches, instead of one navigate-and-screenshot per event.

- **Luma events:** `__PULL_LUMA([...slugs])`, ten per call, from the luma.com tab. Returns the event payload (UTC start and end, address, address visibility, hosts, ticket info, the description) and the URL the fetch landed on. A slug that redirected off Luma comes back through the generic extractor instead.
- **Eventbrite events:** `__PULL_EB([...urls])`, ten per call, from the eventbrite.com tab. Returns the page's JSON-LD (name, start, end, location, organizer, offers, status) plus the local time and timezone from the page's server data, and the URL it landed on.
- **Everything else:** plain fetch of the event page, in parallel subagents for the `web` sources, reading JSON-LD when the page has it and the page text when it does not. A page that returns an empty shell to a plain fetch is navigated in the browser and read with `__EXTRACT_CURRENT()`, one at a time, after the Luma and Eventbrite batches.
- **Submitted and lead rows:** opened like any other, whichever path their URL belongs to.

Write the results to `events_raw.json`, one record per candidate, with the `page_checks` object filled in for every record. Those are the three things the old flow asked you to check while on the page, and they are now fields the build script reads:

| Field | True when |
|---|---|
| `is_this_event` | The page is about this event (name matches the candidate, allowing for the status-tag stripping below) |
| `date_matches` | The page's date equals the candidate's listing date, or the candidate had no listing date and the page gave one |
| `not_passed` | The page does not say the event has ended or been cancelled; the extractor's `page_says_passed`, `cancelled` and `status` fields are read for this. Sold out is not passed: it is a fact for the Description |
| `landed_url` | The address the fetch or navigation actually ended on |

A record with any of the first three false does not ship as it stands: fix the link, fix the date, or drop the event. Two or more of Start Time, Location, and Access missing on the same record means the structured payload was thin; open that page in the tab and read it. No registration link at all means the row does not ship: find the page or drop the event.

**Upcoming rows get the same page reads as this-week rows.** In one reviewed issue every one of fourteen link failures was in `upcoming`. Those links reach a reader the same way.

### The link must be the page you landed on

- **Never construct a URL** from a pattern, a slug, an ID, or a date. The helpers return `landed_url` after redirects; that is the link. A constructed slug lands on the wrong event silently; one redirected to the previous year's edition.
- **Never join a title to a URL afterwards.** The helpers return name and URL in the same record. A positional join once attached real event IDs to the wrong names, which is why `decode_transport.py` keeps the record index and refuses to drop a record it could not parse.
- **Never fall back to the listing page.** If an event has no page of its own, leave `Registration Link` empty and let the row flag red. An empty cell is recoverable; a plausible wrong link ships.

Do not compare the slug to the title as a substitute for the `page_checks`. Slugs legitimately drift.

### Times

Luma returns UTC. Eventbrite returns local time with its timezone. Convert everything to the city's timezone before writing `Start Time` and `End Time`, and spot-check one Luma row against its page in the tab before trusting the batch.

## Step 4. Write the rows: every required cell, with a value or a resolved unknown

Rows are written from `events_raw.json`, never from memory of the sweep. Where the session has a subagent tool, split the records into groups of ten to fifteen and have each subagent write its rows into its own `events_part_N.json` with this section, the Output section, and `../ctc-assemble/references/voice.md` section 6 in front of it, and nothing about the other groups. Concatenate the parts into `events.json`. A record marked `carried` whose fresh date, start time, location and `description_text` all match last week's row (`source_description`) may keep last week's Description, Format and Categories verbatim; anything else is written fresh from the record.

**One rule for the whole sheet: every required cell holds either the value from the event's own page or one of the four resolved-unknown values below. Never a guess, and never a silent blank.** A blank is a defect the script marks red; a resolved unknown is a fact.

| Event Type | Required |
|---|---|
| In-person, Hybrid | Everything below, including Location and Google Maps |
| Online | Everything below except Location and Google Maps |

Required on every row: Event Name, Date, Start Time, Registration Link, Event Type, Access, City / Neighborhood, Format, Host Organization(s), Description, Categories. Additionally when there is a venue: Location, and Google Maps (derived by the script from Location; never build it by hand; where no map can exist, for an online event or a withheld address, the script writes an n/a value so the cell is never blank). End Time does not block the sheet, but an empty End Time cell ships red like every other blank, so record the published end time whenever the page gives one.

When the organizer published nothing, record that as a value rather than leaving the cell empty:

| Situation | What goes in the cell |
|---|---|
| The page states no price anywhere | `Access` = **Not stated** |
| Address released after registration | `Location` = **Shared after registration** |
| Venue not announced yet | `Location` = **To be announced** |
| Runs all day, no start time published | `Start Time` = **All day** |

"Not stated" records that the page was read and no price was found. Never write `Free` because a page did not mention money. When the address is withheld, Location and Google Maps are both satisfied and the script stops asking.

`build_sheet.py` writes a `Missing Info` column naming every empty cell and shades each one red -- **every blank cell in the sheet ships red, no exceptions**. Empty required fields also make the sheet not ready: open the event page for each flagged row, read the value, and re-run. An empty End Time is the one red that does not block, because many organizers never publish one; the run report names each. **The lead should receive a sheet where the only red cells are End Times no organizer published, each named in the report.** If any other field is unavailable on the event's own page, say which row, which field, and what the page showed, and use the resolved-unknown value where one applies.

## Output: the events sheet

Fourteen columns in this order with these exact headers, then `Block` and `Source`, then `Missing Info`:

| # | Column | Contents |
|---|---|---|
| 1 | `Event Name` | As the organizer wrote it, with one exception: strip status tags such as "(Sold Out)", "SOLD OUT", "(Waitlist)" or "(Registration Closed)" from the name. Status is a fact for the `Description` ("this date is sold out"), never part of the name a reader scans. Do not shorten or editorialize otherwise; the build script flags any name still carrying a status tag |
| 2 | `Date` | `YYYY-MM-DD` |
| 3 | `Start Time (TZ)` | `HH:MM`, 24-hour. The city's timezone in the header: `(PDT)`, `(EDT)`, `(BST)` |
| 4 | `End Time (TZ)` | Same format. Blank only when the page publishes none, and the blank ships red |
| 5 | `Registration Link` | Where people register. Never a homepage, never a listing page |
| 6 | `Event Type` | `In-person` / `Hybrid` / `Online` |
| 7 | `Access` | `Free` / `Free — register to view address` / `Ticketed (Paid)` / `Ticketed (Paid) — register to view address` / `Not stated` |
| 8 | `Location` | Full street address as published. `Online` for online events |
| 9 | `City / Neighborhood` | The scannable geography: `Brooklyn`, `Cambridge`, `Vancouver, BC` |
| 10 | `Google Maps` | Derived by the script from Location |
| 11 | `Format` | Comma-separated, from the list below |
| 12 | `Host Organization(s)` | Comma-separated. Include named individuals when the page credits them |
| 13 | `Description` | From the event's own page, see below |
| 14 | `Categories` | One to three from the controlled list, comma-separated |
| 15 | `Block` | `this_week` / `upcoming` |
| 16 | `Source` | `registry` / `submitted` / `lead` |

The `Access` values are matched literally by the script, punctuation included. Reproduce them exactly.

**Write the sheet with the bundled script**, never by hand, so the columns come out identical every week and `ctc-assemble` can read them by name:

```
mkdir -p /mnt/user-data/outputs
python3 scripts/build_sheet.py events.json /mnt/user-data/outputs/CTC_Events_<City>_<send date>.xlsx --tz EDT --block
```

**The file goes to `/mnt/user-data/outputs/` under that exact name**, with the send date as `YYYY-MM-DD`. If the turn ends without it there, the task is not done. The name is also how `ctc-assemble` confirms which sheet is current after the lead's cut. Copy `events.json` there too, as `CTC_Events_<City>_<send date>.json`: it is the companion file next week's planner reads with `--previous`. Mention it once at delivery, in plain words, as optional.

`events.json` is a list of objects keyed by the column names, using `Start Time` and `End Time` without the timezone suffix, plus `Block` and `Source`. **Each row also carries two things the sheet does not print: its `page_checks` object, copied verbatim from its `events_raw.json` record (the build script reads it and warns on any row without one), and `source_description`, the description text the page gave, which is what next week's carry-forward compares against.** The build script ignores any other key. Two timezone arguments appear in this skill: `plan_candidates.py --tz` takes the IANA zone from section 1 of the settings file (`America/New_York`); `build_sheet.py --tz` takes the abbreviation for the column header (`EDT`). `--block` is the newsletter mode and adds both columns. The script warns rather than refusing; a warning is a prompt for the editor, not a reason to withhold the file.

### Descriptions

**From the event's own page, two to three sentences, 40 to 70 words, in the shape `../ctc-assemble/references/voice.md` section 6 "This Week in Detail descriptions" sets.** That section is the only statement of the shape; do not restate it here or anywhere else.

Every this-week event's description is printed in the issue, one entry each, so this column is read by subscribers, not just by the lead. Condense and tidy the page's own wording; do not rewrite from scratch and do not embellish. If the page gives fewer than 40 words of fact, a shorter description is the correct output; never pad toward the range and never invent a speaker, venue, or price the page did not give.

### Categories

Controlled vocabulary, one to three per event:

`Adaptation` · `AI & Data` · `Arts & Culture` · `Biodiversity & Nature` · `Buildings` · `Circular Economy & Waste Management` · `Cities` · `Climate Tech & Startups` · `Communications` · `Corporate Sustainability` · `Energy` · `Environmental Justice` · `Finance` · `Food & Agriculture` · `Fun for Kids` · `Get Outside` · `Health` · `Mobility & Logistics` · `Philanthropy` · `Policy` · `Social` · `Water`

Do not invent a category. If nothing fits, use the closest and flag it in the run report. The same 22 are the choices on the submission form.

### Format

Freer than Categories, but stay consistent within a run:

`Panel Session` · `Happy Hour` · `Workshop` · `Networking` · `Community Event` · `Tour` · `Field Trip` · `Outdoors` · `Volunteer` · `Talk` · `Social` · `Meetup` · `Conference` · `Fair` · `Q&A` · `Presentation` · `Webinar` · `Screening` · `Exhibition` · `Site Tour` · `Fireside Chat` · `Dinner` · `Hackathon` · `Info Session`

## Dedupe

The same event appears on several calendars under slightly different names, and now also through the submission form. `plan_candidates.py` has already merged the exact URL duplicates and flagged same-day name overlaps as `probable_duplicate_of`; this step settles those flags and catches anything else. Match on `Date` plus fuzzy `Event Name`, then confirm by venue. Two names are the same event when one contains the other, or when they agree after stripping the host name, the city name, edition numbers, and punctuation.

| Situation | Ruling |
|---|---|
| Same event, two calendars, different registration links | Merge. Keep the organizer's own link |
| One listing has a full description, the other a better link | Merge, taking the best value per field |
| Same event from a registry source and the submission form | Merge. Keep `Source = submitted`, prefer the submitter's description, keep the organizer's link |
| Same series, different dates | Two rows in the sheet. The issue prints only the earliest (see `ctc-assemble`, Upcoming Events); later dates surface in later issues as earlier ones pass |
| In-person and online tickets listed separately | One row, `Event Type` = `Hybrid` |
| Two calendars credit different co-hosts | Merge, and merge the host list |
| Same title, same day, different venues across the metro | Two rows, and flag it |
| Uncertain whether two rows are one event | Keep both, surface the collision in the report |

Merging destroys information and duplicating does not. When unsure, duplicate and report.

## Verify before handing over

Run `references/verifier.md` on the built sheet: a fresh, adversarial pass that re-fetches every registration link (upcoming rows included) and compares the sheet against what the page says now, opens a page in the tab wherever the data cannot settle it, checks each row against the scope rule and the window boundary, reads every description against voice.md, and confirms no submitted row was dropped. That file says how to run it as a subagent where the session has one, how to split it across several, and how to run it as a separate step where there is no subagent tool. Fix `events.json`, re-run `build_sheet.py`, and only then write the run report. The verifier's findings are part of the report.

## Run report

After writing the sheet, in chat:

- Events found, split by block, and how many came through the submission form
- Sources swept out of sources registered, and which path each needed (structured batch, plain fetch, browser read, paste)
- Candidates found, pages opened, duplicates merged by URL before opening, and candidates dropped as outside the window, from the planner's summary
- Sources that returned nothing, by name, and sources that failed, by name and cause, reported separately
- Duplicates merged, and collisions left for the lead
- Rows with missing required fields, by column, and why
- Anything that could not be categorized
- Any submitted row where the form and the event page disagreed

## Sanity check

Compare the count against the city's normal before handing over. A launch chapter's first issues carry 3 to 8 events this week and 5 to 15 upcoming; New York in 2026 carries 15 to 25 and 25 to 40. These are diagnostic ranges, not targets. A sweep returning three events in a city that normally yields twenty means a source broke. Never add a marginal event to reach a number; a quiet August is a real result.

## Failure modes

**Times off by the UTC offset.** Luma's `start_at` is UTC. Convert to the city's timezone before writing the sheet. Check one event against its own page before trusting the batch.

**Out-of-town events shipped.** Multi-city organizations put every city on one calendar. Filter on the event's own location against the scope rule, not the calendar's name. The same applies to the submission form: a submitter can pick the wrong city.

**A city discovery page treated as a source.** `luma.com/{city}` is a general local feed and a discovery aid for `ctc-source-map`, never an auto-pull here.

**Syndicated training spam.** Generic "ESG & Sustainability Strategy: 1 Day Training" listings republished across dozens of cities by resellers. If the same title appears in three cities, it is a reseller.

**A term-time calendar declared dead.** University sources empty out in July and August and in late December. A zero return in August from a source that was weekly in April is a season.

**A submitted event trusted without opening its page.** The form is an intake, not a verification. Every submitted link gets opened like any other.

**Shipping the sheet without the report.** The counts, the failures, and the zero-return sources are how the lead knows whether to trust the file.

**Two agents in the browser.** Faster for a minute, then a CAPTCHA, then no harvest. Every browser call runs from one agent in one tab, paced. Parallel work is for plain fetches and for writing rows.

**A batch that came back half-empty.** The extension's time limit was hit or the page body was replaced before the read. Probe with `__PROBE()`: `LOST` means re-inject the helpers in a fresh tab and re-run that batch, smaller. Never fill the gap from the listing.
