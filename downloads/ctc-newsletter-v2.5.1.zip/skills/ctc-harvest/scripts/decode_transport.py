#!/usr/bin/env python3
"""
decode_transport.py -- turn the page text read after a harvest_helpers.js call
back into JSON.

The helpers write their result as µ-encoded text (the javascript_tool return
channel strips long alphanumeric runs, query strings and base64, which is the
shape of URLs and JSON). Read each chunk with get_page_text, save it to a file,
then:

    python3 scripts/decode_transport.py chunk0.txt chunk1.txt ... -o records.json

Chunks are concatenated in the order given, so pass them in __SHOW order. The
output is a JSON list of the records the helper produced (one per calendar,
organizer or event). A record that could not be parsed is kept as
{"idx": n, "parse_error": "...", "text": "..."} rather than dropped, so a
transport fault is visible instead of silently losing an event.

Encoding (must match harvest_helpers.js):
  µ -> µMµ (first)   ?  -> µQµ      &  -> µAµ      =  -> µEµ      NBSP -> µNµ
  'µµ' inserted after every 10 alphanumerics
  records separated by '\n<<CTC-REC>>\n', each prefixed '<<CTC-IDX n>>'
"""
import json
import re
import sys

WRAP_RE = re.compile(r"^\s*<<CTC-HARVEST chunk \d+ of \d+>>\n?|\n?<<END>>\s*$", re.S)


def strip_wrapper(s: str) -> str:
    # Anchored to the edges of a chunk, so the markers cannot be mistaken for
    # event text in the middle of one.
    return WRAP_RE.sub("", s)


TOKENS = {"Q": "?", "A": "&", "E": "=", "N": "\u00a0", "M": "\x00"}


def decode_blob(s: str) -> str:
    if s is None:
        return ""
    # Tokens first, in one left-to-right pass, so a run-breaker next to a token
    # ('µµµQµ') cannot be mis-split. A raw µ comes back last, via a sentinel,
    # so it is not stripped as a stray.
    s = re.sub(r"µ([QAENM])µ", lambda m: TOKENS[m.group(1)], s)
    s = s.replace("µµ", "")
    s = s.replace("µ", "")
    return s.replace("\x00", "µ")


def split_records(decoded: str):
    out = []
    for ch in re.split(r"\n<<CTC-REC>>\n", decoded):
        ch = ch.strip()
        if not ch:
            continue
        m = re.match(r"<<CTC-IDX (\d+)>>\s*(.*)", ch, re.S)
        idx, text = (int(m.group(1)), m.group(2).strip()) if m else (None, ch)
        try:
            rec = json.loads(text)
            if isinstance(rec, dict):
                rec.setdefault("idx", idx)
            out.append(rec)
        except json.JSONDecodeError as e:
            out.append({"idx": idx, "parse_error": str(e), "text": text[:400]})
    return out


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("chunks", nargs="*", help="chunk text files in __SHOW order (stdin if none)")
    ap.add_argument("-o", "--out", help="write the JSON list here instead of stdout")
    args = ap.parse_args()
    if not args.chunks:
        raw = sys.stdin.read()
    else:
        parts = []
        for p in args.chunks:
            with open(p, encoding="utf-8") as fh:
                parts.append(strip_wrapper(fh.read()))
        raw = "".join(parts)
    records = split_records(decode_blob(strip_wrapper(raw)))
    bad = [r for r in records if isinstance(r, dict) and "parse_error" in r]
    out = open(args.out, "w", encoding="utf-8") if args.out else sys.stdout
    json.dump(records, out, ensure_ascii=False, indent=2)
    print(file=out)
    if args.out:
        out.close()
        print(f"{len(records)} record(s) -> {args.out}", file=sys.stderr)
    if bad:
        print(f"{len(bad)} record(s) failed to parse; re-read those chunks "
              f"(a chunk boundary mid-record means two chunks were passed out of order "
              f"or one is missing).", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
