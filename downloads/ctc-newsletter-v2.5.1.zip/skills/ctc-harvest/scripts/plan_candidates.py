#!/usr/bin/env python3
"""
plan_candidates.py -- decide which event pages to open, before opening any.

Input: candidates.json, a list of everything the enumeration pass found, one
object per listing-level hit:

  {"name": "...", "url": "https://luma.com/abc", "start": "2026-10-07T00:30:00Z",
   "source": "Climate SF (Luma)", "platform": "luma", "origin": "registry"}

`start` may be an ISO timestamp (UTC or with offset), a bare YYYY-MM-DD, or
missing. `origin` is registry / submitted / lead (default registry).

What it does, in order:
  1. Puts every candidate in a window (this_week / upcoming / out) from its
     listing date, converted to the city's timezone. A candidate with no date
     is kept: never drop an event because the listing did not say when it is.
     Submitted and lead rows are never dropped here either, even if the date
     looks out of window; the extractor and the lead decide.
  2. Collapses exact duplicates by canonical URL (host lowercased, www and
     query and fragment stripped, lu.ma -> luma.com, eventbrite country
     domains folded). The merged record keeps every source name, and keeps
     origin = submitted if any copy was submitted.
  3. Flags probable duplicates (same local date and one name contains the
     other after stripping punctuation) so the extractor pulls both and the
     merge is decided on venue, per the dedupe table in SKILL.md.
  4. With --previous (last week's companion file, CTC_Events_<City>_<date>.json,
     written next to last week's sheet), marks candidates whose URL was fully
     harvested last week as `carried` and attaches `previous_row` (last week's
     Date, Start Time, Location, source_description, Description, Format,
     Categories). They are still re-fetched; the row-writer may reuse the prose
     only when all four facts come back unchanged from the fresh page.

Output: plan.json with to_extract, dropped (out of window, with the date that
put them there), merged, probable_duplicates and counts; a summary on stdout.

    python3 scripts/plan_candidates.py candidates.json plan.json \
        --send-date 2026-10-06 --tz America/New_York [--cadence biweekly] \
        [--previous last_week_events.json]
"""
import argparse
import json
import re
import sys
from datetime import date, datetime, timedelta
from urllib.parse import urlsplit, urlunsplit
from zoneinfo import ZoneInfo


def canonical(url: str) -> str:
    if not url:
        return ""
    u = url.strip()
    if not re.match(r"^https?://", u, re.I):
        u = "https://" + u
    p = urlsplit(u)
    host = p.netloc.lower()
    host = re.sub(r"^www\.", "", host)
    if host in ("lu.ma",):
        host = "luma.com"
    host = re.sub(r"^eventbrite\.[a-z.]+$", "eventbrite.com", host)
    path = re.sub(r"/+$", "", p.path) or "/"
    # Eventbrite event URLs carry a numeric id at the end; that id is the identity.
    m = re.search(r"-(\d{6,})$", path)
    if host == "eventbrite.com" and m:
        path = "/e/" + m.group(1)
    return urlunsplit(("https", host, path, "", ""))


def local_date(start, tz):
    if not start:
        return None
    s = str(start).strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return date.fromisoformat(s)
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        # A naive timestamp from a listing is assumed to be local already.
        return dt.date()
    return dt.astimezone(tz).date()


def norm_name(n: str) -> str:
    n = (n or "").lower()
    n = re.sub(r"\(.*?\)|\[.*?\]", " ", n)
    n = re.sub(r"[^a-z0-9 ]+", " ", n)
    n = re.sub(r"\b(the|a|an|and|of|in|at|with|for|to)\b", " ", n)
    return re.sub(r"\s+", " ", n).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("candidates_json")
    ap.add_argument("plan_json")
    ap.add_argument("--send-date", required=True, help="YYYY-MM-DD")
    ap.add_argument("--tz", required=True, help="IANA zone, e.g. America/New_York")
    ap.add_argument("--cadence", default="weekly", choices=["weekly", "biweekly"])
    ap.add_argument("--previous", help="last week's events.json, for carry-forward")
    args = ap.parse_args()

    tz = ZoneInfo(args.tz)
    send = date.fromisoformat(args.send_date)
    week = 7 if args.cadence == "weekly" else 14
    this_end = send + timedelta(days=week - 1)          # inclusive
    up_end = send + timedelta(days=(28 if week == 7 else 42) - 1)

    with open(args.candidates_json) as fh:
        cands = json.load(fh)

    previous = {}
    if args.previous:
        with open(args.previous) as fh:
            for r in json.load(fh):
                previous[canonical(r.get("Registration Link", ""))] = r

    by_url = {}
    dropped = []
    for c in cands:
        c = dict(c)
        c.setdefault("origin", "registry")
        key = canonical(c.get("url", ""))
        d = local_date(c.get("start"), tz)
        c["listing_date"] = d.isoformat() if d else None
        if d is None:
            block = "unknown"
        elif send <= d <= this_end:
            block = "this_week"
        elif this_end < d <= up_end:
            block = "upcoming"
        else:
            block = "out"
        c["block_hint"] = block
        protected = c["origin"] in ("submitted", "lead")
        if block == "out" and not protected:
            dropped.append(c)
            continue
        if not key:
            # No URL at all: keep it, the extractor will have to find the page.
            key = "nourl:" + norm_name(c.get("name")) + ":" + (c["listing_date"] or "")
        if key in by_url:
            m = by_url[key]
            m["sources"] = sorted(set(m["sources"] + [c.get("source", "")]))
            if c["origin"] == "submitted":
                m["origin"] = "submitted"
            elif c["origin"] == "lead" and m["origin"] != "submitted":
                m["origin"] = "lead"
            if not m.get("start") and c.get("start"):
                m["start"], m["listing_date"], m["block_hint"] = c["start"], c["listing_date"], block
            m.setdefault("submitted_description", None)
            if c.get("submitted_description"):
                m["submitted_description"] = c["submitted_description"]
            m["merged_from"].append(c)
        else:
            c["canonical_url"] = key
            c["sources"] = [c.get("source", "")]
            c["merged_from"] = []
            c["carried"] = key in previous
            if c["carried"]:
                pr = previous[key]
                c["previous_row"] = {k: pr.get(k, "") for k in (
                    "Date", "Start Time", "Location", "source_description",
                    "Description", "Format", "Categories")}
            by_url[key] = c

    plan = list(by_url.values())

    # Probable duplicates across different URLs: same date, one name inside the other.
    probable = []
    for i in range(len(plan)):
        for j in range(i + 1, len(plan)):
            a, b = plan[i], plan[j]
            if not a["listing_date"] or a["listing_date"] != b["listing_date"]:
                continue
            na, nb = norm_name(a.get("name")), norm_name(b.get("name"))
            if na and nb and (na in nb or nb in na):
                probable.append({"a": a["canonical_url"], "b": b["canonical_url"],
                                 "date": a["listing_date"], "names": [a.get("name"), b.get("name")]})
                a["probable_duplicate_of"] = b["canonical_url"]
                b["probable_duplicate_of"] = a["canonical_url"]

    merged = [p for p in plan if p["merged_from"]]
    out = {
        "send_date": send.isoformat(), "tz": args.tz, "cadence": args.cadence,
        "windows": {"this_week": [send.isoformat(), this_end.isoformat()],
                    "upcoming": [(this_end + timedelta(days=1)).isoformat(), up_end.isoformat()]},
        "counts": {
            "candidates": len(cands), "to_extract": len(plan),
            "this_week": sum(p["block_hint"] == "this_week" for p in plan),
            "upcoming": sum(p["block_hint"] == "upcoming" for p in plan),
            "no_listing_date": sum(p["block_hint"] == "unknown" for p in plan),
            "protected_out_of_window": sum(p["block_hint"] == "out" for p in plan),
            "dropped_out_of_window": len(dropped),
            "merged_by_url": len(merged), "probable_duplicates": len(probable),
            "carried_from_previous": sum(p.get("carried", False) for p in plan),
        },
        "to_extract": plan, "dropped": dropped,
        "merged": [{"url": m["canonical_url"], "sources": m["sources"]} for m in merged],
        "probable_duplicates": probable,
    }
    with open(args.plan_json, "w") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)

    c = out["counts"]
    print(f"{c['candidates']} candidates -> {c['to_extract']} pages to open "
          f"({c['this_week']} this week, {c['upcoming']} upcoming, "
          f"{c['no_listing_date']} with no listing date, kept)")
    print(f"dropped {c['dropped_out_of_window']} outside the window; "
          f"{c['protected_out_of_window']} submitted/lead rows outside the window kept for the lead")
    print(f"merged {c['merged_by_url']} by URL; {c['probable_duplicates']} probable duplicate pair(s) "
          f"flagged for a venue check after extraction")
    if args.previous:
        print(f"{c['carried_from_previous']} were in last week's sheet (re-fetched; prose reusable if unchanged)")
    if c["no_listing_date"] > c["to_extract"] * 0.5 and c["to_extract"] > 5:
        print("WARNING: most candidates have no listing date. That usually means a "
              "source was read from page text rather than its structured list; "
              "check the enumeration before extracting.", file=sys.stderr)


if __name__ == "__main__":
    main()
