/*
 * harvest_helpers.js -- browser-side helpers for ctc-harvest.
 *
 * Inject the whole file ONCE per tab with the Claude in Chrome `javascript_tool`
 * (the tab must be on the platform's own origin: a luma.com page for Luma, an
 * eventbrite.com page for Eventbrite). It defines helpers on `window` and returns
 * "helpers ready". Then call the helpers one at a time:
 *
 *   await __ENUM_LUMA(["climate-sf", "cleantech-open"])     // calendars -> candidates
 *   await __PULL_LUMA(["grid-101-abc", "repair-cafe-xyz"])  // event slugs -> full detail
 *   await __ENUM_EB(["https://www.eventbrite.com/o/x-123"]) // organizers -> candidates
 *   await __PULL_EB(["https://www.eventbrite.com/e/..."])   // event URLs -> full detail
 *   __EXTRACT_CURRENT()                                     // whatever page the tab is on
 *   __SHOW(0), __SHOW(1), ...                               // read results in chunks
 *
 * Every helper stores its result with __STORE, which splits it into chunks small
 * enough for `get_page_text` and REPLACES the page body with the first chunk, so
 * the page text IS the data. Read chunk i with __SHOW(i) then get_page_text,
 * then decode with scripts/decode_transport.py. The javascript_tool return value
 * is deliberately tiny ("OK chunks=3"): its return channel is capped at about 1KB
 * and strips long alphanumeric runs, query strings and base64, which is exactly
 * the shape of URLs and JSON.
 *
 * Pacing: every helper fetches sequentially with a short pause between
 * requests. Do not shorten PAUSE_MS and do not run helpers from two tabs; a
 * burst is how a harvest ends at a CAPTCHA. Ten events per __PULL_* call is
 * the default and keeps every call under the extension's ~45s limit; fifteen
 * is the most that is safe, and only for __ENUM_EB, whose first path is one
 * small JSON request per organizer.
 *
 * Same-origin only. A luma.com tab cannot fetch eventbrite.com and vice versa
 * (CORS). Eventbrite country domains (.ca, .co.uk) are separate origins too:
 * navigate once per domain and re-inject. Navigating a tab discards the
 * helpers: re-inject after every navigate, and __PROBE() says whether they
 * are still there.
 *
 * Verified live on 1 Oct 2026 against luma.com (vanity-slug calendars,
 * /calendar/cal-... calendars, event pages) and www.eventbrite.com (organizer
 * pages, event pages). Field names below are what those pages served then.
 */
(function () {
  var PAUSE_MS = 700;      // between requests inside one helper call
  var CHUNK = 28000;       // characters per __SHOW chunk; get_page_text truncates ~35KB

  // ---------------- transport (mirror of decode_transport.py) ----------------
  // Input is always JSON.stringify output, which never contains a raw newline,
  // so only the characters the return filter dislikes are encoded. A raw µ in
  // content is escaped first so nothing in the data can be mistaken for a
  // token. Non-breaking spaces are encoded too: get_page_text normalizes them
  // to plain spaces (seen live), and a silent change inside a URL would be a
  // wrong link.
  function enc(s) {
    if (s == null) return "";
    s = String(s)
      .split("µ").join("µMµ")
      .split("?").join("µQµ")
      .split("&").join("µAµ")
      .split("=").join("µEµ")
      .split("\u00a0").join("µNµ");
    return s.replace(/([A-Za-z0-9]{10})/g, "$1µµ");
  }
  // Record framing uses angle-bracket markers that JSON.stringify never
  // produces from a string (it does not escape < or >, but no event text
  // contains these exact markers) and the encoder never emits.
  function pack(records) {
    window.__LAST = records;   // raw copy, for a quick probe before decoding
    return records.map(function (r, i) {
      return "<<CTC-IDX " + i + ">>\n" + enc(JSON.stringify(r));
    }).join("\n<<CTC-REC>>\n");
  }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  window.__CHUNKS = [];
  window.__STORE = function (payload) {
    var chunks = [];
    for (var i = 0; i < payload.length; i += CHUNK) chunks.push(payload.slice(i, i + CHUNK));
    if (!chunks.length) chunks.push("");
    window.__CHUNKS = chunks;
    return window.__SHOW(0) + " chunks=" + chunks.length;
  };
  window.__SHOW = function (i) {
    var pre = document.createElement("pre");
    pre.id = "__CTXT";
    pre.style.whiteSpace = "pre-wrap";
    pre.textContent = "<<CTC-HARVEST chunk " + i + " of " + window.__CHUNKS.length + ">>\n"
      + (window.__CHUNKS[i] || "") + "\n<<END>>";
    // The page body becomes the data, so get_page_text returns nothing else.
    document.body.replaceChildren(pre);
    return "OK chunk=" + i;
  };
  window.__PROBE = function () {
    return typeof window.__PULL_LUMA === "function" ? "READY" : "LOST";
  };

  // ---------------- generic page extraction (JSON-LD, meta, body) ----------------
  function parseLD(doc) {
    var out = {};
    var nodes = doc.querySelectorAll('script[type="application/ld+json"]');
    for (var i = 0; i < nodes.length; i++) {
      try {
        var d = JSON.parse(nodes[i].textContent);
        var arr = Array.isArray(d) ? d : (d["@graph"] ? d["@graph"] : [d]);
        arr.forEach(function (o) {
          var t = String(o["@type"] || "");
          if (!/Event/i.test(t) && !o.startDate) return;
          out.ld_type = t;
          if (!out.name && o.name) out.name = o.name;
          if (!out.start && o.startDate) out.start = o.startDate;
          if (!out.end && o.endDate) out.end = o.endDate;
          if (!out.description && o.description) out.description = o.description;
          if (!out.url && o.url) out.url = o.url;
          if (!out.status && o.eventStatus) out.status = o.eventStatus;
          if (!out.attendance && o.eventAttendanceMode) out.attendance = o.eventAttendanceMode;
          if (!out.location && o.location) {
            var L = Array.isArray(o.location) ? o.location[0] : o.location;
            if (typeof L === "string") out.location = L;
            else {
              var a = L.address;
              var addr = !a ? "" : (typeof a === "string" ? a
                : [a.streetAddress, a.addressLocality, a.addressRegion, a.postalCode].filter(Boolean).join(", "));
              out.location = [L.name, addr].filter(Boolean).join(", ");
              if (/VirtualLocation/i.test(String(L["@type"] || ""))) out.location = out.location || "Online";
            }
          }
          if (!out.host && o.organizer) {
            var O = Array.isArray(o.organizer) ? o.organizer : [o.organizer];
            out.host = O.map(function (x) { return typeof x === "string" ? x : x.name; }).filter(Boolean).join(", ");
          }
          if (!out.offers && o.offers) {
            var F = Array.isArray(o.offers) ? o.offers : [o.offers];
            out.offers = F.map(function (f) {
              return { price: f.price, currency: f.priceCurrency, lowPrice: f.lowPrice, highPrice: f.highPrice, availability: f.availability };
            });
          }
        });
      } catch (e) {}
    }
    return out;
  }
  function meta(doc, sel) { var m = doc.querySelector(sel); return m ? (m.content || "") : ""; }
  function extractDoc(doc, url) {
    var ld = parseLD(doc);
    // Only phrases that mean the event itself is over. "Sold out" is a fact
    // for the Description, not a reason to drop; "deadline has passed" is
    // not about the event.
    var passed = /this event has (ended|passed|already (taken place|happened))|event has ended|this event is over|registration for this event is closed because it has/i
      .test(doc.body ? doc.body.innerText.slice(0, 20000) : "");
    var desc = ld.description || "";
    if (!desc) {
      var sels = [".event-description__content", ".has-user-generated-content",
                  '[data-testid="richTextViewer"]', "[class*=description]"];
      for (var i = 0; i < sels.length; i++) {
        var el = doc.querySelector(sels[i]);
        if (el && el.innerText && el.innerText.trim()) { desc = el.innerText.trim(); break; }
      }
    }
    if (!desc) desc = meta(doc, 'meta[property="og:description"]') || meta(doc, 'meta[name="description"]');
    return {
      landed_url: url,
      title: (doc.querySelector("title") || {}).textContent || "",
      name: ld.name || meta(doc, 'meta[property="og:title"]') || "",
      start: ld.start || meta(doc, 'meta[property="event:start_time"]') || "",
      end: ld.end || meta(doc, 'meta[property="event:end_time"]') || "",
      location: ld.location || "",
      host: ld.host || "",
      offers: ld.offers || null,
      status: ld.status || "",
      attendance: ld.attendance || "",
      description: desc.slice(0, 2500),
      page_says_passed: passed,
      source_of_truth: ld.start ? "json-ld" : "page-text"
    };
  }
  window.__EXTRACT_CURRENT = function () {
    return window.__STORE(pack([extractDoc(document, location.href)]));
  };

  // ---------------- Luma ----------------
  // Luma's payload sits at pageProps.initialData.data on vanity-slug pages and
  // directly at pageProps.initialData on /calendar/cal-... pages (seen live,
  // Oct 2026). Accept both.
  function nextData(html) {
    var m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
    if (!m) return null;
    try {
      var id = JSON.parse(m[1]).props.pageProps.initialData;
      if (!id) return null;
      return (id.data && (id.data.event || id.data.featured_items || id.data.calendar)) ? id.data : id;
    } catch (e) { return null; }
  }
  // description_mirror is a ProseMirror document; the plain `description`
  // field is usually empty. Flatten to text with a line break per block.
  function flattenMirror(n) {
    if (!n) return "";
    if (n.type === "text") return n.text || "";
    var inner = (n.content || []).map(flattenMirror).join("");
    return /paragraph|heading|list_item|listItem|blockquote|horizontal_rule/.test(n.type || "") ? inner + "\n" : inner;
  }
  function lumaAddress(g) {
    if (!g) return "";
    if (g.full_address) return g.full_address;
    return [g.address, g.city, g.region].filter(Boolean).join(", ");
  }
  function lumaCalendarItems(d) {
    // Union featured_items and upcoming.entries; the same api_id appears in
    // both, so key on it. `upcoming.has_more` means the calendar lists more
    // than one page; report it so the sweep knows to open the page itself.
    var seen = {}, out = [];
    var lists = [d.featured_items || [], (d.upcoming && d.upcoming.entries) || []];
    lists.forEach(function (list) {
      list.forEach(function (x) {
        var e = x.event || x;
        if (!e || !e.api_id || seen[e.api_id]) return;
        seen[e.api_id] = 1;
        out.push({
          name: e.name, slug: e.url, api_id: e.api_id,
          start: e.start_at, end: e.end_at, timezone: e.timezone,
          city: e.geo_address_info && (e.geo_address_info.city_state || e.geo_address_info.city),
          address: lumaAddress(e.geo_address_info),
          location_type: e.location_type
        });
      });
    });
    return out;
  }
  window.__ENUM_LUMA = async function (calSlugs) {
    var out = [];
    for (var i = 0; i < calSlugs.length; i++) {
      // Keep the whole path: calendars live at luma.com/<slug> and also at
      // luma.com/calendar/<cal-id> (a calendar with no vanity slug). A bare
      // cal-... id is sent to the second form.
      var slug = String(calSlugs[i]).replace(/^https?:\/\/(www\.)?(lu\.ma|luma\.com)\//, "").replace(/[?#].*$/, "").replace(/\/+$/, "");
      if (/^cal-[A-Za-z0-9]+$/.test(slug)) slug = "calendar/" + slug;
      var rec = { calendar: slug, ok: false, items: [] };
      try {
        var r = await fetch("/" + slug, { credentials: "include" });
        rec.http = r.status;
        rec.landed_url = r.url;
        var d = nextData(await r.text());
        if (d && (d.calendar || d.featured_items || d.upcoming)) {
          rec.ok = true;
          rec.calendar_name = d.calendar && d.calendar.name;
          rec.calendar_timezone = d.calendar && d.calendar.timezone;
          rec.items = lumaCalendarItems(d);
          rec.has_more = !!(d.upcoming && d.upcoming.has_more);
        }
      } catch (e) { rec.error = String(e); }
      out.push(rec);
      await sleep(PAUSE_MS);
    }
    return window.__STORE(pack(out));
  };
  window.__PULL_LUMA = async function (eventSlugs) {
    var out = [];
    for (var i = 0; i < eventSlugs.length; i++) {
      var slug = String(eventSlugs[i]).replace(/^https?:\/\/(www\.)?(lu\.ma|luma\.com)\//, "").replace(/[?#].*$/, "");
      var rec = { slug: slug, landed_url: "https://luma.com/" + slug, ok: false };
      try {
        var r = await fetch("/" + slug, { credentials: "include" });
        rec.http = r.status;
        rec.landed_url = r.url || rec.landed_url;
        var html = await r.text();
        var d = nextData(html);
        if (d && d.event) {
          var e = d.event;
          rec.ok = true;
          rec.name = e.name;
          rec.start = e.start_at;  // UTC
          rec.end = e.end_at;      // UTC
          rec.timezone = e.timezone;
          rec.location = lumaAddress(e.geo_address_info);
          rec.venue_note = e.geo_address_info && e.geo_address_info.description || "";
          rec.city = e.geo_address_info && (e.geo_address_info.city_state || e.geo_address_info.city);
          rec.location_type = e.location_type;              // offline / zoom / online / ...
          rec.address_visibility = e.geo_address_visibility; // public / after-registration
          rec.hosts = (d.hosts || []).map(function (h) { return h.name; });
          rec.ticket_info = d.ticket_info || null;          // {is_free, price, is_sold_out, require_approval}
          rec.description_text = ((e.description || "") || flattenMirror(d.description_mirror)).trim().slice(0, 2500);
          rec.has_rich_description = !!d.description_mirror;
          rec.visibility = e.visibility;
          rec.cancelled = !!e.cancelled;
        } else {
          // Not a Luma-native page (redirect or external): fall back to generic.
          var doc = new DOMParser().parseFromString(html, "text/html");
          Object.assign(rec, extractDoc(doc, rec.landed_url));
          rec.ok = !!rec.start;
        }
      } catch (e) { rec.error = String(e); }
      out.push(rec);
      await sleep(PAUSE_MS);
    }
    return window.__STORE(pack(out));
  };

  // ---------------- Eventbrite ----------------
  // Eventbrite is a Next.js app (seen live, Oct 2026). Organizer pages carry
  // their upcoming list in __NEXT_DATA__ pageProps.upcomingEvents; event pages
  // carry everything in pageProps.context (basicInfo, structuredContent,
  // salesStatus, goodToKnow) and also publish full JSON-LD. The older
  // /org/<id>/showmore endpoint returns 403 and is not used.
  function ebNext(html) {
    var m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
    if (!m) return null;
    try { return JSON.parse(m[1]).props.pageProps; } catch (e) { return null; }
  }
  function ebVenue(v) {
    if (!v) return { name: "", address: "", city: "" };
    var a = v.address || {};
    var lines = a.localizedMultiLineAddressDisplay || a.localized_multi_line_address_display || [];
    var addr = lines.length ? lines.join(", ") : (a.localized_address_display || a.localizedAddressDisplay || "");
    return { name: v.name || "", address: addr, city: a.city || "", region: a.region || "" };
  }
  function stripHtml(h) { return String(h || "").replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>|<\/li>|<\/h\d>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&#39;|&rsquo;/g, "'").replace(/&quot;/g, '"').trim(); }
  window.__ENUM_EB = async function (orgUrls) {
    var out = [];
    for (var i = 0; i < orgUrls.length; i++) {
      var u = String(orgUrls[i]).replace(/[?#].*$/, "");
      var rec = { organizer: u, ok: false, items: [], path: "" };
      try {
        var r = await fetch(u, { credentials: "include" });
        rec.http = r.status;
        rec.landed_url = r.url || u;
        var html = await r.text();
        var pp = ebNext(html);
        if (pp && Array.isArray(pp.upcomingEvents)) {
          rec.path = "next-data";
          rec.organizer_name = pp.organizer && pp.organizer.name;
          rec.upcoming_total = pp.upcomingEventsTotal;
          rec.has_more = !!pp.hasMoreUpcoming;
          rec.list_failed = !!pp.upcomingEventsFailed;
          pp.upcomingEvents.forEach(function (e) {
            var v = ebVenue(e.primary_venue);
            rec.items.push({
              name: e.name, url: e.url,
              start: e.start_date && e.start_time ? e.start_date + "T" + e.start_time : (e.start_date || ""),
              end: e.end_time ? (e.end_date || e.start_date) + "T" + e.end_time : (e.end_date || ""),
              timezone: e.timezone,
              online: !!e.is_online_event, cancelled: !!e.is_cancelled,
              venue: v.name, address: v.address, city: v.city,
              series_id: e.series_id || null, sales_status: e.event_sales_status && (e.event_sales_status.sales_status || e.event_sales_status)
            });
          });
          rec.ok = !rec.list_failed;
          if (!rec.items.length && !rec.list_failed) rec.note = "organizer page loaded; zero upcoming events";
        } else {
          // Fallback: JSON-LD Event nodes or plain event links on the page.
          var doc = new DOMParser().parseFromString(html, "text/html");
          doc.querySelectorAll('script[type="application/ld+json"]').forEach(function (s) {
            try {
              var d = JSON.parse(s.textContent);
              var arr = Array.isArray(d) ? d : (d.itemListElement ? d.itemListElement.map(function (x) { return x.item || x; }) : [d]);
              arr.forEach(function (o) { if (o && o.startDate) rec.items.push({ name: o.name, url: o.url, start: o.startDate, end: o.endDate }); });
            } catch (e) {}
          });
          if (rec.items.length) { rec.ok = true; rec.path = "json-ld"; }
          else {
            var links = {}; doc.querySelectorAll('a[href*="/e/"]').forEach(function (a) { var h = (a.getAttribute("href") || "").split("?")[0]; if (/\/e\/.+-\d{6,}$/.test(h)) links[h] = (a.textContent || "").trim(); });
            Object.keys(links).forEach(function (h) { rec.items.push({ name: links[h], url: h.indexOf("http") === 0 ? h : "https://www.eventbrite.com" + h, start: "" }); });
            if (rec.items.length) { rec.ok = true; rec.path = "links-only"; rec.note = "no structured list; dates come from the event pages"; }
            else rec.note = "no event list found; open the organizer page in the tab and read it";
          }
        }
      } catch (e) { rec.error = String(e); }
      out.push(rec);
      await sleep(PAUSE_MS);
    }
    return window.__STORE(pack(out));
  };
  window.__PULL_EB = async function (eventUrls) {
    var out = [];
    for (var i = 0; i < eventUrls.length; i++) {
      var u = eventUrls[i];
      var rec = { requested_url: u, landed_url: u, ok: false };
      try {
        var r = await fetch(u, { credentials: "include" });
        rec.http = r.status;
        rec.landed_url = r.url || u;
        var html = await r.text();
        var doc = new DOMParser().parseFromString(html, "text/html");
        Object.assign(rec, extractDoc(doc, rec.landed_url));   // JSON-LD: name, start/end with offset, location, host, offers, status
        var pp = ebNext(html);
        var ctx = pp && pp.context;
        if (ctx && ctx.basicInfo) {
          var b = ctx.basicInfo;
          rec.source_of_truth = "next-data+json-ld";
          rec.name = b.name || rec.name;
          if (b.startDate) { rec.start_local = b.startDate.local; rec.start_utc = b.startDate.utc; rec.timezone = b.startDate.timezone; }
          if (b.endDate) { rec.end_local = b.endDate.local; rec.end_utc = b.endDate.utc; }
          rec.is_free = b.isFree;
          rec.online = b.isOnline;
          rec.event_status = b.status;                        // live / ended / canceled ...
          rec.sales_status = ctx.salesStatus && ctx.salesStatus.salesStatus;
          rec.is_series = !!b.isSeries;
          if (b.organizer) { rec.host = b.organizer.name || rec.host; rec.organizer_url = b.organizer.url; rec.organizer_id = b.organizer.id; }
          var v = ebVenue(b.venue);
          if (v.name || v.address) rec.location = [v.name, v.address].filter(Boolean).join(", ");
          rec.city = v.city; rec.region = v.region;
          var mods = (ctx.structuredContent && ctx.structuredContent.modules) || [];
          var text = mods.filter(function (m) { return m.type === "text" && m.text; }).map(function (m) { return stripHtml(m.text); }).join("\n").trim();
          if (text) rec.description = text.slice(0, 2500); else if (b.summary) rec.description = b.summary;
          var gk = ctx.goodToKnow && ctx.goodToKnow.highlights;
          if (gk) { rec.location_type = gk.locationType; rec.duration_minutes = gk.durationInMinutes; rec.door_time = gk.doorTime; }
          rec.page_says_passed = rec.page_says_passed || /ended|canceled|cancelled/i.test(String(b.status || "")) || /ended/i.test(String(rec.sales_status || ""));
        }
        rec.ok = !!(rec.start || rec.start_local);
      } catch (e) { rec.error = String(e); }
      out.push(rec);
      await sleep(PAUSE_MS);
    }
    return window.__STORE(pack(out));
  };

  // ---------------- generic same-origin batch (university CMS etc.) ----------------
  // Only for URLs on the SAME origin as the tab. Cross-origin fetches are blocked.
  window.__PULL_SAME_ORIGIN = async function (urls) {
    var out = [];
    for (var i = 0; i < urls.length; i++) {
      var u = urls[i];
      var rec = { requested_url: u, landed_url: u, ok: false };
      try {
        var r = await fetch(u, { credentials: "include" });
        rec.http = r.status;
        rec.landed_url = r.url || u;
        var doc = new DOMParser().parseFromString(await r.text(), "text/html");
        Object.assign(rec, extractDoc(doc, rec.landed_url));
        rec.ok = !!rec.start;
      } catch (e) { rec.error = String(e); }
      out.push(rec);
      await sleep(PAUSE_MS);
    }
    return window.__STORE(pack(out));
  };

  return "helpers ready";
})();
