# Platform notes

How to actually get event data off each platform. These techniques are the difference between a harvest that works and one that returns titles with no dates.

---

## Running the helpers

`scripts/harvest_helpers.js` is one file, injected once per tab with `javascript_tool`. It returns "helpers ready" and defines the functions below on `window`. Every helper writes its result into the page body as encoded text in chunks; the tool's own return value is kept to a few characters because the extension's return channel is capped at about 1KB and strips long alphanumeric runs, query strings and base64, which is exactly the shape of URLs and JSON.

Read a result like this, every time:

1. The helper returns `OK chunk=0 chunks=N`.
2. `get_page_text` on the tab. Save what comes back as `chunk0.txt`.
3. For each further chunk: `__SHOW(i)` then `get_page_text`, save as `chunk<i>.txt`.
4. `python3 scripts/decode_transport.py chunk0.txt chunk1.txt ... -o result.json`.

Chunks are about 28KB each, under the `get_page_text` limit. A decode error names the record it could not parse rather than dropping it; it means a chunk was missed, truncated or read out of order, so re-read the chunks in `__SHOW` order.

Before each batch, `__PROBE()`. `LOST` means the tab was navigated or timed out: open a fresh tab on the same origin and inject again. The extension times out at about 45 seconds per call, which is why batches are ten events (fifteen at most, and only for `__ENUM_EB`). A page that has been replaced by a result still holds the helpers; you can keep calling them in that tab, and the next call overwrites the body.

The helpers pause between requests. Do not shorten the pause and do not run helper calls from two agents or two tabs at once. A burst is how a sweep ends at a CAPTCHA, and a CAPTCHA is a hard stop.

---

## Luma

**Tier 1 (plain fetch) is not enough.** A calendar page returns event titles and slugs, but dates, times and addresses render client-side. You get a page full of empty bullets where the dates should be.

**The browser is the reliable path, and one tab covers every Luma calendar.** Luma embeds the full structured payload in a `__NEXT_DATA__` script tag, and any luma.com page can fetch any other luma.com page same-origin. So: navigate to one luma.com page (a registered calendar is fine), inject the helpers, and call:

- `__ENUM_LUMA(["calendar-slug-1", "cal-AbC123", "https://luma.com/other", ...])` with every registered Luma calendar, as a vanity slug, a bare `cal-...` id (a calendar with no vanity slug, which lives at `luma.com/calendar/cal-...`), or a full URL. One record per calendar: `ok`, `calendar_name`, `has_more`, and `items` (name, slug, `start` and `end` in UTC, `timezone`, city, address, `location_type`) read from the union of `featured_items` and `upcoming.entries`. A calendar with `ok: false` and an HTTP status is a failed source; a calendar with `ok: true` and zero items is an empty one. Report them differently. `has_more: true` means the calendar lists more than one page of upcoming events; open that calendar in the tab and scroll before trusting the count. `calendar_timezone` is often null; take the city's zone from the settings file.
- `__PULL_LUMA(["event-slug-1", ...])` with ten event slugs from the plan. One record per event: `start` and `end` (UTC), `timezone` (the event's own IANA zone), `location` (venue and street address) and `city`, `venue_note` (the organizer's parking or access note, if any), `location_type` (`offline`, `zoom`, `online`, ...), `address_visibility` (`public`, or shared after registration, which is the `Shared after registration` value for Location), `hosts`, `ticket_info` (`is_free`, `price`, `max_price`, `is_sold_out`, `require_approval`), `description_text` (flattened from the page's rich description; the plain description field is usually empty), `cancelled`, and `landed_url` after redirects. A slug that is no longer a Luma event comes back through the generic extractor with `source_of_truth` set to whatever it found. Verified live 1 Oct 2026: ten events in about 17 seconds.

**Watch for:**
- `start_at` is **UTC**. Convert to the city's timezone before writing the sheet, or every time will be wrong for every row. The record carries `timezone` to convert with.
- A calendar returning `featured_items` of length 0 is either empty or not yet launched. Both are worth reporting. An empty core source is a signal, not a non-event.
- Multi-city organizations put every city on one calendar. Greentown Labs lists Houston alongside Boston. **Filter on the event's `city` against the city's scope rule** or out-of-town events will ship. The listing-level city is enough to drop; confirm on the event record before keeping.
- `ticket_info.is_free: true` is `Free`; `is_free: false` with a price is `Ticketed (Paid)`; a `max_price` alongside `is_free: true` means a free tier exists with paid options, which is `Free` (say the paid option in the Description if it matters). `ticket_info` absent is `Access = Not stated`; never `Free` by default. `is_sold_out: true` is a Description fact, not a reason to drop.
- `location_type` of `zoom` or `online` with an empty `location` is an Online event; `address_visibility` other than `public` with an empty `location` is `Shared after registration`.
- Luma's city discovery page (`luma.com/{city}`) is *not* a climate source. On a Boston sample it returned 20 events of which 2 were climate-relevant; the rest were AI meetups and run clubs. Treat it as a discovery aid, never an auto-pull.

If the helpers cannot be injected (the extension refuses scripting on the site), fall back to the previous method: navigate to each calendar and read `__NEXT_DATA__` directly:

```js
const d = JSON.parse(document.getElementById('__NEXT_DATA__').textContent).props.pageProps.initialData.data;
(d.featured_items || []).map(x => { const e = x.event || x; return { name: e.name, start: e.start_at, slug: e.url, city: e.geo_address_info?.city_state }; });
```

Individual event pages use the same structure, with the payload at `data.event` and hosts at `data.hosts`.

---

## Eventbrite

Roughly half of all event links in a mature chapter, bigger than Luma, and less cooperative to a plain fetch. It is, however, fully structured once you are on an eventbrite.com tab.

**One tab covers every organizer and every event on the same domain.** Eventbrite is a Next.js app and both page types carry a `__NEXT_DATA__` payload (verified live 1 Oct 2026). Navigate to any eventbrite.com page, inject the helpers, and call:

- `__ENUM_EB(["https://www.eventbrite.com/o/org-name-12345678", ...])` with every registered organizer URL (the name part is optional; `/o/12345678` works too). Path `next-data` reads the organizer page's upcoming list: per event, name, URL, local `start` and `end` with `timezone`, `online`, `cancelled`, venue name, address and city, `series_id`, and `sales_status`; per organizer, `organizer_name`, `upcoming_total` and `has_more`. If `has_more` is true the page lists more than one screen of events: open the organizer page in the tab and scroll before trusting the count. The record says which path worked; `json-ld` and `links-only` are the fallbacks if the page shape changes, and `ok: false` with a note means open the page by eye. The old `/org/<id>/showmore` endpoint returns 403 and is not used.
- `__PULL_EB(["https://www.eventbrite.com/e/...", ...])` with ten event URLs. One record per event, `source_of_truth: next-data+json-ld`: `name`, `start_local` / `end_local` with `timezone` and `start_utc` / `end_utc`, `is_free`, `online`, `event_status` (`live`, `ended`, `canceled`), `sales_status` (`on_sale`, `sales_ended`, ...), `is_series`, `host` with `organizer_url` (the canonical organizer page, useful for the source list), `location` (venue and multi-line address joined), `city`, `region`, `location_type`, `duration_minutes`, `description` (the full structured description with HTML stripped; falls back to the summary), `offers` and `status` from JSON-LD, `page_says_passed`, and `landed_url`.

**Watch for:**
- Country domains vary. `.com`, `.ca`, `.co.uk`, `.sg` all appear. They are separate origins: group the URLs by domain, navigate once per domain, inject, and run that domain's batch. `plan_candidates.py` folds them to one canonical form for dedupe, but the fetch has to go to the real domain.
- Event URLs end in a numeric id. The id is the identity; the words before it change when an organizer renames an event, and the page redirects. `landed_url` is the link that ships.
- `is_free: true` is `Free`; `is_free: false` is `Ticketed (Paid)`; if neither is present, fall back to JSON-LD `offers` (lowPrice 0 is free), and with nothing at all write `Not stated`. An `online: true` event is `Event Type = Online`; a `location_type` of `online_with_venue` or JSON-LD `MixedEventAttendanceMode` is `Hybrid`.
- `event_status` other than `live`, or `sales_status` containing `ended`, or `page_says_passed: true` means the row does not ship as it stands. `cancelled: true` on a list item means the event page still exists but the event is off.
- Syndicated commercial training spam (SKILL.md, failure modes) often arrives here from an unrelated country's domain. It passes a naive relevance check and pollutes every issue once registered.
- Register **organizer pages**, not individual events. An organizer is a durable source; one event is not.

---

## The CTC event submission form (Airtable)

One table for every chapter. The link is the standing `submissions` row in the registry (and in `../../ctc-assemble/references/ctc-links.md`).

**Read the table live. Its columns are deliberately not listed here.** The base is maintained outside this toolkit and its columns change. A copy of them in this file would go stale silently and still be believed, which is worse than having no copy at all. Read what is actually there, then map it.

**How to read it, in order:**

1. **An Airtable tool or connector, if the session has one.** Ask the base for its own structure, then read the rows. This is the reliable path: it returns the real column names and needs no browser.
2. **The shared view in the browser.** A plain fetch of an Airtable shared view returns an empty shell, so the grid has to render. Read the column headings off the grid rather than assuming them.

**Fill the events sheet by matching, and ignore everything else.** The fixed thing here is the events sheet's own columns (SKILL.md, "Output: the events sheet"), not the table's. Take each sheet column from whichever table column plainly corresponds to it, matching on meaning rather than exact spelling.

**Anything in the table that does not correspond to a sheet column is not used.** Not summarised, not folded into a neighbouring cell, and above all not appended to `Description`. The submission form carries fields meant for the chapter lead rather than for readers, and a column added to the base next month is unknown to this file by design. Taking only what the sheet has a column for is what keeps both cases safe without a list of exceptions to maintain.

Two things to expect whatever the columns turn out to be called:

- Take only this chapter's rows, inside the date windows. Every other chapter's rows are ignored.
- Times arrive as a person typed them, such as "6:00 PM". Convert to `HH:MM`. Anything the form does not carry at all, such as Format or Google Maps, is filled from the event's own page as for any other row.

The rules for submitted rows (open every link, the page wins on facts and the submitter wins on description, `Source = submitted`, never drop one, report the count, carry on if the table will not open) are in SKILL.md Step 2 and are not repeated here.

---

## Web calendars

Universities, utilities, and government sites. Mostly server-rendered and fine on Tier 1, and Tier 1 has no shared state, so these are the sources to split across subagents: five to eight sources each, candidates back, failures named. Many of their event pages carry JSON-LD (`application/ld+json` with `startDate`, `location`, `organizer`); a plain fetch that returns it gives the row's facts as data, and the fetch tool's page text gives the description. When a page returns an empty shell, navigate the browser to it and call `__EXTRACT_CURRENT()`, which reads the same JSON-LD and meta tags off the rendered page and falls back to the page body. Several event pages on the same site can be batched with `__PULL_SAME_ORIGIN([...])` from a tab on that site. Also:

- Many are seasonal. University calendars empty out between terms. A quiet source in July is not a dead source.
- Some render the list client-side while showing events on the homepage. If `/events` looks emptier than the homepage, escalate to Tier 2 before concluding the source is quiet.
- Prefer a stable listing URL over a filtered search result.

---

## When the browser is not available

Tier 2 is the reliable path for Luma and Eventbrite, so a lead without the Claude in Chrome extension is not running a degraded harvest, they are running a broken one. Say so rather than producing a sheet full of blanks.

The submission form is the exception: an Airtable tool or connector reads it without any browser at all. Where the session has one, that source keeps working and only the calendar sources are affected.

Three honest options, in order:

1. **Install the extension.** It fixes every week from now on. This is the answer for anyone planning to keep sending.
2. **Paste per source.** The lead opens each Luma calendar and pastes the page. Workable for a registry of five sources, miserable at twenty.
3. **Harvest the server-rendered sources only** and say plainly which sources were skipped and roughly what share of a normal week they represent. A thin issue with a known cause is recoverable. A thin issue with an unknown cause is what makes a lead quit.

Never pick option 3 silently.

## General rules

The sandbox's network limits, CAPTCHA and login walls, and the no-guessing rule with its four resolved-unknown values all live in SKILL.md (Environment, Step 1, and Step 4). Pacing is built into the helpers and restated at the top of this file. This file is only about getting data off each platform.
