# Events sheet verifier

A second, adversarial pass over the finished events sheet before it goes to the lead. Every one of the fourteen link defects that shipped in a real issue would have been caught by this pass. It is not optional.

## How to run it

Run this as a fresh pass with no memory of the sweep. If the session has a subagent or task tool, launch one with exactly this file, the events `.xlsx`, `events_raw.json` (the extraction records, for the `landed_url` and `page_checks` per row), `plan.json` (for the probable duplicates and the dropped list), the scope rule, and the three things Layer 1 needs to re-fetch: `scripts/harvest_helpers.js`, `scripts/decode_transport.py`, and the "Running the helpers" section of `platform-notes.md`. Nothing else, and in particular nothing from the sweep's conversation. For a sheet over about twenty rows, launch several, each with its own slice of rows plus the whole-sheet checks assigned to one of them; they do not share the browser (see below). If the session has no subagent tool, run it yourself as a separate step after the sheet is built: read this file first, open the sheet cold, and work every row as though someone else harvested it. Fix `events.json`, re-run `build_sheet.py`, and only then deliver.

Do the whole sheet, `upcoming` included. In the reviewed issue every failure was in `upcoming`.

## Every link is re-fetched; a page is re-opened where the data cannot settle it

The pass has two layers, and every row goes through the first.

**Layer 1, re-fetch and compare, every row.** Fetch each registration link fresh (plain fetch for `web` rows; the Luma and Eventbrite rows go through `__PULL_LUMA` / `__PULL_EB` from `scripts/harvest_helpers.js` in batches, which is a fresh fetch of each page's structured payload). Compare what comes back against the cell: the page loads (not 404, not a challenge page), its name is this event, its date equals `Date`, its start time equals `Start Time` after timezone conversion, its location agrees with `Location`, its price agrees with `Access`, and it does not say the event has ended or been cancelled. Any disagreement is a finding. A link that redirected to a different page is a finding. This layer catches a changed time or a dead link more reliably than a second read by eye, because it compares values rather than impressions.

**Layer 2, open the page in the tab and read it, for these rows:**

- every row where Layer 1 found a disagreement, or could not fetch structured data at all;
- every `Source = submitted` row;
- every row whose link is not on luma.com or eventbrite.com **and** whose fresh fetch returned no structured date (off-platform pages with no JSON-LD are where a wrong row hides; an off-platform page that returned JSON-LD with a start date is treated like a platform row and sampled);
- three Luma rows and three Eventbrite rows chosen at random, read for the rendered local start time, because Layer 1 converts times with the same logic the sweep used and a zone or daylight-saving error passes both (check 10);
- the `carried` rows: all of them when there are ten or fewer, otherwise at least three chosen at random;
- every row the build script warned about;
- plus a random sample of the rest, at least five rows or fifteen percent, whichever is more, spread across both blocks.

The sample is what keeps this adversarial: it is the check that the structured payload itself is telling the truth. A sheet of five rows gets all five opened.

**Browser use.** One agent, one tab, paced, exactly as in the sweep. When the verifier is split across subagents, give the browser work (the Luma and Eventbrite batches and every Layer 2 open) to one of them and the plain-fetch rows to the others. Two agents in the browser is the failure this file is guarding against, not a shortcut.

## Checks, per row

1. **The registration link resolves to this event.** The page loads, its title is this event, its date matches the `Date` cell, and it does not say the event has passed. Any of the three failing means fix the link, fix the date, or drop the row. A redirect to a different slug means the event you wanted does not exist. The `page_checks` in `events_raw.json` say what the extractor saw; confirm them, do not trust them.
2. **The link is an event page**, not a calendar, a homepage, or a listing index (`/events`, `/calendar`, `/upcoming`, `/whats-on`). The build script flags the obvious ones; catch the rest by eye.
3. **Start Time, Location, Access, Host** match the page. A row with two or more of these blank was written from a listing page and needs the page opened.
4. **Scope.** The event's own location is inside the scope rule. Multi-city calendars and the submission form both let out-of-town events through.
5. **Block.** `this_week` rows fall inside the this-week window, `upcoming` rows after it. A row on the wrong side of the boundary lands in the wrong listing.
6. **Description.** Two to three sentences, 40 to 70 words, from the page, in the shape `../../ctc-assemble/references/voice.md` section 6 sets. No banned phrases from voice.md section 5, no invented speaker, venue, or price, no why-go sentence. This column is printed for every this-week event, so it is read by subscribers. A row carried from last week with reused prose is checked the same way; the reuse was only allowed because the page did not change, so confirm that it did not.
7. **Categories** are one to three from the controlled list, and fit the event.
8. **Submitted rows.** `Source = submitted` rows exist for every submission in the shared view for this city and these windows. None were dropped. Where the form and the page disagreed, the page won and the report says so.

## Checks, whole sheet

9. **Duplicates.** Same date plus similar name plus same venue is one event. The planner's `probable_duplicates` list names the pairs it could not settle; each has a ruling in the report. Merge per the dedupe table in SKILL.md, keeping the organizer's link.
10. **Times.** Read three Luma rows and three Eventbrite rows in the tab, by eye, against the rendered local time; do not use the fetched payload for this one. If one is off by hours, every row from that platform is off (UTC not converted, or the wrong zone); fix all of them.
11. **Red cells.** None remain, or each remaining one is named in the report with what the page showed.
12. **Count.** The total against the chapter's normal, and the zero-return sources named. The planner's dropped-as-out-of-window list is spot-checked: three of them, to confirm their listing dates really were outside the window.

## What to report

Rows fixed (by name, with the check number), rows dropped and why, duplicates merged, which rows were opened in the tab and why (the Layer 2 list), anything left red and why, and a one-line verdict: ready, or not.
