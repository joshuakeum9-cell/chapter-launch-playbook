# Source list verifier

A second, adversarial pass over the finished registry before it is handed to the lead. It exists because the two failures of this skill, an overclaimed `auto` source and a wrongly excluded real one, are invisible in the file and only show up months later as thin issues.

## How to run it

Run this as a fresh pass with no memory of the research that produced the file. If the session has a subagent or task tool, launch one with exactly this file, the registry `.xlsx`, and the scope rule from Step 1, and nothing else. If it does not, run it yourself as a separate step after the file is built: read this file first, then open the registry cold and work through the checks as though someone else compiled it. An audit that changes nothing usually means the audit was weak.

Report the results in the delivery summary as its own paragraph, and fix the file (edit `sources.json`, re-run `build_registry.py`) before delivering. Never deliver a registry with a failed check noted "for later."

## Checks

Every row is re-fetched; a page is opened by eye where the fetch cannot settle it. Luma and Eventbrite rows go through `__ENUM_LUMA` / `__ENUM_EB` from `../../ctc-harvest/scripts/harvest_helpers.js`, every registered calendar or organizer in one or two batched calls from one tab (read the result as `../../ctc-harvest/references/platform-notes.md` describes), which answers checks 1 to 3 as data for each row: it loaded, it listed dated events, the most recent date. Web rows are plain fetches, and can be split across subagents. Then open in the tab by eye: every row whose batch record came back `ok: false` or with zero items, every `manual` and `unverified` row, every row with a `relationship` value, and at least three `auto` rows chosen at random, to confirm the structured read is telling the truth. One agent in the browser, paced; never two.

For each row:

1. **The URL loads and is the page the row claims.** An organizer or calendar page, not a single event, not a homepage, not a filtered search. Luma and Eventbrite pages need the browser; a plain fetch returning an empty shell is not a pass.
2. **`method` is honest.** `auto` only if the page returned structured, dated event listings on this visit. A JavaScript-rendered calendar that came back empty to a plain fetch is `manual`. An `auto` row that returns nothing is the single worst outcome of this skill, because the weekly harvest fails silently on it.
3. **Gate 2 and Gate 3 hold.** At least one event in the last 90 days (term-time exception applies), and a repeating pattern. Confirm `last_event` against the page, not against the row.
4. **`category` is one of the nine, or `submissions`.** A row in the wrong category is counted wrong on the quarterly refresh.
5. **Nothing excluded is real.** Read the rejected-candidates list from the chat summary. For every rejection on the grounds "CTC property" or "another chapter," confirm who actually runs the page. A calendar named like a chapter and run by someone else is a real source and goes back in.
6. **The standing submissions row is present** with the exact URL from `../../ctc-assemble/references/ctc-links.md`, `platform = airtable`, `method = auto`, `tier = core`, `category = submissions`, `origin = ctc`.
7. **No syndicated spam.** Any organizer whose listings are generic training titles republished across cities is out.
8. **Scope.** Every source is in the metro the scope rule defines. A multi-city organization's calendar is fine only if `notes` says the harvest filters on location.

## What to report

- Rows changed, with the check number and what changed
- Rows dropped, and why
- Rejections reversed, and who runs the page
- The final count of external sources and the empty categories, restated after the fixes
