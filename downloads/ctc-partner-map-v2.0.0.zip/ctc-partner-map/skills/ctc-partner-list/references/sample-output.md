# Sample output

What a finished run of `ctc-partner-list` returns, so a new chapter lead knows what to expect before running it.

**Everything on this page is illustrative.** The organizations are real Houston ones, but the `why` lines, asks, contact routes, tier placements and notes were written to show the shape of each field and have not been through the four checks. Where a line states something about an organization (that it has event space, a calendar submission form, a named contact, a meeting schedule), treat that as invented for the example, not as a fact about the organization. Nothing here should be copied into a real Houston map. The data behind it is `scripts/partner_data_EXAMPLE.py`; build it with `python3 scripts/build_partners.py scripts/partner_data_EXAMPLE.py` to get the actual workbook. The commentary on why each field is written the way it is lives in `references/worked-example.md`.

---

## The file

`CTC_Partner_Map_Houston.xlsx`, two sheets.

## Sheet 1: `Partners`

Row 1 is the title, `Houston - Partner Map`, on a teal band. Row 2 is the subtitle, row 3 the tab note in small italics. Then three tier bands, each with its count and its approach window, each followed by a column header row and the entries on blue fill. Nine columns: Organization, Category, Why them, Ask for first, Contact route, Website, Source, Status, Note.

### TIER 1 (9). Approach in the first 30 days. Can host or co-host now.

| Organization | Category | Why them | Ask for first | Contact route | Website | Source | Status | Note |
|---|---|---|---|---|---|---|---|---|
| Greentown Labs Houston | Accelerators and incubators | Their member companies are the founders we want in the room, and the building has event space they already open to outside groups. | Co-host our launch mixer in your event space on a weeknight in October. | Community or events team, via the contact form on the Houston page | https://greentownlabs.com/houston/ | workbook | Not contacted | |
| Ion District | Coworking and innovation districts | They publish a public events calendar with an open submission form, so they are set up to carry our listings from week one. | Add our monthly meetup to the Ion events calendar and let us book a room for the first one. | Calendar submission form on the events page | https://iondistrict.com/ | gap research | Not contacted | Submission form is for listings, not room booking. Two separate asks in one email. |
| Rice Alliance for Technology and Entrepreneurship | Universities and research centers | They convene the founder and investor side of this city on a recurring basis and their audience is ours a year earlier. | Put our chapter lead on a panel at your next energy venture event. | Named program director listed on the Rice Alliance team page | https://alliance.rice.edu/ | workbook | Not contacted | |
| Houston Renewable Energy Group | Professional and affinity groups | They already assemble the exact audience we want on a recurring meeting schedule, and they meet at rotating venues rather than defending one of their own. | Co-host one of your monthly meetings as a joint session with our chapter. | Contact form on the site. Do not use the published inbox address | https://houstonrenewableenergy.org/ | gap research | Not contacted | |
| CenterPoint Energy | Corporates and industry | A founder cannot raise from a utility, which is why the workbook cut them, but they will put a grid person on a panel and that is the talk this city turns out for. | Provide a speaker on grid interconnection for our first quarterly panel. | Community relations, via the corporate responsibility page | https://www.centerpointenergy.com/ | reconsidered | Not contacted | Cut upstream as reputation-only admission. Passes the partner bar on speaker access. |
| Bayou City Waterkeeper | Nonprofits and advocacy | Water and flooding is the climate conversation this city actually has, and their members show up for it in numbers climate tech events do not reach. | Send a speaker to our first event and share the launch issue with your list. | General contact form on the site | https://bayoucitywaterkeeper.org/ | gap research | Not contacted | |
| Houston Public Library | Arts, culture, and civic venues | Free meeting rooms across the city and a walk-in audience that is exactly the readers who are curious about climate work but not yet in it. | Book a meeting room for a free introductory climate careers evening. | Meeting room reservation form on the library site | https://houstonlibrary.org/ | gap research | Not contacted | |
| Houston Advanced Research Center | Universities and research centers | Independent research shop with its own convening habit, and its staff are the people our readers most want to hear from. | Host a joint evening session at your campus in The Woodlands. | Events contact listed on the HARC site | https://harcresearch.org/ | workbook | Not contacted | Based in The Woodlands, not Houston proper. Inside the metro scope, named so nobody is misled. |
| Cup of Joey | Professional and affinity groups | A standing weekly founder gathering the lead already attends, and a warm room to make the chapter's first introductions in. | Introduce the chapter from the front at one Friday session. | Warm path. The lead already attends | https://www.cupofjoey.com/ | lead added | Not contacted | KEPT DESPITE A FAILED CHECK. No published partnerships route, so check four fails on the research. The lead knows the organizer personally and asked to keep it. |

All four gap categories are present, all four `source` values are present, and Capital is absent because funds rarely host.

### TIER 2 (4). Approach at 60 to 90 days. Wants a warm intro or a track record first.

| Organization | Category | Why them | Ask for first | Contact route |
|---|---|---|---|---|
| Houston Museum of Natural Science | Arts, culture, and civic venues | Their public programming reaches the general-audience readers no climate tech event reaches, and one joint night would be the chapter's widest room of the year. | Co-present one evening in your public lecture series. | Public programs team, via the education contact page |
| Halliburton Labs | Corporates and industry | Their cohort founders are ours, but a corporate program will want to see the chapter running before it lends its name. | Send your cohort founders to our monthly meetup, then talk about co-hosting a demo night. | Program contact listed on the Halliburton Labs site |
| Houston Parks Board | Civic and government | Bayou infrastructure is the most legible climate adaptation story in the city and a walking tour would be our most distinctive listing. | Lead a bayou resilience walking tour for our members in spring. | Community engagement, via the contact page |
| Rice University Office of Innovation | Universities and research centers | Campus access needs a sponsor inside the university, and Rice Alliance is the introduction that gets us one. | Introduce us to the student sustainability groups you work with. | Warm path via Rice Alliance |

The Museum's note reads: *Programs are planned far ahead. Approach early even though the event lands late.*

### TIER 3 (2). Later. Real, but not a first-quarter target.

| Organization | Category | Why them | Ask for first | Contact route |
|---|---|---|---|---|
| Port Houston | Civic and government | The single most interesting site visit in the region, and the one that will take a year of relationship to earn. | Explore a member site visit once the chapter has a track record. | Community relations, via the public affairs page |
| City of Houston Mayor's Office of Sustainability | Civic and government | City endorsement would carry weight with every other partner, and city offices answer chapters that already exist. | Have a staff member speak once the chapter has published for a quarter. | General office contact on the city site |

## Sheet 2: `Not approaching`

| Organization | Why not |
|---|---|
| Houston Botanic Garden | Event spaces are rental only with a minimum spend. A venue option, not a partner. Revisit if a sponsor covers the room. |
| Elemental Impact | National program with no Houston staffed presence. Correctly cut upstream and it does not flip under the partner bar. |
| WeWork Houston locations | Space is bookable but there is no local programming counterpart, so the realistic outcome is a room invoice. |
| Texas Energy Founders Meetup | Runs the same weeknight slot and has no reason to send people to us. Worth registering as an event source, not as a partner. |
| Regional office of a national engineering firm | Would be a logo on a slide and nothing else. No public programming, no member list, no venue. |

Every reason is one a reader could check and overturn.

---

## What the build script prints

```
wrote /mnt/user-data/outputs/CTC_Partner_Map_Houston.xlsx

  TIER 1       9
  TIER 2       4
  TIER 3       2
  NOT APPR.    5
  TOTAL       15

QA: no failures.

QA warnings - judgment calls, decide and say which:
  ! TAB_NOTE still says WORKED EXAMPLE. This is the illustrative file. Do not deliver it as a real map.
```

That one warning is deliberate and only appears on the example file. A real city's run should print no warnings, or warnings you can explain at delivery.

## The chat summary that accompanies the file

> Houston: 9 in Tier 1, 4 in Tier 2, 2 in Tier 3, 5 on Not approaching. One came back in from the resource workbook's exclusions, CenterPoint Energy, on speaker access. Gap research added one coworking district, one professional group, one nonprofit, two civic venues, and three more in the workbook's own categories. Capital is empty in Tier 1, which is usual: funds rarely host. Cup of Joey is kept despite a failed check because you asked for it; the note says which check. This workbook is also what `ctc-opportunities` reads for local grants and programs each month, so keep it in your project.
>
> That is who to approach and in what order. When you are ready to write to any of them, say `/ctc-partner-outreach` and name the organization. Start with two or three from Tier 1 rather than working down the whole list.
