# The partner bar

The single most important file in this skill. Read it before any research.

The person every rule here is written for is described in `SKILL.md`, "What
this is for": a volunteer lead in their first month who needs a list short
enough to finish and specific enough to act on without thinking. When you hit a
case this file does not cover, reason from that person.

---

## The bar is not the resource bar

`ctc-city-resources` asks one question of every candidate: **can a founder walk
through this door.** That is the right test for a founder-facing resource page,
and it is why that skill correctly cuts national programs with no local tie and
organizations that got in on reputation.

This skill asks a different question: **would they co-host, host, promote, or
send their people.**

The two tests disagree often, and the disagreement runs in both directions.

**Passes the resource bar, fails the partner bar.** A seed fund with a real
local office and a climate thesis belongs on the resource page. If it is two
people who invest quietly and have never put their name on a public event, it
is not a Tier 1 partner. Being useful to a founder is not the same as being
useful to a chapter.

**Fails the resource bar, passes the partner bar.** A large utility a founder
cannot get money from will happily put a speaker on a panel and open a room. A
national nonprofit with a local chapter is not a city resource, but its local
chapter organizer is exactly who a new chapter should be talking to in week two.
Both were correctly cut from the workbook. Both belong here.

This is why `read_workbook.py` surfaces the reviewer notes. Every organization
the resource pass recorded as excluded gets reconsidered against this bar, and
the two most common exclusion reasons, national scope and reputation-only
admission, are precisely the ones that flip.

## The four checks

Approve a partner only if all four hold. Which entries get which checks is set
in `SKILL.md`, Steps 1 and 4: roster rows from the workbook have already passed
checks 1 and 2 upstream and get checks 3 and 4 here; everything else gets all
four.

**1. Real and local.** A staffed presence in the metro, or a local chapter with
a named local organizer. The metro scope is the one `ctc-city-resources` fixed
in its Step 1 for this city, unchanged. Name the actual municipality in the
note when it is not the city proper, so nobody is misled.

**2. Active in the last twelve months.** Dated evidence. An event, a program, a
post, a cohort. A partner that has gone quiet is a research artifact, not a
partner.

**3. Audience overlap that is real, not thematic.** Their people would come to a
climate tech event. "They care about sustainability" is thematic. "They run a
monthly meetup for the exact people we want in the room" is real.

**4. A visible route in.** A named person or role that is publicly findable, an
events or partnerships form, or a warm path through CTC or the lead's own
network. No route in means Tier 3 at best, however good the fit.

## What does not qualify

**Organizations that would only ever be a logo.** If the realistic outcome is a
name on a slide and nothing else, it is not a partner.

**Anything that competes for the same weeknight without reciprocating.**
Adjacent meetups are worth knowing and worth listing as event sources. They are
partners only when there is a plausible trade.

**CTC's own properties.** Never register another chapter, the main site, or
Streetlife Ventures as a partner.

**Anything requiring money.** A first event is free and partner hosted. A venue
that needs a minimum spend is a venue option, not a partner.

---

## Ruled cases

The four checks decide the clear ones. These are the cases that recur and get
decided inconsistently, usually toward inclusion, because including something
feels like doing more work.

| Situation | Ruling | Reasoning |
|---|---|---|
| Utility or large industrial a founder cannot raise from | Include. Often Tier 1 | They open rooms and supply speakers. Money was never the point |
| National nonprofit with a named local organizer | Include, as the local chapter | The organizer is the partner. Name them, not the national body |
| National organization with a local landing page and no local staff | Exclude | Nothing local to co-host with |
| Venue that hosts only on paid rental with a minimum spend | Exclude, and record it on Not approaching | A first event is free and partner hosted. Note it as a venue option in case a sponsor appears |
| Venue with free or waivable community rooms | Include | Library and community center meeting rooms are the standard case here |
| Coworking chain branch with no local programming | Exclude | Bookable space with no counterpart is an invoice, not a partnership |
| Adjacent meetup in the same slot with no reason to reciprocate | Exclude as a partner | Register it as an event source instead. It becomes a partner when there is a trade |
| Organization already on the resource workbook | Run checks 3 and 4, do not auto-include | The workbook tested a different question. Most pass, some do not |
| University department versus the university | The department or center, always | A university is not a contactable entity. A named center is |
| Only published contact is a general inbox address | Include, and write the route as the form or page | Never put the address in the file. The lead finds it on the site when they write |
| Strong fit, no findable route in at all | Tier 3 | It is a real partner and it is not a first-30-days one |
| The lead's own employer | Include if it passes the four checks, and note the relationship | The conflict is the lead's to manage. Hiding it is worse |
| An organization the lead added that fails a check | Keep it, per `SKILL.md` Step 4 | They live there and the research does not |
| Government agency with a long approval path | Tier 3 unless a named staffer is already reachable | Tiering is about when, not about quality |

**The principle underneath: would this organization plausibly say yes to
something specific within the tier's window, and is there a door to knock on.**
Work any case this table missed back to that. Two halves, and both have to hold.
A perfect fit with no door is Tier 3. A findable door with nothing behind it is
Not approaching.

---

## The nine categories

The first five come from the resource workbook. The last four are the gap, and
they exist because a tech-focused search never surfaces them.

| # | Category | Where it comes from |
|---|---|---|
| 1 | Accelerators and incubators | Workbook |
| 2 | Universities and research centers | Workbook |
| 3 | Capital | Workbook |
| 4 | Civic and government | Workbook |
| 5 | Corporates and industry | Workbook |
| 6 | Coworking and innovation districts | Gap research |
| 7 | Professional and affinity groups | Gap research |
| 8 | Nonprofits and advocacy | Gap research |
| 9 | Arts, culture, and civic venues | Gap research |

### Mapping the workbook's blocks onto these categories

The resource workbook uses five block names and they are not the same five
words. Do not guess the mapping, and in particular do not send everything from
the third block into Civic and government.

| Workbook block | Partner category |
|---|---|
| Universities & Research Institutions | Universities and research centers |
| Incubators & Accelerators | Accelerators and incubators |
| Startup Resources & Public Programs | Split it. Government and agency programs go to Civic and government. Everything else goes to the category that fits the host, most often Accelerators and incubators or Universities and research centers |
| Industry Partners | Corporates and industry |
| Capital Partners | Capital |

An organization can move category between the two files when the reason
changes. A city economic development corporation sits under Startup Resources
upstream because it runs a founder program. Here it is Civic and government,
because what it would do for the chapter is open a public building.

### Two categories to watch

**Category 9 is the one that gets skipped and should not be.** Roughly 40
percent of a chapter's audience is not yet working in climate. That figure is
CTC's own, from the audience composition published on the About page: 28 percent
are actively transitioning careers and 12 percent are curious and learning.
Museums, libraries, botanical gardens, maker spaces, community centers, and
civic venues are much of what serves those readers, they are usually free, and
they are frequently delighted to host. The New York newsletter's most
distinctive listings come from exactly this category.

**Category 7 is the highest yield per search.** Women in renewable energy
groups, young professionals in energy, industry associations, and university
alumni climate groups already assemble the audience the chapter wants. They
recur reliably and they are easy to miss.

---

## Tiering

Tiering is about **when to approach**, not about how good the organization is. A
world-class institution with a six-month procurement process is Tier 3, and that
is not an insult.

**Tier 1, first 30 days.** Could host or co-host now. Audience overlaps
directly. Route in is visible. This is where the weight goes, because a new lead
has time for about ten conversations, not forty.

**Tier 2, 60 to 90 days.** Good fit, but wants a warm introduction or wants to
see the chapter exist first.

**Tier 3, later.** Real, but slow, large, or currently out of reach. Keep it
short. A long Tier 3 is a wish list pretending to be a plan.

### How many

This table is the only place tier sizes are stated. The QA gate in
`build_partners.py` enforces the same numbers.

| Tier | Expected range | What the QA gate does |
|---|---|---|
| Tier 1 | 6 to 14 | Warns under 6 and over 14 |
| Tier 2 | 6 to 10 | Nothing |
| Tier 3 | 3 to 6 | Nothing |
| Whole map | 12 or more | Warns under 12 |
| Not approaching | Never empty | Warns when empty |

**These are distributions, not quotas.** The count is an output of what the city
has, never an input to the research. A stated target of ten reliably produces
ten, two of which should not be there, and those two are the ones that cost the
lead an afternoon and cost the map its credibility.

If a city yields five Tier 1 partners, ship five and say so. That is a fact the
lead needs before they plan a quarter around partners who are not there. If it
yields eighteen that all pass, the tiering is doing no work: split by who could
host in the next thirty days and move the rest to Tier 2.

**Provenance, stated plainly.** These ranges come from the design of the skill
and the size of a volunteer's first month. They have not yet been calibrated
against completed maps for real cities. Treat the QA warnings as prompts to say
which way the city went, not as failures. When enough real runs exist, replace
this table with what they actually produced.

---

## The ask

Every partner gets one concrete first ask, and it has to be something that can
be said yes to in a single email reply.

Concrete: host our first event in your space on a weeknight in October. Put a
speaker on a panel about grid interconnection. Share our launch issue with your
member list. Co-host a founder breakfast.

Not concrete: explore ways to collaborate. Discuss a partnership. Build a
relationship. Sync.

Match the ask to the tier. Tier 1 asks for a room or a co-host. Tier 2 asks for
an introduction or a newsletter share. Tier 3 asks for a conversation.

Paired weak and strong examples for every field are in
`references/worked-example.md`. Read them before writing entries rather than
after.

## Contacts

**Never invent a name, a title, an email address, or a phone number.** This is
absolute, and inventing a contact is the one unrecoverable error in this skill.

The contact field holds one of four things, and nothing else: a publicly
findable named person with their public role, a role without a name where only
the role is published, a general route such as the partnerships form on their
site, or a warm path where a real connection exists through CTC or the lead's
network.

Never write an email address into the workbook, even a published one. A scraped
address in a shared file is a liability, and the lead can find it on the site
when they are ready to write. The QA gate fails the build on any `@` in the
contact field.

## Honest gaps

Same principle as the resource workbook. A short honest list beats a padded one.

If a category returns nothing in this city, say so and leave it empty. Capital
is empty in Tier 1 more often than not, because funds rarely host, and that is
information rather than a hole.

Record everything set aside on the Not approaching sheet with its reason. That
sheet is why the lead trusts the other three.
