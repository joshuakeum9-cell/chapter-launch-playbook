# Gap research

The resource workbook already covers five categories. This file holds the
research prompt for the four it does not, and the separate pass category 9
needs. When to run it, and what to do first with the roster and the reviewer
notes, is in `SKILL.md`, Steps 1 to 3. The tools to use are under Environment
there.

Do not re-research categories 1 to 5. They have been through two research
passes and an adversarial audit upstream.

---

## The gap prompt

Substitute the city and the metro scope already fixed by the resource pass.

```
Find organizations in the {CITY} metro area ({SCOPE}) that would plausibly
host, co-host, promote, or send their members to a climate tech community
event. Not funders and not startup support programs, which are already
covered. Specifically:

1. COWORKING AND INNOVATION DISTRICTS
   Coworking spaces, innovation districts, maker spaces, and hardware or
   climate-focused workspaces that host public community events on weeknights.
   Note capacity and whether they host outside groups.

2. PROFESSIONAL AND AFFINITY GROUPS
   Local chapters of energy, sustainability, engineering, and built-environment
   professional associations. Women in energy or climate groups. Young
   professionals groups. University alumni climate or sustainability groups.
   Anything that already assembles this audience on a recurring basis.

3. NONPROFITS AND ADVOCACY
   Environmental, energy, transportation, environmental justice, and urban
   sustainability organizations with a staffed local presence and a record of
   public programming.

4. ARTS, CULTURE, AND CIVIC VENUES
   Museums, science centers, libraries, botanical gardens, aquariums,
   community centers, and civic venues that have run climate, sustainability,
   energy, or environment programming. Include venues that host outside groups
   even where the climate angle is occasional.

For every candidate return: name, category, canonical URL, a local physical
address or the named local chapter, dated evidence of activity in the last
twelve months, whether they visibly host outside organizations, and any
publicly listed contact route such as a partnerships or events page. Do not
return contact email addresses.

Do not return national organizations with no local staffed presence or named
local chapter. Do not return organizations whose last visible activity is
more than twelve months old.
```

Over-collect here. Cutting is cheap and noticing an absence is not. Expect to
collect roughly twice what survives.

### What each category usually returns

A sense of scale, not a quota. Any of these can be zero in a small metro, and a
zero that is stated is fine.

| Category | Usual survivors in a mid-size metro | If you get zero |
|---|---|---|
| Coworking and innovation districts | 2 to 5 | Unlikely in any city with a startup scene. Search the district by name, not by climate |
| Professional and affinity groups | 3 to 6 | Almost certainly a search failure. Try association names directly |
| Nonprofits and advocacy | 3 to 6 | Try the local environmental coalition or resource guide, which most metros have |
| Arts, culture, and civic venues | 2 to 5 | See below. This is the category a climate search cannot find |

## Category 9 needs its own pass

A generalist search for climate organizations will not surface a botanical
garden, and that is exactly the failure this category exists to prevent. Search
venue types directly by name, city by city: museum, science center, library
system, botanical garden, aquarium, nature center, community center, maker
space, historic site, public park conservancy.

Then check each for public programming rather than for a climate mission. A
venue with no climate mission that has run one climate talk is a better partner
than a climate organization that has never opened a room.

Check the room terms while you are there, because they decide the ruling: the
rows for free or waivable rooms and for rental with a minimum spend are in
`references/partner-bar.md`, Ruled cases.

---

Everything that comes back, and everything the lead supplies, goes through
Step 4 of `SKILL.md`.
