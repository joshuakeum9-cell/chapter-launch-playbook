# Partner map verifier

A second, adversarial pass over the finished partner map before it goes to the lead. The resource workbook upstream was audited; the entries this skill added (the reconsidered exclusions and the four gap categories) were not, and the asks and contact routes are new for every row. A contact route that leads nowhere costs the lead the evening the map was supposed to save.

## How to run it

Run this as a fresh pass with no memory of the research. If the session has a subagent or task tool, launch one with exactly this file, the `CTC_Partner_Map_<City>.xlsx`, and the metro scope, and nothing else. If it does not, run it yourself as a separate step after the file is built: read this file, open the map cold, and work every row as though a stranger compiled it. Fix the data module, re-run `build_partners.py`, and only then deliver.

## Checks, per Partners row

1. **The organization is real and local.** Open its website. A staffed presence inside the metro scope, not a national landing page. Give the municipality.
2. **Active in the last twelve months.** Dated evidence: an event, a post, a cohort, a news item. Note the date.
3. **The contact route resolves.** Open it. A named role, a general form, or a page that actually exists. No invented names, titles, or email addresses anywhere in the file (the script blocks `@`; check for names that cannot be found on the organization's site or LinkedIn).
4. **The ask passes the single-email test.** It could be answered yes in one reply, it fits the tier (a venue ask to an organization with no space fails), and it is not reused word for word from another row.
5. **The `why` line is about this chapter**, one sentence, not a description of the organization.
6. **Tier fits.** Tier 1 could host or co-host now with a visible route in; anything needing a warm introduction is Tier 2; anything that needs the chapter to exist first is Tier 3.
7. **No CTC property, other chapter, or Streetlife Ventures** listed as a partner.
8. **Prose.** No banned phrases from `../../ctc-partner-outreach/references/voice.md` section 5, no volatile figures, no em dashes.

## Checks, whole file

9. **Not approaching sheet.** Every entry has a reason a reader could act on, and nothing there is a Tier 1 candidate in disguise.
10. **Counts against the ranges** in `partner-bar.md` "How many," with a stated reason for any deviation.
11. **The lead's own additions** (rows flagged as lead-supplied in the note field) are all present. None dropped.

## What to report

Rows fixed (name, check number, what changed), rows moved between tiers or to Not approaching, rows dropped and why, and a one-line verdict.
