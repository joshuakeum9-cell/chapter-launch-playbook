#!/usr/bin/env python3
"""
Render the CTC partner map workbook from a partner data module.

Usage:
    python3 build_partners.py partner_data_<city>.py

Writes /mnt/user-data/outputs/CTC_Partner_Map_<City>.xlsx and prints a
structural summary plus a QA report. Read the QA output rather than assuming
it passed.

Deliberately a SEPARATE FILE from CTC_City_Resources_<City>.xlsx. The resource
workbook is public facing and feeds the chapter page. This one carries contact
routes, approach order, and status, which is internal working state and must
not ship with the public file.
"""

import importlib.util
import os
import re
import sys

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

OUT_DIR = '/mnt/user-data/outputs'

TITLE_FILL = PatternFill('solid', fgColor='0F6E6E')
TIER_FILL = PatternFill('solid', fgColor='BBD3D1')
HDR_FILL = PatternFill('solid', fgColor='D9E2E1')
DATA_FILL = PatternFill('solid', fgColor='DCE6F1')
CUT_FILL = PatternFill('solid', fgColor='F2F2F2')

THIN = Side(style='thin', color='9AB3B2')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

COLUMNS = [
    ('Organization', 30),
    ('Category', 26),
    ('Why them', 46),
    ('Ask for first', 40),
    ('Contact route', 30),
    ('Website', 34),
    ('Source', 14),
    ('Status', 14),
    ('Note', 34),
]

TIER_BLURB = {
    'TIER 1': 'Approach in the first 30 days. Can host or co-host now.',
    'TIER 2': 'Approach at 60 to 90 days. Wants a warm intro or a track record first.',
    'TIER 3': 'Later. Real, but not a first-quarter target.',
}

REQUIRED = ('org', 'category', 'why', 'ask', 'contact', 'url', 'source')

VOLATILE = re.compile(
    r'(\$\s?\d|\d+\s?%|\bover \d|\bmore than \d|\b\d+\+?\s+(companies|startups|'
    r'founders|members|portfolio)\b|\bAUM\b|\bfund size\b)', re.I)


def load_module(path):
    spec = importlib.util.spec_from_file_location('partner_data', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def wrap(cell, wrap_text=True, bold=False, color=None, size=10):
    cell.alignment = Alignment(vertical='top', wrap_text=wrap_text)
    cell.font = Font(bold=bold, color=color, size=size)
    cell.border = BORDER


def est_height(entry):
    longest = max(len(str(entry.get('why', ''))) / 46,
                  len(str(entry.get('ask', ''))) / 40,
                  len(str(entry.get('note', '') or '')) / 34)
    return max(18, 14 * (int(longest) + 1))


def build(mod):
    wb = Workbook()
    ws = wb.active
    ws.title = 'Partners'

    for i, (_, width) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width

    ncols = len(COLUMNS)
    r = 1

    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
    c = ws.cell(r, 1, f'{mod.CITY} - Partner Map')
    c.fill = TITLE_FILL
    wrap(c, wrap_text=False, bold=True, color='FFFFFF', size=13)
    ws.row_dimensions[r].height = 26
    r += 1

    if getattr(mod, 'SUBTITLE', ''):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
        c = ws.cell(r, 1, mod.SUBTITLE)
        wrap(c, bold=False)
        r += 1

    if getattr(mod, 'TAB_NOTE', ''):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
        c = ws.cell(r, 1, mod.TAB_NOTE)
        wrap(c)
        c.font = Font(italic=True, size=9, color='555555')
        ws.row_dimensions[r].height = 28
        r += 1

    r += 1
    counts = {}

    for label, entries in (('TIER 1', mod.TIER_1),
                           ('TIER 2', mod.TIER_2),
                           ('TIER 3', mod.TIER_3)):
        counts[label] = len(entries)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
        c = ws.cell(r, 1, f'{label}  ({len(entries)})   {TIER_BLURB[label]}')
        c.fill = TIER_FILL
        wrap(c, wrap_text=False, bold=True)
        ws.row_dimensions[r].height = 22
        r += 1

        for i, (name, _) in enumerate(COLUMNS, start=1):
            c = ws.cell(r, i, name)
            c.fill = HDR_FILL
            wrap(c, wrap_text=False, bold=True, size=9)
        r += 1

        for e in entries:
            vals = [e.get('org'), e.get('category'), e.get('why'),
                    e.get('ask'), e.get('contact'), e.get('url'),
                    e.get('source'), e.get('status', 'Not contacted'),
                    e.get('note', '')]
            for i, v in enumerate(vals, start=1):
                c = ws.cell(r, i, v)
                c.fill = DATA_FILL
                wrap(c)
            ws.row_dimensions[r].height = est_height(e)
            r += 1
        r += 1

    ws.freeze_panes = 'A2'

    cut = getattr(mod, 'NOT_APPROACHING', [])
    ws2 = wb.create_sheet('Not approaching')
    ws2.column_dimensions['A'].width = 34
    ws2.column_dimensions['B'].width = 90
    c = ws2.cell(1, 1, 'Considered and set aside')
    ws2.merge_cells('A1:B1')
    c.fill = TITLE_FILL
    wrap(c, wrap_text=False, bold=True, color='FFFFFF', size=12)
    for i, name in enumerate(('Organization', 'Why not'), start=1):
        c = ws2.cell(2, i, name)
        c.fill = HDR_FILL
        wrap(c, wrap_text=False, bold=True, size=9)
    for j, (org, reason) in enumerate(cut, start=3):
        for i, v in enumerate((org, reason), start=1):
            c = ws2.cell(j, i, v)
            c.fill = CUT_FILL
            wrap(c)
    return wb, counts, cut


def qa(mod):
    fails = []
    warns = []
    allowed = set(getattr(mod, 'CATEGORIES', []))
    seen = {}
    total = 0

    for label, entries in (('TIER 1', mod.TIER_1),
                           ('TIER 2', mod.TIER_2),
                           ('TIER 3', mod.TIER_3)):
        for e in entries:
            total += 1
            org = e.get('org', '<unnamed>')
            for k in REQUIRED:
                if not str(e.get(k, '') or '').strip():
                    fails.append(f'{org}: blank required field "{k}"')
            url = str(e.get('url', '') or '')
            if not url.startswith('https://'):
                fails.append(f'{org}: URL not https -> {url}')
            if allowed and e.get('category') not in allowed:
                fails.append(f'{org}: category "{e.get("category")}" not in CATEGORIES')
            key = org.lower().strip()
            if key in seen:
                fails.append(f'{org}: duplicated in {seen[key]} and {label}')
            seen[key] = label
            blob = ' '.join(str(e.get(k, '') or '') for k in ('why', 'ask', 'contact', 'note'))
            if '\u2014' in blob or '\u2013' in blob:  # em dash, en dash
                fails.append(f'{org}: em dash or en dash in copy')
            if VOLATILE.search(blob):
                fails.append(f'{org}: volatile figure in copy')
            if '@' in str(e.get('contact', '') or ''):
                fails.append(f'{org}: contact route contains an email address. '
                             f'Never publish a scraped address.')
            if len(str(e.get('why', '') or '').split()) > 40:
                warns.append(f'{org}: "why" is long. One sentence is the target.')

    n1 = len(mod.TIER_1)
    if n1 < 6:
        warns.append(f'Tier 1 has {n1}. Under 6 usually means the gap research '
                     f'was thin, or the city is. Confirm which.')
    if n1 > 14:
        warns.append(f'Tier 1 has {n1}. Over 14 is not a first-30-days list.')
    if total < 12:
        warns.append(f'{total} partners total. Small ecosystems are real, but '
                     f'confirm the four gap categories were searched.')
    if not getattr(mod, 'NOT_APPROACHING', []):
        warns.append('NOT_APPROACHING is empty. An entirely uncut list usually '
                     'means the bar was not applied.')

    # The three documented failure modes that a structural check can catch.
    all_entries = list(mod.TIER_1) + list(mod.TIER_2) + list(mod.TIER_3)
    sources = {str(e.get('source', '')).strip().lower() for e in all_entries}
    if all_entries and sources <= {'workbook'}:
        warns.append('Every entry has source "workbook". This is the resource '
                     'workbook re-sorted. Step 2 and Step 3 did not happen.')
    if all_entries and 'reconsidered' not in sources:
        warns.append('Nothing came back in from the exclusions. Possible in a '
                     'workbook with no reviewer notes, otherwise it means the '
                     'partner bar is being applied as a copy of the resource '
                     'bar. Say which.')

    gap_cats = {'Coworking and innovation districts',
                'Professional and affinity groups',
                'Nonprofits and advocacy',
                'Arts, culture, and civic venues'}
    present = {e.get('category') for e in all_entries}
    missing_gap = sorted(gap_cats - present)
    if all_entries and missing_gap:
        warns.append('No entries in gap categories: ' + ', '.join(missing_gap) +
                     '. Honest zeros happen, but "Arts, culture, and civic '
                     'venues" empty usually means category 9 was skipped.')

    asks = [str(e.get('ask', '')).strip().lower() for e in all_entries]
    repeats = {a for a in asks if a and asks.count(a) > 1}
    for a in sorted(repeats):
        warns.append(f'Ask reused across entries: "{a[:60]}". A shared ask is '
                     f'a template, not a first ask.')

    if 'WORKED EXAMPLE' in str(getattr(mod, 'TAB_NOTE', '')):
        warns.append('TAB_NOTE still says WORKED EXAMPLE. This is the '
                     'illustrative file. Do not deliver it as a real map.')

    return fails, warns, total


def main(path):
    mod = load_module(path)
    wb, counts, cut = build(mod)
    os.makedirs(OUT_DIR, exist_ok=True)
    safe = re.sub(r'[^A-Za-z0-9]+', '_', mod.CITY).strip('_')
    out = os.path.join(OUT_DIR, f'CTC_Partner_Map_{safe}.xlsx')
    wb.save(out)

    print(f'wrote {out}\n')
    for k, v in counts.items():
        print(f'  {k:<10} {v:>3}')
    print(f'  {"NOT APPR.":<10} {len(cut):>3}')
    print(f'  {"TOTAL":<10} {sum(counts.values()):>3}\n')

    fails, warns, _ = qa(mod)
    if fails:
        print('QA FAILURES - fix these before delivering:')
        for f in fails:
            print(f'  X {f}')
    else:
        print('QA: no failures.')
    if warns:
        print('\nQA warnings - judgment calls, decide and say which:')
        for w in warns:
            print(f'  ! {w}')
    print('\nTwo checks this script cannot make. Make them by hand:')
    print('  1. Would a local recognize every Tier 1 name?')
    print('  2. Could each "ask" be said yes to in a single email reply?')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit('usage: build_partners.py partner_data_<city>.py')
    main(sys.argv[1])
