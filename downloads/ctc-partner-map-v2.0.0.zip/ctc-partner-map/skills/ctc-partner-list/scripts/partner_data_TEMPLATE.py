# -*- coding: utf-8 -*-
"""
Partner data module for the CTC partner map.

Copy to partner_data_<city>.py, fill in, then:
    python3 build_partners.py partner_data_<city>.py

BEFORE FILLING THIS IN, read references/worked-example.md and look at
partner_data_EXAMPLE.py, which is this file filled in for one city. An empty
template plus a field name is not enough to write a good entry from, and the
example carries weak-against-strong versions of every field. The example is
illustrative and unverified. Never carry its content into a real city.

Entry format for every partner, as a dict. Seven keys are required; "note" is
optional and is an empty string when there is nothing to say.

    {
      "org":      "Organization name",
      "category": "One of the CATEGORIES list below",
      "why":      "Per voice.md section 6, 'Partner map why lines'",
      "ask":      "Per references/partner-bar.md, The ask",
      "contact":  "One of the four forms in references/partner-bar.md, "
                  "Contacts. Never an email address.",
      "url":      "https://...",
      "source":   "workbook" | "reconsidered" | "gap research" | "lead added",
      "note":     "Optional. A failed check the entry was kept despite, a "
                  "scope caveat, or a warning about the approach.",
    }

The QA gate in build_partners.py fails the build on em dashes, volatile
figures (dollar amounts, percentages, cohort counts) and an "@" in the contact
field. Tier sizes it expects are in references/partner-bar.md, How many.
"""

CITY = "Houston"

# One line under the title.
SUBTITLE = ("Organizations to approach for the Climate Tech Houston chapter, "
            "ordered by when to approach them.")

# Optional note pinned to the title row.
TAB_NOTE = ("Built from CTC_City_Resources_Houston.xlsx as edited by the "
            "chapter lead, plus gap research on the four categories a resource "
            "workbook does not cover.")

CATEGORIES = [
    "Accelerators and incubators",
    "Universities and research centers",
    "Capital",
    "Civic and government",
    "Corporates and industry",
    "Coworking and innovation districts",
    "Professional and affinity groups",
    "Nonprofits and advocacy",
    "Arts, culture, and civic venues",
]

# ---------------------------------------------------------------------------
# TIER 1 - approach in the first 30 days.
# Can host or co-host now, audience overlaps directly, contact route is visible.
# This is where the weight goes. Expected size: references/partner-bar.md.
# ---------------------------------------------------------------------------
TIER_1 = [
    # {
    #   "org": "", "category": "", "why": "", "ask": "",
    #   "contact": "", "url": "https://", "source": "workbook", "note": "",
    # },
]

# ---------------------------------------------------------------------------
# TIER 2 - approach at 60 to 90 days.
# Useful, but wants a warm introduction or a track record first.
# ---------------------------------------------------------------------------
TIER_2 = []

# ---------------------------------------------------------------------------
# TIER 3 - later.
# Aspirational, large, or slow moving. Real, but not a first-quarter target.
# ---------------------------------------------------------------------------
TIER_3 = []

# ---------------------------------------------------------------------------
# NOT APPROACHING - organizations considered and set aside, with the reason.
# This sheet is why the lead trusts the other three. Format:
#     ("Organization", "Reason in one line")
# ---------------------------------------------------------------------------
NOT_APPROACHING = [
    # ("Example Org", "No local staffed presence. National program only."),
]
