---
name: ctc-partner-list
description: Turn a Climate Tech Cities city resource workbook into a partner outreach plan - a tiered list of who a chapter lead should approach, what to ask each for first, and in what order, plus the four categories a resource workbook deliberately leaves out. Use this skill whenever the user has a CTC_City_Resources workbook and wants partners, a partner map, an outreach plan, or "who should I contact in this city", or says a phrase like "now do the partner map" after the resource workbook was built. Also use it when a user asks for chapter partners, venue partners, event co-hosts, or a launch outreach list for a city. Always use it even if the user only wants one category or "just a few names to start". Do NOT use it to research a city's resources from scratch - that is ctc-city-resources, stage one of this plugin. Do NOT use it to find event calendars - that is ctc-source-map.
---

# CTC Partner List

Stage two of the `ctc-partner-map` plugin. Takes the resource workbook produced
by `ctc-city-resources`, as edited by the chapter lead, and turns it into a
partner outreach plan: who to approach, what to ask for first, and in what
order.

## What you will get back

One file, `CTC_Partner_Map_<City>.xlsx`, with two sheets.

**Sheet 1, `Partners`.** Three tiers, each under a header carrying the count
and the approach window (Tier 1 first 30 days, Tier 2 at 60 to 90 days, Tier 3
later). Nine columns: Organization, Category, Why them, Ask for first, Contact
route, Website, Source, Status, Note. The first five are what the lead reads
on the morning they write the email:

| Organization | Category | Why them | Ask for first | Contact route |
|---|---|---|---|---|
| Greentown Labs Houston | Accelerators and incubators | Their member companies are the founders we want in the room, and the building has event space they already open to outside groups. | Co-host our launch mixer in your event space on a weeknight in October. | Community or events team, via the contact form on the Houston page |
| Houston Renewable Energy Group | Professional and affinity groups | They already assemble the exact audience we want on a recurring meeting schedule, and they meet at rotating venues rather than defending one of their own. | Co-host one of your monthly meetings as a joint session with our chapter. | Contact form on the site. Do not use the published inbox address |
| Houston Public Library | Arts, culture, and civic venues | Free meeting rooms across the city and a walk-in audience that is exactly the readers who are curious about climate work but not yet in it. | Book a meeting room for a free introductory climate careers evening. | Meeting room reservation form on the library site |

Website is the canonical URL. Source is one of `workbook`, `reconsidered`,
`gap research`, `lead added`. Status starts as `Not contacted` and is the
lead's to update. Note is empty unless there is a caveat to carry.

**Sheet 2, `Not approaching`.** Two columns, Organization and Why not: every
organization considered and set aside, with a reason a reader could check.

**The chat summary that comes with it**, in about this shape:

> Houston: 9 in Tier 1, 4 in Tier 2, 2 in Tier 3, 5 on Not approaching. One came back in from the resource workbook's exclusions, CenterPoint Energy, on speaker access. Gap research added one coworking district, one professional group, one nonprofit, two civic venues, and three more in the workbook's own categories. Capital is empty in Tier 1, which is usual: funds rarely host. Cup of Joey is kept despite a failed check because you asked for it; the note says which check. This workbook is also what `ctc-opportunities` reads for local grants and programs each month, so keep it in your project.

The rows above are from `scripts/partner_data_EXAMPLE.py`, which is
illustrative and not verified data. A fuller excerpt of the finished workbook
is in `references/sample-output.md`. To see the real file, run
`python3 scripts/build_partners.py scripts/partner_data_EXAMPLE.py`.

The workbook has a second use: it is the Tier 4 (local) input to
`ctc-opportunities` in the `ctc-newsletter` plugin, and the "Later, Partners"
stage of the chapter launch site. Say so once at delivery.

## What this is for

Climate Tech Cities is a network of volunteer-run city chapters. A new chapter
becomes real when it runs events and publishes a newsletter, and both depend on
partners: someone with a room, someone with an audience, someone who will put a
speaker on a panel.

The person who reads this file is a volunteer chapter lead, usually in their
first month, with a full-time job elsewhere and no background in partnerships.
The map works when they open it on a Tuesday morning, read one row, and send
that email without having to decide anything.

That is where every rule here and in `references/partner-bar.md` comes from.
Tier 1 is capped because their month is capped. Asks are concrete because a
vague ask makes them compose an email from scratch. Contact routes are
researched because hunting for one is the step where an evening dies. When
you hit a case this skill does not cover, reason from that person and that
Tuesday morning.

A second reader exists occasionally: the central team, profiling a city before
recruiting a lead there. Same file, same standard.

## Input

One `.xlsx`, the resource workbook for the city, ideally edited by the lead.
Nothing else is required.

If no workbook is supplied, see Step 0. Do not start researching from scratch
here.

## Output

One standalone `.xlsx` named `CTC_Partner_Map_<City>.xlsx`, containing the two
sheets described above.

**This is a separate file from the resource workbook, deliberately.** The
resource workbook is public facing and feeds the chapter page on
climatetechcities.com. This one carries contact routes, approach order, and
status, which is internal working state. It is never merged into the resource
file and no partner tab is ever written there.

Always deliver the actual file. Research notes and tables in chat are inputs to
the job, not the job. If the turn ends without an `.xlsx` in
`/mnt/user-data/outputs/` presented to the user (present_files), the task is
not done.

---

## The bar

The map is finished when the chapter lead could send ten emails from it tomorrow
morning without having to think, and when a local reading it would not name an
obvious omission or spot a name that does not belong.

The failure modes at the end of this file describe what a bad map looks like.
Read them before you deliver, not after.

---

## Read these first

| File | What it holds | When |
|---|---|---|
| `references/partner-bar.md` | The inclusion test, why it differs from the resource bar, the four checks, the ruled cases, the nine categories and the block mapping, tiering and tier sizes, asks, contacts | Before anything else. This is the most important file |
| `references/worked-example.md` | A complete filled-in map, annotated, with weak and strong versions of every field | Before writing any entry |
| `references/verifier.md` | The second-pass check run on the finished map before it is handed over | At Step 7b, after the file exists |
| `references/gap-research.md` | The research prompt for the four uncovered categories and the category 9 pass | Before researching |
| `../ctc-partner-outreach/references/voice.md` | How CTC sounds, the banned words, and section 6 "Partner map why lines". This is the plugin's one copy of the CTC voice file | Read `references/voice.md` before writing any prose, via that path |
| `references/sample-output.md` | A fuller excerpt of a finished map and its chat summary | Whenever you want to see what done looks like |

`scripts/read_workbook.py` reads the resource workbook back out.
`scripts/partner_data_TEMPLATE.py` is the data file to fill in.
`scripts/partner_data_EXAMPLE.py` is the same file filled in and runnable.
`scripts/build_partners.py` renders the workbook and runs the QA gate. Do not
hand-roll openpyxl formatting.

## Environment

- **Where the scripts are.** This skill installs as part of the
  `ctc-partner-map` plugin, and the install path differs between accounts. Do
  not assume one. Locate it once at the start and reuse it:

  ```bash
  SKILL=$(dirname $(find /mnt/skills -name read_workbook.py 2>/dev/null | head -1))
  echo $SKILL
  ```

- **Work in a writable directory.** The skill directory is read only. Copy the
  template out before filling it in:

  ```bash
  mkdir -p /home/claude/work && cd /home/claude/work
  cp $SKILL/partner_data_TEMPLATE.py partner_data_<city>.py
  ```

- **openpyxl** is required by both scripts. If the import fails:
  `pip install openpyxl --break-system-packages -q`
- **Research tool.** An extended or deep research tool, if the session has one,
  is the right instrument for Step 3, and one call replaces most of the search
  volume. Without one, run fifteen or more distinct `web_search` calls plus
  page fetches: four categories, four or more angles each. If a category has
  returned nothing after three differently phrased searches, that is a finding
  about the city. After one search, it is a finding about the search.
- **`curl` and `requests` cannot reach arbitrary domains** from the sandbox,
  which reaches an allowlist of package registries only. They fail in ways
  that look like the site being down. Use the fetch tool for anything on the
  open web. A URL never observed resolving has not been checked.
- **Outputs go to `/mnt/user-data/outputs/`.** The build script writes there
  already.
- Do not use the words config, registry, schema, or pipeline with the lead.
  Say settings file, source list, spreadsheet, and the stages.

---

## Step 0 - Intake

Chapters are not required. This plugin runs for any city, including one with no
chapter and no lead yet, because a city profile is often what central wants
before recruiting anyone. Never ask for a chapter settings file and never block
on one.

Three cases.

**A workbook was attached.** Confirm the city and go to Step 1.

**No workbook, but the resource workbook exists from earlier in this
conversation.** Offer it: "I can run on the workbook from earlier, or you can
upload an edited version." Wait once, then proceed on whichever they choose.

**No workbook at all.** Say plainly that stage one comes first, and offer to run
it: "The partner map is built from the resource workbook. I can run
`ctc-city-resources` for [city] first and then come back to this, or you can
upload an existing workbook."

Do not research a city from scratch inside this skill. That duplicates two
verification passes and an audit that already exist upstream.

## Step 1 - Read the workbook

```bash
python3 $SKILL/read_workbook.py <path to workbook>
```

Three things come back and all three matter.

**The roster.** Every organization with its block, type, focus, URL, and
published description. These rows have already passed two research passes and
an adversarial audit, so checks 1 and 2 of the partner bar (real and local,
active) are settled for them and are not re-run. Checks 3 and 4 (audience
overlap, a route in) are not, because the workbook never asked them: every
roster row still goes through those two, and some end up on Not approaching.

**Rows carrying no renderer formatting.** Usually organizations the lead typed
in by hand, which makes them the highest-signal entries in the file. Occasionally
it means the whole file was round tripped through another tool, which the script
will make obvious because every row will be flagged. These go through all four
checks in Step 4.

**The reviewer notes.** This is where `ctc-city-resources` recorded what it
excluded and why. Treat this as the highest-yield input in the whole skill.

**If the script returns no rows, stop.** It exits with an error and says why.
That is a wrong file or a wrong sheet, never a finding about the city. Ask the
user before doing anything else, and never quietly replace the missing roster
with research of your own.

## Step 2 - Reconsider the exclusions

Before searching for anything new, walk every excluded organization against the
partner bar in `references/partner-bar.md`.

The resource bar asks whether a founder can walk through the door. The partner
bar asks whether they would co-host, host, promote, or send their people. The
two most common exclusion reasons upstream are national scope and admission on
reputation, and both routinely flip.

A utility a founder cannot raise from will put a speaker on a panel. A national
nonprofit with a named local organizer is not a city resource but is a strong
week-two conversation.

Say out loud how many came back in. Somewhere between a fifth and a half of a
recorded exclusion list is the rough expectation. Zero across a substantial list
means the partner bar is being applied as a copy of the resource bar; all of
them means no bar is being applied at all. Either way, go back to
`references/partner-bar.md`.

## Step 3 - Research the gap

The workbook covers five categories. Four are missing and they are missing on
purpose, because a founder resource page has no reason to list a botanical
garden:

6. Coworking and innovation districts
7. Professional and affinity groups
8. Nonprofits and advocacy
9. Arts, culture, and civic venues

**Ask how they want to fill them first.** The lead may already know
organizations in these categories, and a name they vouch for beats anything
research returns. Ask in one message and wait:

> Four categories are missing from the resource workbook on purpose: coworking and innovation districts, professional and affinity groups, nonprofits and advocacy, and arts and civic venues. How do you want to fill them?
>
> **A. You name some, then I research too.** Paste anything you already know and I verify it, then run the full search on top. Best coverage, and what I would recommend.
>
> **B. You name all of them.** I verify what you paste and stop there. Fastest, and a fair choice if you already know the scene.
>
> **C. I research everything.** Nothing needed from you. I find them and bring back a verified list to review.
>
> Paste what you have straight into your reply and I will take that as option A, or just tell me which you want.

**If they paste names or links, take that as A and get on with it.** Do not
make someone pick from a menu when they have already answered.

Then branch:

- **Option B.** Verify what they gave you in Step 4 and skip the research
  prompt entirely. Do not quietly run it anyway.
- **Option A or C.** Use the prompt in `references/gap-research.md` verbatim,
  substituting the city and the metro scope already fixed upstream. Run
  category 9 as its own pass; `references/gap-research.md` says how, because a
  climate search never returns a library.

Whichever option, also seed CTC's own partners wherever they have a local
presence: My Climate Journey, Women and Climate, Climatebase, SOSV, Climate
Draft, Newlab, ClimateRaise. An existing organizational relationship is the
warmest path a new lead has.

## Step 4 - Verify additions

Everything that did not come off the roster, meaning what the lead pasted in
Step 3, what research returned, what came back in from the exclusions, and any
row the lead typed into the workbook by hand, gets the four checks in
`references/partner-bar.md`.

**Anything the lead supplied is never dropped silently.** If a check fails on
one of theirs, keep it, name the failed check in the note field, and say so at
delivery. They live in that city and the research does not. An organization
with a bad website that a local knows is thriving is a research failure, not a
partner failure.

## Step 5 - Tier and write the asks

Tier every entry per `references/partner-bar.md`, Tiering, which also holds the
expected size of each tier. Tiering is about when to approach, not how good the
organization is.

Every entry gets one concrete first ask, per `references/partner-bar.md`, The
ask, and a contact route in one of the four forms in `references/partner-bar.md`,
Contacts.

Record everything set aside on the Not approaching sheet with its reason.

The weak and strong versions of every field are in
`references/worked-example.md`. Write against those, not against the field names.

## Step 6 - Build the data file

Copy `partner_data_TEMPLATE.py` into the working directory, fill it in, and keep
it as a real Python module. The data-module plus shared-renderer pattern is what
makes revisions cheap.

Every entry needs the seven required fields; `note` is optional and is an empty
string when there is nothing to say. Read `references/voice.md` (the plugin's
copy is at `../ctc-partner-outreach/references/voice.md`), section 6 "Partner
map why lines", before writing any prose. No em dashes, no dollar amounts, no
percentages, no cohort counts, so the file stays timeless; the QA gate fails
the build on any of them.

`scripts/partner_data_EXAMPLE.py` is a filled-in version to calibrate density
and voice against. It is illustrative, not verified data, and nothing in it
should be carried into a real city.

## Step 7 - Render and QA

```bash
cd /home/claude/work && python3 $SKILL/build_partners.py partner_data_<city>.py
```

The script writes to `/mnt/user-data/outputs/CTC_Partner_Map_<City>.xlsx` and
prints a summary plus a QA report. Read the output rather than assuming it
passed.

It fails the build on:

- A blank required field
- A URL that is not `https://`
- A category not in the declared list
- The same organization in two tiers
- An em dash or en dash in copy
- A volatile figure in copy
- An `@` in the contact route

It warns, and a warning is a judgment call to decide and state at delivery, on:

- Tier 1 under 6 or over 14, or fewer than 12 partners in the whole map
- An empty Not approaching sheet
- Every entry sourced from the workbook, or nothing sourced as reconsidered
- A gap category with no entries
- An ask reused word for word across entries
- A `why` over 40 words
- A tab note still marked as the worked example

A Tier 1 of five in a thin city is a correct output and the warning exists to
make you state that rather than pad.

Two checks the script cannot make. Make them by hand:

- **Recognition.** Would a local recognize every Tier 1 name?
- **The single-email test.** Could each ask be said yes to in one reply?

## Step 7b - Verify the file

Run `references/verifier.md` on the built map: a fresh, adversarial pass that
opens every organization and contact route, tests every ask, and checks every
`why` line. That file says how to run it as a subagent where the session has one
and as a separate step where it does not. Fix the data module, re-run
`build_partners.py`, and only then go on.

## Step 8 - Ask once for what is missing

Present the map, then ask one question: is anything obvious missing.

A lead who has lived there five years will name two or three organizations no
search returns. Add what they give you, run Step 4 on them, and rebuild.

Ask once. If they say no or say nothing, deliver and stop.

## Step 9 - Deliver

Present the file (present_files). Then in a few lines: the count per tier, how
many came back in from the resource workbook's exclusions, what the gap research
added per category, anything empty and why, anything kept despite a failed
check, and the one line about the workbook's second use in `ctc-opportunities`.

Keep it short. No preamble, no restating the method.

## Step 10 - Hand off to outreach

The map is a list of names until someone writes to them. Offer the next stage:

> That is who to approach and in what order. When you are ready to write to any of them, say `/ctc-partner-outreach` and name the organization. It reads this map, asks you a few questions, and drafts the message in your own voice.
>
> Start with two or three from Tier 1 rather than working down the whole list.

Offer once. Do not chain into it.

---

## Common failure modes

Recognize these in your own draft before the lead does.

**Applying the resource bar again.** The most likely failure by far. It looks
like diligence and produces the resource workbook re-sorted. Symptom: every
entry has `source: workbook`, nothing came back in from the exclusions, and
categories 6 to 9 are thin or empty.

**A Tier 1 the lead cannot finish.** Every entry defensible, the set unusable.
A Tier 1 they cannot finish is one they never start. The size the gate expects
is in `references/partner-bar.md`.

**Vague asks.** "Discuss a partnership" in the ask column means Step 5 was
skipped.

**Descriptions in the `why` column.** Read that column on its own. If it reads
like a directory of local organizations rather than a set of reasons, it was
written about the organizations instead of about the chapter.

**Contact routes that are all "website".** The route was not researched. Half
of those organizations publish a named events or partnerships contact.

**An empty Not approaching sheet.** Nothing was refused, which means the bar was
never applied. Even a thin city produces refusals.

**Skipping category 9.** It reads as the least serious category and it serves
the readers not yet working in climate, which is the audience a new chapter
grows fastest from. `references/partner-bar.md` has the figure.

**Dropping the lead's own additions.** They know the city. A failed check on
their entry is information for them, not a decision for the skill.

**Treating an empty read as a thin city.** If `read_workbook.py` returns
nothing, the file or the sheet is wrong. Ask.

**Shipping research instead of the file.** The resource skill made this mistake
more than once. The turn is not done until the workbook exists and is presented.
