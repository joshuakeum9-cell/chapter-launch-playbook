---
name: ctc-partner-outreach
description: Draft partner outreach messages for a Climate Tech Cities chapter lead, in their own voice, by walking them through the seven elements a partner email needs. Use this skill whenever someone wants to write to a partner, venue, sponsor, or co-host, asks for an outreach email or a cold email, says "help me write to [organization]", has a partner map and wants to start contacting people, asks how to ask for a venue or a co-host, or wants a template for partner outreach. Always use it even if they only want one message or say they just need a quick draft. Do NOT use it to research who to approach, which is ctc-partner-list, or to write newsletter copy, which is ctc-assemble.
---

# CTC Partner Outreach

Stage three of the `ctc-partner-map` plugin. Turns a name on the partner list into a message the lead can actually send.

The message goes out under their name, from their address, and they have to have the conversation it starts. So this skill drafts, and they edit. It never sends.

## What you will get back

For one organization: the message in chat, ready to copy into email or LinkedIn, followed by four short lines. In about this shape:

> **Subject:** October meetup at Tidewater?
>
> Hi Dana,
>
> I run Climate Tech Alderport, the new local chapter of Climate Tech Cities. I was at your spring open house in the cannery and spent most of the evening talking shore power with two of your member teams, which is exactly the conversation our readers keep asking for.
>
> We're hosting our first meetup in October and we'd like to hold it in your building. You'd get about forty founders, engineers and investors in your space on a weeknight you weren't using, and we handle the invite, the run of show and the cleanup. (...)
>
> Do you ever open the event space to outside groups on weeknights? If so, I'd take fifteen minutes to walk through dates whenever suits you.
>
> Priya
>
> **Four question test.** Why them: the open house and the shore power teams. Why now: the October date is being set. What is in it for them: forty people in their space, no work, their members on the program. What exactly: one yes-or-no question, then a short call.
> **Word count:** 165.
> **Check this line:** the open house sentence. It only works if you were actually there.
> This is a draft. Put it in your own words before it goes out.

For several organizations at once: the same thing for each, delivered together as one `.docx` file.

The full version of that exchange, from the first question to the follow up, is in `references/sample-output.md`. The organization and the lead in it are fictional.

## Input

An organization to write to. Everything else comes from the interview, the chapter settings file if one is in the project, or the partner map if one exists.

## Output

One message: in chat, ready to copy, plus the four lines above. Two or more messages in one session: one `.docx` with all of them, presented to the user (present_files).

---

## The bar

The lead reads it, changes a line or two, and sends it without rewriting. If they would rewrite it from scratch, the voice work failed.

---

## Read these first

| File | What it holds | When |
|---|---|---|
| `references/voice.md` | How CTC sounds and the banned words. Section 6 "Partner outreach emails" is the part that applies here. This is the plugin's one copy of the CTC voice file | Read `references/voice.md` before writing any prose |
| `references/seven-elements.md` | The seven elements, the failure each one prevents, weak-versus-strong examples, the four question test | Before drafting anything |
| `references/sample-output.md` | A complete exchange, from the first question to the follow up | Whenever you want to see what done looks like |

Do not use the words config, registry, schema, or pipeline with the lead. Say settings file, source list, spreadsheet, and the stages.

---

## Step 1. Work out what you already know

Do not ask for anything you can find.

**From the chapter settings file, if one is in the project:** city, chapter name, lead name, reply address, send day, sign off.

**From a partner map workbook, if one is in the project or the conversation:** the organization's category, tier, why-them line, the suggested first ask, and the contact route. That is four of the seven elements already half answered, so read it before the interview and confirm rather than ask.

**From the conversation itself:** if the lead has already described the organization or what they want, take it.

Say in one line what you picked up, then start.

## Step 2. Get a writing sample

Ask once, early, because it changes every draft after it:

> Before I draft anything: paste an email you have written recently, to anyone, about anything. It does not have to be a good one. I will match how you actually write rather than guessing.
>
> If you would rather skip it, say skip and I will write plainly, and you can adjust the voice yourself.

**How the sample and the voice file fit together, stated once:** `references/voice.md` sets the CTC baseline, and the lead's writing sample overrides it for their own outreach. Where the two differ on sentence length, greeting, sign off, contraction use, formality, or how they open and close, the sample wins, because the message goes out under their name. The banned words and constructions in voice.md section 5 still apply, and so do the seven elements. Do not copy typos or filler from the sample.

If they skip, write to voice.md as it stands and say once in the delivery that the voice is generic and worth a pass.

If past conversations are searchable and the lead has written outreach in them, you may use that as the sample instead of asking, and say in one line that you did.

## Step 3. The interview

Seven questions, **one per message**, in the order of `references/seven-elements.md`. Never a wall.

Each question does three things: names what it is for, gives an example, and offers a way out for a lead who does not know.

1. **Who are you writing to, and what do you know about them?** Anything specific and true: a program they run, a cohort, an event, a mutual connection. If they do not know, offer to research the organization and come back with two or three concrete things to choose from.

2. **What kind of partnership?** Venue host, event co-host, speaker, cross-promotion, newsletter share, community partner. If the partner map has a suggested first ask, propose that and let them confirm.

3. **What do they get out of it?** The hardest question and the most important. Prompt with the currencies listed under element 3 in `references/seven-elements.md`. Push back if the answer is really about what the chapter gets.

4. **Why should they believe you?** One or two proof points. If the chapter is new and has none of its own, use the network proof points under element 4. Never invent a number, and if they give one, use theirs.

5. **What exactly would you do together?** Concrete enough to picture. A month, a rough size, who does the work. "Our October meetup in your space, about forty people, a Tuesday, we handle everything."

6. **What are you asking for in this email?** Default to the low friction ask under element 6: a short call, or a single qualifying question.

7. **Email, LinkedIn, or a warm introduction?** Changes length and opening. LinkedIn runs shorter and drops the subject line. A warm intro names the person connecting them in the first sentence.

**If they answer several at once, take them all and skip ahead.** If they say "you decide" on any question, make the call, draft it, and mark that line as the one to check.

## Step 4. Draft

Build the message in the element order in `references/seven-elements.md`.

**Lead with the opportunity you are creating for them, never with what you want.** This is the single highest-leverage rule in the skill.

**100 to 175 words, counted.** This is the one place the range is set for this skill; voice.md section 6 states the same numbers. Over 175 is not a stronger pitch, it is one with a lower chance of being finished.

Write a subject line for email. Six words or fewer, specific, no clickbait.

## Step 4b. Check the draft

Before delivering, read the draft once as the recipient, with no memory of the interview: does the first sentence name something true and specific about them, is there exactly one ask, is every fact one the lead supplied, and is the word count 100 to 175? Then scan it against `references/voice.md` section 5. Fix anything that fails. Where the session has a subagent or task tool, this read can be a separate agent given only the draft and this skill's `references/seven-elements.md`.

## Step 5. Deliver

Give the message, then, in a few lines:

- **The four question test, answered.** Why them, why now, what is in it for them, what exactly is being asked. If any answer is thin, say which and why.
- **The word count.**
- **One line naming what to check.** Usually the personalization, since it is the line most likely to be slightly wrong and the most damaging when it is.
- **That it is a draft and should go out in their words.** Every delivery, every time.

Then stop.

## Step 6. Offer the follow up, once

After the first message, offer a follow up for no reply after a week or ten days. Three sentences, no guilt, one new piece of information, an easier ask than the first.

Offer once. If they say no, drop it.

---

## House rules

**Never send anything.** This skill writes. The lead sends.

**Never invent a fact, a number, a name, or a relationship.** No made up subscriber counts, no attendance figures that have not happened, no claiming a connection that does not exist. If the lead supplies a number, use theirs. If nobody has one, use the network's existence instead.

**Never claim a warm introduction that has not been offered.** "[Name] suggested I reach out" is only written when [Name] actually did.

**Never write around missing personalization.** If there is no real, specific, true thing to open with, go back to question one or research the organization. The openers that announce a missing personalization are on the banned list in voice.md section 5.

---

## Failure modes

**The lead does not know anything about the organization.** Offer to research it and come back with two or three specific true things. Do not write around it with vague flattery.

**The value proposition is really about the chapter.** The most common failure. "It would help us grow" is not their benefit. Ask again, from their side: what does this organization want more of, and can the chapter supply any of it.

**They want to skip the interview and get a template.** Give them the shape from `references/seven-elements.md` and say plainly that a template with the personalization missing is the thing that gets ignored. Then offer to run the interview anyway, one question at a time.

**They ask for twenty messages at once.** Run the interview once for the shared parts, which are elements 3, 4, and 6, then ask only the personalization question per organization. Deliver as one document. Never reuse one personalization across two organizations.
