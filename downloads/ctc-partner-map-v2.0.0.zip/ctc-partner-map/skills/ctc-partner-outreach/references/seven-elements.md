# The seven elements

Every message this skill produces has all seven. A message missing any one of them is the reason partner outreach usually fails, and each element below names the specific failure it prevents.

**The order matters:** personalization, then the opportunity, then their benefit, then proof, then the specific collaboration, then the ask.

**The rule underneath the order:** lead with the opportunity you are creating for them, never with what you want from them. That single shift is worth more than everything else on this page.

How the message should sound is in `references/voice.md` (section 6, "Partner outreach emails", and the banned list in section 5) and in `SKILL.md` Step 2, which says how the lead's own writing sample overrides that baseline. This file is about what the message contains.

---

## 1. Personalized opening

Show you know who they are and what they do. Reference a recent initiative, program, cohort, event, or a shared connection.

**Prevents:** the message reading like it was sent to forty organizations, because it was.

| Weak | Strong |
|---|---|
| I came across your organization and was impressed | I saw you ran the fall hardware cohort out of the Ion, and three of those founders are exactly who our readers are trying to meet |

The weak version is on the banned list in voice.md for a reason: it announces that personalization was attempted and abandoned, which is worse than no personalization. If the lead cannot name one specific true thing about the organization, that is a signal to research it rather than a signal to write around it.

## 2. Clear reason for reaching out

One or two sentences naming the partnership type: venue host, event co-host, speaker, cross-promotion, newsletter share, community partner.

**Prevents:** the recipient finishing the email unsure what kind of relationship is being proposed, which reads as unserious.

## 3. Partner-specific value proposition

The most important element. Answer the question they are actually asking, which is "why should I care."

**Prevents:** the message being about the chapter instead of about them.

Frame everything as their upside. For a chapter partnership the honest currencies are: reach to a defined local audience, programming they do not have to produce, association with a national network, a filled room on a night they were not using, and access to people they want to recruit or fund. This is the list Step 3, question 3 of the interview prompts with.

| Weak | Strong |
|---|---|
| We would love your support as we launch | Your space gets forty climate people in it on a Tuesday, and you do not have to organize anything |

Do not overstate. A new chapter with two hundred subscribers should say two hundred, or say nothing, and never imply thousands.

## 4. Credibility

One or two proof points. Not a history.

**Prevents:** the recipient having no reason to believe the event will actually happen or the audience actually exists.

For a new chapter the honest proof points are the network rather than the chapter: Climate Tech Cities runs chapters in ten cities, the New York newsletter has been publishing since 2021, and the community spans founders, investors, researchers, and policy people. If the chapter has its own numbers, use those instead, because local beats national. This is the list Step 3, question 4 of the interview draws on.

If the lead does not have a number of their own, use the network's existence rather than a metric.

## 5. The proposed collaboration

Make it concrete enough to picture.

**Prevents:** a yes that means nothing, because neither side knows what was agreed.

"We could host our October meetup in your space, forty people, a Tuesday evening, we handle everything" is concrete. "Explore ways our organizations might work together" is not.

## 6. Low friction call to action

Ask for something small. A fifteen or twenty minute call, or a single qualifying question. This is the default Step 3, question 6 of the interview offers.

**Prevents:** a no that is really a not-right-now, because the ask was too big to say yes to on first contact.

Never ask them to commit to the partnership in the first email. The ask is the conversation, not the outcome.

| Weak | Strong |
|---|---|
| Let us know if you would like to become a partner | Would you be open to a fifteen minute call in the next couple of weeks to see if it fits? |

A qualifying question also works, and is lower friction still: "Do you ever open the space to outside groups on weeknights?"

## 7. Brevity

Short enough that the whole pitch is understood on one read. The word range is set in `SKILL.md`, Step 4, and counted at delivery.

**Prevents:** the message not being read at all.

---

## The four question test

Before any message ships, it answers all four. If it cannot, it is not ready.

| Question | Which element carries it |
|---|---|
| Why them? | 1, personalization |
| Why now? | 2, the reason for reaching out |
| What is in it for them? | 3, their value proposition |
| What exactly am I asking for? | 6, the call to action |

State the four answers back to the lead when delivering. If any one of them is thin, say so plainly rather than shipping a message that will not land.
