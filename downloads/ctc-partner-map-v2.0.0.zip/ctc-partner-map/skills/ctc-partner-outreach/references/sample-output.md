# Sample output

What a run of `ctc-partner-outreach` looks like from the first message to the follow up, so a new chapter lead knows what to expect before running it.

**Everything on this page is illustrative.** Alderport is a fictional city, Climate Tech Alderport is a fictional chapter, Priya is a fictional lead, and Tidewater Climate Labs and Dana are invented. The organization comes from the fictional resource workbook in `ctc-city-resources/scripts/city_data_EXAMPLE.py`. Nothing here is a template to reuse: the personalization is the point, and it is different every time.

---

## What the lead said

> /ctc-partner-outreach Tidewater Climate Labs

## Step 1. What Claude picked up

> From your settings file: Climate Tech Alderport, you sign off as Priya, replies go to your chapter address. From the partner map: Tidewater Climate Labs is Tier 1, Accelerators and incubators, suggested first ask is to co-host the launch meetup in their event space, contact route is the community team via the form on their site. So I have the partnership type and a first ask already; I will confirm those rather than ask.

## Step 2. The writing sample

> Before I draft anything: paste an email you have written recently, to anyone, about anything. It does not have to be a good one. I will match how you actually write rather than guessing. If you would rather skip it, say skip and I will write plainly, and you can adjust the voice yourself.

The lead pastes a short email to a colleague. Claude reads it for sentence length (short), greeting ("Hi [first name],"), sign off (first name only), contractions (on), formality (low). Those override the voice file's defaults where they differ.

## Step 3. The interview, one question per message

**1.** *Who are you writing to at Tidewater, and what do you know about them? Something specific and true: a program, a cohort, an event, someone you both know. If nothing comes to mind, I can look and bring back two or three things to choose from.*

> Dana runs their community programming. I went to their spring open house and talked to two member teams about shore power.

**2.** *The partner map suggests asking them to co-host your launch meetup in their event space. Is that the partnership you want, or is it something else: speaker, cross-promotion, newsletter share?*

> Yes, venue for the October meetup.

**3.** *What does Tidewater get out of it? Not what the chapter gets. The usual currencies are a filled room on a night they weren't using, programming they don't have to produce, reach to a local audience, or people they'd want to recruit or fund.*

> A room full of the founders and engineers they want as members, and their own teams get to present.

**4.** *Why should they believe the event will happen and the audience exists? One or two proof points. If the chapter has none yet, the network does: ten cities, the New York newsletter since 2021.*

> We're new. Use the network.

**5.** *What exactly would you do together? A month, a rough size, who does the work.*

> October, about forty people, a weeknight, we run everything.

**6.** *What are you asking for in this email? The default is a short call, or one yes-or-no question like whether they ever open the space to outside groups.*

> Both, question first.

**7.** *Email, LinkedIn, or a warm introduction?*

> Email.

## Step 4 and 5. The draft and the delivery

> **Subject:** October meetup at Tidewater?
>
> Hi Dana,
>
> I run Climate Tech Alderport, the new local chapter of Climate Tech Cities. I was at your spring open house in the cannery and spent most of the evening talking shore power with two of your member teams, which is exactly the conversation our readers keep asking for.
>
> We're hosting our first meetup in October and we'd like to hold it in your building. You'd get about forty founders, engineers and investors in your space on a weeknight you weren't using, and we handle the invite, the run of show and the cleanup. Your member companies get first billing on the program if they want it.
>
> Climate Tech Cities runs chapters in ten cities, and the New York newsletter has been going since 2021, so this isn't our first event even if it's our first one here.
>
> Do you ever open the event space to outside groups on weeknights? If so, I'd take fifteen minutes to walk through dates whenever suits you.
>
> Priya
>
> **Four question test.** Why them: the open house and the two shore power teams, which is specific and true. Why now: the October date is being set and you need a room. What is in it for them: forty of the people they want as members, in their space, with none of the work, and their own teams on the program. What exactly: one yes-or-no question, then a short call.
>
> **Word count:** 165.
>
> **Check this line:** the open house sentence. It only works if you were there and talked to those teams; if either detail is off, change it before anything else.
>
> This is a draft. Put it in your own words before it goes out.

What the draft does, element by element: opens on something only someone who was there could say (1), names the partnership in the second paragraph's first sentence (2), gives their upside before the chapter's (3), uses the network for proof because the chapter has none of its own yet (4), makes the event concrete enough to picture (5), and asks one small question with a short call behind it (6), in 165 words (7).

## Step 6. The follow up, offered once

> If Dana hasn't replied in a week or ten days, here is a follow up. Three sentences, one new piece of information, an easier ask.
>
> Hi Dana, one more note on the October meetup. Two of your member teams have since signed up to demo, so the room would be partly your own people. If a weeknight in October doesn't work, would you be open to us listing Tidewater as a venue option for the spring instead?
>
> The second sentence is only true if it is true. Swap in whatever has actually changed since the first email.

Then the skill stops. Nothing is sent.
