# CTC voice file

Read this before writing any prose for Climate Tech Cities: newsletter opening notes, picks, event descriptions, opportunity descriptions, partner outreach, city resource descriptions, and climate week guide intros. It is an instruction manual for how CTC sounds, built from verbatim passages in the New York chapter's Substack (the 2024, 2025, and 2026 NY Climate Week guides and the July 21 and Aug 18, 2026 weekly issues). Claude drafts to this standard; the human still rewrites the editorial blocks (opening note, picks, housekeeping) before anything ships.

## 1. Who is talking

A person who goes to these events, writing to friends in their city. The authors say where they will be ("Come find us at Shakes and Cakes with Climate Friends in Madison Square Park"), what is worth a trip ("always worth the trip to the Brooklyn waterfront"), and when things are quiet ("a lot quieter (including on the newsletter)").

The frame is big-tent and place-based ("the world's largest place-based climate tech community"). The signature move is the long list of who belongs: "startups, investors, corporate titans, scientists, policymakers, and grassroots activists". The recurring phrases are "big tent", "every job is a climate job", "a global network of local communities", and "and counting". Newcomers are addressed directly ("definitely read this if you're a first timer"), and free events get equal billing with invite-only ones.

The guides describe and the reader decides. Editorializing about how exciting something is reads as AI, and the editors will cut it.

## 2. The sound, in ten rules

1. **Sentence case in prose, subtitles, and guide headings.** The guides write "A guide to the guide", not "A Guide To The Guide". The newsletter's fixed section headings are the one exception: "This Week's Events", "Upcoming Events", "This Week in Detail", and "Join the Fun!" are printed as published and never rewritten.
2. **Contractions, always.** "It's a stunning space", "there's still plenty of ways to connect". Uncontracted prose sounds like a form letter.
3. **Concrete beats abstract.** "Take a Citibike rather than the subway at least once" does the work that "engage with the city" cannot.
4. **Name the neighborhood or venue.** Sheep's Meadow, Whoopsie Daisy in Brooklyn, Pier 57, the 1885 tall ship Wavertree. Location is the differentiator for a place-based community.
5. **State the price plainly.** "This free evening event", "the first glass of wine complimentary", "expense a ticket to". Cost is part of the decision to go.
6. **Verbs first in picks.** "talk sustainable finance", "hop on a boat", "roll the dice with". Day in bold, verb next, linked title last.
7. **Short declaratives carry the rhythm; one long list sentence per paragraph.** "Lean into the city itself." (5 words) "Get above 96th Street and below Canal." (7) Then one 30-plus-word sentence that lists everything. Never three long sentences in a row.
8. **Acknowledge quiet weeks and gaps without apologizing.** "(including on the newsletter)", "(too many people were out of town!)". Self-aware, never sorry.
9. **One exclamation mark per piece, at most, on something small.** "The Bronx is getting a river back!" The 2026 guide uses "(!)" in parentheses to shrug at its own word count.
10. **Describe; do not editorialize, and never invent.** What the event is, who runs it, where, what it costs. Never a speaker, venue, or price the source did not give you.

## 3. Verbatim examples that show the voice

### Openings

- "Hi all, Last week we pulled out our N95s once again as wildfire smoke subsumed the summer. The brown-orange skies, torrential rain, and tornado warnings have been stark reminders that climate change is here and now. For such a global problem, we continually find hope and inspiration in local community." (Weekly, July 21, 2026.) Topical hook, then the turn to community.
- "The Bronx is getting a river back! NYC is taking on its first "daylighting" project, uncovering a hidden stream to reduce flooding and improve resiliency (and quality of life) as climate change leads to more flooding. More at Bloomberg (gift link)." (Weekly, Aug 18, 2026.) Local news hook, one exclamation mark, a parenthetical, a source.
- "Climate Week is whatever you make of it. You can spend Monday watching six startups demo battery hardware for renters and Tuesday counting trees in Crotona Park with the NYC Parks Department." (Guide, 2026.) Short thesis, then named places.
- "The most important thing to know about NY Climate Week is that it's not just one big conference. Think of it more as a coral reef, providing the structure for 600+ independently organized events to swim and thrive. There are big fish, small ones, and dazzlingly weird ones, and never enough time to see them all." (Guide, 2024.) One metaphor, carried for two sentences, then dropped.
- "Politics requires visibility. Movements require community. And so we take heart that there are more culture events than ever this year, from Broadway to Hollywood to Late Night." (Guide, 2025.) The most editorial the guides get: three short sentences tied to a concrete observation.

### Event descriptions

- "Terraformation's inaugural summit is about the delivery of large-scale reforestation rather than the pledges. The room is curated down for organizations moving from concept to implementation: project developers with boots on the ground, funders deploying capital, corporates with real nature commitments, and the community leaders whose knowledge and land tenure make restoration possible." (Guide, 2026.) What it is, who it is for, nothing about excitement.
- "Pleiades Network and Out in Climate are hosting a summer mixer at Whoopsie Daisy, a women-owned wine bar in Brooklyn... This free evening event creates space for conversation and community-building among climate solution makers, with the first glass of wine complimentary." (Weekly, Aug 18, 2026, This Week in Detail.) Host, venue with a one-clause gloss, price.

### Picks

- "**Tomorrow** embrace the tides at the 🌊 2026 Offshore Wind Innovator Program: Q&A Social Hour or make calls (and friends!) at the ⏳ Manhattan Climate Changemakers Hour of Action or ⏰ Brooklyn Hour of Action" (Weekly, July 21, 2026.) Verb first, the aside in parentheses, events joined with "or".
- "**Wednesday** hop on a boat for 🚢 Energy Infrastructure Boat Tour with OHNY, expense a ticket to the ⚡ NY Executive Roundtable: Affordability & Grid Optimization, or get a casual drink at the 🍻 Climate Pints August Gathering" (Weekly, Aug 18, 2026.) Three registers in one line.
- "Start the week off with urban solutions at our morning 🗽 Climate Tech Demo Series, featuring 6 creative startup demos - no PPTs allowed!" (Guide, 2025, Top Hits.) The chapter's own event gets one detail, not a pitch.

### Housekeeping and sign-off

- "We've postponed Wednesday's Other Intelligence summit until later this year (too many people were out of town!) but are still looking forward to it in the Fall." (Weekly, July 21, 2026.) A postponement in one sentence, reason in parentheses, no apology.
- "Also, Climate Week is around the corner! Keep your eyes peeled for our first guide, and if you're planning any events for Climate Week NYC, send them our way by replying to this email." (Weekly, July 21, 2026.) The reader ask is one plain imperative, bolded in the original.
- "Don't sleep on two of our favorite Climate Week events: the Climate Film Festival and the Narrative Change Summit." (Weekly, Aug 18, 2026.) How the house says "don't miss" without saying it.
- "Til next week! Alec, Sonam, and the Climate Tech Cities team" (Weeklies, 2026.) The standard sign-off; the variant is "As always,".
- "We hope these streets will make you feel brand new and the big lights will inspire you! We look forward to seeing you! 🍎" (Guides, 2024, 2025, 2026.) The fixed guide sign-off, unchanged for three years. Do not rewrite it.

### Guide-to-the-guide and orientation prose

- "A guide to the guide: 💚 Heartwarming Masterpiece of an Introduction (You're here) / 📅 How to Climate Week (definitely read this if you're a first timer) / 🎯 Our Top Hits: Where We'll Be and What We Like" (Guide, 2026.) Self-deprecating about its own intro, direct with first-timers.
- "There are 978 events and a total of 33,717 words (!) - we've categorized all of them across 25 themes and picked our favorites." (Guide, 2026.) Scale as a number, reaction as a parenthetical.
- "If it's your first NY Climate Week, give yourself room to explore. Pick a few events you're excited about and leave time for the unexpected." (Guide, 2026.) Advice in short sentences, none over 25 words.
- "Don't feel like you need to go to everything or skip out on your day job (unless going to these events *is* your day job)." (Guide, 2024.) Permission to skip things, joke in parentheses.
- "Every job is a climate job! Find your next one at the 👷‍♀️ NextGen CleanTech Workforce Summit in the Lower East Side." (Guide, 2025.) The recurring phrase as a lead-in, then a neighborhood.

## 4. Weak and strong pairs

| Weak | Why it fails | Strong |
|---|---|---|
| "Hi everyone! Hope you're all having a great week. We've got an exciting lineup of events for you this week!" | No hook, stacked exclamation marks, promised excitement. | "Hi all, The Bronx is getting a river back! NYC is taking on its first daylighting project, uncovering a hidden stream to reduce flooding. Events are picking back up this week, and Climate Week is on the horizon." |
| "Don't miss this unmissable opportunity to dive deep into the future of adaptation with thought leaders from across the ecosystem." | Four banned phrases, zero facts. | "This session brings adaptation startups, investors, corporate buyers, and policymakers together to get concrete about how resilience gets built: parametric insurance, flood protection, heat mitigation." |
| "Join us for a vibrant evening of networking at a beautiful venue in the heart of Brooklyn!" | Filler adjectives; the venue is unnamed. | "Pleiades Network and Out in Climate are hosting a summer mixer at Whoopsie Daisy, a women-owned wine bar in Brooklyn. Free, first glass of wine included." |
| "Wednesday: Energy Infrastructure Boat Tour, NY Executive Roundtable, Climate Pints" | A list, not a pick. No verbs, no reason to choose. | "**Wednesday** hop on a boat for 🚢 Energy Infrastructure Boat Tour with OHNY, expense a ticket to the ⚡ NY Executive Roundtable, or get a casual drink at the 🍻 Climate Pints August Gathering" |
| "This transformative six-month fellowship empowers the next generation of climate leaders with world-class mentorship." | Every adjective is marketing; the deadline and the money are missing. | "The Climate Tech Fellowship is a six-month hybrid program with expert-led curriculum, 1:1 mentorship, and non-dilutive funding. Applications due August 1." |
| "I hope this email finds you well. I came across your organization and would love to explore ways to collaborate." | Three banned openers in a row; nothing about them or you. | "Hi Maria, I run the Climate Tech Cities chapter in Chicago. We saw your April hard-tech showcase at mHUB and want to send our members to the next one." |
| "Newlab is a cutting-edge innovation hub at the intersection of technology and sustainability." | Marketing copy; nothing a reader could not guess. | "Newlab is a hardware and deep-tech campus at the Brooklyn Navy Yard, home to 70+ climate startups and the annual New Climate Futures showcase." |
| "In today's fast-paced world, the built environment landscape is evolving rapidly. Attendees will explore..." | Throat-clearing opener, "landscape", "attendees will". | "Two panels on retrofit financing and one on heat pumps, hosted by Urban Green at their Midtown office. $25, free for members." |
| "Overall, this is a fantastic chance to connect, learn, and grow with the community." | Summary sentence that restates nothing; tricolon of abstract verbs. | (Delete the sentence. End on the last fact.) |
| "We're thrilled to announce our partnership with the University of Toronto!" | The reader wants to know what changes for them. | "Starting in March, the University of Toronto's climate accelerator will host our monthly meetup at the Schwartz Reisman building. Free, RSVP required." |

Strong examples drawn from the sources are verbatim or lightly cut; the Chicago, Toronto, and Urban Green rows are illustrative and their facts are invented for the example only.

## 5. Banned words and constructions

Two notes. The 2025 guide used "Don't miss" and "deep dive" once each; the 2026 guide dropped both. "Groundbreaking" and "at the intersection of" live only in the fixed footer and About boilerplate.

**A to C:** "a must-attend"; "at the intersection of" (outside the fixed About text); "attendees will" as a sentence opener, more than once per piece; "boasts"; "bustling"; "circle back"; "curated" as an adjective for your own list (say "our picks"); "cutting-edge".

**D to F:** "deep dive", "dive deep", "delve"; "don't miss" (say "don't sleep on" if you must); "dynamic"; "ecosystem" more than once per piece; "elevate"; "empower"; "exciting opportunity"; "excited to announce"; "explore ways to collaborate".

**G to L:** "game-changing"; "groundbreaking" (outside the fixed footer); "I came across your organization"; "I hope this finds you well"; "in today's fast-paced world"; "innovative" as a filler adjective; "it's not just X, it's Y"; "join us as we explore"; "landscape" as in "the climate landscape"; "leverage"; "look no further".

**N to R:** "nestled"; "next-level"; "passionate"; "perfect for"; "premier"; "robust".

**S to Z:** "seamless"; "showcase" as a verb for events (the noun in a real event name is fine); "supercharge"; "synergy"; "the future of"; "thought leader"; "transformative"; "unique" as filler; "unlock"; "unmissable"; "vibrant"; "we are thrilled"; "whether you're a X or a Y"; "world-class".

**Punctuation and form:** em dashes (use a comma, a period, a parenthesis, or a spaced hyphen as the guides do); stacked exclamation marks; title case headings; rhetorical questions as openers ("Ready to make a difference?"); any sentence beginning "In conclusion" or "Overall".

**Patterns, not words:**

- Three adjectives in a row.
- Tricolons of abstract nouns ("connection, inspiration, and impact"). The guides list concrete things: "shakes, cakes, and fresh air".
- Ending a description with a why-you-should-care sentence that is really marketing. End on the last fact.
- Starting three consecutive sentences with the same word.
- Summarizing what you just said. If the paragraph was clear, the summary is redundant.
- Inventing a detail to make a sentence land.
- Promises about the reader's feelings ("you'll leave inspired").
- Opening with the date or "This week" when a real hook is available.
- Metaphors carried past two sentences. The 2024 coral reef gets two and stops.

## 6. How to use this file per output type

**Newsletter opening note draft.** 60 to 120 words, two short paragraphs. Paragraph one is a topical hook: local news, weather, or the chapter's own upcoming event. Paragraph two turns to community and ends with "Here are our picks for the week:". Greeting is "Hi all," or "Hi friends,". Claude drafts it in full from what the lead said and marks it; the human rewrites it in their own words.

**Picks.** One bullet per day, four to six bullets, day in bold, verb first, then place or reason, then the emoji and linked title. Same-day events are joined with "or". One parenthetical aside per block, at most. Claude proposes; the human reorders and cuts, since picks are an opinion.

**This Week in Detail descriptions.** Two to three sentences, 40 to 70 words. Sentence one: what it is and who hosts it. Sentence two: venue or neighborhood, time of day, price. Optional sentence three: one concrete detail from the listing. No why-go sentence. The human spot-checks facts and links; these ship with light edits.

**Opportunity descriptions.** One to two sentences plus a bolded deadline: what the program is, who it is for, what you get (money, mentorship, a pilot site), and "Applications due [date]." No adjectives about ambition. The human confirms the deadline and eligibility.

**Partner outreach emails.** 100 to 175 words, which is the limit `ctc-partner-outreach` enforces. Open with who you are and one specific, true thing about them. Lead with what they get, then one ask that can be answered yes in a single reply. Close with a plain next step. The human rewrites the first sentence and signs in their own name.

**City resource descriptions (the public resource workbook).** Three to six sentences, per `ctc-city-resources`: what the organization does, where it is, what a founder actually gets from it, closing on "Suits [founder type]." Only facts the research established, nothing invented, and no figures that go stale (fund sizes, cohort counts, percentages). The human checks it is still active.

**City narratives (the City Narratives sheet of the same workbook).** 300 to 500 words on what makes the city distinctive for climate tech, researched separately from the roster. Show, do not announce: never open with "What makes X distinctive is", "X is unique in that", "The key thing about X is", or "X stands out because". Put the reader somewhere concrete (the refinery down the highway, the test basin on campus) and let them draw the conclusion. Close on the city's honest gap. The human checks the industrial facts.

**Partner map "why" lines.** One sentence about this chapter, not about the organization. "Runs the monthly hardware meetup our members already attend" passes; "A leading innovation hub in Chicago" is a description and fails.

**Climate week guide category intros.** The NY guides do not use category intros; the heading with its count ("🌱 Adaptation (64)") goes straight into Highlights. If a city guide needs one, keep it to one or two sentences that say what kind of events sit in the category and name one venue or host. The human writes the welcome and "guide to the guide"; Claude supplies the numbers and the highlight descriptions.

## 7. Merging Sonam's personal voice file later

CTC's co-founder Sonam Velani keeps a personal voice.md. When it arrives, fold its general banned constructions into section 5 and its general rules into section 2, and leave out anything specific to Streetlife Ventures (portfolio language, investor updates) or to her personally (her signature phrases, her sign-off). The test is whether a chapter lead in Amsterdam could follow the rule without knowing who Sonam is. Never let two rules in this file contradict each other; if a merged rule conflicts with an existing one, the more specific rule wins and the other is deleted, not kept alongside it with a caveat.
