---
name: ctc-city-resources
description: Research a city's climate tech ecosystem and produce the standard Climate Tech Cities resource workbook for it - a formatted .xlsx with the five-block city tab (Universities & Research Institutions, Incubators & Accelerators, Startup Resources & Public Programs, Industry Partners, Capital Partners) plus a City Narratives sheet. Use this skill whenever the user names a city and wants its resources, chapter resources, ecosystem list, or resource spreadsheet built - including bare invocations like "Houston", "do Berlin", "add Toronto", "new chapter for Denver", or any request to research climate orgs, accelerators, incubators, universities, industry partners, or capital partners for a city page or Squarespace chapter page. Always use this skill even if the user only asks for one section, one block, or "just a quick list". Do NOT use it for events, calendars, or newsletters - those belong to the harvest and source-map skills.
---

# CTC City Resources

Stage one of the `ctc-partner-map` plugin. Produce the Climate Tech Cities resource workbook for one city: a researched, verified, founder-facing roster of the organizations that actually help early-stage climate startups there, rendered as a formatted `.xlsx`.

## What you will get back

One file, `CTC_City_Resources_<City>.xlsx`, with two sheets.

**Sheet 1, `<City>`.** Five blocks in a fixed order, each under a teal section header that carries the count. Columns A to E are the same for every block; column F holds yellow reviewer notes for the person who publishes the page.

| Organization | Type | Focus Area | Description | Website |
|---|---|---|---|---|
| Tidewater Climate Labs | Incubator | Hardware climate startups | Tidewater Climate Labs is a climate hardware incubator in a converted cannery on the Sound Harbor waterfront, offering prototyping bays, a shared machine shop and desk space. (...) Suits hardware founders who need real prototyping infrastructure and peers who have solved the same problems. | https://example.org/tidewater-climate-labs |
| Meridian Power, Innovation Challenge | Utility | Grid resilience and storm hardening | Meridian Power is the investor owned utility for the Alderport region, and its annual innovation challenge takes applications from early stage companies working on storm hardening (...) Suits grid software and sensing founders who can run a trial within a year. | https://example.com/meridian-innovation-challenge |
| Estuary Ventures | Venture capital | Pre-seed and seed climate hardware | Estuary Ventures is a seed fund headquartered in downtown Alderport that writes first checks into climate hardware (...) Suits hardware founders raising a first priced round who want an operator lead investor. | https://example.vc/estuary-ventures |

In the Universities block, column A is headed `Program / Center` and rows are grouped under an institution sub-header, because the entry is the program, not the university.

**Sheet 2, `City Narratives`.** One row: the city name and a 300 to 500 word narrative about what makes the city distinctive for climate tech.

**The chat summary that comes with it**, in about this shape:

> Alderport: 11 organizations across the five blocks (3, 2, 2, 2, 2). Industry Partners and Capital Partners are short by design; the organizations considered and cut are on each section header in column F. The audit corrected one URL and removed nothing. One row carries VERIFY BEFORE PUBLISH: Harbor Tech Marine Trades Lab, on whether its prototype placement is still open to outside companies.

The rows above are from `scripts/city_data_EXAMPLE.py`, a fictional city built to show the shape. A fuller excerpt of the finished workbook is in `references/sample-output.md`. To see the real file, run `python3 scripts/build_city.py scripts/city_data_EXAMPLE.py`.

## Input

A city name. `Houston`, `Berlin`, `Toronto`, `Singapore`. That is all that is required.

Optionally, organizations the lead already knows belong on the list, pasted as names or links. Step 0 asks for these. No file is required and no prior research is required; everything else comes from research run inside this skill.

## Output

One standalone `.xlsx` named `CTC_City_Resources_<City>.xlsx`, containing exactly the two sheets described above.

This workbook is public facing: it feeds the chapter's page on climatetechcities.com (Squarespace). Contact routes, approach order and status never go in it; those belong to the partner map, which is a separate file built by `ctc-partner-list`.

Always deliver the actual file. Research notes, markdown summaries, and tables in chat are inputs to the job, not the job. Historically the single most common failure on this project was producing beautiful research and never writing the spreadsheet. If the turn ends without an `.xlsx` in `/mnt/user-data/outputs/` presented to the user (present_files), the task is not done.

---

## The bar

The workbook is finished when a founder who has built in that city could read it without naming an obvious omission, and without spotting a single entry that does not belong.

Both halves matter equally. A missing organization costs the reader one opportunity. A wrong organization costs the workbook its credibility, because the reader who spots one assumes the rest are unchecked too.

---

## Read these first

The reference files carry the detail. Each one encodes corrections that cost real rework to learn.

| File | What it holds | When |
|---|---|---|
| `references/inclusion-rules.md` | The three tests (local, qualifying, active), the five block definitions, the ruled cases, column F | Before research. This is the most important file |
| `references/research-brief.md` | The exact research prompts for both passes | Before launching research |
| `../ctc-partner-outreach/references/voice.md` | How CTC sounds, the banned words, and section 6 "City resource descriptions" and "City narratives". This is the plugin's one copy of the CTC voice file | Read `references/voice.md` before writing any prose, via that path |
| `references/editorial-style.md` | The shape of a description and of the narrative, the rules specific to this workbook | Before writing any prose, after voice.md |
| `references/audit-pass.md` | The post-build re-verification stage and its prompt | At Step 8, after the file exists |
| `references/sample-output.md` | A fuller excerpt of a finished workbook and its chat summary | Whenever you want to see what done looks like |

`scripts/build_city.py` renders the workbook and runs the QA gate. `scripts/city_data_TEMPLATE.py` is the data file to fill in. `scripts/city_data_EXAMPLE.py` is the template filled in for a fictional city. `scripts/extract_for_audit.py` reads a built workbook back out as an audit checklist. Do not hand-roll openpyxl formatting: the build script already encodes the fills, widths, merges, freeze panes, and row-height math that match the existing chapters.

## Environment

- **Research tool.** Use an extended or deep research tool if the session has one. It is the right instrument for Steps 2, 3 and 8, and it does not need asking about first: it is doing the job that was requested, not a new one. Where none is available, run the same brief as thirty or more `web_search` and `web_fetch` calls per pass. The characteristic failure is running five searches and calling it done.
- **openpyxl** is required by the build and audit scripts. If the import fails: `pip install openpyxl --break-system-packages -q`.
- **`curl` and `requests` cannot reach arbitrary domains** from the sandbox, which reaches an allowlist of package registries only. They fail in ways that look like the site being down. Use the fetch tool for anything on the open web. A URL never observed resolving has not been checked.
- **Outputs go to `/mnt/user-data/outputs/`.** The build script writes there already.
- Do not use the words config, registry, schema, or pipeline with the lead. Say settings file, source list, spreadsheet, and the stages.

---

## Step 0 - Ask how they want to start

**Always ask this first. Never start researching without it.**

The user may already know organizations that belong here. A name a real person vouched for is better than anything research returns, and skipping this question is how a skill produces a list that misses the obvious.

Ask in one message and wait:

> Before I start, how do you want to do this?
>
> **A. You give me some, then I research too.** Paste anything you already know and I verify it, then run the full search on top. Best coverage, and what I would recommend.
>
> **B. You give me all of them.** I verify what you paste and stop there. Fastest, and a fair choice if you already know the scene.
>
> **C. I research everything.** Nothing needed from you. I find them and bring back a verified list to review.
>
> Paste what you have straight into your reply and I will take that as option A, or just tell me which you want.

**If they paste names or links in their first message, take that as A and get on with it.** Do not make someone pick from a menu when they have already answered.

**Whatever they give you is a candidate, not an entry.** It goes through the same verification as anything found by research. When one fails a check, name the check it failed rather than dropping it silently, and let them decide whether to keep it anyway. They know the place and the research does not.

On option B, verify what they gave you (Step 3, verification only), skip the discovery pass, and go on to Step 4. Do not quietly run the research pass anyway.

## Step 1 - Fix the metro scope

Before searching, decide out loud what counts as "in the city", and say so to the user in one line.

The rule is a real physical base: headquarters, or a staffed office where people go to work. Not a mailing address, not a partner firm, not "serves the region", not a national organization with a local chapter page. `references/inclusion-rules.md`, Test 1, has the full test.

Metro areas count when the ecosystem functions as one, but name the actual municipality in the entry so nobody is misled. Precedents from existing chapters, which the partner map inherits unchanged:

- **Washington DC** = DC proper + Northern Virginia + suburban Maryland. Deliberate, after the DMV question was settled explicitly.
- **Chicago** = Chicagoland, with Evanston, Lemont, Naperville named as such.
- **Amsterdam** = Amsterdam Metropolitan Area, with Haarlem, Haarlemmermeer, Amstelveen named as such.
- **Boston** = Greater Boston, which is how MIT and Cambridge organizations qualify.

Do not silently widen scope to fill a thin block. A short honest roster is the correct output when the city is thin; padding is not.

## Step 2 - Research pass one: discovery

Use the discovery prompt in `references/research-brief.md` verbatim, substituting the city and metro scope. It is written to return the fields the data file needs, with dated evidence attached to every candidate.

Cast wide here. Over-collect deliberately, because pass two is where things get cut, and it is far easier to reject a candidate than to notice an absence.

Skip this step only under option B.

## Step 3 - Research pass two: verification and deepening

Never skip this. Two passes is the floor, not the target.

Pass two does two jobs at once, and the prompt in `references/research-brief.md` covers both:

- **Verify** every candidate, including anything the user pasted, against the four checks: still active with dated evidence, canonical working URL, real local physical base, correct block placement and qualification.
- **Deepen** the blocks that came back thin, hunting specifically for the categories generalist searches miss: corporate venture arms of local industrials, university commercialization and venture funds, city and state agency startup programs, sector-specific funds, angel groups with a real climate thesis, national lab or research institute spinout programs.

Run a third pass when pass two leaves a block visibly thinner than the ecosystem should support. Keep going until the searches stop returning new qualifying names.

Then apply `references/inclusion-rules.md` strictly and cut. Expect to cut a lot. Record every cut with its reason; those become the section-header reviewer notes in column F.

## Step 4 - Build the data file

Copy `scripts/city_data_TEMPLATE.py`, fill it in, and keep it as a real Python module. The modular pattern of data file plus shared renderer is what makes revisions cheap; monolithic build scripts have repeatedly proved painful on this project.

Every entry needs all five fields populated. A row with a website and no description, or a name and nothing else, is a defect. A past workbook shipped with orphaned URL-only rows and it was noticed immediately.

Read `references/voice.md` (the plugin's copy is at `../ctc-partner-outreach/references/voice.md`), section 6 "City resource descriptions", before writing any prose. Then write each description to the shape in `references/editorial-style.md`, closing on `Suits [founder type].`

## Step 5 - Write the narrative

Write the narrative per voice.md section 6 "City narratives" and the structure in `references/editorial-style.md`. Research it independently rather than summarizing the roster: the narrative is about the city's industrial DNA and character, not a list of its accelerators.

## Step 6 - Render

```bash
cd <workdir> && python3 scripts/build_city.py city_data_<city>.py
```

The script writes to `/mnt/user-data/outputs/CTC_City_Resources_<City>.xlsx` and prints a structural summary plus a QA report.

## Step 7 - QA gate

The build script runs these automatically and prints failures. Read the output rather than assuming it passed.

- Zero blank cells in columns A through E on any data row
- Every URL is well-formed and starts with `https://`
- No duplicate organization within a block
- The prose rules in `references/editorial-style.md`: description sentence count, the `Suits` closer, no volatile figures, narrative word count
- No em dashes anywhere in the workbook, which is the one voice.md rule the script checks mechanically

Two checks the script cannot make, so make them by hand before delivering:

- **Locality.** Walk the roster and ask of each entry: would a local say this organization is based here? This is the check that has failed most often.
- **Qualification.** Ask of each: does this run a dedicated vehicle for early-stage climate startups, or did it get in on reputation?

## Step 8 - Audit the built workbook

A full re-verification pass, run against the file rather than against the research notes, and treated as adversarial. Read `references/audit-pass.md` and follow it: extract the roster from the `.xlsx`, run the audit prompt, spot-check URLs, apply the findings to the data module, rebuild.

This is not optional and it is not a formality. The earlier passes verified candidates; this one verifies what actually shipped, which is where transcription errors, stale URLs and quietly-closed programs survive. An audit that changes nothing usually means the audit was weak, not that the file was perfect.

## Step 9 - Deliver

Present the file (present_files). Then, in a few lines: the row count per block, what the audit changed (rows removed and why, URLs corrected, descriptions fixed), anything else cut and why, and anything carrying a `VERIFY BEFORE PUBLISH` flag. If the audit found nothing, say so.

Keep it short. No preamble, no restating the method.

## Step 10 - Hand off to the partner map

The workbook is the input to the second stage, so do not end the turn without offering the handoff.

Say, in about this shape:

> That is the resource workbook. Next it becomes a partner outreach plan: who to approach, what to ask for first, and in what order.
>
> You know this city better than the research does. Open the workbook and change whatever is wrong. Cut anything that has quietly closed or that a local would not recognize. Add anything obvious that is missing. Then upload the edited file back here and say `/ctc-partner-list`.
>
> If you would rather not edit it, say "use it as is" and I will run on this version.

Three rules for the handoff:

**The edit is optional and must never block.** If the user says use it as is, the partner map runs on the unedited file. Do not ask twice.

**Say what to look for, not just "edit this."** A lead who has lived in the city for five years will cut two organizations that closed and add three that no search surfaces. Naming that is what gets the edit done.

**Never revise the workbook conversationally on their behalf.** If they describe changes in chat instead of editing the file, make the changes in the data module and rebuild with `build_city.py` so the shipped file and the roster never disagree.

---

## Common failure modes

These are the specific mistakes this project has actually made. Each one shipped and had to be corrected. The organizations removed under each are listed in `references/inclusion-rules.md`.

**Listing organizations that serve everywhere.** The original workbook was full of national programs with no particular tie to the city. If it is equally available to a founder in Denver and a founder in Atlanta, it is not a city resource.

**Admitting organizations on reputation.** A famous utility, a famous university, a famous VC. The question is never prominence, it is whether a founder can walk through a door.

**Padding to hit a number.** Chicago Capital Partners stopped at six because six were real. Reaching eight would have meant admitting two that did not belong. Honest gaps beat filler, always.

**Confusing Capital Partners with everything financial.** Capital Partners means firms whose primary business is writing venture checks. Not accelerators that also invest, not state agencies, not green banks, not project lenders.

**Shipping research instead of the file.** It happened more than once. The turn is not done until the `.xlsx` exists and is presented.
