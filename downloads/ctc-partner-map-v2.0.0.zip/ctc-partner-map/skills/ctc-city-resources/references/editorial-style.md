# Editorial style

Two kinds of prose live in this workbook: the organization descriptions in column D, and the city narrative. They share a voice and differ in shape. This file covers the shape and the rules specific to this workbook.

## Voice

Read the voice file before writing any prose. The plugin's one copy is at `../../ctc-partner-outreach/references/voice.md` (relative to this file; `../ctc-partner-outreach/references/voice.md` from the skill folder). Section 6, "City resource descriptions" and "City narratives", is the part that applies here, and section 5 is the only place a banned word or construction lives, including em dashes and the narrative openers to avoid. Nothing in this file repeats those rules; if this file and voice.md ever seem to disagree, voice.md is wrong or stale and should be fixed there.

The build script checks one voice.md rule mechanically, the em dash rule, because it has been broken on every past build.

---

## Timeless copy

This rule is specific to the workbook, and the reason is maintenance: a workbook full of figures needs revisiting every few months, and a timeless one does not. Banned from published copy:

- Fund sizes, assets under management, any dollar or euro amount
- Cohort headcounts, "over 200 startups supported", portfolio counts
- Percentages and statistics
- Current policy numbers, emissions targets with dates, current program deadlines
- Founding years where the point is recency rather than heritage

Research may surface these numbers and should, as verification evidence. They just do not reach the page. The build script fails any description that carries one.

---

## Organization descriptions

Three to six sentences. The build script fails anything outside that range. Four is the usual length.

**Shape:**

1. What it is and where, in one sentence. Name the actual municipality when it differs from the city brand.
2. What it operationally provides a founder: capital, space, non-dilutive money, lab access, pilots, mentorship, customer introductions. Be concrete about the mechanism.
3. What distinguishes it, or what a founder should understand before approaching. Sector focus, selection criteria, stage.
4. A closer, always in this form: `Suits [founder type].` The build script fails a description without it.

**The `Suits` closer** is the most useful line in the entry. It does routing work: it tells a reader scanning forty rows which three are for them. Make it specific.

Weak: `Suits climate founders.`
Strong: `Suits scientist-founders commercializing lab research who need non-dilutive runway before raising.`
Strong: `Suits hardware founders who need prototyping space more than they need a check.`
Strong: `Suits Pacific Northwest climate-software founders at the earliest stages.`

**Non-programs get flagged plainly.** When an ecosystem anchor does not run a startup vehicle, say so directly and name the adjacent vehicle. This is a service to the reader, not a disclaimer.

> The Institute is a research center rather than a startup program, and it does not run cohorts or write checks. Founders looking to commercialize work from it should approach the university's technology licensing office instead.

**Generalist investors get flagged too.** Where a fund is local and early-stage but not climate-dedicated, say so rather than implying a focus it lacks: `It is not climate-dedicated, with climate fitting only incidentally.`

**Worked example:**

> Greentown Labs is a climate tech incubator in Somerville offering prototyping space, wet labs, machine shops and office space alongside a community of hardware-focused climate startups. Membership brings access to a corporate partner network that opens pilot conversations, plus programming on manufacturing, fundraising and hiring. It leans hard toward physical products rather than software, and the value is as much the neighbors as the facilities. Suits hardware founders who need real prototyping infrastructure and peers who have solved the same problems.

Four sentences. Concrete about the mechanism. No figures. Honest about what it is not for. Routes the reader.

---

## The city narrative

300 to 500 words. The build script fails anything outside that range.

**Research it independently.** Do not summarize the roster. The narrative is about industrial DNA, anchor institutions, ecosystem character and honest gaps, not about which accelerators exist.

**Show, do not announce.** This is the note the project pushed back on hardest, and it applies throughout, not just to openers. The openers to avoid are listed in voice.md section 6.

Announcing:
> What makes Houston distinctive is its industrial depth and proximity to energy infrastructure.

Showing:
> A founder building industrial heat electrification in Houston can drive to a refinery that might pilot it before lunch, and hire a process engineer who has run one for twenty years.

The second does not say "distinctive". It puts the reader somewhere and lets them conclude it.

**Structure**, loosely, over three or four paragraphs:

- Open on something concrete and specific to the place. Not a thesis statement.
- The industrial and institutional substrate: what the city already does at scale, who anchors it, what infrastructure sits nearby.
- What that means for a founder building there: which sectors have unfair advantages, where the customers and the talent are.
- Close on the honest gap. Every city has one. Naming it earns the rest of the piece its credibility, and CTC readers are operators who can tell when they are being sold to.

**Tone check.** It should read like someone who has spent time there, not like a chamber of commerce page and not like a consultant's market brief.
