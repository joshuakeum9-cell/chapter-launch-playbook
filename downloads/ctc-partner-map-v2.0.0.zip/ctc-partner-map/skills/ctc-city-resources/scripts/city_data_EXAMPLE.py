# -*- coding: utf-8 -*-
"""
ILLUSTRATIVE EXAMPLE. Fictional city, fictional organizations. NOT data.

This is city_data_TEMPLATE.py filled in for a city that does not exist,
"Alderport", so a new chapter lead can see what a finished data module looks
like and what the renderer produces from it. Every organization, program, URL
and narrative detail here is invented. Nothing in this file should be carried
into a real city.

It is deliberately small: two or three entries per block. A real city usually
has more, and the counts are an output of the research, never a target.

Run it to see the workbook and the QA report:

    python3 build_city.py city_data_EXAMPLE.py

The rules the entries follow are in references/inclusion-rules.md (what gets
in), references/editorial-style.md (the shape of a description and the
narrative) and ../ctc-partner-outreach/references/voice.md, section 6 (how CTC
sounds). Read those, not this file, when writing a real one.
"""

CITY = "Alderport"

SUBTITLE = ("Organizations based in the Alderport metro that support early-stage "
            "climate startups.")

TAB_NOTE = ("ILLUSTRATIVE EXAMPLE. Alderport is a fictional city and every entry "
            "is invented. Metro scope: Alderport city proper plus Fenwick and "
            "the Sound Harbor waterfront.")

SECTION_NOTES = {
    "INDUSTRY_PARTNERS": ("Short by design. Excluded: Sound Harbor Petroleum "
                          "(sustainability pledge, no startup vehicle); Alderport "
                          "Transit Authority (procurement only, no program a "
                          "startup can apply to)."),
    "CAPITAL": ("Excluded: Brightwater Growth Partners (growth stage only, no "
                "seed activity); Cascade Angels (no stated climate thesis, "
                "generalist)."),
}


# ---------------------------------------------------------------------------
# Block 1: Universities & Research Institutions - Programs & Centers
# ---------------------------------------------------------------------------
UNIVERSITIES = [
    {
        "group": "Alderport State University",
        "rows": [
            ("Estuary Institute for Coastal Energy",
             "Research institute",
             "Tidal and offshore energy research",
             "The Estuary Institute is a coastal energy research center on the "
             "Fenwick campus, with a test basin and instrumented moorings in "
             "Sound Harbor. It is a research center rather than a startup "
             "program, and it does not run cohorts or write checks. Founders "
             "commercializing work from it should approach the university's "
             "venture office, listed below. Suits scientist-founders who need "
             "test-tank access and a faculty collaborator before they raise.",
             "https://example.edu/estuary-institute"),
            ("ASU Venture Office Climate Track",
             "University program",
             "Commercialization and spinouts",
             "The Venture Office runs a climate track for faculty and student "
             "teams turning lab results into companies, with licensing support, "
             "a customer discovery course and a small proof of concept grant. "
             "Teams keep their equity and the office takes no board seat. It is "
             "the door for anything coming out of the Estuary Institute or the "
             "engineering school. Suits scientist-founders commercializing "
             "university research who need non-dilutive runway before raising.",
             "https://example.edu/venture-office"),
        ],
    },
    {
        "group": "Harbor Technical College",
        "rows": [
            ("Harbor Tech Marine Trades Lab",
             "University program",
             "Marine electrification and workforce",
             "The Marine Trades Lab is a working boatyard classroom on the Sound "
             "Harbor waterfront where students retrofit vessels with electric "
             "drivetrains. Startups can place prototypes with student crews for "
             "installation and field testing, and hire from the graduating "
             "class. Suits marine electrification founders who need hands on "
             "installers and a place to test on real hulls.",
             "https://example.edu/marine-trades-lab",
             "VERIFY BEFORE PUBLISH: confirm the prototype placement program is "
             "still open to outside companies this year."),
        ],
    },
]


# ---------------------------------------------------------------------------
# Block 2: Incubators & Accelerators
# ---------------------------------------------------------------------------
INCUBATORS = [
    ("Tidewater Climate Labs",
     "Incubator",
     "Hardware climate startups",
     "Tidewater Climate Labs is a climate hardware incubator in a converted "
     "cannery on the Sound Harbor waterfront, offering prototyping bays, a "
     "shared machine shop and desk space. Membership brings a corporate "
     "partner network that opens pilot conversations, plus programming on "
     "manufacturing and first hires. It leans toward physical products rather "
     "than software, and the value is as much the neighbors as the "
     "facilities. Suits hardware founders who need real prototyping "
     "infrastructure and peers who have solved the same problems.",
     "https://example.org/tidewater-climate-labs"),
    ("Kiln Accelerator",
     "Accelerator",
     "Pre-seed climate software and services",
     "Kiln is a twelve week accelerator in downtown Alderport for pre-seed "
     "climate companies, run out of the Millrace coworking building. Founders "
     "get a small check, weekly working sessions with operators from the region's "
     "utilities and shipping firms, and a demo day in front of local "
     "investors. It is the only cohort program in the city that reaches "
     "software founders. Suits first time founders at the idea or prototype "
     "stage who want structure and local customer introductions.",
     "https://example.org/kiln-accelerator"),
]


# ---------------------------------------------------------------------------
# Block 3: Startup Resources & Public Programs
# ---------------------------------------------------------------------------
STARTUP_RESOURCES = [
    ("Alderport Economic Development Office, Clean Industry Grants",
     "Public agency",
     "Non-dilutive grants and permitting help",
     "The city's economic development office runs a clean industry grant "
     "round each year for companies locating a first facility inside city "
     "limits, alongside a permitting concierge for anything touching the "
     "waterfront. Applications open in spring and the office publishes the "
     "criteria plainly. Suits hardware and manufacturing founders ready to "
     "lease a first space in Alderport.",
     "https://example.gov/clean-industry-grants"),
    ("Sound Regional Energy Authority, Pilot Program",
     "Public agency",
     "Grid and distributed energy pilots",
     "The regional energy authority runs an annual call for pilots on its "
     "distribution network, covering storage, demand response and "
     "electrification of the ferry fleet. Selected companies get a signed "
     "pilot site and an engineering contact rather than money. It is a "
     "public body and moves at public speed, so start early. Suits grid and "
     "storage founders who need a first utility reference more than a check.",
     "https://example.gov/energy-authority-pilots"),
]


# ---------------------------------------------------------------------------
# Block 4: Industry Partners
# ---------------------------------------------------------------------------
INDUSTRY_PARTNERS = [
    ("Meridian Power, Innovation Challenge",
     "Utility",
     "Grid resilience and storm hardening",
     "Meridian Power is the investor owned utility for the Alderport region, "
     "and its annual innovation challenge takes applications from early stage "
     "companies working on storm hardening, outage prediction and vegetation "
     "management. Winners get a funded field trial on Meridian's network and "
     "a named sponsor inside the company. Suits grid software and sensing "
     "founders who can run a trial within a year.",
     "https://example.com/meridian-innovation-challenge"),
    ("Northshore Shipyards, Startup Dock",
     "Industrial",
     "Shipbuilding and port decarbonization",
     "Northshore Shipyards runs Startup Dock, a residency that places two or "
     "three early stage companies a year inside its yard to test electric "
     "propulsion, shore power and materials on working vessels. The yard "
     "supplies engineers and berth time, and asks for first refusal on a "
     "commercial contract. Suits marine and port decarbonization founders "
     "with a prototype ready for salt water.",
     "https://example.com/northshore-startup-dock"),
]


# ---------------------------------------------------------------------------
# Block 5: Capital Partners
# ---------------------------------------------------------------------------
CAPITAL = [
    ("Estuary Ventures",
     "Venture capital",
     "Pre-seed and seed climate hardware",
     "Estuary Ventures is a seed fund headquartered in downtown Alderport "
     "that writes first checks into climate hardware, with a bias toward "
     "marine, grid and industrial companies. The partners came out of the "
     "shipyards and the utility, and they lead rounds rather than follow. "
     "They take a board seat and expect a Sound Harbor presence. Suits "
     "hardware founders raising a first priced round who want an operator "
     "lead investor.",
     "https://example.vc/estuary-ventures"),
    ("Loam Capital",
     "Venture capital",
     "Seed stage, generalist with a climate thesis",
     "Loam Capital is a seed fund in the Fenwick district that invests across "
     "software and services, with a stated climate thesis covering roughly "
     "half of its recent deals. It is not climate dedicated, with climate "
     "fitting alongside logistics and fintech. Founders get a fast process "
     "and introductions to the regional corporates on its advisory board. "
     "Suits climate software founders raising seed who want a local "
     "generalist on the cap table.",
     "https://example.vc/loam-capital"),
]


# ---------------------------------------------------------------------------
# City narrative, per references/editorial-style.md. Fictional, like everything above.
# ---------------------------------------------------------------------------
NARRATIVE = """A founder building electric propulsion in Alderport can walk from a desk at Tidewater Climate Labs to a working shipyard without leaving the waterfront, past the ferry slips where the region's transit authority is already swapping diesel for batteries. The city grew up around the Sound Harbor timber docks and the hydro dams on the Alder River, and both are still there, which is why so much of its climate work happens in salt water and on the grid rather than in a browser.

The substrate is industrial. Northshore Shipyards has built and repaired vessels on the same waterfront for three generations and now spends its capital budget on shore power and hull materials. Meridian Power runs a distribution network that gets hit by winter storms off the Sound every year, and it has stopped pretending that vegetation management alone will fix outages. Alderport State University's coastal energy institute sits on the Fenwick campus with a test basin that private companies elsewhere would pay a great deal to use. The Sound Regional Energy Authority is small enough that a founder can get the head of grid planning on the phone.

For a founder, that means the customers and the talent are the same people. Marine electrification, storm resilience, shore power, industrial heat for the mills up the river: these are sectors where an Alderport company gets a first pilot from someone who can drive to the site. The engineering school graduates people who have already worked a summer at the yard. The utility's innovation challenge and the shipyard's residency are unusual in being real doors rather than pledges, and the city's clean industry grants are written for companies leasing a first bay, not for companies that already have three.

The gap is capital past seed and anything that is not hardware. Estuary Ventures will lead a first round for a marine or grid company, and Loam will join a software round, and after that a founder is flying to a bigger city to raise. Software founders find a thinner scene here than hardware founders do, and there is no climate software community to speak of outside the Kiln cohort. The city also has no design or consumer scene to draw from, so a founder hiring a product team is recruiting from elsewhere. Alderport is a place to build something that floats or plugs in, prove it against a real customer, and raise the next round somewhere else. That is a narrower promise than the chamber of commerce makes, and it is the accurate one."""
