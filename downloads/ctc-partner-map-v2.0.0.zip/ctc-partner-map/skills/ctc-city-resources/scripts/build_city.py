#!/usr/bin/env python3
"""
Render a Climate Tech Cities single-city resource workbook.

Usage:
    python3 build_city.py city_data_houston.py [output_dir]

Reads a city data module (see city_data_TEMPLATE.py), writes a formatted .xlsx
with two sheets - the city resource tab and City Narratives - then runs QA and
prints a report. Formatting matches the existing CTC chapter tabs exactly.
"""

import sys
import os
import re
import math
import importlib.util

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

# ---------------------------------------------------------------- style constants
# These match the existing chapter tabs. Do not change without checking a peer tab.
TEAL_BAND   = 'FF0F6E6E'   # section header band
SUBHEAD     = 'FFBBD3D1'   # institution sub-header (universities block)
DATA_FILL   = 'FFDCE6F1'   # data row
COLHDR_FILL = 'FFD9E2E1'   # column header row
YELLOW      = 'FFFFFF00'   # reviewer note, column F ONLY
TITLE_COLOR = 'FF0F3D3D'
GREY        = 'FF6B7A7A'
LINK_COLOR  = 'FF0563C1'

WIDTHS = {'A': 34.0, 'B': 22.0, 'C': 26.0, 'D': 64.0, 'E': 40.0, 'F': 52.0}
MIN_ROW_H = 38.25
FREEZE = 'E1'

F_TITLE   = Font(name='Calibri', size=15, bold=True, color=TITLE_COLOR)
F_SUBTITLE= Font(name='Calibri', size=9, color=GREY)
F_SECTION = Font(name='Calibri', size=12, bold=True, color='FFFFFFFF')
F_SUB     = Font(name='Calibri', size=11, bold=True, color=TITLE_COLOR)
F_COLHDR  = Font(name='Calibri', size=11, bold=True, color=TITLE_COLOR)
F_ORG     = Font(name='Calibri', size=11, bold=True)
F_CELL    = Font(name='Calibri', size=11)
F_WEB     = Font(name='Calibri', size=11, color=LINK_COLOR, underline='single')
F_NOTE    = Font(name='Calibri', size=8, italic=True, color='FF7A6000')

BLOCK_ORDER = [
    ('UNIVERSITIES',       'Universities & Research Institutions - Programs & Centers'),
    ('INCUBATORS',         'Incubators & Accelerators'),
    ('STARTUP_RESOURCES',  'Startup Resources & Public Programs'),
    ('INDUSTRY_PARTNERS',  'Industry Partners'),
    ('CAPITAL',            'Capital Partners'),
]

VOLATILE = [
    (r'[$£€]\s?\d', 'currency amount'),
    (r'\b\d+(\.\d+)?\s?(million|billion|bn|m\b|k\b)', 'magnitude figure'),
    (r'\b\d+\s?%', 'percentage'),
    (r'\bover\s+\d+\b', '"over N" count'),
    (r'\bmore than\s+\d+\b', '"more than N" count'),
    (r'\b\d+\+\s', 'N+ count'),
    (r'\bassets under management\b', 'AUM'),
]


def est_height(desc, note):
    """Row height from wrapped text length. ~70 chars/line in col D, ~60 in col F."""
    lines = max(
        math.ceil(len(desc or '') / 70) if desc else 1,
        math.ceil(len(note or '') / 60) if note else 1,
        1,
    )
    return max(MIN_ROW_H, 13 * lines + 6)


def load_data(path):
    spec = importlib.util.spec_from_file_location('city_data', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def build(D, outdir):
    city = D.CITY
    wb = Workbook()
    ws = wb.active
    ws.title = city[:31]
    ws.sheet_view.showGridLines = False

    for col, w in WIDTHS.items():
        ws.column_dimensions[col].width = w
    ws.freeze_panes = FREEZE

    def band(r, value, fill_hex, font, height=None):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
        c = ws.cell(r, 1)
        c.value = value
        c.font = font
        c.alignment = Alignment(vertical='center')
        if fill_hex:
            fill = PatternFill('solid', fgColor=fill_hex)
            for col in range(1, 6):
                ws.cell(r, col).fill = fill
        if height:
            ws.row_dimensions[r].height = height

    def note(r, text):
        if not text:
            return
        c = ws.cell(r, 6)
        c.value = text
        c.fill = PatternFill('solid', fgColor=YELLOW)
        c.font = F_NOTE
        c.alignment = Alignment(wrap_text=True, vertical='top')

    def colhdr(r, first='Organization'):
        for i, label in enumerate(['Organization', 'Type', 'Focus Area',
                                   'Description', 'Website'], start=1):
            c = ws.cell(r, i)
            c.value = first if i == 1 else label
            c.fill = PatternFill('solid', fgColor=COLHDR_FILL)
            c.font = F_COLHDR
            c.alignment = Alignment(vertical='center')

    def data_row(r, entry):
        org, typ, focus, desc, web = entry[:5]
        rnote = entry[5] if len(entry) > 5 else None
        fill = PatternFill('solid', fgColor=DATA_FILL)
        for i, v in enumerate([org, typ, focus, desc, web], start=1):
            c = ws.cell(r, i)
            c.value = v
            c.fill = fill
            c.font = F_ORG if i == 1 else (F_WEB if i == 5 else F_CELL)
            c.alignment = Alignment(wrap_text=(i == 4), vertical='top')
        if web and str(web).startswith('http'):
            ws.cell(r, 5).hyperlink = web
        note(r, rnote)
        ws.row_dimensions[r].height = est_height(desc, rnote)

    # --- title + subtitle
    r = 1
    band(r, f'{city} - Climate Tech Ecosystem Resources',
         None, F_TITLE, height=21.95)
    note(r, getattr(D, 'TAB_NOTE', None))
    r += 1
    band(r, getattr(D, 'SUBTITLE', None), None, F_SUBTITLE)
    r += 1

    counts = {}

    for key, label in BLOCK_ORDER:
        block = getattr(D, key, None)
        if not block:
            counts[key] = 0
            continue

        if key == 'UNIVERSITIES':
            n = sum(len(g['rows']) for g in block)
            header = f'{label}  ({len(block)} institutions)'
        else:
            n = len(block)
            header = f'{label}  ({n})'
        counts[key] = n

        band(r, header, TEAL_BAND, F_SECTION)
        note(r, getattr(D, 'SECTION_NOTES', {}).get(key))
        r += 1
        colhdr(r, first='Program / Center' if key == 'UNIVERSITIES' else 'Organization')
        r += 1

        if key == 'UNIVERSITIES':
            for group in block:
                ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
                c = ws.cell(r, 1)
                c.value = group['group']
                c.font = F_SUB
                c.alignment = Alignment(vertical='center')
                for col in range(1, 6):
                    ws.cell(r, col).fill = PatternFill('solid', fgColor=SUBHEAD)
                r += 1
                for entry in group['rows']:
                    data_row(r, entry)
                    r += 1
        else:
            for entry in block:
                data_row(r, entry)
                r += 1
        r += 1  # spacer between blocks

    # --- City Narratives sheet
    nws = wb.create_sheet('City Narratives')
    nws.sheet_view.showGridLines = False
    nws.column_dimensions['A'].width = 18.0
    nws.column_dimensions['B'].width = 118.0
    nws['A1'] = 'Climate Tech Cities - City Page Narratives'
    nws['A1'].font = F_TITLE
    nws['A2'] = ('A 300-500 word narrative for each city page: '
                 'what makes each place distinctive for climate tech.')
    nws['A2'].font = F_SUBTITLE
    for coord, label in (('A3', 'City'), ('B3', 'Narrative')):
        nws[coord] = label
        nws[coord].font = F_SECTION
        nws[coord].fill = PatternFill('solid', fgColor=TEAL_BAND)
        nws[coord].alignment = Alignment(horizontal='left', vertical='center')
    nws['A4'] = city
    nws['A4'].font = F_ORG
    nws['A4'].alignment = Alignment(vertical='top')
    nws['B4'] = D.NARRATIVE
    nws['B4'].font = F_CELL
    nws['B4'].alignment = Alignment(wrap_text=True, vertical='top')
    para = D.NARRATIVE.split('\n')
    nlines = sum(max(1, math.ceil(len(p) / 135)) for p in para) + len(para)
    nws.row_dimensions[4].height = max(MIN_ROW_H, 13 * nlines + 6)

    os.makedirs(outdir, exist_ok=True)
    safe = re.sub(r'[^A-Za-z0-9]+', '_', city).strip('_')
    path = os.path.join(outdir, f'CTC_City_Resources_{safe}.xlsx')
    wb.save(path)
    return path, counts


def qa(D, path, counts):
    problems = []
    rows = []
    for key, _ in BLOCK_ORDER:
        block = getattr(D, key, None) or []
        if key == 'UNIVERSITIES':
            for g in block:
                for e in g['rows']:
                    rows.append((key, e))
        else:
            for e in block:
                rows.append((key, e))

    seen = {}
    for key, e in rows:
        org, typ, focus, desc, web = (list(e) + [None] * 5)[:5]
        label = f'{key}/{org}'

        for name, val in (('Organization', org), ('Type', typ),
                          ('Focus Area', focus), ('Description', desc),
                          ('Website', web)):
            if not val or not str(val).strip():
                problems.append(f'BLANK {name}: {label}')

        if org:
            k = (key, str(org).strip().lower())
            if k in seen:
                problems.append(f'DUPLICATE within block: {label}')
            seen[k] = True

        if web and not str(web).startswith('https://'):
            problems.append(f'URL not https: {label} -> {web}')

        if desc:
            d = str(desc)
            if '\u2014' in d:
                problems.append(f'EM DASH: {label}')
            n_sent = len([s for s in re.split(r'(?<=[.!?])\s+', d.strip()) if s])
            if n_sent < 3:
                problems.append(f'TOO SHORT ({n_sent} sentences): {label}')
            if n_sent > 6:
                problems.append(f'TOO LONG ({n_sent} sentences): {label}')
            if 'Suits ' not in d:
                problems.append(f'MISSING "Suits" closer: {label}')
            for pat, why in VOLATILE:
                if re.search(pat, d, re.I):
                    problems.append(f'VOLATILE FIGURE ({why}): {label}')
                    break

    nar = getattr(D, 'NARRATIVE', '') or ''
    if '\u2014' in nar:
        problems.append('EM DASH in narrative')
    wc = len(nar.split())
    if not (300 <= wc <= 500):
        problems.append(f'Narrative is {wc} words, needs 300-500')

    for key, note in (getattr(D, 'SECTION_NOTES', {}) or {}).items():
        if note and '\u2014' in note:
            problems.append(f'EM DASH in section note: {key}')

    print(f'\nWorkbook: {path}')
    print('-' * 62)
    for key, label in BLOCK_ORDER:
        print(f'  {label:<58} {counts.get(key, 0):>3}')
    print(f'  {"TOTAL organizations":<58} {sum(counts.values()):>3}')
    print(f'  {"Narrative word count":<58} {wc:>3}')
    print('-' * 62)
    if problems:
        print(f'QA: {len(problems)} issue(s) to fix\n')
        for p in problems:
            print(f'  ! {p}')
    else:
        print('QA: all checks passed')
    print()
    print('REMEMBER: two checks are manual and are the ones that fail most often.')
    print('  1. Locality  - would a local say each org is actually based here?')
    print('  2. Qualification - does each run a dedicated early-stage climate vehicle?')
    return problems


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit('usage: build_city.py <city_data_module.py> [output_dir]')
    outdir = sys.argv[2] if len(sys.argv) > 2 else '/mnt/user-data/outputs'
    D = load_data(sys.argv[1])
    path, counts = build(D, outdir)
    issues = qa(D, path, counts)
    sys.exit(0)
