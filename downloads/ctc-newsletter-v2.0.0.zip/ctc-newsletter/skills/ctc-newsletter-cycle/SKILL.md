---
name: ctc-newsletter-cycle
description: Run the Climate Tech Cities weekly newsletter end to end for a city chapter, sequencing the source map, the harvest, the cut, and the assembly, and prompting the chapter lead at each handoff. Use this skill whenever someone wants to produce this week's issue, says "run the newsletter", "let's do this week's newsletter", "start the weekly cycle", "make this week's issue for [city]", asks what to do first with their newsletter, or is a new chapter lead who has installed the toolkit and wants the whole newsletter workflow rather than one piece of it. Also use it when someone is midway through the cycle and asks what comes next. Always use it even if they only mention one city or one week. Do NOT use it for chapter setup, logos, partners, or events, which are separate skills.
---

# CTC Newsletter Cycle

The operating system for a chapter's newsletter. It runs the other skills in order, stops at the two points where a person has to decide something, and picks up again afterward.

A chapter lead should be able to type "run the newsletter" and never need to remember which skill comes next or what it wants from them.

## What you will get back

Each run ends with one finished issue: a Word document and an HTML file in the current ten-block order, every link and emoji in place, and the three editorial blocks drafted with a yellow `[REWRITE IN YOUR OWN WORDS, then delete this line]` marker above each. Along the way the lead sees one spreadsheet (the events sheet, which they cut) and one short report per stage. A rendered example of the finished issue is `../ctc-assemble/references/sample-output/Portland_Climate_Tech_Aug_11-Aug_18.html`, and every skill in this plugin opens with a "What you will get back" section showing its own output.

## Who you are working with

A volunteer with a day job, running this chapter for free, in a sitting a week they do not really have. Not a developer. A paid Claude account and nothing else.

Two consequences govern everything below. **Never use the words config, registry, schema, or pipeline with them**: say settings file, source list, spreadsheet, and the weekly cycle. And **the failure you are guarding against is not a bad issue, it is no issue.** Reliability is the whole game.

## What the newsletter is for

A few hundred to a few thousand people in one city, reading on a phone, scanning for one thing: is there anything on this week I should go to? Roughly 40% of them do not yet work in climate. That decides ties: free and newcomer-friendly wins, in-person beats webinar, and the volunteering and arts listings are not filler.

## The one rule this plugin exists to protect

**Automate the lists. The lead owns the words.**

A mature issue runs about three thousand words. The tools collect, verify, format, and draft. The lead chooses what makes the issue, rewrites the opening note, the picks, and the housekeeping in their own voice, and sends. Those rewritten words are the reason anyone subscribes.

## Cadence

**Weekly.** Every chapter sends once a week on the send day in its settings file. That is the Climate Tech Cities standard; Seattle sends weekly on a much smaller event base than New York.

**The one exception is volume, decided after evidence.** If the first two or three harvests come back with fewer than about five events a week in the this-week window after the cut, the city may not have enough happening for a weekly issue. Then, and only then, offer every two weeks:

> Your last three harvests came back with three, four, and two events for the week. That is thin for a weekly issue. You can keep sending weekly and let quiet weeks be quiet, or move to every two weeks so each issue has more in it. Either is fine with Climate Tech Cities; weekly is the default.

If the lead chooses every two weeks, ask them to change the `Cadence` row in section 2 of their settings file from `Weekly` to `Every two weeks`, and from then on `ctc-harvest` uses a 14-day this-week window and `ctc-assemble` a 14-day title window. Until the settings file carries it, state the cadence at the start of each run.

Never offer every two weeks because the lead missed a week or is busy. Missed weeks are handled below; cadence is about the city's volume, not the lead's calendar.

**Never tell the lead how long a stage will take.** No estimates, no minute counts, no "this is the slow part". Say what is happening and what comes next. If they ask, say it varies by city and by how much they paste in themselves.

**Never quote a day of the week for any stage.** The send day is the only fixed point. Whether they harvest three days before or the night before is theirs.

**Carry state across the stages.** The source list, the events sheet, the lead's edits, and the opportunities queue are one chain. Never let two stages read two different versions of the same file.

## The stages

### Setup, once per city

| Stage | Who | Skill |
|---|---|---|
| Source map | Claude, lead approves | `ctc-source-map` |

Done once, then refreshed every three months. Not part of the weekly loop. The source list always includes one standing row that is the same for every chapter: the CTC event submission form, through which readers send the chapter events. The link to that form sits at the bottom of every issue.

### Every week

| Stage | Who | Skill |
|---|---|---|
| 1 Harvest | Claude | `ctc-harvest` |
| 2 Cut | Lead | none, this is judgment |
| 3 Assemble and write | Both | `ctc-assemble` |
| 4 Send | Lead | none |

### Once a month

| Stage | Who | Skill |
|---|---|---|
| Opportunities | Claude | `ctc-opportunities` |

Run it in the first week of the month. It maintains a rolling queue of grants, fellowships, and accelerators that `ctc-assemble` reads every week, so the opportunities block still has something in it in weeks two, three, and four. The research is monthly; the publishing is weekly. Nothing else in the toolkit runs monthly, and nothing except the source list runs quarterly.

## Step 0. Work out where they are

Before running anything, establish three things. Ask only for what you cannot see.

**Which city, and is there a settings file?** If a chapter settings file (from `ctc-chapter-setup`) is in the project, read from it and do not ask again:

| Section | Holds | Used by |
|---|---|---|
| 1. Identity | City, chapter name, lead name, timezone | harvest, assemble |
| 2. Newsletter | Send day, cadence, scope rule, grouping, web address, sender name, sign-off, reporting | all stages |
| 3. To update later | Substack URL, reply-to email, source list file name | harvest |

Section 3 is blank until the lead fills it; that is normal. If there is no settings file, ask for the city and the sign-off, note once that `ctc-chapter-setup` would save re-answering this every week, and carry on.

**Is there a source list?** If yes, go to stage 1. If no, they are at setup:

> Before the first issue you need a source list, which is every place events get announced in your city, plus the Climate Tech Cities submission form readers use to send you events. Every week after this reads from it, so it is the step that decides how good every future issue is. Want to build it now?

Never run a harvest without a source list. It returns almost nothing and the lead concludes the tool is broken.

**Is the environment ready?** Check once per session, before the first fetch:

| Needed | For | If missing |
|---|---|---|
| Code execution enabled | Building the spreadsheet and the issue files | Ask them to turn it on in Claude settings. A toggle, not an install |
| Claude in Chrome extension | Luma, Eventbrite, and the submission form's shared view | Say plainly that Luma will return names with no dates and submissions cannot be read without it, and offer the options `ctc-harvest` lists in its platform notes under "When the browser is not available" |
| `openpyxl`, `docx` | The build scripts | `pip install openpyxl --break-system-packages` and `npm install docx`. Handle it yourself |

Say what is missing in one line, without a lecture.

## Setup. Source map, once per city

Run `ctc-source-map`. It handles its own interview, including asking whether the lead has calendar links of their own, it adds the submission form row itself, and it ends with its own handoff prompt (the source count, the category count, and the request to read the file and add it to the project). Do not add a second prompt on top of it.

Wait for a reply. Do not chain into the harvest. Tell them once that this refreshes every three months.

## Stage 1. Harvest

Run `ctc-harvest` across every registered source and the submission form. Two windows: this week (7 days, or 14 for a chapter sending every two weeks) and upcoming (to day 56). Collection only, no filtering.

When it finishes, check the total against the chapter's normal. Far below means a source broke rather than the city going quiet; say so, name the zero-return sources, and offer to check them. Then prompt:

> Harvested [N] events into the spreadsheet, [K] of them sent in by readers through the submission form. Next step is yours: open it and cut it down.

## Stage 2. The cut

**No automation here, on purpose.** How many events end up in the issue is the decision that sets its shape, and it belongs to the lead.

> Open the sheet and delete rows.
>
> **Delete:** anything outside your scope rule, anything not really climate, anything with a dead link or no date, and duplicates. When the same event came from two calendars, keep the one with the better registration link. Rows marked `submitted` in the Source column were sent in by a reader; treat them like any other row, but if you cut one, it is worth a reply to whoever sent it.
>
> **Flag:** put PICK in a spare column next to four to six events worth featuring, roughly one per day that has events. Favor events that are free, easy for a newcomer, in person, or hard to find elsewhere. Assembly reads that column, so this is a one-line answer later.
>
> There is no target number. A good week is however many good events your city actually has. Padding trains readers to skim.
>
> Upload it back when you are done.

**Do not offer to do the cut for them.** If they ask, explain in one line that this is what makes the issue theirs, then offer to answer questions about specific rows.

### Answering "should I cut this one?"

| Row | Ruling | Reasoning |
|---|---|---|
| Just outside the scope rule, but a subscriber would plainly go | Keep | New York's stated rule is 95% the city proper and its issues carry Hoboken. The test is whether someone would travel on a weeknight |
| Clearly climate but in the next metro area | Cut | The reader cannot go |
| Adjacent but not climate: a general tech meetup, a running club | Cut | The newsletter is the one place in the city that filters |
| Arts or volunteering, not obviously "climate tech" | Keep | Much of what serves the 40% not yet working in climate |
| Webinar with no local tie | Keep in Upcoming, cut from the picks | Listable, not recommendable |
| Expensive conference | Keep, and say the price if it goes in the picks | Naming the cost is the honest version of listing it |
| No start time on the event page, everything else solid | Keep | The harvest recorded what the page gave rather than guessing; a reader can still click through. Not worth losing a real event over |
| No date, or a dead registration link | Cut | There is nothing for a reader to click |
| Two rows that look like the same event | Keep the one with the better registration link | Usually the organizer's own |
| A great event on a day that already has three picks | Keep in the listings, do not add a fifth pick | More than six picks becomes a second listing |

The principle: could a reader actually go, and would they be glad it reached them? Tiebreak toward the newcomer.

## Stage 3. Assemble and write

Run `ctc-assemble` on the edited sheet. Confirm by file name that it is the edited one. It asks its three questions itself, in one message, before building: which events are the picks (it reads the PICK column if there is one and confirms rather than re-asking), any opportunities (it reads the queue file if there is one), and anything the sheet cannot know. Let it ask; do not put a second version of those questions in the handoff.

Assembly returns the issue with seven blocks finished and three drafted: the opening note, the picks, and the housekeeping, each with a bracketed marker above it. Then prompt:

> Here is the issue. Three blocks have a yellow line above them: the opening note, the picks, and the housekeeping. They are drafted from what you told me. Rewrite each in your own words, then delete the yellow line. Nothing in square brackets ships. You are the person who goes to these events, and that is the whole value.

**On a quiet week, the draft says so.** Acknowledging a thin stretch reads better than inflating it, and it is house voice.

## Stage 4. Send

No skill runs here. Give the checklist:

> **Before you send:**
> - Search the document for a square bracket. Nothing in brackets ships.
> - Scan the dates. Nothing in the past, and this week's events actually this week.
> - Click two or three links at random, from Upcoming rather than This Week. If one is dead, check its neighbors from the same source.
> - Check no event is listed twice, and that no opportunity deadline has passed.
> - Check This Week in Detail has an entry for every event in This Week's Events.
> - Confirm the platforms block sits after your sign-off and Join the fun is the last thing on the page.
>
> **Then:** open the HTML file in your browser, click before the first word, drag to the bottom, copy, paste into a new Substack post, read the whole thing once top to bottom as a subscriber would, and send.

After they send, remind them once to log four numbers: issues sent on schedule, subscribers, open rate, and how many events came in through the submission form. These are the four the settings file's Reporting row names, so the lead has already seen them.

## When they miss a week

They will.

> Send the next one. No apology and no explanation.

The New York newsletter went quiet for 216 days between May and December 2025, came back with "Hi friends," and carried on as though nothing had happened. Chapters fail by not sending, not by sending badly. The target is weeks covered over a quarter, not a perfect streak, and a missed week is never a reason to change the cadence.

## House rules for the orchestrator

**Stop at every handoff.** Two stages belong to the lead. Never chain past them, and never assume silence is approval.

**Every Claude stage ends with its verifier before the handoff.** `ctc-source-map`, `ctc-harvest`, `ctc-opportunities`, and `ctc-assemble` each carry a `references/verifier.md`: a fresh, adversarial second pass over the built file (re-opening links, checking claims against pages, scanning prose against the voice file). Where the session has a subagent or task tool, the verifier runs as a separate agent that sees only the verifier file and the output; where it does not, it runs as a separate step after the build. A file whose verifier has not run is not ready to hand over, and the verifier's findings are part of every stage report.

**Read the settings file, do not re-ask.** Asking a lead their own scope rule every week is how a toolkit stops being used.

**Never send anything.** No skill in this plugin sends, publishes, or posts.

**Never ship a marker.** The bracketed lines are for the lead to delete after rewriting. Say so at delivery, every time.

**Issue size is an output, not a target.** A new chapter runs 8 to 15 events an issue. New York averaged 56 in 2025 and 2026, four years in. Never suggest padding toward another chapter's number.

**Keep the stages separate.** Harvest collects. The cut judges. Assembly formats and drafts. Merging any two of them is the failure that turns the weekly sitting into an afternoon.

**A first issue should look small.** New York's launch issue carried three events and a long personal note explaining why the newsletter existed. That is the correct shape for week one. Say so before a new lead sees their first harvest.

## Failure modes

**Harvest returns almost nothing.** A source broke rather than the city going quiet. Check the zero-return sources before concluding anything about the week.

**Luma returns names with no dates.** The Chrome extension is not installed. Check in Step 0 rather than discovering it mid-sweep.

**A page blocks or asks to prove you are human.** `ctc-harvest` stops at CAPTCHAs by design. Tell the lead which source needs checking by hand.

**No source list.** Do not harvest. Route to setup.

**The lead asks Claude to skip the rewrite and ship the draft.** Say once that it reads better in their words, then deliver it with the markers left in. Removing them is their decision.

**They want to skip the cut.** Explain that the cut is what makes it their issue, then offer to answer questions about specific rows. If they insist, run assembly on the uncut sheet and say plainly it will read as a padded list.

**Two versions of the spreadsheet in play.** Confirm which file is current, by name, before building, every time.

**Explaining the workflow instead of running it.** A lead who asked for this week's newsletter wants the issue. One line of orientation, then the next action.
