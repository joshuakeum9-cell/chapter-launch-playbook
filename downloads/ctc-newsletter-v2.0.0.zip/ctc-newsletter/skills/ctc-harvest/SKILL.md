---
name: ctc-harvest
description: Harvest this week's climate events for a Climate Tech Cities chapter. Sweep the city's source list (Luma calendars, Eventbrite organizers, other verified sources, and the CTC event submission form) and produce the standard events spreadsheet the newsletter is built from. Use this skill whenever the user wants to collect, pull, gather, or sweep events for a city's newsletter, asks "get this week's events for [city]", wants the events sheet or events spreadsheet built, or is starting the weekly newsletter cycle. Always use this skill even if the user only wants one source swept or a single day's events. Do NOT use it to find new sources, which is the source-map skill's job.
---

# CTC Harvest

Sweep a city's registered sources and the CTC event submission form, and produce the events spreadsheet. This is the collection half of the weekly newsletter cycle: collection only, no judgment, no writing.

## What you will get back

One spreadsheet, `CTC_Events_<City>_<send date>.xlsx`, one sheet named `Events`, one row per event, the fourteen standard columns, then `Block` and `Source`, then `Missing Info`. A three-row excerpt (columns cut for width):

| Event Name | Date | Start Time (PDT) | Registration Link | Event Type | Access | Location | Block | Source |
|---|---|---|---|---|---|---|---|---|
| Grid Interconnection 101 | 2026-08-12 | 17:30 | https://luma.com/... | In-person | Free | Ecotrust Building, 721 NW 9th Ave, Portland | this_week | registry |
| Repair Cafe: Small Appliances | 2026-08-13 | 10:00 | https://... | In-person | Not stated | St. Johns Community Center... | this_week | submitted |
| Green Drinks Portland | 2026-08-25 | 17:30 | https://www.eventbrite.com/... | In-person | Ticketed (Paid) | Loyal Legion, 710 SE 6th Ave, Portland | upcoming | submitted |

Any cell that should have a value and does not is shaded red and named in `Missing Info`. The chat report says how many sources were swept, which returned nothing, which failed, and how many rows came from the submission form. A full sample is `references/sample-output/CTC_Events_SAMPLE.xlsx`; `references/example-events.csv` is the same data as text (without the `Missing Info` column, which the script derives).

## What this is for

The sheet is a worksheet for one person, the chapter lead, who will delete rows from it and hand it to `ctc-assemble`. That reader wants three things: **every event that exists**, so nothing good is missed; **enough detail per row to decide**, so they are not opening twenty tabs; and **no invented data**, because anything guessed at gets published under their name.

Over-collection is cheap, because a row is easy to delete. Under-collection is expensive, because it is invisible.

## Input

- **The source list**, `CTC_Source_Registry_<City>.xlsx` from `ctc-source-map`. If none exists, stop and say so. Harvesting without one means guessing at sources and the result cannot be trusted for completeness.
- **The chapter settings file**, if it is in the project: city and timezone from section 1, scope rule and cadence from section 2. Read it rather than asking.
- **The date windows.** For a weekly chapter: `this_week` is the 7 days from the send day, `upcoming` is days 8 to 56. For a chapter that has moved to every two weeks (decided in `ctc-newsletter-cycle`, recorded in the settings file): `this_week` is 14 days, `upcoming` is days 15 to 56. Both windows, every run.

## What this skill does not do

No filtering for quality, no cutting, no picking, no prose. Collection and judgment are separate stages on purpose; mixing them is what turns a short sitting into a long one. Harvest everything in the windows and let the lead cut afterward in the sheet.

Do not tell the lead how long any of this will take.

## Read this first

- `references/platform-notes.md`: how to pull structured data out of Luma reliably, what breaks on Eventbrite, how to read the CTC submission view, and the traps that produce wrong times or out-of-scope events.
- `references/verifier.md`: the second-pass check run on the finished sheet before it is handed over.
- `references/example-events.csv`: a complete valid 21-row sheet, the same fictional week as the assemble skill's example issue, to calibrate description length and what a filled row looks like. Illustrative data; never copy its rows into a live sheet.

## Environment

| Dependency | Needed for | If it is missing |
|---|---|---|
| Code execution and `openpyxl` | `build_sheet.py` | `pip install openpyxl --break-system-packages`. If code execution is off, ask the lead to enable it in Claude settings; without it, output a CSV with the same columns and say the .xlsx step was skipped |
| Claude in Chrome extension | Luma, Eventbrite, and the CTC submission view | Say so before sweeping. Without it Luma returns titles with no dates and the submission view cannot be read. Offer the three options in `references/platform-notes.md`, "When the browser is not available" |

The browser is not optional for this skill. A harvest run without it produces a sheet of names with empty date cells, which looks like a data problem and is a missing tool. Check once, at the start, before the first fetch.

The sandbox only reaches an allowlisted set of domains, so `curl` and Python `requests` fail on event sites that are fine. Use the fetch tool or the browser for anything on the open web, and never conclude a source is dead because a shell command could not reach it.

## Step 0. Anything the lead already knows

Ask once, in the opening message:

> Sweeping your source list and the submission form now. Anything you already know about that will not be on a calendar? Paste it in and I will add it to the sheet.

Anything they add goes into the sheet with `Source = lead`. Never drop a lead-supplied event, even when a field is missing: name the missing field and keep the row.

If what they actually want is new sources rather than new events, that is `ctc-source-map`. Point them there.

## Step 1. Sweep every registered source

**Every registered source gets opened, every run.** Not a sample, not the ones that produced events last week. The sources that usually return nothing are exactly where a missed event hides, and "usually empty" is the state a broken source hides in.

Work down the fetch ladder per source. The registry's `method` column says which tier to expect.

- **Tier 1, plain fetch.** Sufficient for most server-rendered university, government, and utility calendars. Try first.
- **Tier 2, browser.** Escalate when Tier 1 returns an empty shell, a JavaScript placeholder, a 403, or truncated content. This is the expected path for every Luma calendar and Eventbrite organizer page. Ask before opening the browser the first time in a session. Pace the sweep; thirty organizer pages in a burst trips rate limiting.
- **Tier 3, paste.** If a source still fails, ask the lead to open it and paste the contents, and record the failure. A source needing this every week should be reclassified `manual` in the registry.

**Hard stops.** A CAPTCHA or bot challenge: report it and move on, never solve or route around it. A login wall: skip it and note it. Never enter credentials.

Account for every row before writing the sheet. A source that could not be reached is a fact to report, not a row to skip quietly. **A source returning nothing and a source failing are different things and are never reported the same way**: the first is information about the week, the second is a broken registry row.

If the week's total comes in far below the chapter's normal, a source broke rather than the city going quiet. Check the zero-return sources by eye before concluding anything.

## Step 2. Read the CTC event submission form

Climate Tech Cities runs one event intake form for every chapter. Anyone can submit an event; the table behind it is internal and readers never see it. The registry carries it as a standing row (`platform = airtable`, `category = submissions`), and it is swept every week like any other source, with these differences:

1. Open the shared view in the browser (the URL is in the registry row; `platform-notes.md` says how to read the table). Take only rows where `City` matches this chapter and `Date` falls inside either window. Ignore every other city's rows.
2. **Open the registration link on every submitted row**, the same as for any other source. Submitters make mistakes and a submitted link is no more trusted than a scraped one. Fill the sheet from the event's own page; where the form and the page disagree, the page wins, and say so in the report.
3. The submitter's `Description` goes into the `Description` column, tidied to the standard length. It was written by a person who knows the event, so prefer it to the page's copy where both exist.
4. Rows get `Source = submitted`. **Never drop a submitted event**, even with a missing field. Name the field, keep the row, and tell the lead a reader sent it in, so they can decide.
5. The submitter's contact fields and the form's internal columns never leave the table (`platform-notes.md` lists them). They are for the lead to follow up, not for the sheet.
6. Report the count: "3 events came in through the submission form this week, all in scope."

A submitted event that is already in the sheet from a registry source is a duplicate; merge per the dedupe rules below, keep `Source = submitted` on the merged row so the lead knows a reader asked for it, and prefer the submitter's description.

If the shared view cannot be opened, say so and carry on with the registry. The form is a source, not the sheet.

## Step 3. Open the event's own page, always

**A calendar tells you an event exists. Only the event's own page tells you when and where it is.**

The rule: never write a row from a listing page. Follow the title through to the event's own page and read the row from there. A registration link ending in `/events`, `/calendar`, `/boards`, `/programs`, `/upcoming`, or `/whats-on` is an index, not an event, and the build script flags it, but by then the browsing is finished. Catch it while you are on the page.

Two or more of Start Time, Location, and Access missing on the same row means the event page was not opened. Go back. No registration link at all means the row does not ship: find the page or drop the event.

**Upcoming rows get the same page visits as this-week rows.** In one reviewed issue every one of fourteen link failures was in `upcoming`. Those links reach a reader the same way.

### The link must be the page you landed on

- **Never construct a URL** from a pattern, a slug, an ID, or a date. Copy the address bar after the page loads. A constructed slug lands on the wrong event silently; one redirected to the previous year's edition.
- **Never join a title to a URL afterwards.** Read the name and the link from the same element in the same pass. A positional join once attached real event IDs to the wrong names.
- **Never fall back to the listing page.** If an event has no page of its own, leave `Registration Link` empty and let the row flag red. An empty cell is recoverable; a plausible wrong link ships.
- **While you are on the page, check three things:** it is about this event, its date matches the row, and it does not say the event has passed. Any failing means the row does not ship as it stands.

Do not compare the slug to the title as a substitute for reading the page. Slugs legitimately drift.

## Step 4. Fill every required cell, with a value or a resolved unknown

**One rule for the whole sheet: every required cell holds either the value from the event's own page or one of the four resolved-unknown values below. Never a guess, and never a silent blank.** A blank is a defect the script marks red; a resolved unknown is a fact.

| Event Type | Required |
|---|---|
| In-person, Hybrid | Everything below, including Location and Google Maps |
| Online | Everything below except Location and Google Maps |

Required on every row: Event Name, Date, Start Time, Registration Link, Event Type, Access, City / Neighborhood, Format, Host Organization(s), Description, Categories. Additionally when there is a venue: Location, and Google Maps (derived by the script from Location; never build it by hand, and the script leaves it empty when the address is withheld). Optional: End Time.

When the organizer published nothing, record that as a value rather than leaving the cell empty:

| Situation | What goes in the cell |
|---|---|
| The page states no price anywhere | `Access` = **Not stated** |
| Address released after registration | `Location` = **Shared after registration** |
| Venue not announced yet | `Location` = **To be announced** |
| Runs all day, no start time published | `Start Time` = **All day** |

"Not stated" records that the page was read and no price was found. Never write `Free` because a page did not mention money. When the address is withheld, Location and Google Maps are both satisfied and the script stops asking.

`build_sheet.py` writes a `Missing Info` column naming any missing required field and shades only the empty cells red. When it says the sheet is not ready, open the event page for each flagged row, read the value, and re-run. **The lead should receive a sheet with no red in it.** If a field is unavailable on the event's own page, say which row, which field, and what the page showed, and use the resolved-unknown value where one applies.

## Output: the events sheet

Fourteen columns in this order with these exact headers, then `Block` and `Source`, then `Missing Info`:

| # | Column | Contents |
|---|---|---|
| 1 | `Event Name` | As the organizer wrote it. Do not shorten or editorialize |
| 2 | `Date` | `YYYY-MM-DD` |
| 3 | `Start Time (TZ)` | `HH:MM`, 24-hour. The city's timezone in the header: `(PDT)`, `(EDT)`, `(BST)` |
| 4 | `End Time (TZ)` | Same format. Blank if not published |
| 5 | `Registration Link` | Where people register. Never a homepage, never a listing page |
| 6 | `Event Type` | `In-person` / `Hybrid` / `Online` |
| 7 | `Access` | `Free` / `Free — register to view address` / `Ticketed (Paid)` / `Ticketed (Paid) — register to view address` / `Not stated` |
| 8 | `Location` | Full street address as published. `Online` for online events |
| 9 | `City / Neighborhood` | The scannable geography: `Brooklyn`, `Cambridge`, `Vancouver, BC` |
| 10 | `Google Maps` | Derived by the script from Location |
| 11 | `Format` | Comma-separated, from the list below |
| 12 | `Host Organization(s)` | Comma-separated. Include named individuals when the page credits them |
| 13 | `Description` | From the event's own page, see below |
| 14 | `Categories` | One to three from the controlled list, comma-separated |
| 15 | `Block` | `this_week` / `upcoming` |
| 16 | `Source` | `registry` / `submitted` / `lead` |

The `Access` values are matched literally by the script, punctuation included. Reproduce them exactly.

**Write the sheet with the bundled script**, never by hand, so the columns come out identical every week and `ctc-assemble` can read them by name:

```
python3 scripts/build_sheet.py events.json out.xlsx --tz EDT --block
```

`events.json` is a list of objects keyed by the column names, using `Start Time` and `End Time` without the timezone suffix, plus `Block` and `Source`. `--block` is the newsletter mode and adds both columns. The script warns rather than refusing; a warning is a prompt for the editor, not a reason to withhold the file.

### Descriptions

**From the event's own page, two to three sentences, 40 to 70 words, in the shape `../ctc-assemble/references/voice.md` section 6 "This Week in Detail descriptions" sets.** That section is the only statement of the shape; do not restate it here or anywhere else.

Every this-week event's description is printed in the issue, one entry each, so this column is read by subscribers, not just by the lead. Condense and tidy the page's own wording; do not rewrite from scratch and do not embellish. If the page gives fewer than 40 words of fact, a shorter description is the correct output; never pad toward the range and never invent a speaker, venue, or price the page did not give.

### Categories

Controlled vocabulary, one to three per event:

`Adaptation` · `AI & Data` · `Arts & Culture` · `Biodiversity & Nature` · `Buildings` · `Circular Economy & Waste Management` · `Cities` · `Climate Tech & Startups` · `Communications` · `Corporate Sustainability` · `Energy` · `Environmental Justice` · `Finance` · `Food & Agriculture` · `Fun for Kids` · `Get Outside` · `Health` · `Mobility & Logistics` · `Philanthropy` · `Policy` · `Social` · `Water`

Do not invent a category. If nothing fits, use the closest and flag it in the run report. The same 22 are the choices on the submission form.

### Format

Freer than Categories, but stay consistent within a run:

`Panel Session` · `Happy Hour` · `Workshop` · `Networking` · `Community Event` · `Tour` · `Field Trip` · `Outdoors` · `Volunteer` · `Talk` · `Social` · `Meetup` · `Conference` · `Fair` · `Q&A` · `Presentation` · `Webinar` · `Screening` · `Exhibition` · `Site Tour` · `Fireside Chat` · `Dinner` · `Hackathon` · `Info Session`

## Dedupe

The same event appears on several calendars under slightly different names, and now also through the submission form. Match on `Date` plus fuzzy `Event Name`, then confirm by venue. Two names are the same event when one contains the other, or when they agree after stripping the host name, the city name, edition numbers, and punctuation.

| Situation | Ruling |
|---|---|
| Same event, two calendars, different registration links | Merge. Keep the organizer's own link |
| One listing has a full description, the other a better link | Merge, taking the best value per field |
| Same event from a registry source and the submission form | Merge. Keep `Source = submitted`, prefer the submitter's description, keep the organizer's link |
| Same series, different dates | Two rows |
| In-person and online tickets listed separately | One row, `Event Type` = `Hybrid` |
| Two calendars credit different co-hosts | Merge, and merge the host list |
| Same title, same day, different venues across the metro | Two rows, and flag it |
| Uncertain whether two rows are one event | Keep both, surface the collision in the report |

Merging destroys information and duplicating does not. When unsure, duplicate and report.

## Verify before handing over

Run `references/verifier.md` on the built sheet: a fresh, adversarial pass that re-opens every registration link (upcoming rows included), checks each row against its page, the scope rule, and the window boundary, reads every description against voice.md, and confirms no submitted row was dropped. That file says how to run it as a subagent where the session has one and as a separate step where it does not. Fix `events.json`, re-run `build_sheet.py`, and only then write the run report. The verifier's findings are part of the report.

## Run report

After writing the sheet, in chat:

- Events found, split by block, and how many came through the submission form
- Sources swept out of sources registered, and which tier each needed
- Sources that returned nothing, by name, and sources that failed, by name and cause, reported separately
- Duplicates merged, and collisions left for the lead
- Rows with missing required fields, by column, and why
- Anything that could not be categorized
- Any submitted row where the form and the event page disagreed

## Sanity check

Compare the count against the city's normal before handing over. A launch chapter's first issues carry 3 to 8 events this week and 5 to 15 upcoming; New York in 2026 carries 15 to 25 and 25 to 40. These are diagnostic ranges, not targets. A sweep returning three events in a city that normally yields twenty means a source broke. Never add a marginal event to reach a number; a quiet August is a real result.

## Failure modes

**Times off by the UTC offset.** Luma's `start_at` is UTC. Convert to the city's timezone before writing the sheet. Check one event against its own page before trusting the batch.

**Out-of-town events shipped.** Multi-city organizations put every city on one calendar. Filter on the event's own location against the scope rule, not the calendar's name. The same applies to the submission form: a submitter can pick the wrong city.

**A city discovery page treated as a source.** `luma.com/{city}` is a general local feed and a discovery aid for `ctc-source-map`, never an auto-pull here.

**Syndicated training spam.** Generic "ESG & Sustainability Strategy: 1 Day Training" listings republished across dozens of cities by resellers. If the same title appears in three cities, it is a reseller.

**A term-time calendar declared dead.** University sources empty out in July and August and in late December. A zero return in August from a source that was weekly in April is a season.

**A submitted event trusted without opening its page.** The form is an intake, not a verification. Every submitted link gets opened like any other.

**Shipping the sheet without the report.** The counts, the failures, and the zero-return sources are how the lead knows whether to trust the file.
