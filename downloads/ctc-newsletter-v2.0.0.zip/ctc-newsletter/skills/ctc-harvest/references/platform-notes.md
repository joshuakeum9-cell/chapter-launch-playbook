# Platform notes

How to actually get event data off each platform. These techniques are the difference between a harvest that works and one that returns titles with no dates.

---

## Luma

**Tier 1 (plain fetch) is not enough.** A calendar page returns event titles and slugs, but dates, times and addresses render client-side. You get a page full of empty bullets where the dates should be.

**Tier 2 (browser) is the reliable path.** Luma embeds the full structured payload in a `__NEXT_DATA__` script tag. Read it directly rather than scraping the rendered DOM:

```js
const nd = document.getElementById('__NEXT_DATA__');
const j = JSON.parse(nd.textContent);
const d = j.props.pageProps.initialData.data;
const items = d.featured_items || [];
items.map(x => {
  const e = x.event || x;
  return {
    name: e.name,
    start: e.start_at,             // ISO, UTC. Convert to local
    end: e.end_at,
    slug: e.url,                   // full URL is https://luma.com/{slug}
    city: e.geo_address_info?.city_state,
    address: e.geo_address_info?.full_address,
  };
});
```

**Sweeping several calendars in one pass.** From any luma.com page, fetch sibling calendars same-origin and parse the same tag. No need to navigate per calendar:

```js
async function cal(slug) {
  const html = await fetch('/' + slug).then(r => r.text());
  const m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
  if (!m) return null;
  const d = JSON.parse(m[1]).props?.pageProps?.initialData?.data;
  return { name: d?.calendar?.name, items: d?.featured_items || [] };
}
```

**Individual event pages** use the same structure, with the payload at `data.event` and hosts at `data.hosts`. Use these to fill descriptions, full addresses, and host organizations.

**Watch for:**
- `start_at` is **UTC**. Convert to the city's timezone before writing the sheet, or every time will be wrong for every row.
- A calendar returning `featured_items` of length 0 is either empty or not yet launched. Both are worth reporting. An empty core source is a signal, not a non-event.
- Multi-city organizations put every city on one calendar. Greentown Labs lists Houston alongside Boston. **Filter on `geo_address_info` against the city's scope rule** or out-of-town events will ship.
- Luma's city discovery page (`luma.com/{city}`) is *not* a climate source. On a Boston sample it returned 20 events of which 2 were climate-relevant; the rest were AI meetups and run clubs. Treat it as a discovery aid, never an auto-pull.

---

## Eventbrite

Roughly half of all event links in a mature chapter, bigger than Luma, and less cooperative.

- Organizer pages are heavier and more likely to block a plain fetch. Expect to reach Tier 2 more often than with Luma.
- Register **organizer pages**, not individual events. An organizer is a durable source; one event is not.
- Country domains vary. `.com`, `.ca`, `.co.uk`, `.sg` all appear. Normalize when deduping.
- Syndicated commercial training spam (SKILL.md, failure modes) often arrives here from an unrelated country's domain. It passes a naive relevance check and pollutes every issue once registered.

---

## The CTC event submission form (Airtable shared view)

One table for every chapter, read through a read-only shared view. The link is the standing `submissions` row in the registry (and in `../../ctc-assemble/references/ctc-links.md`).

- **Open it in the browser.** A plain fetch of an Airtable shared view returns an empty shell. In the browser the grid renders; filter or scroll to this chapter's `City` and read the rows inside the date windows. The view is already sorted by `Date` and hides past events.
- **Columns map onto the sheet by name:** Event Name, City (the chapter), Date, Start Time, End Time, Registration Link, Event Type, Access, Location, City / Neighborhood, Host Organization(s), Description, Categories. Anything the form does not carry (Format, Google Maps) is filled from the event's own page, as for any other row. `Start Time` and `End Time` are free text as the submitter typed them ("6:00 PM"); convert to `HH:MM`.
- **`Your Name`, `Your Email`, `Anything else?`, `Status`, and `Submitted At` never leave the table.** They are for the lead to follow up, not for the sheet.
- The rules for submitted rows (open every link, the page wins on facts and the submitter wins on description, `Source = submitted`, never drop one, report the count, carry on if the view will not open) are in SKILL.md Step 2 and are not repeated here.

---

## Web calendars

Universities, utilities, and government sites. Mostly server-rendered and fine on Tier 1, but:

- Many are seasonal. University calendars empty out between terms. A quiet source in July is not a dead source.
- Some render the list client-side while showing events on the homepage. If `/events` looks emptier than the homepage, escalate to Tier 2 before concluding the source is quiet.
- Prefer a stable listing URL over a filtered search result.

---

## When the browser is not available

Tier 2 is the reliable path for Luma, Eventbrite, and the submission view, so a lead without the Claude in Chrome extension is not running a degraded harvest, they are running a broken one. Say so rather than producing a sheet full of blanks.

Three honest options, in order:

1. **Install the extension.** It fixes every week from now on. This is the answer for anyone planning to keep sending.
2. **Paste per source.** The lead opens each Luma calendar and pastes the page. Workable for a registry of five sources, miserable at twenty.
3. **Harvest the server-rendered sources only** and say plainly which sources were skipped and roughly what share of a normal week they represent. A thin issue with a known cause is recoverable. A thin issue with an unknown cause is what makes a lead quit.

Never pick option 3 silently.

## General rules

Pacing, the sandbox's network limits, CAPTCHA and login walls, and the no-guessing rule with its four resolved-unknown values all live in SKILL.md (Environment, Step 1, and Step 4). This file is only about getting data off each platform.
