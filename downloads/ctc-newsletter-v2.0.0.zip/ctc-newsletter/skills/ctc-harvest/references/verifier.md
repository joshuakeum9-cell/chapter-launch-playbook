# Events sheet verifier

A second, adversarial pass over the finished events sheet before it goes to the lead. Every one of the fourteen link defects that shipped in a real issue would have been caught by this pass. It is not optional.

## How to run it

Run this as a fresh pass with no memory of the sweep. If the session has a subagent or task tool, launch one with exactly this file, the events `.xlsx`, and the scope rule, and nothing else. If it does not, run it yourself as a separate step after the sheet is built: read this file first, open the sheet cold, and work every row as though someone else harvested it. Fix `events.json`, re-run `build_sheet.py`, and only then deliver.

Do the whole sheet, `upcoming` included. In the reviewed issue every failure was in `upcoming`.

## Checks, per row

1. **Open the registration link.** The page loads, its title is this event, its date matches the `Date` cell, and it does not say the event has passed. Any of the three failing means fix the link, fix the date, or drop the row. A redirect to a different slug means the event you wanted does not exist.
2. **The link is an event page**, not a calendar, a homepage, or a listing index (`/events`, `/calendar`, `/upcoming`, `/whats-on`). The build script flags the obvious ones; catch the rest by eye.
3. **Start Time, Location, Access, Host** match the page. A row with two or more of these blank was written from a listing page and needs the page opened.
4. **Scope.** The event's own location is inside the scope rule. Multi-city calendars and the submission form both let out-of-town events through.
5. **Block.** `this_week` rows fall inside the this-week window, `upcoming` rows after it. A row on the wrong side of the boundary lands in the wrong listing.
6. **Description.** Two to three sentences, 40 to 70 words, from the page, in the shape `../../ctc-assemble/references/voice.md` section 6 sets. No banned phrases from voice.md section 5, no invented speaker, venue, or price, no why-go sentence. This column is printed for every this-week event, so it is read by subscribers.
7. **Categories** are one to three from the controlled list, and fit the event.
8. **Submitted rows.** `Source = submitted` rows exist for every submission in the shared view for this city and these windows. None were dropped. Where the form and the page disagreed, the page won and the report says so.

## Checks, whole sheet

9. **Duplicates.** Same date plus similar name plus same venue is one event. Merge per the dedupe table in SKILL.md, keeping the organizer's link.
10. **Times.** Spot-check three Luma rows against their pages. If one is off by hours, every Luma row is off (UTC not converted); fix all of them.
11. **Red cells.** None remain, or each remaining one is named in the report with what the page showed.
12. **Count.** The total against the chapter's normal, and the zero-return sources named.

## What to report

Rows fixed (by name, with the check number), rows dropped and why, duplicates merged, anything left red and why, and a one-line verdict: ready, or not.
