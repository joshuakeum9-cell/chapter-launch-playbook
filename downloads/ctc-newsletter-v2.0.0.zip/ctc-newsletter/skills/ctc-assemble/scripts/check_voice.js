#!/usr/bin/env node
/**
 * Scan an issue.json for banned words and constructions, using the list in
 * references/voice.md section 5 as the single source of truth.
 *
 *   node check_voice.js issue.json [path/to/voice.md]
 *
 * Reads every quoted "phrase" between the "## 5." and "## 6." headings of
 * voice.md and searches the issue's prose for each one, case-insensitive.
 * Also flags em dashes, stacked exclamation marks, and title-case headings.
 * Exit code 0 always: this is a report for a person, not a gate. Read it.
 *
 * Fixed blocks (platforms, footer) are skipped: their wording is fixed text
 * that voice.md exempts.
 */

const fs = require('fs');
const path = require('path');

const [, , inPath, voiceArg] = process.argv;
if (!inPath) {
  console.error('usage: node check_voice.js issue.json [voice.md]');
  process.exit(1);
}
const voicePath = voiceArg || path.join(__dirname, '..', 'references', 'voice.md');
const voice = fs.readFileSync(voicePath, 'utf8');
const issue = JSON.parse(fs.readFileSync(inPath, 'utf8'));

// ---- banned list from voice.md section 5 ---------------------------------
const s5 = voice.split(/^## 5\./m)[1];
const section5 = s5 ? s5.split(/^## 6\./m)[0] : '';
const banned = [];
const seen = new Set();
for (const m of section5.matchAll(/"([^"]{3,60})"/g)) {
  const phrase = m[1].trim().replace(/[\u2018\u2019]/g, "'");
  // Skip the two "say X instead" recommendations that appear in quotes.
  if (/^(our picks|don't sleep on|shakes, cakes)/i.test(phrase)) continue;
  // Skip the example words used to illustrate a pattern.
  if (/^(ready to make a difference|connection, inspiration|x|y)$/i.test(phrase)) continue;
  // "This week" is banned only as an opener (voice.md section 5, patterns); it is
  // checked below against the first words of each opening-note paragraph, not
  // as a phrase anywhere in the prose.
  if (/^this week$/i.test(phrase)) continue;
  if (!seen.has(phrase.toLowerCase())) { seen.add(phrase.toLowerCase()); banned.push(phrase); }
}
if (!banned.length) {
  console.error('could not read a banned list from ' + voicePath + ' (section 5 has no quoted phrases)');
  process.exit(1);
}

// ---- collect the prose to scan, with a label per string -------------------
const texts = [];
const norm = t => String(t).replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"');
const add = (label, t) => { if (typeof t === 'string' && t.trim()) texts.push([label, norm(t)]); };
add('title', issue.title); add('subtitle', issue.subtitle);
(issue.opening_note || []).forEach((p, i) => add(`opening note ${i + 1}`, p));
(issue.picks || []).forEach((p, i) => (p.segments || []).forEach(s => add(`pick ${i + 1} (${p.day})`, s.text)));
(issue.housekeeping || []).forEach((p, i) => add(`housekeeping ${i + 1}`, p));
(issue.signoff || []).forEach((p, i) => add(`sign-off ${i + 1}`, p));
(issue.opportunities || []).forEach(o => { add(`opportunity "${o.title}"`, o.description); add(`opportunity "${o.title}" deadline`, o.deadline); });
(issue.this_week_in_detail || []).forEach(e => add(`detail "${e.title}"`, e.description));

// ---- scan --------------------------------------------------------------------
const hits = [];
for (const [label, t] of texts) {
  if (/^\[.*\]$/.test(t.trim())) continue; // the rewrite marker itself
  for (const b of banned) {
    const re = new RegExp('(^|[^a-z])' + b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+') + '(?=$|[^a-z])', 'i');
    if (re.test(t)) hits.push([label, `banned: "${b}"`]);
  }
  if (/—/.test(t)) hits.push([label, 'em dash (use a comma, period, or parenthesis)']);
  if (/!{2,}/.test(t) || (t.match(/!/g) || []).length > 1) hits.push([label, 'more than one exclamation mark']);
}
// Opening with the date or "This week" when a real hook is available (voice.md section 5, patterns).
(issue.opening_note || []).forEach((p, i) => {
  const t = norm(p).trim();
  if (/^\[.*\]$/.test(t) || /^hi\b/i.test(t)) return; // marker line or greeting
  // A date is a weekday name or "Month D"; a seasonal hook ("August is quiet here") is fine.
  if (/^this week\b/i.test(t) || /^(it's |it is )?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/i.test(t) || /^(it's |it is )?(january|february|march|april|may|june|july|august|september|october|november|december) \d/i.test(t)) {
    hits.push([`opening note ${i + 1}`, 'opens with the date or "This week"; open on a real hook instead']);
  }
});
// One exclamation mark per piece at most, across the editorial blocks.
const editorial = texts.filter(([l]) => /^(opening note|pick|housekeeping)/.test(l)).map(([, t]) => t).join(' ');
const bangs = (editorial.match(/!/g) || []).length;
if (bangs > 1) hits.push(['editorial blocks together', `${bangs} exclamation marks; the voice allows one per piece`]);
// Title-case headings: an event title is the organizer's and is exempt; check only the subtitle.
if (issue.subtitle && issue.subtitle.split(/\s+/).filter(w => /^[A-Z][a-z]+$/.test(w)).length > issue.subtitle.split(/\s+/).length * 0.6) {
  hits.push(['subtitle', 'reads as title case; the subtitle is sentence case except proper nouns']);
}

// ---- report ------------------------------------------------------------------
console.log(`checked ${texts.length} strings against ${banned.length} banned phrases from voice.md section 5`);
if (!hits.length) { console.log('no banned phrases, em dashes, or stacked exclamation marks found'); }
else {
  console.log(`${hits.length} thing(s) to fix before delivering:`);
  hits.forEach(([l, h]) => console.log(`  ! ${l}: ${h}`));
}
