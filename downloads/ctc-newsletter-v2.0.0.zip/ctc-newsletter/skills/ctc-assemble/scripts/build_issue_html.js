#!/usr/bin/env node
/**
 * Render an assembled CTC issue as a Substack-styled HTML article.
 *
 *   node build_issue_html.js issue.json out.html
 *
 * Same issue.json contract and the same fixed block order as build_issue.js:
 *   title, opening note, picks, housekeeping + sign-off, platforms block,
 *   opportunities, This Week's Events, Upcoming Events, This Week in Detail,
 *   Join the fun.
 *
 * Styling mirrors nyc.climatetechcities.com, measured from the live DOM: body
 * serif at 17px, headers sans, h2 1.625x, h3 1.375x, h4 1.125x, list items
 * indented 32px, descriptions in a left-bordered blockquote.
 *
 * Open the file in a browser, click before the first word, drag to the bottom,
 * copy, paste into the Substack editor. Formatting and links carry across.
 */

const fs = require('fs');

// Fixed CTC links. Identical for every chapter. Same table as build_issue.js
// and references/ctc-links.md; change all three together.
const FIXED_LINKS = {
  ctc: 'https://www.climatetechcities.com/',
  streetlife: 'https://www.streetlifeventures.com/',
  raise: 'https://gccht82e8mz.typeform.com/to/fLp65vtz?typeform-source=www.climatetechcities.com',
  talent: 'https://gccht82e8mz.typeform.com/to/Rk2roZac?typeform-source=www.climatetechcities.com',
  volunteer: 'https://airtable.com/appJJx88dpQsUuEas/pagA3Zi7dEGeGuxmd/form',
  submit_events: 'https://airtable.com/appunzUZg6b8fe83m/pagmLLAnynXZxEtmL/form',
};

const STANDARD_PLATFORMS = {
  heading: '\u{1F30E} Climate Tech Cities and Streetlife Ventures Startup and Talent Platforms',
  body: 'Climate Tech Cities and Streetlife Ventures are launching new platforms to support climate founders, funders, and career transitioners! There is no shortage of great companies raising money for their groundbreaking ideas, great investors looking to support with capital, and great talent living the mantra that every job is a climate job. We can\'t wait to hear from you!',
  links: [
    { text: 'Climate startups looking to raise', url: FIXED_LINKS.raise },
    { text: 'Climate talent looking to transition', url: FIXED_LINKS.talent },
  ],
};

const STANDARD_FOOTER = {
  heading: 'Join the Fun!',
  items: [
    {
      title: 'Submit Events',
      body: 'Running something climate-related in the city? We\'d love to spread the word. Tell us about it and it goes into next week\'s list.',
      link_text: 'Submit an event',
      url: FIXED_LINKS.submit_events,
    },
    {
      title: 'Volunteer',
      body: 'Climate Tech Cities runs on volunteers. If you want to help with events, the newsletter, or the chapter itself, say hello.',
      link_text: 'Volunteer with Climate Tech Cities',
      url: FIXED_LINKS.volunteer,
    },
  ],
};

const PLACEHOLDER = /example\.|PLACEHOLDER|replace before sending|_URL_PENDING|_URL\b|^#?$/i;

function checkFixedLinks(d) {
  const bad = [];
  const check = (label, url, expected) => {
    const u = String(url || '');
    if (PLACEHOLDER.test(u)) bad.push(`  X ${label}: "${u || '(empty)'}" is a placeholder`);
    else if (expected && u !== expected) bad.push(`  X ${label}: "${u}" is not the fixed CTC link (${expected})`);
  };
  (d.platforms.links || []).forEach((l, i) => check(`platforms link ${i + 1} "${l.text}"`, l.url, [FIXED_LINKS.raise, FIXED_LINKS.talent][i]));
  (d.footer.items || []).forEach((it, i) => check(`footer item ${i + 1} "${it.title}"`, it.url, [FIXED_LINKS.submit_events, FIXED_LINKS.volunteer][i]));
  if (bad.length) {
    console.error('FIXED LINKS NOT READY. The CTC links are the same for every chapter and never placeholders:');
    bad.forEach(b => console.error(b));
    console.error('  See references/ctc-links.md. Omit "platforms" and "footer" from issue.json and the standard blocks are inserted.');
    process.exit(1);
  }
}

// Structural checks that catch the errors readers notice. Warnings only, so a
// build never silently withholds the file, but read them before delivering.
function structureReport(issue) {
  const notes = [];
  const twTitles = [];
  (issue.this_week || []).forEach(d => (d.events || []).forEach(e => twTitles.push(e.title)));
  const detailTitles = (issue.this_week_in_detail || []).map(e => e.title);
  const missingDetail = twTitles.filter(t => !detailTitles.includes(t));
  const extraDetail = detailTitles.filter(t => !twTitles.includes(t));
  if (twTitles.length && !detailTitles.length) notes.push(`This Week in Detail is empty but This Week's Events has ${twTitles.length} events. Every this-week event gets a detail entry.`);
  if (missingDetail.length) notes.push(`This Week in Detail is missing ${missingDetail.length} of this week's events: ${missingDetail.join(' | ')}`);
  if (extraDetail.length) notes.push(`This Week in Detail has entries not in This Week's Events: ${extraDetail.join(' | ')}`);
  const upTitles = (issue.upcoming || []).map(e => e.title);
  const both = twTitles.filter(t => upTitles.includes(t));
  if (both.length) notes.push(`Listed in both This Week's Events and Upcoming: ${both.join(' | ')}`);
  const allListed = twTitles.concat(upTitles);
  (issue.picks || []).forEach(p => (p.segments || []).forEach(s => {
    if (s.link && !allListed.includes(s.text)) notes.push(`Pick "${s.text}" is not in either listing block.`);
  }));
  let brackets = 0;
  const scan = s => { if (typeof s === 'string') brackets += (s.match(/\[[^\]]*\]/g) || []).length; };
  (issue.opening_note || []).forEach(scan); (issue.housekeeping || []).forEach(scan); scan(issue.picks_intro);
  (issue.picks || []).forEach(p => (p.segments || []).forEach(s => scan(s.text)));
  (issue.opportunities || []).forEach(o => { scan(o.description); scan(o.deadline); });
  console.log(`blocks: note ${(issue.opening_note || []).length} paras, picks ${(issue.picks || []).length}, opportunities ${(issue.opportunities || []).length}, this week ${twTitles.length}, upcoming ${upTitles.length}, in detail ${detailTitles.length}`);
  console.log(`bracketed draft markers still in the editorial blocks: ${brackets} (all of these must be gone before sending)`);
  if (notes.length) { console.log('CHECK BEFORE DELIVERING:'); notes.forEach(n => console.log('  ! ' + n)); }
}

const esc = s => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const link = (text, url) => `<a href="${esc(url)}">${esc(text)}</a>`;

function segs(list) {
  return (list || []).map(s => {
    const t = s.bold ? `<strong>${esc(s.text)}</strong>` : esc(s.text);
    return s.link ? `<a href="${esc(s.link)}">${t}</a>` : t;
  }).join('');
}

/** A paragraph. A bracketed draft marker on its own line renders as a yellow
 *  band so the pre-send check ("search for a square bracket") has help. */
function p(text, style) {
  const isMarker = /^\[.*\]$/.test(String(text).trim());
  if (isMarker) return `<p class="draft">${esc(text)}</p>`;
  return `<p${style ? ` style="${style}"` : ''}>${inlineBold(text)}</p>`;
}

/** "a **b** c" -> a <strong>b</strong> c, escaped. */
function inlineBold(text) {
  return String(text).split('**').map((t, i) => i % 2 === 1 ? `<strong>${esc(t)}</strong>` : esc(t)).join('');
}

const CSS = `
:root { --base: 17px; }
body { margin: 0; padding: 40px 20px; background: #fff; }
.post { max-width: 620px; margin: 0 auto; color: #1a1a1a;
  font-family: Spectral, Georgia, Cambria, serif; font-size: var(--base); line-height: 1.6; }
.post h1, .post h2, .post h3, .post h4 {
  font-family: "SF Pro Display", -apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif;
  font-weight: 700; line-height: 1.16; }
.post h1 { font-size: 2.2em; margin: 0 0 .3em; letter-spacing: -.02em; }
.post .subtitle { font-size: 1.25em; color: #5f5f5f; margin: 0 0 1.6em;
  font-family: "SF Pro Display", -apple-system, Helvetica, Arial, sans-serif; font-weight: 400; }
.post h2 { font-size: 1.625em; margin: 1em 0 .625em; }
.post h3 { font-size: 1.375em; margin: 1em 0 .625em; }
.post h4 { font-size: 1.125em; margin: 1em 0 .625em; }
.post p { margin: 0 0 20px; }
.post ul { margin: 0 0 17px; padding: 0; list-style: disc; }
.post li { margin: 8px 0 0 32px; }
.post blockquote { margin: 20px 0; padding-left: 16px; border-left: 4px solid #e0e0e0; color: #333; }
.post a { color: #1a1a1a; text-decoration: underline; text-underline-offset: 2px; }
.post hr { border: 0; border-top: 1px solid #e6e6e6; margin: 32px 0; }
.post .draft { background: #fff6d9; border-left: 4px solid #e0b000; padding: 8px 12px;
  font-family: -apple-system, Helvetica, Arial, sans-serif; font-size: 13px; color: #6b5200; margin: 0 0 12px; }
`;

function build(d) {
  const h = [];
  // 1. Title and subtitle
  h.push(`<h1>${esc(d.title)}</h1>`);
  if (d.subtitle) h.push(`<p class="subtitle">${esc(d.subtitle)}</p>`);

  // 2. Opening note
  (d.opening_note || []).forEach(t => h.push(p(t)));

  // 3. Picks
  if ((d.picks || []).length) {
    // picks_intro is the block 3 marker slot: the bracketed line above the bullets.
    if (d.picks_intro) h.push(p(d.picks_intro));
    h.push('<ul>');
    d.picks.forEach(pk => h.push(`<li><strong>${esc(pk.day)}</strong> ${segs(pk.segments)}</li>`));
    h.push('</ul>');
  }

  // 4. Housekeeping and sign-off
  (d.housekeeping || []).forEach(t => h.push(p(t)));
  (d.signoff || []).forEach(l => h.push(p(l, 'margin-bottom:4px')));

  // 5. Platforms block (fixed)
  h.push('<hr>');
  h.push(`<h2>${esc(d.platforms.heading)}</h2>`);
  h.push(`<p>${esc(d.platforms.body)}</p><ul>`);
  (d.platforms.links || []).forEach(l => h.push(`<li>${link(l.text, l.url)}</li>`));
  h.push('</ul>');

  // 6. Opportunities
  if ((d.opportunities || []).length) {
    h.push('<hr>');
    h.push('<h3>Opportunities:</h3>');
    d.opportunities.forEach(o => {
      h.push(`<h3>${link(o.title, o.url)}</h3>`);
      const dl = o.deadline ? ` <strong>${esc(o.deadline)}</strong>` : '';
      h.push(`<blockquote>${esc(o.description)}${dl}</blockquote>`);
    });
  }

  // 7. This Week's Events
  if ((d.this_week || []).length) {
    h.push('<hr>');
    h.push("<h2>This Week's Events</h2>");
    d.this_week.forEach(day => {
      h.push(`<h4>${esc(day.day)}</h4><ul>`);
      (day.events || []).forEach(e => h.push(`<li>${link(e.title, e.url)}</li>`));
      h.push('</ul>');
    });
  }

  // 8. Upcoming Events
  if ((d.upcoming || []).length) {
    h.push('<hr>');
    h.push('<h2>Upcoming Events</h2><ul>');
    d.upcoming.forEach(e => h.push(`<li>${link(e.title, e.url)}: ${esc(e.date)}</li>`));
    h.push('</ul>');
  }

  // 9. This Week in Detail
  if ((d.this_week_in_detail || []).length) {
    h.push('<hr>');
    h.push('<h2>This Week in Detail</h2>');
    d.this_week_in_detail.forEach(e => {
      h.push(`<h3>${link(e.title, e.url)}</h3>`);
      h.push(`<p><strong>When:</strong> ${esc(e.when)}</p>`);
      h.push(`<p><strong>Where:</strong> ${esc(e.where)}</p>`);
      h.push(`<blockquote>${esc(e.description)}</blockquote>`);
    });
  }

  // 10. Join the fun (fixed)
  h.push('<hr>');
  h.push(`<h2>${esc(d.footer.heading)}</h2>`);
  (d.footer.items || []).forEach(it => {
    h.push(`<h3>${esc(it.title)}</h3>`);
    h.push(`<p>${esc(it.body)} ${link(it.link_text, it.url)}</p>`);
  });

  return `<!DOCTYPE html><html><head><meta charset="utf-8">
<title>${esc(d.title)}</title>
<link href="https://fonts.googleapis.com/css2?family=Spectral:wght@400;700&display=swap" rel="stylesheet">
<style>${CSS}</style></head><body><div class="post">
${h.join('\n')}
</div></body></html>`;
}

const [, , inPath, outPath] = process.argv;
if (!inPath || !outPath) {
  console.error('usage: node build_issue_html.js issue.json out.html');
  process.exit(1);
}
const d = JSON.parse(fs.readFileSync(inPath, 'utf8'));
if (!d.platforms) d.platforms = STANDARD_PLATFORMS;
if (!d.footer) d.footer = STANDARD_FOOTER;
checkFixedLinks(d);
structureReport(d);
fs.writeFileSync(outPath, build(d));
console.log('wrote ' + outPath);
