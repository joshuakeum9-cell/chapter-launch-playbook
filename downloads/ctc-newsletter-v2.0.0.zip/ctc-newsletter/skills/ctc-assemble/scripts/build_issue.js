#!/usr/bin/env node
/**
 * Render an assembled CTC newsletter issue as a formatted .docx with embedded
 * hyperlinks, ready to paste straight into the Substack editor.
 *
 *   node build_issue.js issue.json out.docx
 *
 * See SKILL.md for the issue.json contract. Block order is fixed here and
 * matches the order Climate Tech Cities set on 20 Aug 2026:
 *
 *   1 title + subtitle          7 This Week's Events
 *   2 opening note              8 Upcoming Events
 *   3 picks of the week         9 This Week in Detail
 *   4 housekeeping + sign-off  10 Join the fun (submit events, volunteer)
 *   5 platforms block
 *   6 opportunities
 *
 * Blocks 5 and 10 are fixed text with fixed links. If issue.json omits them
 * the script inserts the standard versions. If issue.json supplies them, the
 * links are checked against FIXED_LINKS and a placeholder is a hard stop.
 */

const {
  Document, Packer, Paragraph, TextRun, ExternalHyperlink,
  HeadingLevel, AlignmentType, LevelFormat, BorderStyle,
} = require('docx');
const fs = require('fs');

// ---------------------------------------------------------------------------
// Fixed CTC links. Identical for every chapter. The same table lives in
// build_issue_html.js and in references/ctc-links.md; change all three together.
// ---------------------------------------------------------------------------
const FIXED_LINKS = {
  ctc: 'https://www.climatetechcities.com/',
  streetlife: 'https://www.streetlifeventures.com/',
  raise: 'https://gccht82e8mz.typeform.com/to/fLp65vtz?typeform-source=www.climatetechcities.com',
  talent: 'https://gccht82e8mz.typeform.com/to/Rk2roZac?typeform-source=www.climatetechcities.com',
  volunteer: 'https://airtable.com/appJJx88dpQsUuEas/pagA3Zi7dEGeGuxmd/form',
  submit_events: 'https://airtable.com/appunzUZg6b8fe83m/pagmLLAnynXZxEtmL/form',
};

const STANDARD_PLATFORMS = {
  heading: '\u{1F30E} Climate Tech Cities and Streetlife Ventures Startup and Talent Platforms',
  body: 'Climate Tech Cities and Streetlife Ventures are launching new platforms to support climate founders, funders, and career transitioners! There is no shortage of great companies raising money for their groundbreaking ideas, great investors looking to support with capital, and great talent living the mantra that every job is a climate job. We can\'t wait to hear from you!',
  links: [
    { text: 'Climate startups looking to raise', url: FIXED_LINKS.raise },
    { text: 'Climate talent looking to transition', url: FIXED_LINKS.talent },
  ],
};

const STANDARD_FOOTER = {
  heading: 'Join the Fun!',
  items: [
    {
      title: 'Submit Events',
      body: 'Running something climate-related in the city? We\'d love to spread the word. Tell us about it and it goes into next week\'s list.',
      link_text: 'Submit an event',
      url: FIXED_LINKS.submit_events,
    },
    {
      title: 'Volunteer',
      body: 'Climate Tech Cities runs on volunteers. If you want to help with events, the newsletter, or the chapter itself, say hello.',
      link_text: 'Volunteer with Climate Tech Cities',
      url: FIXED_LINKS.volunteer,
    },
  ],
};

const PLACEHOLDER = /example\.|PLACEHOLDER|replace before sending|_URL_PENDING|_URL\b|^#?$/i;

function checkFixedLinks(issue) {
  const bad = [];
  const check = (label, url, expected) => {
    const u = String(url || '');
    if (PLACEHOLDER.test(u)) bad.push(`  X ${label}: "${u || '(empty)'}" is a placeholder`);
    else if (expected && u !== expected) bad.push(`  X ${label}: "${u}" is not the fixed CTC link (${expected})`);
  };
  (issue.platforms.links || []).forEach((l, i) =>
    check(`platforms link ${i + 1} "${l.text}"`, l.url, [FIXED_LINKS.raise, FIXED_LINKS.talent][i]));
  (issue.footer.items || []).forEach((it, i) =>
    check(`footer item ${i + 1} "${it.title}"`, it.url, [FIXED_LINKS.submit_events, FIXED_LINKS.volunteer][i]));
  if (bad.length) {
    console.error('FIXED LINKS NOT READY. The CTC links are the same for every chapter and never placeholders:');
    bad.forEach(b => console.error(b));
    console.error('  See references/ctc-links.md. Omit "platforms" and "footer" from issue.json and the standard blocks are inserted.');
    process.exit(1);
  }
}

// Structural checks that catch the errors readers notice. Warnings only, so a
// build never silently withholds the file, but read them before delivering.
function structureReport(issue) {
  const notes = [];
  const twTitles = [];
  (issue.this_week || []).forEach(d => (d.events || []).forEach(e => twTitles.push(e.title)));
  const detailTitles = (issue.this_week_in_detail || []).map(e => e.title);
  const missingDetail = twTitles.filter(t => !detailTitles.includes(t));
  const extraDetail = detailTitles.filter(t => !twTitles.includes(t));
  if (twTitles.length && !detailTitles.length) notes.push(`This Week in Detail is empty but This Week's Events has ${twTitles.length} events. Every this-week event gets a detail entry.`);
  if (missingDetail.length) notes.push(`This Week in Detail is missing ${missingDetail.length} of this week's events: ${missingDetail.join(' | ')}`);
  if (extraDetail.length) notes.push(`This Week in Detail has entries not in This Week's Events: ${extraDetail.join(' | ')}`);
  const upTitles = (issue.upcoming || []).map(e => e.title);
  const both = twTitles.filter(t => upTitles.includes(t));
  if (both.length) notes.push(`Listed in both This Week's Events and Upcoming: ${both.join(' | ')}`);
  const allListed = twTitles.concat(upTitles);
  (issue.picks || []).forEach(p => (p.segments || []).forEach(s => {
    if (s.link && !allListed.includes(s.text)) notes.push(`Pick "${s.text}" is not in either listing block.`);
  }));
  let brackets = 0;
  const scan = s => { if (typeof s === 'string') brackets += (s.match(/\[[^\]]*\]/g) || []).length; };
  (issue.opening_note || []).forEach(scan); (issue.housekeeping || []).forEach(scan); scan(issue.picks_intro);
  (issue.picks || []).forEach(p => (p.segments || []).forEach(s => scan(s.text)));
  (issue.opportunities || []).forEach(o => { scan(o.description); scan(o.deadline); });
  console.log(`blocks: note ${(issue.opening_note || []).length} paras, picks ${(issue.picks || []).length}, opportunities ${(issue.opportunities || []).length}, this week ${twTitles.length}, upcoming ${upTitles.length}, in detail ${detailTitles.length}`);
  console.log(`bracketed draft markers still in the editorial blocks: ${brackets} (all of these must be gone before sending)`);
  if (notes.length) { console.log('CHECK BEFORE DELIVERING:'); notes.forEach(n => console.log('  ! ' + n)); }
}

// Measured from the live NY Climate Tech DOM. Substack's base font is
// reader-configurable (17px / 19px observed) but the ratios are stable:
// h2 1.625x, h3 1.375x, h4 1.125x. Body is serif, headers are sans.
const BODY = 26;            // half-points -> 13pt, matches 17px base
const H2 = 42;              // 1.625x
const H3 = 36;              // 1.375x
const H4 = 29;              // 1.125x
const FONT = 'Georgia';     // stand-in for Spectral
const HFONT = 'Helvetica';  // stand-in for SF Pro Display

/** Turn a segment array into runs. A segment is {text} or {text, link}. */
function runs(segments) {
  const out = [];
  for (const seg of segments) {
    const bold = !!seg.bold;
    const italics = !!seg.italics;
    if (seg.link) {
      out.push(new ExternalHyperlink({
        link: seg.link,
        children: [new TextRun({ text: seg.text, bold, italics, font: FONT, size: BODY, style: 'Hyperlink' })],
      }));
    } else {
      out.push(new TextRun({ text: seg.text, bold, italics, font: FONT, size: BODY }));
    }
  }
  return out;
}

const para = (segments, opts = {}) => new Paragraph({
  children: runs(segments),
  spacing: { after: 200, line: 300 },
  ...opts,
});

/** Plain paragraph. A bracketed draft marker renders shaded so it cannot be missed. */
function plain(text, opts = {}) {
  const isMarker = /^\[.*\]$/.test(String(text).trim());
  if (isMarker) {
    return new Paragraph({
      children: [new TextRun({ text, font: HFONT, size: 22, color: '6B5200', bold: true, shading: { fill: 'FFF6D9' } })],
      spacing: { after: 160, line: 300 },
      border: { left: { style: BorderStyle.SINGLE, size: 18, color: 'E0B000', space: 8 } },
      indent: { left: 200 },
    });
  }
  return para(inlineBold(text), opts);
}

/** Split "a **b** c" into segments so reader asks bolded inline render bold. */
function inlineBold(text) {
  const parts = String(text).split('**');
  return parts.map((t, i) => ({ text: t, bold: i % 2 === 1 })).filter(s => s.text.length);
}

const bullet = (segments) => new Paragraph({
  children: runs(segments),
  numbering: { reference: 'b', level: 0 },
  spacing: { after: 140, line: 300 },
});

function h(text, level, size) {
  return new Paragraph({
    heading: level,
    spacing: { before: 360, after: 160 },
    children: [new TextRun({ text, bold: true, font: HFONT, size })],
  });
}

/** Indented, left-bordered block. Substack renders descriptions as blockquotes. */
function quote(segments) {
  return new Paragraph({
    children: runs(segments),
    indent: { left: 340 },
    spacing: { after: 200, line: 300 },
    border: { left: { style: BorderStyle.SINGLE, size: 12, color: 'E0E0E0', space: 8 } },
  });
}

/** Linked heading: emoji + title that is itself a hyperlink. */
function hLink(text, url, level, size) {
  return new Paragraph({
    heading: level,
    spacing: { before: 320, after: 120 },
    children: [new ExternalHyperlink({
      link: url,
      children: [new TextRun({ text, bold: true, font: HFONT, size, style: 'Hyperlink' })],
    })],
  });
}

const rule = () => new Paragraph({
  text: '',
  spacing: { before: 240, after: 240 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'D8D8D8', space: 1 } },
});

function build(issue) {
  const body = [];

  // 1. Title and subtitle
  body.push(new Paragraph({
    spacing: { after: 120 },
    children: [new TextRun({ text: issue.title, bold: true, font: FONT, size: 56 })],
  }));
  if (issue.subtitle) {
    body.push(new Paragraph({
      spacing: { after: 320 },
      children: [new TextRun({ text: issue.subtitle, font: HFONT, size: 32, color: '5F5F5F' })],
    }));
  }

  // 2. Opening note
  (issue.opening_note || []).forEach(p => body.push(plain(p)));

  // 3. Picks of the week
  if (issue.picks && issue.picks.length) {
    // picks_intro is the block 3 marker slot: the bracketed line above the bullets.
    if (issue.picks_intro) body.push(plain(issue.picks_intro));
    issue.picks.forEach(pick => {
      const segs = [{ text: pick.day + ' ', bold: true }].concat(pick.segments || []);
      body.push(bullet(segs));
    });
  }

  // 4. Housekeeping and sign-off
  (issue.housekeeping || []).forEach(p => body.push(plain(p)));
  (issue.signoff || []).forEach(line => body.push(
    new Paragraph({ spacing: { after: 60, line: 300 }, children: [new TextRun({ text: line, font: FONT, size: BODY })] })
  ));

  // 5. Platforms block (fixed)
  body.push(rule());
  body.push(h(issue.platforms.heading, HeadingLevel.HEADING_2, H2));
  body.push(plain(issue.platforms.body));
  (issue.platforms.links || []).forEach(l => body.push(bullet([{ text: l.text, link: l.url }])));

  // 6. Opportunities
  if (issue.opportunities && issue.opportunities.length) {
    body.push(rule());
    body.push(h('Opportunities:', HeadingLevel.HEADING_3, H3));
    issue.opportunities.forEach(o => {
      body.push(hLink(o.title, o.url, HeadingLevel.HEADING_3, H3));
      const segs = [{ text: o.description }];
      if (o.deadline) segs.push({ text: ' ' + o.deadline, bold: true });
      body.push(quote(segs));
    });
  }

  // 7. This Week's Events
  if (issue.this_week && issue.this_week.length) {
    body.push(rule());
    body.push(h("This Week's Events", HeadingLevel.HEADING_2, H2));
    issue.this_week.forEach(day => {
      body.push(h(day.day, HeadingLevel.HEADING_4, H4));
      (day.events || []).forEach(e => body.push(bullet([{ text: e.title, link: e.url }])));
    });
  }

  // 8. Upcoming Events
  if (issue.upcoming && issue.upcoming.length) {
    body.push(rule());
    body.push(h('Upcoming Events', HeadingLevel.HEADING_2, H2));
    issue.upcoming.forEach(e => body.push(bullet([{ text: e.title, link: e.url }, { text: ': ' + e.date }])));
  }

  // 9. This Week in Detail
  if (issue.this_week_in_detail && issue.this_week_in_detail.length) {
    body.push(rule());
    body.push(h('This Week in Detail', HeadingLevel.HEADING_2, H2));
    issue.this_week_in_detail.forEach(e => {
      body.push(hLink(e.title, e.url, HeadingLevel.HEADING_3, H3));
      body.push(para([{ text: 'When: ', bold: true }, { text: e.when }], { spacing: { after: 80, line: 300 } }));
      body.push(para([{ text: 'Where: ', bold: true }, { text: e.where }], { spacing: { after: 120, line: 300 } }));
      body.push(quote([{ text: e.description }]));
    });
  }

  // 10. Join the fun (fixed)
  body.push(rule());
  body.push(h(issue.footer.heading, HeadingLevel.HEADING_2, H2));
  (issue.footer.items || []).forEach(it => {
    body.push(h(it.title, HeadingLevel.HEADING_3, H3));
    body.push(para([{ text: it.body + ' ' }, { text: it.link_text, link: it.url }]));
  });

  return new Document({
    creator: 'Climate Tech Cities',
    title: issue.title,
    styles: { default: { document: { run: { font: FONT, size: BODY, color: '1A1A1A' } } } },
    numbering: {
      config: [{
        reference: 'b',
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: '•',
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 480, hanging: 240 } } },
        }],
      }],
    },
    sections: [{
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
      children: body,
    }],
  });
}

const [, , inPath, outPath] = process.argv;
if (!inPath || !outPath) {
  console.error('usage: node build_issue.js issue.json out.docx');
  process.exit(1);
}
const issue = JSON.parse(fs.readFileSync(inPath, 'utf8'));
if (!issue.platforms) issue.platforms = STANDARD_PLATFORMS;
if (!issue.footer) issue.footer = STANDARD_FOOTER;
checkFixedLinks(issue);
structureReport(issue);
Packer.toBuffer(build(issue)).then(buf => {
  fs.writeFileSync(outPath, buf);
  console.log('wrote ' + outPath);
});
