---
name: ctc-assemble
description: Assemble a Climate Tech Cities weekly newsletter draft from the edited events spreadsheet, building all ten blocks in house order, ready to paste into Substack. Use this skill whenever the user wants to build, assemble, draft, or write a city newsletter issue, has an events sheet and wants the newsletter made from it, asks for "this week's issue", wants the picks or opportunities or event listings written up, or is at the drafting stage of the weekly newsletter cycle. Always use this skill even if the user only wants one block, such as just the picks or just the listings. Do NOT use it to collect events, which is the harvest skill's job.
---

# CTC Assemble

Turn the edited events sheet into a complete newsletter draft in house style. Output is a formatted Word document and a matching HTML file, ready to paste into the Substack editor.

## What you will get back

Two files, named for the chapter and the window, for example `Portland_Climate_Tech_Aug_11-Aug_18.docx` and `.html`. Both carry every link, emoji, and day header, in this order:

| # | Block | Who finishes it |
|---|---|---|
| 1 | Title and subtitle | Claude |
| 2 | Opening note | Claude drafts, you rewrite |
| 3 | Picks of the week | Claude drafts from your choices, you add the asides |
| 4 | Housekeeping and sign-off | Claude drafts from what you tell it, you rewrite |
| 5 | Climate Tech Cities and Streetlife Ventures platforms block | Fixed text, never changes |
| 6 | Opportunities | Claude drafts from the queue, you confirm |
| 7 | This Week's Events | Claude, complete |
| 8 | Upcoming Events | Claude, complete |
| 9 | This Week in Detail | Claude, complete, one entry per this-week event |
| 10 | Join the fun: submit events and volunteer | Fixed text, never changes |

Blocks 2, 3, and 4 come back with a yellow line above them reading `[REWRITE IN YOUR OWN WORDS, then delete this line]`. Nothing ships until every one of those lines is gone. A rendered example of the whole thing is `references/sample-output/Portland_Climate_Tech_Aug_11-Aug_18.html` (with the matching `.docx` beside it), built from `references/example-issue.json`; a published New York issue as text is `references/example-issue.md`.

## What this is for

The issue goes to a few hundred to a few thousand people in one city, by email, on the morning of the send day. Most of them scan it once, looking for one thing: is there anything on this week I should go to?

Roughly 40% of the audience does not yet work in climate. That decides ties: free and newcomer-friendly wins, in-person beats webinar, and the arts and volunteering listings are not filler.

A mature issue runs about 3,000 words, of which fewer than 150 are the lead's own. Those words are why anyone subscribes. Everything else is listings, and the tool's job is to make the listings free so the words get written.

## Read this first

- `references/voice.md`, the CTC voice file. Read it before writing any prose. Section 6 says what each block needs. It is the only place banned words live.
- `references/house-style.md`, the formatting spec, the ten blocks with worked examples, emoji vocabulary, and scale expectations.
- `references/example-issue.md`, one complete issue end to end in the current order, so proportions are concrete.
- `references/example-issue.json`, a complete valid input file for the build scripts. Read its `picks` array before writing your own; the segment array is the part people get wrong.
- `references/verifier.md`, the second-pass check run on the built issue before it is handed over, and `scripts/check_voice.js`, the banned-phrase scanner it starts with.
- `references/ctc-links.md`, the fixed CTC links. You should never need to type one: the build scripts insert blocks 5 and 10 themselves.

## Environment

| Dependency | Needed for | If it is missing |
|---|---|---|
| Node.js and code execution | Both build scripts | Ask the user to enable code execution in Claude settings. Without it, output the issue as markdown and say plainly that the .docx and .html steps were skipped and the lead will have to re-attach links by hand |
| `docx` npm package | `build_issue.js` | `npm install docx` in the scripts directory. Handle it yourself |

`build_issue_html.js` has no dependencies beyond Node, so if `npm install` fails the HTML output still works and is the file the lead pastes from anyway.

## Input

- **The edited events sheet** from `ctc-harvest` after the lead's cut: the 14-column format plus `Block` (`this_week` / `upcoming`) and `Source` (`registry` / `submitted` / `lead`). Confirm by file name which sheet is current before reading it. The most common assembly error is building from the file Claude produced rather than the one the lead edited.
- **The chapter settings file** (from `ctc-chapter-setup`), if it is in the project: city, chapter name, timezone from section 1; send day, cadence, scope rule, sign-off from section 2. Read it rather than asking. If there is no settings file, ask for the chapter name and the sign-off once.
- **The opportunities queue**, `Opportunities_<City>.xlsx`, if it is in the project.
- **The date window.** Seven days from the send day for a weekly chapter. Fourteen for a chapter that has moved to every two weeks (see `ctc-newsletter-cycle`, which is where that decision is made).

## Before you build anything: three questions, one message

Read the sheet first so the questions are specific, then ask all three in one message and wait. Do not start assembling until you have the answers.

**1. Which events are the picks?**

Check the sheet for a column the lead added with `PICK` in it. If there is one, list those events back and confirm in one line rather than asking again. If there is not, list the `this_week` events in date order, numbered, one line each with day, name, and neighborhood, and propose four to six: the chapter's own and partner events first, then free and open to newcomers, then things a reader could not easily have found alone, then in-person over webinars. Say plainly that the proposal is a starting point.

Accept anything back: numbers, names, "your list is fine", or picks that were not on the shortlist. Four to six picks, roughly one per day that has events. More than six and the block stops being a recommendation and turns into a second listing.

**2. Opportunities.**

Fellowships, accelerators, grants, calls for applications. These never come from the events sheet.

If `Opportunities_<City>.xlsx` is in the project, read it and present rather than ask blind: which entries are still open, which have already run in an issue, which close soonest. Suggest two to four, favoring the nearest deadline that has not run yet. Never present anything past its deadline, and say how many were dropped so the lead knows the queue was pruned rather than thin.

The lead can also add one of their own (take name, link, deadline; draft it; write it into the queue so later issues have it) or ask you to go and find some (only on request; run the research pass from `ctc-opportunities` and add the findings to the queue). Never research automatically. The monthly run is where collection belongs.

If there is no queue file, ask for two to four with a name, a link, and a deadline, and mention once that `ctc-opportunities` would keep a running list. If there is nothing either way, the block is omitted rather than padded.

After the issue is drafted, set `Status` to `Used` and `Last used` to the send date on each entry that ran, so next week does not offer the same fellowship again. (`Not used` is the value the queue script writes for a new entry.)

**3. Anything the sheet cannot know?**

The chapter's own upcoming event, a postponement, a call for submissions, something that happened in the city this week, anything the lead wants to say. This is the raw material for the opening note and housekeeping. If the lead has nothing, say so and draft from what is in the sheet and the season; the marker still goes on.

If the lead does not answer part of the message, proceed with what you have and say which part is missing rather than asking again.

## The editorial blocks: draft fully, then mark

Blocks 2, 3, and 4 are written by a person before they ship. The house position is that generated commentary reads as generated and readers notice. That is not a reason to leave the blocks empty. **Draft every one of them completely**, in the voice from `references/voice.md`, from what the lead told you and what the sheet shows, and put this line on its own, directly above each drafted block:

```
[REWRITE IN YOUR OWN WORDS, then delete this line]
```

Square brackets, because the pre-send check is "search the document for a square bracket; nothing in brackets ships." Both build scripts render that line as a yellow band so it cannot be missed, and both count how many are left.

A full draft the lead edits down is less work for them than a blank they have to fill, and it shows them the shape. What the draft cannot contain is anything invented: no weather they did not mention, no verdict on an event nobody attended, no reason for excitement the lead did not give. Where a fact is missing, write around it rather than making one up.

If the lead asks you to skip the rewrite and ship your draft, say once that the issue reads better in their words, then build it as asked with the markers left in. The markers are their decision to remove.

## The ten blocks, in publication order

### 1. Title and subtitle

**Title:** `[Chapter name]: [Month D] - [Month D]`, the send window. Never an issue number.

> Portland Climate Tech: Aug 11 - Aug 18

**Subtitle:** comma-separated topics drawn from the picks and opportunities, closing with `and more upcoming events`. Doubles as the email subject line, so front-load the most interesting item. Six or seven topics, lowercase except proper nouns. Build it after the picks are settled.

### 2. Opening note

Greeting, length, and the two-paragraph shape are set in `references/voice.md` section 6, "Newsletter opening note draft"; the hook comes from question 3. The marker line sits between the greeting and the first paragraph, so the greeting is never inside the bracket.

### 3. Picks of the week

One bullet per day that has picks, in date order, in the shape `references/voice.md` section 6, "Picks", sets (the emoji sits inside the link with the title). Day words: `Today`, `Tomorrow`, weekday names, `Next Tuesday` for the one case of an event just past the window. Every pick must also appear in block 7 or block 8; a `Next Tuesday` pick sits in Upcoming and that is the only case where a pick is not in This Week's Events.

Selection comes from the lead's answer to question 1. Build only what they chose.

Draft the bullets in full, including one aside where the material supports it, and put the marker line above the block. The asides are what make it sound like a person, and the lead will replace yours with theirs.

### 4. Housekeeping and sign-off

Postponements, calls for submissions, whatever the lead needs to say, from question 3. Reader asks in **bold** inline, written as `**...**` in the JSON; the scripts render the bold. Then the sign-off from the settings file, `Til next week!` on one line and the names on the next (variants are in `references/house-style.md`).

If the lead gave nothing for housekeeping, omit the paragraphs and keep the sign-off. Never invent an announcement.

### 5. Platforms block

Fixed text with two fixed Typeform links, the same in every issue of every chapter. Both build scripts insert it when `platforms` is absent from the JSON. Leave it absent. It sits here, after the sign-off and before Opportunities, and nowhere else.

### 6. Opportunities

The items chosen in question 2. Linked emoji heading, then the description from the queue in a blockquote, then the deadline in bold at the end of the description: `Applications due August 1.` A shorter variant puts the deadline in the heading itself. Items recur across issues until they close, which is correct rather than lazy. Anything past its deadline is dropped, and if nothing is open the block is omitted.

### 7. This Week's Events

Every `this_week` row, grouped under day headers, chronological, titles only. The day header carries the date. Event names exactly as harvested.

```
#### Wednesday, Aug 12
[emoji] [Event Name](Registration Link)
```

### 8. Upcoming Events

Every `upcoming` row. Flat, chronological, no day headers, date appended after the link in `Mon D` form. Runs to the end of the harvest window.

### 9. This Week in Detail

**One entry for every event in block 7, no exceptions.** Readers use this section so they do not have to click into each event, and the lead has already cut the sheet, so everything left in `this_week` is worth the space. Upcoming events do not get entries.

Per event: the linked emoji heading exactly as in block 7, then When, Where, then the description in a blockquote.

```
### [emoji] [Event Name](Registration Link)

**When:** Wednesday, Aug 12

**Where:** Ecotrust Building, 721 NW 9th Ave, Portland

[Two to three sentences from the sheet's Description column.]
```

The description comes from the sheet's `Description` column, which `ctc-harvest` wrote from the event's own page at 40 to 70 words in the shape voice.md section 6 sets. Tidy it and do not rewrite it freely. For an online event, Where is `Online`.

Both build scripts compare this block against block 7 and print any event that is missing an entry. Fix those before delivering.

### 10. Join the fun

Fixed text with two fixed links: submit an event (the Climate Tech Cities intake form, one form for every chapter) and volunteer. Both scripts insert it when `footer` is absent from the JSON. Leave it absent. This is the last block of the issue.

## Emoji

Every event in every listing block gets one, placed before the title and inside the link. How to choose it, the fallbacks, and the reuse rules are in `references/house-style.md` section 3.

## Output

Write the issue as JSON in your working directory, then run both scripts:

```
node scripts/build_issue.js issue.json out.docx
node scripts/build_issue_html.js issue.json out.html
```

Read what the scripts print. Both report block counts, how many bracketed markers remain, and a `CHECK BEFORE DELIVERING` list if a pick is not in the listings, an event is in both listing blocks, or block 9 does not match block 7. Fix what they name and rebuild. A missing or placeholder fixed link stops both builds outright; the fix is to remove `platforms` and `footer` from the JSON so the standard blocks are inserted.

Then run the verifier in `references/verifier.md`: the voice checker (`node scripts/check_voice.js issue.json`, which reads the banned list from voice.md section 5) and a fresh read of the built HTML against the edited sheet, the settings file, and the ten-block order. That file says how to run the fresh read as a subagent where the session has one and as a separate step where it does not. Fix, rebuild, re-run.

Then deliver the `.docx` and the `.html`, and nothing else. The JSON is scratch. The lead pastes from the HTML file: open it in a browser, click before the first word, drag to the bottom, copy, paste into a new Substack post. That carries formatting and links across, which a copy button does not.

**issue.json contract:**

```json
{
  "title": "Portland Climate Tech: Aug 11 - Aug 18",
  "subtitle": "topics, comma separated, and more upcoming events",
  "opening_note": ["Hi all,", "[REWRITE IN YOUR OWN WORDS, then delete this line]", "paragraph", "paragraph ending Here are our picks for the week:"],
  "picks_intro": "[REWRITE IN YOUR OWN WORDS, then delete this line]",
  "picks": [
    {"day": "Wednesday", "segments": [
      {"text": "get into the weeds on interconnection queues at "},
      {"text": "⚡ Grid Interconnection 101", "link": "https://..."}
    ]}
  ],
  "housekeeping": ["[REWRITE IN YOUR OWN WORDS, then delete this line]", "paragraph with a **bolded reader ask**"],
  "signoff": ["Til next week!", "Names, and the Climate Tech Cities team"],
  "opportunities": [
    {"title": "💡 Name", "url": "https://...", "description": "...", "deadline": "Applications due August 1."}
  ],
  "this_week": [
    {"day": "Wednesday, Aug 12", "events": [{"title": "⚡ Name", "url": "https://..."}]}
  ],
  "upcoming": [{"title": "♻️ Name", "url": "https://...", "date": "Aug 26"}],
  "this_week_in_detail": [
    {"title": "⚡ Name", "url": "https://...", "when": "Wednesday, Aug 12", "where": "Address", "description": "Two to three sentences."}
  ]
}
```

A segment is `{text}` for plain runs or `{text, link}` for hyperlinked ones, so a pick bullet interleaves prose and linked titles. A paragraph string that is exactly a bracketed line renders as the yellow marker; `picks_intro` is the one slot for block 3's marker, rendered above the bullets, and the marker for block 2 sits in `opening_note` after the greeting and for block 4 at the top of `housekeeping`. `**text**` inside a paragraph renders bold. Omit any block with no content and it is skipped, except blocks 5 and 10, which are inserted whether or not the JSON mentions them. Keys beginning with an underscore are ignored.

Then report in chat, briefly:

- Event counts per listing block, and confirmation that block 9 has one entry per this-week event
- Which blocks carry a rewrite marker
- Picks the lead named that could not be matched to a row
- Opportunities carried forward, and any dropped for a passed deadline
- Emoji assigned by fallback rather than by topic
- Anything in the sheet that could not be placed

## Pre-send checks

Run these before handing over; the lead runs them again before sending:

- Every listing has an emoji and a link that was opened during the harvest
- No event appears in both This Week's Events and Upcoming
- No event dated before the send date
- Every pick appears in block 7 or block 8
- Block 9 has exactly one entry for every event in block 7
- Subtitle matches what the picks cover
- Every deadline in Opportunities is in the future
- Blocks 5 and 10 are the standard text with the fixed links
- Every square bracket in the document is one of the rewrite markers, and the lead knows they all go

## Failure modes

**Building from the wrong sheet.** The lead edited the file and Claude reads the original. Confirm the file name before reading, every time.

**Skipping block 9, or filling it for some events only.** Every this-week event gets a detail entry. The scripts flag a mismatch; fix it rather than delivering with the warning.

**The platforms block at the bottom.** It moved. It sits after the sign-off and before Opportunities. The last block is Join the fun.

**Shipping a marker.** The bracket lines are for the lead to delete after rewriting. Say so at delivery, every time.

**Inventing material for the note.** A draft is built from what the lead said and what the sheet shows. If there is nothing topical, draft the seasonal version and say it is thin, rather than making up weather or news.

**Pick bullets that break the shape.** A list of names, or same-day picks joined with "and". The shape is in `references/voice.md` section 6 and the weak-and-strong pairs are in `references/house-style.md`.

**Padding Opportunities.** Two real ones beat four with filler, and a lapsed deadline is worse than an empty block.

**Rewriting descriptions in block 9.** They were written from the event's own page. Tidy and condense; do not add.

**Shipping markdown instead of the files.** The deliverable is the .docx and the .html. Markdown in chat means the lead re-attaches every link by hand.
