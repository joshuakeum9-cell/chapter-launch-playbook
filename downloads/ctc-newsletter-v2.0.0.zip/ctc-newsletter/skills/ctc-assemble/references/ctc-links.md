# CTC fixed links

These links are the same for every chapter. They are not per-city and they never need to be looked up or asked about. Copy them exactly. This file is the single place they live in the toolkit; every skill that prints one of them reads it from here.

| Link | URL | Used by |
|---|---|---|
| Climate Tech Cities website | https://www.climatetechcities.com/ | platforms block |
| Streetlife Ventures website | https://www.streetlifeventures.com/ | platforms block |
| Climate startups looking to raise (Typeform) | https://gccht82e8mz.typeform.com/to/fLp65vtz?typeform-source=www.climatetechcities.com | platforms block |
| Climate talent looking to transition (Typeform) | https://gccht82e8mz.typeform.com/to/Rk2roZac?typeform-source=www.climatetechcities.com | platforms block |
| Volunteer with Climate Tech Cities (Airtable form) | https://airtable.com/appJJx88dpQsUuEas/pagA3Zi7dEGeGuxmd/form | Join the fun footer |
| Submit an event (Airtable form, all chapters) | https://airtable.com/appunzUZg6b8fe83m/pagmLLAnynXZxEtmL/form | Join the fun footer |
| Submitted events, read-only view (Airtable shared view, all chapters) | https://airtable.com/appunzUZg6b8fe83m/shrXpLGZPZ8KHoJdA | ctc-source-map registers it, ctc-harvest reads it |

The event intake base is `CTC Event Submissions (all chapters)`, base `appunzUZg6b8fe83m`, table `Submitted Events`. It is one table for every chapter with a `City` dropdown. It is an intake, never a public listing: readers see the form, not the table.

## Rules

- **Never rewrite a fixed URL and never substitute a placeholder.** A footer that ships with an `example.` address or a bracketed "replace before sending" note is a defect. The build scripts refuse to render one.
- **Never register any of these as an event source**, with one exception: the submitted-events shared view, which `ctc-source-map` writes into every registry as a standing row and `ctc-harvest` reads every week.
- If a link here ever changes, change it here and in the `FIXED_LINKS` table at the top of `../scripts/build_issue.js` and `../scripts/build_issue_html.js`, in the same edit. Three copies that disagree is how a wrong link ships for months. `example-issue.json` carries none of them, by design.
