# House style reference

The formatting spec, the ten blocks with real examples, the emoji vocabulary, and the scale expectations. Voice rules and banned words are not here: they live in `voice.md`, which is the only place they live.

Derived from published issues of the NY Climate Tech newsletter (2021 to 2026) and the block order Climate Tech Cities set on 20 Aug 2026.

---

## 1. Formatting spec

Measured from the live Substack DOM. The base font is reader-configurable (17px and 19px both observed), so the ratios are the spec, not absolute sizes.

| Element | Size | Font | Used for |
|---|---|---|---|
| Body | 1.0x | serif (Spectral) | line-height 1.6, margin-bottom 20px |
| Title | ~2.2x | sans (SF Pro Display) | bold |
| Subtitle | ~1.25x | sans | gray `#5f5f5f`, regular weight |
| `h2` | 1.625x | sans, bold | Platforms block, This Week's Events, Upcoming Events, This Week in Detail, Join the Fun! |
| `h3` | 1.375x | sans, bold | "Opportunities:", each opportunity title, each detail-entry title, "Submit Events" and "Volunteer" |
| `h4` | 1.125x | sans, bold | Day headers, "Wednesday, Aug 12" |
| List item | 1.0x | serif | indent 32px, margin-top 8px |
| Blockquote | 1.0x | serif | 4px left border, used for every description |

Three things people get wrong:

- Body is serif, headers are sans. Not one font throughout.
- "Opportunities:" is `h3`, a level below the `h2` listing headings.
- Descriptions sit in a blockquote with a left border, not a margin and not a nested list.

Both build scripts implement all of this. Do not hand-format.

---

## 2. The ten blocks, with published examples

Imitate the shape, never the wording.

### 1. Title and subtitle

> **NY Climate Tech: Aug 18 - Aug 25**
> Sustainable fashion, Black eco-poetry, a boat tour of energy infrastructure, climate pints, and more upcoming events

### 2. Opening note

> Hi all,
>
> Last week we pulled out our N95s once again as wildfire smoke subsumed the summer. The brown-orange skies, torrential rain, and tornado warnings have been stark reminders that climate change is here and now.
>
> For such a global problem, we continually find hope and inspiration in local community. While the summer is a lot quieter (including on the newsletter), there's still plenty of ways to connect. Here are our picks for the week:

Two moves: something true about the city this week, then the turn toward local community. The parenthetical admits the newsletter itself has been quiet. Self-aware, not apologetic.

The other standard opening leads with the chapter's own event: *Our big summer event is around the corner! Join us on Wednesday July 22nd for Other Intelligence and meet the people doing some of the most interesting, exciting work out there on things like bioacoustics, new materials, nonhuman design, world models, and more.*

### 3. Picks of the week

> **Tomorrow** embrace the tides at the 🌊 2026 Offshore Wind Innovator Program: Q&A Social Hour or make calls (and friends!) at the ⏳ Manhattan Climate Changemakers Hour of Action or ⏰ Brooklyn Hour of Action
>
> **Thursday** talk sustainable finance in Sheep's Meadow at the 🧺 BASIC NY Summer Social or join Climatebase in Midtown for 💬 Climate Conversations NYC
>
> **Wednesday** hop on a boat for 🚢 Energy Infrastructure Boat Tour with OHNY, expense a ticket to the ⚡ NY Executive Roundtable: Affordability & Grid Optimization, or get a casual drink at the 🍻 Climate Pints August Gathering

The shape of a pick bullet is set in `voice.md` section 6, "Picks", and rule 6, and not restated here. The asides ("make calls (and friends!)", "expense a ticket to") are the voice; Claude drafts one, the lead replaces it with theirs.

Pick bullets that fail, and why:

| Weak | Why it fails | Strong |
|---|---|---|
| **Thursday** BASIC NY Summer Social, Climate Conversations NYC | A list of names. Nothing helps a reader choose | **Thursday** talk sustainable finance in Sheep's Meadow at the 🧺 BASIC NY Summer Social or join Climatebase in Midtown for 💬 Climate Conversations NYC |
| **Wednesday** attend a networking event and a panel discussion | Describes a category, not an evening | **Wednesday** get into the weeds on interconnection queues at ⚡ Grid Interconnection 101 or talk buildings over a beer at 🍻 Mass Timber Happy Hour |
| **Tomorrow** join us as we explore climate solutions | Could be any week in any city, and a banned phrase | **Tomorrow** embrace the tides at the 🌊 2026 Offshore Wind Innovator Program: Q&A Social Hour |

### 4. Housekeeping and sign-off

> We've postponed Wednesday's **Other Intelligence** summit until later this year (too many people were out of town!) but are still looking forward to it in the Fall.
>
> Also, Climate Week is around the corner! Keep your eyes peeled for our first guide, and **if you're planning any events for Climate Week NYC, send them our way by replying to this email.**
>
> Til next week!
> Alec, Sonam, and the Climate Tech Cities team

Reader asks bolded inline. Sign-off variant: `As always,`. Greeting variant: `Hi friends,`.

### 5. Platforms block

Fixed. Sits directly after the sign-off. Heading, one paragraph, two linked bullets. The build scripts insert it.

> ## 🌎 Climate Tech Cities and Streetlife Ventures Startup and Talent Platforms
> Climate Tech Cities and Streetlife Ventures are launching new platforms to support climate founders, funders, and career transitioners! There is no shortage of great companies raising money for their groundbreaking ideas, great investors looking to support with capital, and great talent living the mantra that every job is a climate job. We can't wait to hear from you!
> - Climate startups looking to raise
> - Climate talent looking to transition

### 6. Opportunities

> ### Opportunities:
> ### 💡 New York Climate Exchange Climate Tech Fellowship
> > The Climate Tech Fellowship is a six-month hybrid program that combines expert-led curriculum, 1:1 mentorship, non-dilutive funding, and access to The Exchange's global partner ecosystem. **Applications Due August 1.**

Shorter variant puts the deadline in the heading: `🗽 NYCEDC Founder Fellowship: Due 12/31`.

### 7. This Week's Events

> #### Tuesday, Aug 18
> - 🔌 WISE-NYC: August Lunch on AI in Sustainability
>
> #### Wednesday, Aug 19
> - 🌿 A Community Reading Of Black Eco-Poetry Feat. Keenyn Omari
> - 👗 Sustainable Fashion Networking Hour

Titles only, every title a link, the day header carries the date.

### 8. Upcoming Events

> - ♻️ The Circular Economists Meet-up: New York City: Jul 29
> - 🎻 Wreathed in blossom: chamber music on Governors Island: Aug 1
> - 🏢 Retrofit NYC (Commercial): Aug 6

Flat, chronological, date appended.

### 9. This Week in Detail

One entry per event in block 7. From the 18 Aug 2026 issue, verbatim:

> ### 🔌 WISE-NYC: August Lunch on AI in Sustainability
> **When:** Tuesday, Aug 18
>
> **Where:** New York, NY, New York
>
> > This lunch discussion explores the paradox of AI adoption in sustainability work, examining both its practical benefits and environmental costs. Hosted by Parichat Wrolstad, the event brings together WISE Community members to share experiences with AI implementation and discuss responsible usage strategies.

> ### 🌿 A Community Reading Of Black Eco-Poetry Feat. Keenyn Omari
> **When:** Wednesday, Aug 19
>
> **Where:** New York, NY, New York
>
> > Black Forest School presents a community reading of 40+ Black eco-poems from a collection spanning over 1,000 works in 20+ languages by 300+ poets. The event features live jazz accompaniment by flautist Keenyn Omari, an interactive poetry relay, and a temporary installation within Project EATS' urban farm setting.

Two to three sentences, 40 to 70 words, from the event's own page, in the shape `voice.md` section 6 sets. Where should carry the street address when the sheet has it; the published example above is the weaker version.

### 10. Join the fun

Fixed. The last block. Heading, then two short sub-blocks each ending in a link. The build scripts insert it.

> ## Join the Fun!
> ### Submit Events
> Running something climate-related in the city? We'd love to spread the word. Tell us about it and it goes into next week's list. [Submit an event]
> ### Volunteer
> Climate Tech Cities runs on volunteers. If you want to help with events, the newsletter, or the chapter itself, say hello. [Volunteer with Climate Tech Cities]

The wording follows the Seattle chapter's standing footer; the two links are in `ctc-links.md`.

---

## 3. Emoji

251 distinct emoji across the archive, a per-event thematic choice rather than a fixed vocabulary. Propose from the title and category, fall back to 🌱 or 🌍.

Most frequent, with counts: 🌱 313 · 🌍 241 · 🌊 104 · ♻️ 104 · ⚡ 104 · 🎨 101 · 🌿 83 · 🍻 77 · 📊 70 · 🌳 66 · 🏗️ 54 · 📚 54 · 🏙️ 50 · 🤖 45 · ☀️ 45 · 💧 44 · 🍹 41

| Topic | Emoji |
|---|---|
| Social, drinks, happy hour | 🍻 🍹 🥂 |
| Data, lectures, research | 📊 📈 🔬 |
| Arts, design, galleries | 🎨 🎬 🧵 |
| Buildings, urbanism | 🏗️ 🏙️ 🏢 |
| Energy, grid | ⚡ 🔌 ☀️ |
| Water, ocean | 💧 🌊 |
| Nature, trees, biodiversity | 🌳 🌿 🍄 🦅 |
| Circular economy, waste | ♻️ 🔄 |
| AI, tech | 🤖 |
| Volunteering, restoration | 🦪 🌱 |
| Policy, advocacy | ⏰ ⏳ 🗽 ⚖️ |
| Food, agriculture | 🌾 🍽️ |
| Mobility | 🚲 🚢 🚇 |
| General default | 🌱 🌍 |

Roughly 40% of real listings use one of the top ten. Reusing the same emoji within an issue is normal. The same event keeps the same emoji in every block it appears in.

---

## 4. Scale expectations

Per-issue volume is an output, not a target. The source list sets the ceiling and the lead's cut sets the count. For calibration only:

| Year | Avg events per issue | Peak |
|---|---|---|
| 2021 (launch) | 1 | 4 |
| 2022 | 10 | 24 |
| 2023 | 29 | 63 |
| 2024 | 32 | 59 |
| 2025 | 56 | 82 |
| 2026 | 56 | 98 |

A launch city looks like 2021: a handful of events and a longer personal note. That is correct, not a failure. Never suggest padding toward another chapter's number.

---

## 5. What differs per chapter

Everything below comes from the chapter settings file (sections 1 and 2) and is never assumed:

- Chapter name for the title: "NY Climate Tech", "Portland Climate Tech"
- Sign-off names
- Cadence: weekly, or every two weeks for a chapter that has moved to that
- Geographic scope rule, which decided the cut upstream
- Timezone, for the sheet headers

Everything else in the issue is the same for every chapter: the block order, the fixed blocks 5 and 10 and their links, the category vocabulary (the 22 categories in `ctc-harvest`), and the voice.
