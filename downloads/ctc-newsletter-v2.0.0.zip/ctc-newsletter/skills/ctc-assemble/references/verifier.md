# Issue verifier

A second pass over the built issue before it goes to the lead: structure, links, and voice. The build scripts catch the mechanical structure; this pass catches what a script cannot, which is a wrong link that resolves, a description that quietly editorializes, and a pick that names a venue the sheet does not have.

## How to run it

Two parts, in this order.

**Part 1, the scripts.** Both build scripts print block counts, the marker count, and a `CHECK BEFORE DELIVERING` list. Then run the voice checker:

```
node scripts/check_voice.js issue.json
```

It reads the banned list from `references/voice.md` section 5, so the list lives in one place. Fix every hit in `issue.json`, rebuild, re-run. A hit inside a fixed block is impossible (the scripts insert those); a hit inside an event title is the organizer's wording and stays.

**Part 2, the fresh read.** Run this as a pass with no memory of the assembly. If the session has a subagent or task tool, launch one with exactly this file, the built `.html`, the edited events sheet, and the settings file, and nothing else. If it does not, run it yourself as a separate step: read this file, open the HTML cold, and check it against the sheet as a subscriber and then as an editor.

## Checks

**Structure.** Ten blocks in this order: title and subtitle; opening note; picks; housekeeping and sign-off; platforms block; opportunities; This Week's Events; Upcoming Events; This Week in Detail; Join the fun. The platforms block follows the sign-off directly. Join the fun is the last thing on the page. Block 9 has exactly one entry per event in block 7, same title, same emoji, same link.

**Against the sheet.** Every event in blocks 7 and 8 is a row in the edited sheet, with the sheet's name, date, and link, and no row the lead kept is missing. Nothing the lead cut is in the issue. Every block 9 description is the sheet's description, tidied, not rewritten. Every pick names an event in block 7 or block 8, and any venue or neighborhood in a pick is in that row's Location or City / Neighborhood cell.

**Editorial blocks.** Each of blocks 2, 3, and 4 has the marker line directly above it, exactly `[REWRITE IN YOUR OWN WORDS, then delete this line]`. The greeting is above the marker, not inside it. Nothing in the drafts states a fact the lead did not give in question 3 or that is not on the sheet: no weather, no local news, no verdict on an event, no reason for excitement. Where the draft says something about the city, find where it came from.

**Voice.** Read blocks 2, 3, 4, 6, and 9 against `voice.md` sections 2 and 5. The checker catches words; this catches patterns: three adjectives in a row, a why-you-should-care closing sentence, a summary sentence, a metaphor carried past two sentences, a promise about the reader's feelings.

**Dates and deadlines.** Every date in the issue is inside the window in the title. Every opportunity deadline is after the send date. Day words in the picks (Tomorrow, Thursday, Next Tuesday) are correct for the send day.

**Fixed links.** The platforms block carries the two Typeform links and Join the fun carries the submission form and volunteer form links, all exactly as in `ctc-links.md`.

**Subtitle.** Names the picks, closes with "and more upcoming events", sentence case except proper nouns.

## What to report

A short list: what was fixed, what was flagged for the lead (with the block and the reason), and a one-line verdict. Then deliver the `.docx` and `.html`.
