# Opportunities verifier

A second pass over the finished queue before it goes to the lead. The one field that matters is the deadline, and a wrong one costs a reader an application, so every entry is re-opened by someone who did not find it.

## How to run it

Run this as a fresh pass with no memory of the sweep. If the session has a subagent or task tool, launch one with exactly this file and the `Opportunities_<City>.xlsx`, and nothing else. If it does not, run it yourself as a separate step: read this file, open the Open sheet cold, and work every row. Fix the JSON, re-run `build_queue.py --existing`, and only then deliver.

Every row on the Open sheet, not a sample. Carried rows too: a deadline that was right last month can have moved.

## Checks, per row

1. **Open the URL.** It is the program's own page (not an aggregator, not a news article), it loads, and the program is real and current.
2. **The deadline on the page matches the cell**, or the page says rolling and the cell says `Rolling`, or the page names a future round without a date and the cell says `Unconfirmed`. A date on the page that differs from the cell is the finding this pass exists for. Fix the cell.
3. **Applications are open**, or open on a stated future date. A page that says "applications closed" moves the row to Closed.
4. **The chapter's region is eligible.** Read the eligibility section. A national program that excludes the chapter's state, or a program for a different country, is out.
5. **`scope` is right.** City name only if only that city can apply; state or region name for state programs; `National` or `Global` otherwise. Scope decides the file order.
6. **No application fee, no job posting.** Either one is out.
7. **Description.** 25 to 40 words, what it is, who it is for, what the applicant gets. No dollar figures. No banned phrases from `../../ctc-assemble/references/voice.md` section 5.
8. **Type** is Accelerator, Grant, Fellowship, Competition, or Call for proposals, and matches what the page describes.

## Checks, whole file

9. At least fifteen open after the fixes; not more than half of one type; at least one local or regional entry; Accelerator, Grant, and Fellowship all present.
10. No duplicates by URL or by name.
11. Nothing on the Open sheet is past its deadline as of today.

## What to report

Rows fixed (name, check number, old value, new value), rows moved to Closed, rows dropped, and a one-line verdict.
