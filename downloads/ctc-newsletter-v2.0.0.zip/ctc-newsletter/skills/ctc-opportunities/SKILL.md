---
name: ctc-opportunities
description: Find grants, fellowships, accelerators, and calls for applications for a Climate Tech Cities chapter newsletter, and keep them in a rolling monthly queue. Use this skill whenever the user wants opportunities for their newsletter, asks for grants, fellowships, accelerators, incubators, funding, or calls for applications, says "run the monthly opportunities" or "refresh the opportunities", asks what to put in the opportunities block, or is starting a new month of the newsletter cycle. Always use it even if they only want one or two to fill a gap. Do NOT use it to find events, which is ctc-harvest, or to find partner organizations, which is the ctc-partner-map plugin.
---

# CTC Opportunities

Runs once a month. Finds grants, fellowships, accelerators, and open calls, and keeps them in a rolling queue the newsletter draws on every week.

The opportunities block is why founders stay subscribed through a quiet week. It is also the block that gets skipped, because nothing collects it. This is what collects it.

## What you will get back

One spreadsheet, `Opportunities_<City>.xlsx`, with an `Open` sheet and, once anything has closed, a `Closed` sheet. Open is sorted so the most local entries come first. Twelve columns: `Opportunity`, `Organization`, `Type`, `Deadline`, `Closes in`, `Who it is for`, `Scope`, `Description`, `URL`, `Status`, `Last used`, `Missing Info`. A three-row excerpt of Open (columns cut for width):

| Opportunity | Organization | Type | Deadline | Closes in | Who it is for | Scope | Description | Status | Last used |
|---|---|---|---|---|---|---|---|---|---|
| Oregon BEST Early Commercialization Grant | Oregon BEST | Grant | 2026-09-15 | 6 days | Hardware startups with an Oregon presence | Oregon | Non-dilutive grants for moving from prototype to pilot, with a university lab match for testing. | Used | 2026-09-01 |
| Activate Fellowship | Activate | Fellowship | 2026-10-15 | 36 days | Scientists founding a hardware company | National | Two-year fellowship with a salary, lab access, and a cohort, for scientists leaving research to start a company. | Not used | |
| Elemental Impact | Elemental Impact | Accelerator | Rolling | rolling | Climate startups at first deployment | National | Project funding and deployment support for first-of-a-kind climate projects. | Not used | |

`Status` is `Not used` when the script writes an entry and `Used`, with the send date in `Last used`, once `ctc-assemble` has run it in an issue (the first row above shows that state; in the sample file every row is still `Not used`, because nothing has run yet). Anything that closes within three weeks is shaded; anything past its deadline sits on the Closed sheet. The chat summary says how many are open, how many are new this month, what closes soon, and reminds you to add the file to your project as a context file, replacing last month's. A full sample is `references/sample-output/Opportunities_SAMPLE.xlsx`.

## Input

The city, read from the chapter settings file. The previous month's queue, if one exists.

## Output

One `.xlsx` in `/mnt/user-data/outputs/`, named `Opportunities_<City>.xlsx`, with an Open sheet and, once anything has closed, a Closed sheet.

**The lead adds it to their Claude project as a context file once a month, replacing last month's.** `ctc-assemble` reads it every week from there. That upload is the entire mechanism, so never end a run without saying it.

Do not tell the lead how long a run will take.

---

## The bar

The lead opens the file, picks two, and pastes them into the issue without checking anything. Which means every deadline in it has to be right.

---

## Read this first

`references/sources.md` holds the four source tiers, the scope rule, what qualifies, and the four verification checks. Read it before searching.

`../ctc-assemble/references/voice.md`, section 6 "Opportunity descriptions", is how the description column is written. It is the plugin's one copy of the voice file.

`references/verifier.md` is the second-pass check run on the finished file before it is handed over.

`scripts/build_queue.py` builds and prunes the queue. Do not hand-roll the spreadsheet, and never rebuild the queue from scratch when a previous one exists.

---

## Step 0. Ask how they want to start

**Always ask this first. Never start researching without it.**

The user may already know programs that belong here. A name a real person vouched for is better than anything research returns, and skipping this question is how a skill produces a list that misses the obvious.

Ask in one message and wait:

> Before I start, how do you want to do this?
>
> **A. You give me some, then I research too.** Paste any grants or programs you already know and I verify each one, then run the full search on top. Best coverage, and what I would recommend.
>
> **B. You give me all of them.** I verify what you paste and stop there. Fastest, and a fair choice if you already have the list you want.
>
> **C. I research everything.** Nothing needed from you. I sweep the sources and bring back a verified list to review.
>
> Paste what you have straight into your reply and I will take that as option A, or just tell me which you want.

**If they paste names or links in their first message, take that as A and get on with it.** Do not make someone pick from a menu when they have already answered.

**Whatever they give you is a candidate, not an entry.** It goes through the same verification as anything found by research. When one fails a check, name the check it failed rather than dropping it silently, and let them decide whether to keep it anyway. They know the place and the research does not.

On option B, verify and stop. Do not quietly run the research pass anyway.

## Step 1. Find the previous queue

Ask for it, or look in the project and the conversation.

**With a previous queue this run is short.** Most entries carry over untouched, a few close, and you are looking for what is new since last month.

**Without one**, this is the first run and the sweep starts from nothing. Say so, so the lead is not surprised.

Never rebuild from scratch when a previous file exists. The lead's Status and Last used columns live in that file and they are what stops the same fellowship running four weeks in a row.

## Step 2. Sweep the four tiers

**The queue holds at least fifteen open opportunities after every run.** That is the total on the Open sheet, carried entries included, not the number found this month. Under fifteen means a tier was skipped, and the script reports the queue as not ready. Keep working the tiers until the total clears it.

**Tier 1 alone should produce most of that**, and most of it runs rolling intake, which counts (`references/sources.md` lists the programs and says how `Rolling` is recorded). Excluding rolling programs is what produces a queue of five fellowships.

**A queue of one type is a failed sweep.** Five fellowships and nothing else is not a month with no accelerators open, it is a search that stopped at the first source type. Accelerators, grants, competitions, and calls for proposals all exist in every month of the year at national level. The script reports the queue as not ready when any single type exceeds half of it, or when Accelerator, Grant, or Fellowship is entirely absent.

**Scope mix is the other check.** A healthy queue leads with local and regional programs and carries national and global ones below them. All four tiers contribute, and the file is sorted so the most exclusive opportunities are the first thing the lead sees.

Work down `references/sources.md` in order.

1. **Program pages and public funders.** The backbone. No browser needed.
2. **Aggregators.** Highest yield per fetch. Always confirm the deadline on the program's own page, because aggregators leave dead listings up.
3. **LinkedIn.** Browser only, only with the extension, only if the lead says yes. Skipping this tier is a good run, not a broken one. If the extension is unavailable, say so and say what the tier usually contributes.
4. **Local, from the partner map.** If a `CTC_Partner_Map` or `CTC_City_Resources` workbook exists, read it and check each organization's programs page rather than researching the city again. This tier produces the entries no other newsletter in the city has.

**Set the `scope` field precisely, because it decides the order of the file.** The values, the radius (wider than the events scope rule, on purpose), and the sort are in `references/sources.md`, "Scope" and "Radius". Readers subscribed to their city's newsletter, and an opportunity only they can apply for is the one thing this block offers that a national list cannot.

**A queue with nothing local or regional in it means Tier 4 was skipped.** The script reports it as not ready. Work the partner map and the state energy authority.

## Step 3. Check every candidate

Run the four checks in `references/sources.md`, "Verification", on every candidate, all four, before anything enters the queue. They are stated there once. The deadline is the field that matters; everything else is description.

## Step 4. Build the queue

Write the findings as JSON, `{"city": "<City>", "opportunities": [ ... ]}` with one object per entry (name, org, type, deadline, url, who, scope, description), then:

```bash
python3 scripts/build_queue.py opportunities_<city>.json --existing <previous file>
```

Omit `--existing` only on a first run.

The script merges by URL, keeps the lead's Status and Last used, moves anything past its deadline to the Closed sheet, shades what closes within three weeks, and drops any entry whose deadline is not a date, `Rolling`, or `Unconfirmed`. It always writes the file; it then prints `NOT READY` when the Open sheet is under fifteen, has nothing local or regional, has one type over half, or lacks an Accelerator, Grant, or Fellowship, and `QA FAILURES` for a blank required field, a non-https URL, a duplicate URL, or an em dash or en dash in the name or description. Either line means fix and re-run, not deliver.

Read its output. It reports how many carried, how many are new, how many closed, and how many have not yet run in an issue.

### Missing information is marked, never left silent

The build script writes a `Missing Info` column naming any required field a row is missing, and shades **only the empty cells** red, plus the note that names them.

Cell-level, not row-level, on purpose. Shading a whole row buries the one field that needs attention among a dozen that do not, and large blocks of red read as broken rather than as a few cells to fill.

Read the script's output before delivering. It names every incomplete row and the exact field. Fix them and re-run rather than handing over a file with red in it.


## Step 4b. Verify the file

Run `references/verifier.md` on the built file: a fresh pass that re-opens every URL on the Open sheet, carried rows included, and confirms the deadline, eligibility, scope, and type against the program's own page. That file says how to run it as a subagent where the session has one and as a separate step where it does not. Fix the JSON, re-run `build_queue.py --existing`, and only then deliver.

## Step 5. Deliver

Deliver the file, then in a few lines:

- How many are open, how many are new this month, how many closed.
- What is closing within three weeks, by name. This is the useful part.
- Anything registered with an unconfirmed deadline.
- Which tiers were skipped and why, particularly if the browser was unavailable.
- **Upload this to your Claude project, replacing last month's.** Say it every time. Nothing works if they do not.

Then stop.

---

## House rules

**Never invent a deadline.** If the program's own page does not publish one, record `Rolling` or `Unconfirmed` as `references/sources.md`, "Deadlines: three kinds", defines them. Both are supported by the build script and both list fine in the issue. Never guess a date.

**Never carry a closed opportunity into the Open sheet.** The script prunes by date, so do not work around it.

**Never drop a lead-added entry.** If the lead added something by hand and it fails a check, keep it, name the failed check, and tell them.

**Never list a job posting.** A job is not an opportunity here and the newsletter has no jobs block.

**Never list anything with an application fee.**

**No dollar figures in descriptions.** Award sizes change and the file is meant to survive a year.

**Descriptions run 25 to 40 words**, in the shape `../ctc-assemble/references/voice.md` section 6, "Opportunity descriptions", sets. The script warns over 45. The block in the newsletter is emoji, linked title, short description, bolded deadline.

---

## Failure modes

**A thin month.** Some months add only three new entries. Say so plainly. That is fine as long as the Open sheet still holds fifteen, because the queue carries the rest. If it does not, the tiers were not worked; rolling Tier 1 programs are listable and are usually what is missing.

**An aggregator's deadline disagrees with the program page.** The program page wins, always.

**The browser is unavailable.** Skip Tier 3, name it, carry on. The other three tiers are most of the value.

**No partner map workbook.** Do one research pass over the city's incubators, universities, and economic development bodies. Say once, at delivery, that running `ctc-partner-map` for this city first would make Tier 4 substantially cheaper every month, because most of that research is the same research.

**The lead asks mid-month for more.** Fine. Run the tiers again, then **add the findings to the queue** rather than handing over a one-off list. Anything found mid-month should be there for the following weeks too.

**Two chapters ask for the same national programs.** Expected. Most of this queue is national and will look similar across cities. The local tier is what makes each one different, which is why it is worth the effort.
