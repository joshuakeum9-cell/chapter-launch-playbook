---
name: ctc-source-map
description: Build the event source list for a Climate Tech Cities chapter in a given city, either from calendar links the user already has, from online research, or both. Finds the Luma calendars, Eventbrite organizers, university calendars, and local organizations that consistently post climate tech events there, verifies every one before registering it, and adds the CTC event submission form as a standing source. Use this skill whenever the user names a city and wants event sources, has their own list of calendars they want registered, asks to build or refresh a source map or source list, asks "where should we pull events from" or "what climate calendars exist in [city]", is launching a newsletter for a new chapter, or says the weekly harvest keeps missing events. Always use this skill even if the user only names one city or asks for "just a few calendars to start". Do NOT use it to collect this week's events, which is the harvest skill's job.
---

# CTC Source Map

Research a city and return a verified list of the places its climate events get announced. The weekly harvest reads that list, so every future issue is only as good as this file.

## What you will get back

One spreadsheet, `CTC_Source_Registry_<City>.xlsx`, one row per source, eleven columns plus `Missing Info`. Teal header band (the events sheet is green, so the two are never confused). A three-row excerpt:

| Source Name | URL | Platform | Method | Tier | Category | Cadence | Last Event | Confidence | Origin | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| CTC event submissions (all chapters) | (shared view) | airtable | auto | core | submissions | continuous | 2026-08-04 | verified | ctc | Standing row in every registry. Never delete. |
| Cascadia Cleantech Alliance | https://www.eventbrite.com/o/... | eventbrite | auto | core | eventbrite | weekly in term time | 2026-08-06 | verified | research | Largest single source by volume. Organizer page, not an event page. |
| Portland Art Museum | https://example.org/pam/calendar | web | manual | occasional | arts | 4 to 6 climate items a year | 2026-05-14 | verified | research | Whole-museum calendar. A human picks out the climate programming. |

Unverified rows are shaded; any missing required field is shaded red and named. The chat summary gives the count per category including the empty ones, what was rejected and why, and what a local should check. A full sample is `references/sample-output/CTC_Source_Registry_SAMPLE.xlsx`; `references/example-registry.csv` is the same data as text.

## What this is for

Two readers, wanting different things.

**A machine reads it every week.** `ctc-harvest` walks the rows and fetches each one. That is why `url`, `platform`, and `method` have to be accurate rather than optimistic: an overclaimed `auto` source fails silently in the weekly sweep, the issue comes out thin, and nobody works out why.

**A person reads it about four times a year.** The chapter lead, on the quarterly refresh, deciding what died and what to add. That is why `cadence`, `last_event`, `origin`, and `notes` exist.

The list is finished when someone who lives in that city and works in climate could read it without naming an obvious omission. **Prefer 25 verified sources to 60 guesses.** A missing source is invisible; a bad source silently pollutes every future issue.

Do not use the words config, registry, schema, or pipeline with the lead. Say source list, spreadsheet, and the weekly cycle. The file name keeps "Registry" so the harvest can find it by name.

## Input

A city name. Optionally, calendar links the lead already has (Step 0 asks). If the chapter has a settings file from `ctc-chapter-setup`, the scope rule is in section 2; otherwise establish it in Step 1.

## What this is and is not

**A once-per-city research job, rerun every three months.** It finds which calendars exist. `ctc-harvest` pulls this week's events from them.

Never use open web search to collect a week's events. Search offers no completeness guarantee and returns different results week to week. A registered calendar returns everything on it, every time. That difference is the reason this list exists.

Do not tell the lead how long anything will take. Say what is happening and what comes next.

## Exclusions

**Never register Climate Tech Cities' own properties as event sources.** The list is where other people announce events:

- `climatetechcities.com` and every chapter subdomain
- Any chapter's Substack, including this one. Registering the chapter's own newsletter would re-harvest last week's listings forever
- Other chapters' newsletters
- Typeform, Google Docs, Drive, and social links

**The one CTC property that is always registered** is the event submission form's shared view, as the standing `submissions` row (see Step 5). It is an intake readers use to send the chapter events, which is the opposite of the circular case above.

**Do not assume a calendar belongs to CTC because its name resembles a chapter's.** A Luma calendar named "Seattle Climate Tech" was once excluded as the chapter's own; it was run by Work on Climate, My Climate Journey, and Climate Changemakers. Check who runs it. Excluding a real source is a permanent, invisible loss.

**CTC partner organizations are external sources.** My Climate Journey, Women and Climate, Climatebase, SOSV, Climate Draft, Newlab, and ClimateRaise run their own events. Register them normally where they have local programming.

## Read this first

- `references/search-playbook.md`: concrete queries for all nine categories, the verification checks, and the coverage check to run before finishing. The most common failure of this skill is running two searches and stopping.
- `references/example-registry.csv`: a complete valid registry for a fictional chapter, covering all nine categories, all three tiers, all three pull methods, one `unverified` row, and the standing submissions row.
- `references/verifier.md`: the second-pass check run on the finished file before it is handed over.

## Environment

Web search and page fetching are required. The browser (Claude in Chrome) is needed to verify Luma and Eventbrite pages, which return an empty shell to a plain fetch; a page that would not load has not been verified. `openpyxl` is needed for the build script (`pip install openpyxl --break-system-packages`).

The sandbox restricts outbound access from `bash` to a package-manager allowlist, so `curl` fails on event sites that are healthy. Use the fetch tool or the browser, and never record a source as dead because a shell command could not reach it.

## Step 0. Ask for the lead's own sources first

Before any searching, ask whether they already have calendar links. A lead usually knows five or ten off the top of their head, and those are the highest-quality rows because a real person already vouched for them.

Present all three options in full, every time, in plain language:

> Before I start, do you already have event calendars you want in the source list? Luma calendars, Eventbrite organizer pages, university calendars, anything you already check by hand.
>
> Either way works:
>
> **A. Paste your links, then I research too.** I verify yours, follow their cross-links, and work the full nine-category search on top. Best coverage. This is what I'd recommend for a new chapter.
>
> **B. Paste your links only.** I verify what you give me and stop there. Fastest, and a good choice if you already know your city's scene and just want the file built.
>
> **C. I research from scratch.** No links needed. I go find them and bring back a verified list for you to review.
>
> Paste your links, or just say which option you want.

Then follow the choice. **A:** take the links into Step 1, verify them in Step 3, run the full Step 2 research pass, and use their Luma calendars as cross-link seeds. **B:** verify their links, skip Step 2, and produce the file from those alone, saying plainly what the count and category coverage came to; offer the research pass as a later step and do not run it uninvited. **C:** straight to Step 1 and the full research pass.

Skip the question only when the answer is already in front of you: the lead opened with links, or said "just research it". Confirm the read in one line and get on with it.

**A user-supplied link is a candidate, not a registered source.** It goes through all five gates in Step 3. When one fails, say which gate and why rather than dropping it silently, and register it `unverified` with a note if it is worth keeping.

## Step 1. Scope the city

Establish and write down before searching:

- **Geographic boundary.** From the settings file, or ask. New York's stated rule is roughly 95% the city proper, but its published issues carry Jersey City and Hoboken, so the working rule is closer to "anywhere a subscriber would travel on a weeknight."
- **Neighboring place names** that count as local. These become search terms.

## Step 2. Research the nine categories

Skip this step only under option B.

Run it as extended research, not ordinary searching: many searches, following leads between them, cross-referencing. Work every category, every time, and **report the empty ones**. An empty category is a finding, not a gap to hide.

1. **Luma calendars.** Structured, machine-readable, complete. Highest yield. Three entry points in order: Luma's discovery pages (`luma.com/{city}`, `luma.com/climate`, used to find calendars and never as sources themselves), keyword search (`site:lu.ma`, `site:luma.com` with the city plus climate, energy, sustainability, cleantech), and cross-links, which routinely yield four more calendars from one.
2. **Eventbrite organizers.** The largest single source by volume in mature chapters. Search organizer pages, not individual events.
3. **Universities and research centers.** Several separate calendars per university is normal: sustainability office, engineering school, business school entrepreneurship center, energy or environment institute. Include large public systems.
4. **Incubators, accelerators, coworking spaces.** Climate-focused first, general tech second.
5. **City government and utilities.** Sustainability offices, economic development corporations, energy authorities, utility program pages.
6. **Professional and affinity groups.** Young professionals in energy, women in renewables, LGBTQ+ climate networks, engineering societies, green building councils. Reliably recurring and easy to miss.
7. **Adjacent newsletters and meetups**, including ones that compete. Reading the competition is the cheapest completeness check available.
8. **Climate community organizations with local presence**, including CTC's partner organizations where they run local programming.
9. **Arts, culture, civic venues.** Museums, galleries, botanical gardens, libraries, parks organizations. A tech-focused search never surfaces these, and roughly 40% of CTC's audience is not yet working in climate.

If the lead supplied links in Step 0, sort them into the nine categories first. Leads tend to know the Luma and meetup scene well and the government, university, and arts categories barely at all; that tells you where to spend the search effort.

### How many sources, one rule

**The target for a new chapter is 25 to 30 verified external sources, weighted toward `core`. The sweep is finished when all nine categories have been worked and every cross-link followed, not when a number is reached.**

Reaching the target from scratch is roughly 30 to 50 searches plus a page open for every candidate that survives. A first pass that returns a dozen candidates has finished category one, not the job. If, after all nine categories and the cross-links, the count is below 25, deliver the file, report the count and the empty categories, and let the lead decide whether to add sources they know about. Under option B the count will often land below the target on its own; report it, name the empty categories, and offer the research pass. **Never pad.** Every source still passes all five gates, and one bad source pollutes every issue from now on.

The 25 to 30 figure is a working default carried in the CTC playbook, not a measured standard. Whether a city's event volume supports a weekly issue is decided in `ctc-newsletter-cycle` after the first harvests, not here.

## Step 3. Verification gates

Open every candidate and check all five. A source failing any gate does not go in as `auto`. This applies to user-supplied links too, with no softening.

**Gate 1. It loads.** Never register a page you could not open. Behind a login: record it `unverified` with a note.

**Gate 2. It is active.** At least one event in the last 90 days. A calendar whose most recent event is from 2023 is dead. The exception is a term-time source checked in July, which is a season; check whether it was active the previous spring.

**Gate 3. It is consistent.** Look at past events, not just upcoming. A repeating pattern: a monthly meetup, a weekly series, a seasonal program. Four events in three years is a `manual` check at best. Record the observed cadence.

**Gate 4. It is reputable and relevant.** A real named organization, events that actually happen, climate-adjacent rather than one green-themed event a year. The recurring cases:

| Situation | Ruling |
|---|---|
| Reseller running generic "ESG & Sustainability Strategy: 1 Day Training" listings across dozens of cities | Reject. Syndicated spam that recurs in every issue forever |
| Museum or library whose calendar is 95% non-climate but carries four or five climate events a year | Register as `occasional` and `manual` |
| A competing local climate newsletter | Register as `occasional`, method `email`. A completeness check, not a feed |
| National organization with a genuine local chapter running local events | Register the local chapter page |
| National organization with a local landing page and no local events | Reject |
| A single recurring event with its own page, no organizer page | Register the event page, `occasional`, note why |
| An organization whose calendar is entirely webinars | Register as `secondary` |
| Calendar named like a CTC chapter, run by someone else | Register it normally |
| Corporate marketing calendar with one greenwashed event a year | Reject |

The principle: would a subscriber be glad this event reached them, and does this URL produce such events on a repeating pattern? Both halves have to be true.

**Gate 5. Stable URL.** An organizer or calendar page, not a filtered search result. Will it work in six months?

## Step 4. Tier and classify

**Tier** by expected weekly contribution: `core` (several events most weeks), `secondary` (a few a month), `occasional` (worth checking, rarely fires).

**Method**, accurately rather than optimistically: `auto` (structured and machine-readable: Luma, Eventbrite organizer pages, server-rendered listing pages, the submissions view), `manual` (a human checks it: JavaScript-rendered calendars, PDF listings, events announced in prose, whole-venue calendars), `email` (arrives in the lead's inbox from a named contact; record the contact). When unsure, mark `manual`.

## Step 5. Add the standing submissions row

Every registry carries one row that is the same for every chapter: the CTC event submission form's shared view. Readers of any chapter's newsletter submit events through one form with a city dropdown; the harvest reads this chapter's rows from the shared view each week. Write the row exactly as in `references/example-registry.csv`: `platform = airtable`, `method = auto`, `tier = core`, `category = submissions`, `origin = ctc`, and the URL from `../ctc-assemble/references/ctc-links.md`. The build script writes nothing and exits with an error when the row is missing. It does not count toward the 25 to 30 target and it is never deleted on a refresh.

## Output

Write the workbook with the bundled script, never by hand:

```bash
python3 scripts/build_registry.py sources.json CTC_Source_Registry_<City>.xlsx
```

`sources.json` is `{"city": "...", "sources": [ ... ]}` with one object per source keyed by the column names in the example file. The script exists so the columns come out identical every time for `ctc-harvest`, unverified rows are shaded, missing required fields are shaded red and named in `Missing Info`, and the QA report names the count per category including the empty ones and the external count against the target. It warns (and still writes the file) under 25 external sources or over about 35; it writes nothing and exits with an error only when the submissions row is missing. Read the output before delivering. Fix red cells and re-run rather than handing over a file with red in it.

| Column | Contents |
|---|---|
| `name` | Organization or calendar name |
| `url` | Stable page URL |
| `platform` | `luma` / `eventbrite` / `web` / `email` / `airtable` |
| `method` | `auto` / `manual` / `email` |
| `tier` | `core` / `secondary` / `occasional` |
| `category` | `luma` / `eventbrite` / `university` / `incubator` / `government` / `professional` / `adjacent` / `climate org` / `arts` (the nine, in Step 2 order), or `submissions` |
| `cadence` | Observed: "monthly meetup", "weekly", "continuous" |
| `last_event` | Date of the most recent event seen |
| `confidence` | `verified` / `unverified` |
| `origin` | `user` / `research` / `ctc` |
| `notes` | Who runs it, why it is `manual`, term-time only, what makes it worth the slot. "Good calendar" is not a note |

`origin` earns its place on the quarterly refresh: a `user` row that has gone quiet is worth asking the lead about before deleting; a `research` row that has gone quiet can just go; a `ctc` row is never deleted.

### Verify before handing over

Run `references/verifier.md` on the built file: a fresh, adversarial pass that re-opens every row, checks that every `auto` claim is honest, reverses any exclusion made on a name match, and confirms the standing submissions row. That file says how to run it as a subagent where the session has one and as a separate step where it does not. Fix `sources.json`, re-run the build script, and only then summarize. The verifier's findings are one paragraph of the summary.

**Summary in chat:** which option was run and how many sources came from the lead versus research; any user-supplied link that failed a gate, with the gate named; total verified sources by method and tier; count per category including the empty ones; candidates rejected and why; which sources will carry the most volume; what a local person should check.

Then hand over, and wait for the reply (this is the one handoff prompt for this stage; `ctc-newsletter-cycle` does not add another):

> That is your source list, [N] sources across [M] categories, plus the Climate Tech Cities submission form. Read it before we go further. You live there and the research does not, so if it missed the meetup everyone goes to, say so and I will add it. When it looks right, add the file to your project as a context file and we can run the first harvest.

## Refresh

Rerun every three months. Sources die quietly and nobody notices until the newsletter has been thin for two months.

Run Step 0 on a refresh as well: the lead has been reading the scene for three months and will have picked up calendars the last pass missed. **Re-verify existing rows before hunting for new ones.** A dead core source costs more than a missing new one. Report both what died and what is new. Keep the submissions row.

## Failure modes

**Two searches and a stop.** The single most common failure. A list built from one category looks finished and the gaps are invisible forever after.

**Excluding a real source on a name match.** Check who runs a calendar before excluding it.

**Registering an individual event page as a source.** It fires once and returns nothing forever. Register the organizer.

**Optimistic `auto` classification.** A JavaScript calendar recorded as `auto` returns nothing in the weekly harvest without erroring. Mark `manual` when unsure.

**Syndicated training spam accepted.** If the same title appears in three cities, it is a reseller.

**Arts, government, and utility categories skipped.** The least glamorous searches and among the most reliable sources.

**Forgetting the submissions row.** The script catches it, but a registry without it means reader submissions never reach the issue and nobody knows why.

**Reporting only what was found.** The empty categories, the rejections, and the unverifiable candidates are half the value of the summary.
