#!/usr/bin/env python3
"""
Write the source registry as a formatted workbook.

    python3 build_registry.py sources.json CTC_Source_Registry_<City>.xlsx

Layout matches the events sheet produced by ctc-harvest, so the two files feel
like one product, with one deliberate difference: the header band is TEAL here
and GREEN there. A lead with both files open can tell at a glance which is the
list of places events come from and which is the list of events.

sources.json is {"city": "...", "sources": [ ... ]}, one object per source
keyed by the column names below (a bare list is also accepted).

Exit status: 0 with the file written, and warnings printed, when the external
count is under 25 or over about 35; 1 with nothing written when the standing
submissions row is missing.
"""

import json
import re
import sys
from collections import Counter

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

# Teal. The events sheet uses 2E7D32 green. Do not make these the same.
HEAD_FILL = PatternFill("solid", fgColor="0F6E6E")
UNVERIFIED_FILL = PatternFill("solid", fgColor="FDF0E3")
GAP_FILL = PatternFill("solid", fgColor="F8CBCB")
HEAD_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
BODY_FONT = Font(name="Arial", size=10)

REQUIRED = ["name", "url", "platform", "method", "tier", "category",
            "cadence", "last_event", "confidence", "origin"]


def row_gaps(e):
    """Required fields this source is missing."""
    return [k for k in REQUIRED if not str(e.get(k, "") or "").strip()]


COLUMNS = [
    ("name", "Source Name", 34),
    ("url", "URL", 44),
    ("platform", "Platform", 12),
    ("method", "Method", 10),
    ("tier", "Tier", 10),
    ("category", "Category", 18),
    ("cadence", "Cadence", 22),
    ("last_event", "Last Event", 13),
    ("confidence", "Confidence", 13),
    ("origin", "Origin", 11),
    ("notes", "Notes", 60),
    ("_gaps", "Missing Info", 30),
]

CATEGORIES = [
    "luma", "eventbrite", "university", "incubator", "government",
    "professional", "adjacent", "climate org", "arts", "submissions",
]


def main(src, out):
    data = json.load(open(src))
    city = data.get("city", "City")
    rows = data.get("sources", data if isinstance(data, list) else [])

    wb = Workbook()
    ws = wb.active
    ws.title = "Sources"

    for i, (_, header, width) in enumerate(COLUMNS, start=1):
        c = ws.cell(1, i, header)
        c.fill = HEAD_FILL
        c.font = HEAD_FONT
        c.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[1].height = 27.75

    label = {k: h for k, h, _ in COLUMNS}
    for r, e in enumerate(rows, start=2):
        unverified = str(e.get("confidence", "")).strip().lower() == "unverified"
        gaps = row_gaps(e)
        gap_cols = {k for k in gaps}
        for i, (key, _, _) in enumerate(COLUMNS, start=1):
            if key == "_gaps":
                val = ", ".join(label[k] for k in gaps)
            else:
                val = e.get(key, "")
            c = ws.cell(r, i, val)
            c.font = BODY_FONT
            c.alignment = Alignment(vertical="top",
                                    wrap_text=(key in ("notes", "_gaps")))
            # Only the empty cell goes red, plus the note that names it.
            # Shading a whole row buries the one field that needs attention.
            if key in gap_cols or (key == "_gaps" and gaps):
                c.fill = GAP_FILL
            elif unverified:
                c.fill = UNVERIFIED_FILL

    ws.freeze_panes = "A2"

    # ---- report, read this rather than assuming it passed
    print(f"  {len(rows)} sources for {city}\n")

    per_cat = Counter(str(e.get("category", "")).strip().lower() for e in rows)
    for cat in CATEGORIES:
        n = per_cat.get(cat, 0)
        flag = "" if n else "   <- empty"
        print(f"  {cat:<14} {n:>3}{flag}")
    other = {k: v for k, v in per_cat.items() if k not in CATEGORIES and k}
    for k, v in other.items():
        print(f"  {k:<14} {v:>3}   <- not a standard category")

    print()
    warns = []
    failures = []
    # The CTC event submission form is a standing row in every registry
    # (category "submissions"). It is not an external source and does not
    # count toward the 25 to 30 target.
    subs = [e for e in rows if str(e.get("category", "")).strip().lower() == "submissions"]
    external = len(rows) - len(subs)
    if not subs:
        failures.append(
            "no submissions row. Every registry carries the CTC event submission "
            "form's shared view as a standing row (platform airtable, method auto, "
            "tier core, category submissions). Add it from ctc-links.md.")
    if external < 25:
        warns.append(
            f"{external} external sources, under the 25 to 30 target for a new chapter. "
            f"If all nine categories and the cross-links were worked, deliver it and "
            f"report the count and the empty categories. If not, go back to Step 2. "
            f"Never pad: every source still passes all five gates.")
    if len(rows) > 35:
        warns.append(f"{len(rows)} sources. Over about 35, check that every row is "
                     f"still earning its slot; the weekly sweep opens all of them.")
    empty = [c for c in CATEGORIES if not per_cat.get(c) and c != "submissions"]
    if empty:
        warns.append(f"empty categories: {', '.join(empty)}. Say why each is empty "
                     f"rather than leaving the gap unexplained.")
    incomplete = [(e, row_gaps(e)) for e in rows if row_gaps(e)]
    if incomplete:
        print(f"  {len(incomplete)} source(s) missing required info, shaded red "
              f"and named in the Missing Info column:")
        for e, g in incomplete:
            print(f"    {str(e.get('name'))[:40]:42s} {', '.join(label[k] for k in g)}")
        print()
    for e in rows:
        u = str(e.get("url", ""))
        if u and not u.startswith("http"):
            warns.append(f"{e.get('name')}: URL is not a link -> {u}")
    unv = [e for e in rows if str(e.get("confidence", "")).lower() == "unverified"]
    if unv:
        print(f"  {len(unv)} unverified, shaded in the file:")
        for e in unv:
            print(f"    {e.get('name')}")
        print()

    if failures:
        print("NOT READY. Nothing written. Fix before re-running:")
        for f in failures:
            print(f"  X {f}")
        sys.exit(1)
    wb.save(out)
    print(f"wrote {out}")
    if warns:
        print("CHECK THESE:")
        for w in warns:
            print(f"  ! {w}")
    else:
        print("No warnings.")

    print("\nThis file lists WHERE events are announced. It is not the events "
          "themselves.\nRun ctc-harvest next to sweep these sources into the events sheet.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit("usage: build_registry.py sources.json out.xlsx")
    main(sys.argv[1], sys.argv[2])
