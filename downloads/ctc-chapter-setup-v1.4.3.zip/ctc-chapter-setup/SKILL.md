---
name: ctc-chapter-setup
description: Set up a new Climate Tech Cities chapter. Interviews the new chapter lead in seven plain questions, then produces their chapter settings file and a 90 day launch plan with their real dates in it. Use this skill whenever someone is starting a new CTC chapter, says they have just been approved to lead one, asks "how do I start my chapter" or "what do I do first", wants their chapter settings or city settings file created, wants a launch plan or 90 day plan for a city, or has installed the CTC toolkit and does not know what to run first. Always use it even if they only ask for the settings file or only for the plan. Do NOT use it to research event sources, which is ctc-source-map, or to make a logo, which is ctc-logo-generator.
---

# CTC Chapter Setup

The first thing a new chapter lead runs. Ask seven questions, produce two Word documents.

This is the only skill in the toolkit whose user is definitionally a beginner. They may have been approved yesterday, they may never have used Claude, and they have six other skills installed with no idea what to do with them. This skill is the answer to "okay, now what."

## What this is for

Climate Tech Cities is a network of volunteer-run city chapters. Each chapter publishes a weekly climate events newsletter on Substack. The failure that matters is not a bad issue. It is a chapter that stops sending: the flagship New York newsletter went silent for 216 days in 2025, and covering roughly 37 percent of that year's weeks is the pattern this whole toolkit exists to prevent.

Every rule below bends toward one outcome, which is a lead who reaches their first issue quickly and survives their first missed week. That is why every question has a default, why nothing blocks, why the first issue is described as small on purpose, and why the plan carries a section about missing weeks before the lead has missed one.

The two documents have different readers and need different things.

**The settings file is read by software.** The lead adds it to their Claude project as a **context file** once, and every other CTC skill reads it from there instead of asking. It has to be unambiguous and complete rather than persuasive. Each field exists because a downstream skill would otherwise interrogate the lead about it every week.

**The plan is read by a person, once, in the first ten minutes of their chapter.** Probably on a phone. Then referred back weekly. It answers two questions and no others: what do I do this week, and is what I am seeing normal. It is not a strategy document and should never grow into one.

## The bar

Someone who has never used Claude finishes this in under fifteen minutes, understands what happens next, and never has to answer any of these questions again.

## Read this first

| File | What it holds | When to read it |
|---|---|---|
| `references/worked-example.md` | A complete run end to end: the transcript, the filled data file, and the delivery message | Before your first run. It is the calibration for tone, length, and how to handle a lead who is unsure |
| `references/interview.md` | The exact question wording, the defaults, and how to turn a loose answer into a clean field | Before asking anything |
| `references/plan-notes.md` | Where every number in the plan comes from, and which are measured versus estimated | When the lead asks why the plan says something |
| `references/substack-setup.md` | The seven-step Substack checklist and what not to do | When the lead reaches the newsletter step, or asks how to set up Substack. Not during setup |
| `references/welcome-email.md` | What the welcome email has to do, its length and voice, and a shape to adapt | When the lead asks for the welcome email |
| `references/list-building.md` | Which sources qualify as consent, which do not, and the GDPR rules for UK and EU chapters | When the lead asks how to build the list, or mentions importing one |

The last three arrive in week 1 or 2, not on day one. Do not deliver them during setup. A lead who has just answered seven questions cannot act on six more decisions, and a checklist given early is a checklist forgotten. They are surfaced by the plan, which tells the lead the phrase to ask.

`scripts/build_chapter_docs.js` renders both documents. `scripts/chapter_data_TEMPLATE.json` is the data file to fill in. Do not hand-roll docx generation.

---

## Before you start: check the environment

The skill needs a code execution sandbox with Node and the `docx` package. On a Claude account where code execution is switched off, nothing here works, and the failure looks like a tool that is simply missing rather than an error.

Run this first:

```bash
node -e "require('docx'); console.log('ok')"
```

| Result | What to do |
|---|---|
| Prints `ok` | Proceed |
| `Cannot find module 'docx'` | `npm install docx` in the working directory, then retry |
| No code execution tool available at all | Stop before the interview. Tell the lead to switch on code execution in Claude Settings under Capabilities, then run the skill again. Do not run the interview and then discover you cannot build the files |

The script writes to `/mnt/user-data/outputs/` and creates the directory if it is absent. Network access is not required at any point.

---

## Step 1. Orient them, then start

Open with two sentences, not a wall. Something close to:

> I will set up your chapter. Eight quick questions, then I will hand you your settings file and a plan with your actual dates on it.
>
> First one: which city is your chapter in?

Do not explain the toolkit, do not list the other skills, and do not describe what a settings file is before they have one. Both of those land better after the documents exist.

## Step 2. Run the interview

Follow `references/interview.md` exactly. One question per message, a default offered on every one, and none of the words config, registry, schema, or parameter.

Your own replies between questions run one sentence. Two is already too long. See the transcript in `references/worked-example.md` for the calibration.

If they answer several questions at once, take them all and skip ahead.

If they abandon partway, build with what you have and mark the rest incomplete.

## Step 3. Build the data file

Work from the skill's own directory, so that `scripts/` resolves. Copy `scripts/chapter_data_TEMPLATE.json` to `chapter_data_<city>.json` in that directory and fill it from the interview.

- `startDate` is today, in `YYYY-MM-DD`.
- `chapterName` is always `Climate Tech <City>`.
- `webAddressConfirmed` is `false` unless the lead says the Climate Tech Cities team has already confirmed it.
- `cityNotes` may be an empty string.
- No em dashes anywhere.

Three fields are written by you rather than pasted from the lead: `chapterName`, `scopeRule`, and `signOff`. `references/interview.md` has the rules and the weak-versus-strong examples for each. A loose scope rule is the most common way this output degrades, because every downstream skill filters against that one sentence.

## Step 4. Render

```bash
node scripts/build_chapter_docs.js chapter_data_<city>.json
```

The script validates the data file before building and refuses to run if a required field is blank, the date is malformed, the send day is not a real weekday, or an em dash is present. Read its output rather than assuming it passed.

Then open both documents before delivering. The validator checks the data, not the result.

## Step 5. Deliver, then tell them one thing to do

Call `present_files` on both documents. Then, briefly:

1. What each file is, in one line each.
2. **Tell them to add the settings file to a Claude project as a context file.** This is the only instruction that matters right now, because nothing else in the toolkit works until they do it. Say it in close to these words, and do not shorten it to "upload it":

   > Create a project in Claude, then add `Chapter_Settings_<City>.docx` to that project as a **context file**. Project settings, then add files. Not attached to a chat: a file attached to one conversation is not available in the next one, and every skill in the toolkit reads this file.

   **Never say only "upload this."** A lead who reads that will attach it to the current conversation, it will work once, and then every skill will interrogate them from scratch next week. Name the project and name the words "context file".
3. The one thing to do this week, named from the plan. For almost everyone that is running `ctc-logo-generator`.

If the web address is unconfirmed, say so in one line as part of the delivery.

The whole message runs under 120 words. `references/worked-example.md` has one written out, with the padded version it replaced. Then stop. Do not summarize the plan they can read, do not list the remaining skills, and do not restate the method.

---

## House rules

**One question on screen at a time.** Always.

**Plain words only.** "Your settings file." Never config, registry, schema, parameter, or field.

**Never block on an answer they cannot give.** Record the default, mark it to confirm, keep moving.

**Never pick their web address.** Four Climate Tech Cities chapters use a `climatetechcities.com` subdomain and six use a `substack.com` address. No rule has been published about which a new chapter takes, so record their preference, flag it, and tell them to confirm with the Climate Tech Cities team before publishing. It is a one-way door once other chapters link to it.

**Never assume internal access.** This toolkit is used by volunteers outside the organization. Do not reference internal folders, Slack channels, or individual staff members by name. Say "the Climate Tech Cities team."

**Never write the other skills' sections.** Brand, sources, partners, and events are created as empty scaffolds with a note naming the skill that fills each. Populating them here means two skills fighting over the same file.

**Never invent a number.** Every figure in the plan is in `references/plan-notes.md` with its provenance, including which ones are working estimates rather than measurements. If asked something not covered there, say it is not documented rather than estimating.

---

## Judgment calls

Every one of these has come up or will. The ruling matters less than the reasoning, which is what lets you decide a case that is not listed.

| Situation | Ruling | Reasoning |
|---|---|---|
| The city already has a chapter: New York, Washington DC, Boston, Chicago, San Diego, Los Angeles, San Francisco, Seattle, London, Amsterdam | Ask before building. If they are restarting a chapter that has gone quiet, build normally. If the chapter is active, they need the existing lead, not a second settings file | Two settings files for one city means two people running the same newsletter and neither knowing it |
| They give a metro name or an abbreviation | Ask once for the name the city is known by. `The Bay Area` becomes `San Francisco`, `NYC` becomes `New York` | The chapter name has to match across every chapter, the Substack, the website tile, and every event listing |
| They give a city and a state or country | Take the city alone. `Denver, Colorado` becomes `Denver` | The chapter name is "Climate Tech Denver" |
| They want to send every two weeks or monthly rather than weekly | Record the weekday as normal and put the cadence in `cityNotes` | The send day is a weekday. Cadence is not a field, and inventing one puts something in the settings file that no downstream skill reads |
| The chapter is in the EU or the UK | Build normally. Nothing in the data file changes. Point them at `references/list-building.md` when they reach the subscriber list step | Consent requirements differ there, but they are a reading task for the lead, not a field in the settings file |
| They ask which web address to use | There is no published rule. Say so and do not guess | A wrong answer here is a one-way door |
| They do not know their timezone | Take the standard one for their city and say which you took | A formality that should not cost anyone a minute |
| They answer "whatever you think" to everything | Take every default, build, and mark them to confirm | A chapter that never finishes setup never sends |
| They ask you to make the logo or find their event sources mid-interview | Finish setup, then name the skill that does it | Those sections belong to other skills, and starting a second job mid-interview is how leads end up with neither finished |
| They have no chapter email address yet | Take a personal address they can receive mail at today | Waiting for a chapter address delays the launch, and this is the standard across chapters |
| They give a scope rule as a list of towns | Turn it into one sentence and read it back for confirmation | Downstream skills read it as a sentence, not a list |

**The principle underneath.** Record what the lead can tell you today, flag what they cannot, and never let a missing answer stop the documents from existing. Chapters fail by not sending. An incomplete settings file that lets someone start beats a complete one they never finish.

---

## Failure modes

**Saying "upload" instead of "add to your project as a context file".** The most consequential wording failure in this skill. The lead attaches the file to the conversation, everything works for one session, and next week every skill asks for their city again. Always name the project, and always use the words "context file".

Each of these produces a plausible-looking result, which is why they are worth naming.

**Discovering mid-build that code execution is off.** You run seven questions, then find you cannot render anything. Check the environment before Step 1, not after Step 3.

**A settings file already exists.** Do not overwrite. Show what is in it and ask which fields to change, then rebuild.

**Writing a scope rule that cannot be applied.** "The greater metro area" and "wherever makes sense" both read fine and neither one decides a single real event. Every week, a downstream skill has to answer "does this Hoboken event belong in the New York issue," and that sentence is the only thing it has. See `references/interview.md` for the weak-versus-strong pairs.

**Padding the delivery message.** The temptation at the end is to summarize the plan, list the other skills, and explain what happens next. The lead has a document that does all three. A long closing message competes with the plan and buries the one instruction that matters, which is to add the settings file to a project as a context file.

**Filling in the scaffold sections because they look empty.** Brand, sources, partners, and events are blank on purpose. Writing plausible content there means the skill that owns the section either overwrites it or duplicates it.

**Repeating a number without checking `plan-notes.md`.** Several figures in the plan are working estimates, not measurements, and they are labeled as such. Presenting an estimate as a measured standard is the specific mistake this toolkit has made before: an unsourced 100-subscriber launch threshold survived six drafts of the playbook before anyone checked it, and it contradicted the launch guidance sitting two lines below it.

**Delivering the transcript instead of the documents.** The output is two files in `/mnt/user-data/outputs/`, presented with `present_files`. If the turn ends without them, the task is not done regardless of how good the conversation was.

**They abandon after two questions.** Build anyway, mark the rest incomplete, and tell them they can finish later by running the skill again.

---

## Before you deliver

- Both files exist in `/mnt/user-data/outputs/` and you have opened them
- The chapter name reads `Climate Tech <City>` with no state, country, or abbreviation
- The scope rule is one sentence that would decide a real borderline event
- The five scaffold sections are still empty
- The web address flag is present if it is unconfirmed
- No em dashes in either document
- Your delivery message is under 120 words and names one action
