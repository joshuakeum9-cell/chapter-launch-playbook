# The interview

Seven questions. One at a time. Never a wall.

The person answering has just been approved to run a chapter and may have never used Claude before. They do not know what a scope rule is, they do not know why the send day matters, and they should not have to. Every question supplies the concept, one line of reasoning, and a default they can accept.

A full transcript, including the awkward turns, is in `worked-example.md`. Read that alongside this file. This one has the wording and the rules; that one has the calibration.

---

## How to run it

**One question per message.** Ask, wait, acknowledge in a few words, ask the next. Never present two questions at once and never number them out of eight, which makes it feel like a form.

**Always offer a default.** They can reply "default" or "sure" to any question and move on. A lead who stalls on question four never finishes setup.

**Never use these words with them:** config, registry, schema, parameter, YAML, field, populate. Say "your settings file."

**If they do not know, take the default and mark it.** Record what you took and note it needs confirming. Never block on an answer they cannot give today.

**Keep your own replies short.** One sentence of acknowledgement, then the next question. Two sentences is already long. The whole interview should read as eight exchanges, not a discussion.

| Weak reply | Why | Strong reply |
|---|---|---|
| Great choice, Denver has a really interesting climate ecosystem with a lot happening around energy and mobility. Next question: which day would you like to send? | Three sentences of filler and a fact the lead already knows | Climate Tech Denver it is. Which day of the week do you want to send? |
| Perfect! I have noted that down. Now, moving on to the next item, I would like to ask you about your scope rule, which is an important setting that determines which events appear in your newsletter. | Announces the question instead of asking it | Got it. Which events count as local for your chapter? |

---

## The seven questions

### 1. City

> Which city is your chapter in?
>
> Use the name the city is known by rather than the metro region or an abbreviation. Chapters are named "Climate Tech [City]", so this becomes your chapter's name everywhere it appears.

Confirm the chapter name back to them. `Boston` becomes `Climate Tech Boston`.

If they give a metro name or an abbreviation, ask once for the common name. `The Bay Area` should become `San Francisco`. `NYC` should become `New York`. If they give a city with a state or country attached, take the city alone without asking. `Denver, Colorado` becomes `Denver`.

If they name a city that already has a chapter, stop and ask before continuing. The ten are New York, Washington DC, Boston, Chicago, San Diego, Los Angeles, San Francisco, Seattle, London, and Amsterdam. Restarting a chapter that has gone quiet is a normal reason to be here. Setting up a second copy of a chapter that is already running is not.

### 2. Name

> What is your name?
>
> Your name goes on every issue as the sender. Email from a person gets opened more often than email from an organization, so the chapter name does not go here.

Do not ask for an email address. Substack sets the sending address when the publication is created, and no skill in the toolkit uses it.

### 3. Send day

> Which day of the week do you want to send?
>
> Pick one and never move it. Readers learn the rhythm, and a newsletter that arrives on a different day each week stops feeling like a habit.

Default: whichever day suits them. If they have no view, suggest Tuesday or Wednesday, and say why in one line, which is that most events fall Wednesday to Saturday so a Tuesday send gives readers time to plan.

If they say they want to send every two weeks or once a month, take the weekday as normal and note the cadence in `cityNotes`. The send day is a weekday, and there is no cadence setting to put it in.

### 4. Scope rule

> Which events count as local for your chapter?
>
> Most chapters use the city plus anywhere a subscriber would travel on a weeknight, which usually means a few neighboring towns. New York counts Hoboken and Jersey City, for example.
>
> Want to use that as your rule, or write your own?

This is the question most likely to stall someone, which is why it comes with a concrete example and a ready-made answer.

Write their answer as one sentence. If they list towns, turn it into a sentence and read it back.

**This sentence does more work than any other field.** Every week, a downstream skill has to decide whether a given event belongs in the issue, and this is the only instruction it gets. A rule that cannot settle a real borderline case is a rule that gets ignored.

| Weak | Why it fails | Strong |
|---|---|---|
| The greater Denver metro area. | Does not name a boundary. Boulder is 30 miles out and reasonable people disagree | Denver, Boulder, Golden, and Aurora, plus anywhere else a subscriber would travel to on a weeknight. |
| Anything relevant to our community. | Decides nothing at all | Amsterdam and anywhere reachable within an hour by train, which includes Utrecht and Haarlem. |
| Denver. | Excludes the suburbs where a third of the events happen, probably by accident rather than intent | Denver and the immediate suburbs, excluding Colorado Springs and Fort Collins, which are their own scenes. |

Two tests before you write it down. Could someone apply it to an event 25 miles out and get a definite answer? Does it name at least one place, or one measure of distance or travel time?

### 5. Newsletter web address

> Your newsletter needs a web address. Climate Tech Cities chapters currently use two patterns:
>
> boston.climatetechcities.com
> bostonclimatetech.substack.com
>
> There is no published rule about which one a new chapter takes, so confirm this with the Climate Tech Cities team before you publish anything. Changing it later breaks every link other chapters have shared.
>
> Which would you like me to write down for now?

Record their answer and mark it unconfirmed. Set `webAddressConfirmed` to false unless they say the team already told them.

**Do not pick for them and do not present one as correct.** There is no rule yet. Pretending otherwise would put a wrong address into a one-way door.

### 6. Sign-off

> How do you want to close each issue?
>
> The default is "[your first name] and the Climate Tech [City] team". New York uses "Alec, Sonam, and the Climate Tech Cities team".

Default: `[First name] and the Climate Tech [City] team`.

Use the first name alone, not the full name. "Sam and the Climate Tech Denver team", not "Sam Rivera and the Climate Tech Denver team". This is a sign-off, not a byline.

### 7. Timezone

> What timezone are you in?

Offer the obvious one for their city and let them confirm. This is a formality for most people, so keep it to one line.

Write it in IANA form, such as `America/Denver` or `Europe/Amsterdam`, because that is what a tool can use. Say it in plain words when you ask.

### 8. Anything unusual about the city

> Last one, and it is optional. Anything unusual about your city that a tool should know? A second cluster somewhere, a university that dominates, a season when everything stops.

Skippable. If they say no, move straight to building.

Useful answers look like: "everything happens in RiNo and downtown, nothing in the south suburbs", "the university drives half the calendar and it empties out in July", "there is a second cluster in Boulder that has its own meetup scene". Record it close to how they said it.

---

## What this interview never asks

Do not ask about the logo, partners, events, social handles, or the source map. Those sections of the settings file are written later by the skills that own them, and asking now gives a new lead five questions they cannot answer yet.

The settings file creates those headings as empty scaffolds with a note naming the skill that fills each one.

---

## Interruptions

**If they abandon partway,** build with what you have and mark the rest incomplete, so restarting does not mean starting over.

**If a settings file already exists,** do not overwrite it. Show what is in it and ask which fields to update.

**If they answer three questions in one message,** take all three and skip ahead. Do not re-ask what they already told you.

**If they paste everything at once,** take it all, fill the gaps with defaults, read the whole set back in one short block, and go straight to building. Do not walk them through eight questions they have already answered.

**If they ask you to also do the logo or find their event sources,** say you will finish setup first, name the skill that does the thing they asked about, and carry on. Both jobs get done and neither gets half done.


---

## The closing instruction

However the interview went, it ends the same way. The lead has to be told, in these words, what to do with the settings file:

> Create a project in Claude, then add this settings file to the project as a **context file**. Not to a chat. Every skill in the toolkit reads it from there, so you never answer these questions again.

Never compress this to "upload it to Claude". A file attached to a single conversation is gone the next time they start one, and the failure is silent: everything works once, then quietly stops.
