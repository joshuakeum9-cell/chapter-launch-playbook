# A complete run

One full run of this skill, from the first message to the delivered files. Denver, fictional lead, fictional answers.

**This is illustrative, not data.** The city, the person, the email address, and the notes are invented. Do not copy any of it into a real settings file. What it exists to calibrate is the length of your replies, the handling of a lead who is unsure, and the shape of the delivery message.

It demonstrates, in order: a city given with its state attached, a lead who does not know their send day, a scope rule that arrives too loose and has to be worked, a lead who asks a question back that has no answer, a default accepted, and an optional question that produces something worth recording.

---

## The transcript

> **Claude:** I will set up your chapter. Eight quick questions, then I will hand you your settings file and a plan with your actual dates on it.
>
> First one: which city is your chapter in?

> **Lead:** Denver, Colorado

> **Claude:** Climate Tech Denver it is. What is your name, and what email address should replies go to? Your name goes on every issue as the sender, since email from a person gets opened more often than email from an organization.

> **Lead:** Priya Raman, priya.raman@gmail.com

> **Claude:** Got it. Which day of the week do you want to send? Pick one and never move it, because readers learn the rhythm.

> **Lead:** no idea honestly, does it matter which one

> **Claude:** Only that it stays the same. Most events fall Wednesday to Saturday, so a Tuesday or Wednesday send gives people time to plan. Want Tuesday, or would you rather pick?

> **Lead:** let's do Thursday, I have more time Thursday mornings

> **Claude:** Thursday it is. Which events count as local for your chapter? Most chapters use the city plus anywhere a subscriber would travel on a weeknight, which usually means a few neighboring towns. New York counts Hoboken and Jersey City, for example.

> **Lead:** the metro area basically

> **Claude:** That works, but it needs to be specific enough to settle a real case. Boulder is 30 miles out. In or out?

> **Lead:** in for sure. Boulder, Golden, Aurora. not Colorado Springs or Fort Collins, those are their own thing

> **Claude:** So: Denver, Boulder, Golden, and Aurora, plus anywhere else a subscriber would travel to on a weeknight. Sound right?

> **Lead:** yep

> **Claude:** Your newsletter needs a web address. Chapters currently use two patterns:
>
> denver.climatetechcities.com
> denverclimatetech.substack.com
>
> There is no published rule about which one a new chapter takes, so confirm it with the Climate Tech Cities team before you publish anything. Changing it later breaks every link other chapters have shared. Which would you like me to write down for now?

> **Lead:** which one should I use?

> **Claude:** I cannot tell you, and I would rather say so than guess. Four chapters are on the subdomain and six are on substack.com, and no rule has been published about which a new chapter takes. Pick whichever you prefer for now, and I will flag it in your settings file as needing confirmation before you publish.

> **Lead:** substack one then

> **Claude:** Noted and flagged. How do you want to close each issue? The default is "Priya and the Climate Tech Denver team".

> **Lead:** that's fine

> **Claude:** You are in Mountain Time, I assume?

> **Lead:** yes

> **Claude:** Last one, and it is optional. Anything unusual about Denver that a tool should know? A second cluster somewhere, a university that dominates, a season when everything stops.

> **Lead:** most stuff is in RiNo and downtown. Boulder has its own separate scene, like 30 min away. and the university calendar drives a lot in fall, July is dead

> **Claude:** Useful. Building your files now.

Nine exchanges. Every Claude turn is one or two sentences. The only turn that pushes back is the scope rule, and it pushes once with a concrete case rather than explaining why the rule matters.

---

## The data file

```json
{
  "city": "Denver",
  "chapterName": "Climate Tech Denver",
  "leadName": "Priya Raman",
  "replyEmail": "priya.raman@gmail.com",
  "timezone": "America/Denver",
  "startDate": "2026-08-11",
  "sendDay": "Thursday",
  "scopeRule": "Denver, Boulder, Golden, and Aurora, plus anywhere else a subscriber would travel to on a weeknight.",
  "webAddress": "denverclimatetech.substack.com",
  "webAddressConfirmed": false,
  "signOff": "Priya and the Climate Tech Denver team",
  "cityNotes": "Most events happen in RiNo and downtown. Boulder has its own separate meetup scene about 30 minutes away. The university calendar drives a lot of the fall and it goes quiet in July."
}
```

Note what happened to the raw answers. `Denver, Colorado` lost its state. The sign-off uses `Priya`, not `Priya Raman`. The timezone became IANA form even though the lead said "Mountain Time". The city notes keep the lead's own observations rather than being tidied into corporate phrasing, because a downstream skill reading "July is dead" gets more from it than from "seasonal variance in event volume".

---

## Building

```bash
node scripts/build_chapter_docs.js chapter_data_denver.json
```

```
wrote /mnt/user-data/outputs/Chapter_Settings_Denver.docx
wrote /mnt/user-data/outputs/Chapter_Plan_Denver.docx

  chapter    Climate Tech Denver
  lead       Priya Raman
  send day   Thursday
  starts     Tuesday, August 11, 2026
  first send Thursday, August 20, 2026
  day 90     Monday, November 9, 2026

  ! Web address is marked unconfirmed. The settings file flags it.
QA: data file passed. Open both documents before delivering.
```

Read that block rather than skipping it. The first send date is the one to sanity check, because it is computed rather than given: the script takes the start date, moves a week out, then finds the next matching weekday.

---

## What the two documents contain

**`Chapter_Settings_Denver.docx`.** Eight numbered sections. Sections 1 and 2 are filled from the interview: identity, then newsletter settings including the flagged web address note. Sections 3 through 7 are labeled empty scaffolds, each with a line naming the skill that fills it: brand for `ctc-logo-generator`, sources for `ctc-source-map`, partners for the `ctc-partner-map` plugin, events for `ctc-event-kit`, and social for the lead to fill in themselves. Section 8 records the toolkit version and what gets reported monthly.

**`Chapter_Plan_Denver.docx`.** A phase table with real dates, then the phases in order: logo in the week of August 10, Substack and sources in the weeks of August 10 and 17, first issue on Thursday August 20, partners through the week of August 31, first event between the weeks of August 31 and September 28, and the weekly cycle from there. Then the time budget, the weekly stage table, a section on missing a week, and three calibration facts about readers and issue size.

Both are fully generated. Nothing in them is written by hand at delivery time.

---

## The delivery message

> Two files.
>
> **Chapter_Settings_Denver.docx** holds your answers. **Create a project in Claude and add this file to it as a context file**, in project settings under add files. Not attached to a chat, because a file attached to one conversation is not there the next time you start one. Every other skill reads it from the project, so you never answer these questions again.
>
> **Chapter_Plan_Denver.docx** is your 90 days with real dates. First issue lands Thursday, August 20.
>
> One thing this week: run `ctc-logo-generator`. It reads your city from the settings file.
>
> Your web address is marked unconfirmed. Check it with the Climate Tech Cities team before you publish anything.

91 words. One instruction in bold, one action named, one flag raised.

### What this replaced

> Congratulations on launching Climate Tech Denver! I have created two documents for you.
>
> The first is your chapter settings file, which contains all of the information you provided during our conversation, including your city, your name and reply-to email, your send day of Thursday, your scope rule covering Denver, Boulder, Golden and Aurora, your preferred web address, your sign-off, and your timezone. It also contains empty sections for brand, sources, partners, events and social, which will be filled in later by the other skills in the toolkit.
>
> The second is your 90-day plan, which walks you through branding in week one, newsletter setup in weeks one and two, your first issue, partner outreach in weeks two to four, and your first event in weeks four to eight, followed by the ongoing weekly cycle of harvest, cut, draft and send...

That version is not wrong. It is a summary of two documents the lead is holding, and it buries the context file instruction in the middle of a paragraph. The lead reads the message instead of the plan, and the plan is better.
