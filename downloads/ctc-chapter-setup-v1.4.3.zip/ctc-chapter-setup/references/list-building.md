# Building the list

The rules here are not a formality. One wave of spam complaints damages sending reputation for every Climate Tech Cities chapter on the same infrastructure, not just the one that caused it.

Walk the lead through this when they reach the list step of their plan.

---

## The test

**Only add someone who gave you their email somewhere a newsletter was implied.**

That is the whole rule. Everything below is applying it.

| Source | Add? | Why |
|---|---|---|
| Event RSVPs and sign-in sheets | Yes | They came to a climate event and gave you an email |
| Newsletter sign-up form or QR code | Yes | Unambiguous |
| Someone who asked to be added | Yes | Obviously |
| Personal contacts who said yes when asked | Yes | The ask is the consent |
| Personal contacts who have not been asked | **No** | Ask them first. It takes one message and converts better anyway |
| A conference attendee list | **No** | They gave their email to the conference |
| A Slack or WhatsApp group export | **No** | They joined a group, not a mailing list |
| LinkedIn connections | **No** | Not a mailing list |
| Scraped from any website | **No** | Never |
| A list handed over by a partner | **No** | Their consent does not transfer. Ask the partner to share your sign-up link instead |

---

## Where to start

**Chapter contacts and event RSVPs first,** if any exist.

**Then the lead's own network, one message at a time.** A personal ask converts far better than a public post, and it is also the only route that produces real consent. Tell them to expect this to be most of their first hundred subscribers.

**Announce from personal accounts as well as any chapter account.** Same reason.

**Whoever they have is who they start with.** A first issue going to thirty people is normal and correct. Waiting until the list is big enough is how a launch slips by three months.

---

## For chapters in the UK and the EU

London, Amsterdam, and any future UK or EU chapter operate under GDPR and the UK equivalent, which sets a higher bar than the rule above. Three differences that actually change what the lead does.

**Consent has to be affirmative and specific.** A pre-ticked box does not count, and neither does an event RSVP unless the sign-up said, at the point of signing up, that it also subscribes them to the newsletter. So the event form needs its own separate, unticked newsletter checkbox. This is the one that catches people out, because RSVP-to-subscriber is otherwise the main growth route.

**Record what they consented to and when.** Keep the source and date against each subscriber. Substack does not do this for imports, so the lead needs their own record, which in practice means a spreadsheet.

**Unsubscribing has to be easy and honoured immediately.** Substack handles the mechanism, but a lead who re-imports an old list can resurrect people who left. Never re-import a list.

If a lead is unsure whether their situation qualifies, the safe move is to ask rather than import. This is general guidance, not legal advice, and a chapter with a genuinely unclear case should raise it with the Climate Tech Cities team.

---

## Failure modes

**Importing a conference list.** The single most common one, because it feels like a shortcut and the people are genuinely relevant. It is still not consent, and it is the fastest route to a spam-complaint wave.

**Adding personal contacts without asking.** Feels harmless, damages the relationship, and produces the complaints that hurt most because those people know the lead.

**Waiting for the list to be big enough.** There is no threshold. Send to whoever you have.

**Re-importing an old list.** Resurrects people who unsubscribed. Never do it.
