# Substack setup

Walk the lead through this when they reach the newsletter step of their plan, or when they ask how to set up Substack. Do not deliver it during setup. It arrives in week 1 or 2 and giving it to them on day one is six more decisions they cannot act on yet.

Read their settings file first and fill in the answers they already gave. They should never be asked twice for their send day or their sign-off.

---

## The checklist

Give it as a list they can tick, one screen, not a lecture.

**1. Create the publication.** Name it exactly `Climate Tech [City]`. Not the metro region, not an abbreviation, not "Climate Tech [City] Newsletter". It has to match the logo, the website tile, the social profiles, and every other chapter's naming.

**2. Confirm the web address before publishing anything.** Two patterns exist across Climate Tech Cities: a `climatetechcities.com` subdomain and a `substack.com` address. There is no published rule about which a new chapter takes, so ask the Climate Tech Cities team. This is the one step that cannot be undone quietly, because once other chapters link to the address, changing it breaks their links too.

**3. Upload the logo** as both the publication icon and the header image. Check the icon at small size, since that is where it will mostly be seen.

**4. Set the sender name to the lead's own name,** not the chapter name. Email from a person is opened more often than email from an organization. This is standard across chapters and leads often get it wrong because the chapter name feels more official.

**5. Write the welcome email.** See `references/welcome-email.md`. Substack sends it automatically to every new subscriber, so it is the first thing a reader ever sees from the chapter. Skipping it means new subscribers get silence until the next issue.

**6. Turn off Substack's recommendations and subscription pledges** unless the chapter has decided otherwise. Both default to on. Pledges invite readers to pay for something that is free, and recommendations send readers to publications nobody at Climate Tech Cities has vetted.

**7. Set the publication description** to one line. The chapter one-liners on the Climate Tech Cities site are the model: short, place-based, and specific about who it is for.

---

## What not to do here

**Do not set up paid subscriptions.** A new chapter has nothing to charge for and it complicates the list.

**Do not import a list yet.** That is its own step with its own rules. See `references/list-building.md`.

**Do not publish a test post to the live list.** Substack has a preview and it is enough.

---

## Common failure modes

**Naming it something clever.** Every chapter is `Climate Tech [City]`. A distinctive name breaks the family and makes the chapter look unaffiliated.

**Publishing before the web address is confirmed.** This is the expensive one. It is a one-way door.

**Sender name set to the chapter.** Costs opens every single week, invisibly.

**Skipping the welcome email.** The single cheapest thing in the whole setup and the most commonly skipped.
