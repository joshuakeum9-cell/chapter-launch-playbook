# The welcome email

Substack sends this automatically to everyone who subscribes. It is the first thing a new reader ever gets from the chapter, and often the only thing they get for a week. It is written once and then runs for years.

Draft it for the lead, then hand it over to edit. Read their settings file for city, chapter name, send day, scope rule, and sign-off, and use those rather than asking again.

---

## What it has to do

Four things, in this order. Nothing else.

1. **Say what this is.** One sentence. A weekly roundup of climate events in their city. If the settings file says every two weeks, say that instead.
2. **Say when it arrives.** Name the actual send day. A reader who knows it comes on Tuesdays notices when it does not.
3. **Say how to submit an event.** The Climate Tech Cities event submission form, which is the same link that ends every issue. Events sent through it reach the weekly harvest; a reply to the email reaches only the lead. Replies are still welcome, and say so, because they tell the lead who is reading.
4. **Say who is behind it.** One line, first person. This is the chapter, not a corporate account.

## Length

Under 150 words. It is a welcome, not a manifesto. A long welcome email is a signal that the newsletter will also be long, which is the wrong expectation to set.

## Voice

First person, contractions, warm and plain. The same person who will write the opening note every week.

**Say the newcomer is welcome, explicitly.** Roughly four in ten readers are not working in climate yet. A line like "if you are just starting to look into climate, this is for you too" costs nothing and does real work. Not "whether you're a veteran or a newcomer", which is on the banned list in the house voice file.

**Say weekly, softly.** The chapter sends weekly, which is the Climate Tech Cities standard, and the welcome email should say so. "Most [send day]s" is the form to use, because it survives a missed week without making a liar of the lead, where "every week without fail" does not. For a chapter on every two weeks, say "every other [send day]".

---

## The shape

Something in this shape, adapted to their words. Never ship this verbatim, since the whole point is that it sounds like them.

> Hi, and thanks for subscribing.
>
> This is Climate Tech [City], a roundup of what is happening on climate in and around [city]. It goes out most [send day]s: events for the week ahead, a few things worth planning for, and any opportunities worth knowing about.
>
> I started it because there is a lot going on here and no single place to find it. Plenty of readers do not work in climate yet, and it is for them as much as anyone.
>
> If you are running an event or know one I have missed, send it through the submission form at the bottom of every issue and it will reach me for the next one. Replies to this email come straight to me too.
>
> See you [send day].
>
> [sign-off]

---

## Failure modes

**Writing it in the organization's voice.** "Climate Tech [City] is pleased to welcome you to our community" is not the voice of the newsletter they are about to receive.

**Listing the sections of the newsletter.** They will see it in a week. Describing the blocks reads as a product tour.

**No submission route.** This is where a chapter's inbound events start, and leaving it out means they never start. Name the form, not just replies, because only the form reaches the harvest.

**Promising "every week without fail".** See above. Say most [send day]s.
