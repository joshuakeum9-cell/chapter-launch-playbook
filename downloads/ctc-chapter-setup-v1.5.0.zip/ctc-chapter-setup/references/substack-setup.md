# Ask for your Substack, then set up what is yours

Walk the lead through this when they reach the newsletter step of their plan, or when they ask how to set up Substack. Not during setup; `SKILL.md` says when each reference arrives and why.

Read their settings file first and fill in the answers they already gave. They should never be asked twice for their chapter name, their sender name, their send day, or their sign-off.

**The lead does not create the publication.** The Climate Tech Cities founders create every chapter's Substack centrally, once the logo is approved. That keeps the naming, the web address, and the network settings consistent across chapters. The lead's job is to ask for it, then configure the parts that are theirs.

---

## Part 1. Ask for your Substack

Give this as a short list, one screen.

**What to send the founders,** in one message, once the logo is approved:

1. The approved logo, as SVG and transparent PNG.
2. The chapter name, exactly as in the settings file: `Climate Tech [City]`.
3. The lead's own name, which becomes the sender name.
4. The web address preference from the settings file. Two patterns exist across chapters, a `climatetechcities.com` subdomain and a `substack.com` address, and there is no published rule about which a new chapter takes. The founders settle it when they create the publication, so send the preference and let them decide.

**What comes back:** the publication, already named and carrying the logo, and a login for the lead. When it arrives, the lead writes the Substack URL into section 3 of their settings file and adds the file to their project again.

Do not let the lead create a publication themselves while they wait. A second publication with the same name is the one thing here that cannot be tidied up quietly.

---

## Part 2. Set up what is yours

Once the login arrives, five things belong to the lead. Give them as a list they can tick.

**1. Sender name.** Set it to the lead's own name, not the chapter name. Email from a person is opened more often than email from an organization. Leads often get this wrong because the chapter name feels more official, and it costs opens every single week, invisibly.

**2. Welcome email.** See `references/welcome-email.md`. Substack sends it automatically to every new subscriber, so it is the first thing a reader ever sees from the chapter. Skipping it means new subscribers get silence until the next issue.

**3. One-line description.** The chapter one-liners on the Climate Tech Cities site are the model: short, place-based, and specific about who it is for.

**4. Pledges off.** Subscription pledges default to on and invite readers to pay for something that is free.

**5. Recommendations off.** Recommendations default to on and send readers to publications nobody at Climate Tech Cities has vetted.

---

## What not to do here

**Do not import a list yet.** That is its own step with its own rules. See `references/list-building.md`.

**Do not set up paid subscriptions.** A new chapter has nothing to charge for and it complicates the list.

**Do not publish a test post to the live list.** Substack has a preview and it is enough.

**Do not change the publication name or web address.** Both were settled when the founders created it. Every chapter is `Climate Tech [City]`, and a changed address breaks every link other chapters have shared.

---

## Common failure modes

**Creating the publication themselves.** Usually out of eagerness while waiting for the founders. Two publications with one name, and the chapter looks unaffiliated from either.

**Sender name set to the chapter.** The most common one after the login arrives.

**Skipping the welcome email.** The single cheapest thing in the whole setup and the most commonly skipped.

**Leaving pledges on.** Readers get asked for money in the first week of a free newsletter.
