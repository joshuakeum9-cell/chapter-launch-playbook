# A complete run

One full run of this skill, from the first message to the delivered files. Denver, fictional lead, fictional answers.

**This is illustrative, not data.** The city, the person, and the notes are invented. Do not copy any of it into a real settings file. What it exists to calibrate is the length of your replies, the handling of a lead who is unsure, and the shape of the delivery message.

It demonstrates, in order: a city given with its state attached, a lead who does not know their send day, a lead who would rather send less often and is told why not, a scope rule that arrives too loose and has to be worked, a lead who asks a question back that has no answer, a default accepted, and an optional question that produces something worth recording.

---

## The transcript

> **Claude:** I will set up your chapter. Nine quick questions, the last one optional, then I will hand you your settings file and a plan with your actual dates on it.
>
> First one: which city is your chapter in?

> **Lead:** Denver, Colorado

> **Claude:** Climate Tech Denver it is. What is your name? It goes on every issue as the sender, since email from a person gets opened more often than email from an organization.

> **Lead:** Priya Raman

> **Claude:** Got it. Which day of the week do you want to send? Pick one and never move it, because readers learn the rhythm.

> **Lead:** no idea honestly, does it matter which one

> **Claude:** Only that it stays the same. Most events fall Wednesday to Saturday, so a Tuesday or Wednesday send gives people time to plan. Want Tuesday, or would you rather pick?

> **Lead:** let's do Thursday, I have more time Thursday mornings

> **Claude:** Thursday it is. Every chapter sends weekly, which is the Climate Tech Cities standard, so I will write down weekly. If Denver turns out not to have enough events for a weekly issue, the newsletter cycle will offer every two weeks after your first few harvests. Fine to go with weekly?

> **Lead:** honestly every two weeks sounds more realistic for me, I have a day job

> **Claude:** Understood, and weekly is still what I will write down, because cadence follows how many events Denver produces rather than your calendar. If the first harvests come back thin, the newsletter cycle will offer every two weeks then, and the plan covers missed weeks in the meantime.

> **Lead:** ok fair

> **Claude:** Which events count as local for your chapter? Most chapters use the city plus anywhere a subscriber would travel on a weeknight, which usually means a few neighboring towns. New York counts Hoboken and Jersey City, for example.

> **Lead:** the metro area basically

> **Claude:** That works, but it needs to be specific enough to settle a real case. Boulder is 30 miles out. In or out?

> **Lead:** in for sure. Boulder, Golden, Aurora. not Colorado Springs or Fort Collins, those are their own thing

> **Claude:** So: Denver, Boulder, Golden, and Aurora, plus anywhere else a subscriber would travel to on a weeknight. Sound right?

> **Lead:** yep

> **Claude:** Your newsletter needs a web address. Chapters currently use two patterns:
>
> denver.climatetechcities.com
> denverclimatetech.substack.com
>
> There is no published rule about which one a new chapter takes. The Climate Tech Cities founders settle it when they create your publication, so what I write down now is your preference. Which would you like?

> **Lead:** which one should I use?

> **Claude:** I cannot tell you, and I would rather say so than guess. Four chapters are on the subdomain and six are on substack.com, and no rule has been published about which a new chapter takes. Pick whichever you prefer for now, and I will flag it in your settings file as a preference the founders confirm.

> **Lead:** substack one then

> **Claude:** Noted and flagged. How do you want to close each issue? The default is "Priya and the Climate Tech Denver team".

> **Lead:** that's fine

> **Claude:** You are in Mountain Time, I assume?

> **Lead:** yes

> **Claude:** Last one, and it is optional. Anything unusual about Denver that a tool should know? A second cluster somewhere, a university that dominates, a season when everything stops.

> **Lead:** most stuff is in RiNo and downtown. Boulder has its own separate scene, like 30 min away. and the university calendar drives a lot in fall, July is dead

> **Claude:** Useful. Building your files now.

Fifteen Claude turns for nine questions, counting the follow-ups and the closing line. Every reply between questions is one or two sentences; only the question wording itself runs longer. Two turns push back: the cadence turn holds weekly and says why in one line, and the scope rule turn pushes once with a concrete case rather than explaining why the rule matters. Neither asks for an email address, because no question does.

---

## The data file

```json
{
  "city": "Denver",
  "chapterName": "Climate Tech Denver",
  "leadName": "Priya Raman",
  "timezone": "America/Denver",
  "startDate": "2026-08-11",
  "sendDay": "Thursday",
  "cadence": "weekly",
  "scopeRule": "Denver, Boulder, Golden, and Aurora, plus anywhere else a subscriber would travel to on a weeknight.",
  "webAddress": "denverclimatetech.substack.com",
  "webAddressConfirmed": false,
  "signOff": "Priya and the Climate Tech Denver team",
  "cityNotes": "Most events happen in RiNo and downtown. Boulder has its own separate meetup scene about 30 minutes away. The university calendar drives a lot of the fall and it goes quiet in July."
}
```

Note what happened to the raw answers. `Denver, Colorado` lost its state. The sign-off uses `Priya`, not `Priya Raman`. The timezone became IANA form even though the lead said "Mountain Time". The cadence is `weekly` even though the lead asked for every two weeks, because being busy is not a cadence reason, and their preference is not in `cityNotes` either, because the newsletter cycle will ask the volume question itself. The city notes keep the lead's own observations rather than being tidied into corporate phrasing, because a downstream skill reading "July is dead" gets more from it than from "seasonal variance in event volume".

---

## Building

```bash
node scripts/build_chapter_docs.js chapter_data_denver.json
```

```
wrote /mnt/user-data/outputs/Chapter_Settings_Denver.docx
wrote /mnt/user-data/outputs/Chapter_Plan_Denver.docx

  chapter    Climate Tech Denver
  lead       Priya Raman
  send day   Thursday
  cadence    weekly
  starts     Tuesday, August 11, 2026
  first send Thursday, August 20, 2026
  day 14     Monday, August 24, 2026

  ! Web address is marked unconfirmed. The settings file flags it.
QA: data file passed. Open both documents before delivering.
```

Read that block rather than skipping it. The first send date is the one to sanity check, because it is computed rather than given: the script takes the start date, moves a week out, then finds the next matching weekday.

---

## What the two documents contain

**`Chapter_Settings_Denver.docx`.** A header with the chapter name, the creation date, and the skill version, then a short "how to use this file" block that tells the lead to add it to a Claude project as a context file. Then three numbered sections:

1. **Identity.** City, chapter name, chapter lead, timezone, started date, and the city notes if there are any.
2. **Newsletter.** Send day, Cadence, Scope rule, Grouping, Web address, Sender name, Sign-off, and Reporting, which names the four numbers the lead notes after each send: issues sent on schedule, subscriber count, open rate, and events received through the submission form that week. Below the table, if the web address is unconfirmed, a flagged note saying the founders settle it when they create the publication.
3. **To update later.** Three blank rows: Substack URL, Reply-to email, and Source list file. The lead fills them in when the publication exists and after `ctc-source-map` has run, then adds the file to their project again.

**`Chapter_Plan_Denver.docx`.** A two week plan, August 11 to August 24, with real dates. In order: a "before you start" list (project, context file, toolkit, Chrome extension, code execution); a schedule table with Week 1 (logo, then ask the founders for your Substack), Week 2 (source list, subscriber list, first issue), Ongoing (every Thursday), Monthly, Quarterly, and Later; then Week 1 in detail, with the logo made in ChatGPT from the launch site and sent to the founders for approval, and what to send the founders to get the Substack plus the parts the lead sets up themselves; Week 2 in detail, with the source list target of 25 to 30 verified sources, the subscriber list rules, and the first issue on Thursday August 20, including the line that every issue ends with the Join the Fun! block; the every-week table of the four steps, which describes ctc-assemble drafting the opening note, picks, and housekeeping for the lead to rewrite; every month; every quarter; once the newsletter is running; if you miss a week; and a files table.

For a chapter on every two weeks, the Ongoing row reads "Every other Thursday", the every-week section is headed "Every other week", and the Cadence row in the settings file reads "Every two weeks". Nothing else changes.

Both are fully generated. Nothing in them is written by hand at delivery time.

---

## The delivery message

> Two files.
>
> **Chapter_Settings_Denver.docx** holds your answers. **Create a project in Claude and add this file to it as a context file**, in project settings under add files. Not attached to a chat, which only lasts one conversation. Every other skill reads it from the project, so you never answer these questions again.
>
> **Chapter_Plan_Denver.docx** is your first two weeks with real dates. First issue lands Thursday, August 20.
>
> One thing this week: the logo. Open the chapter launch site, enter Denver, paste its prompt into ChatGPT with the five reference images, and send your pick to the founders for approval.
>
> Your web address is a preference for now. The founders settle it when they create your Substack.

116 words. One instruction in bold, one action named, one flag raised.

### What this replaced

> Congratulations on launching Climate Tech Denver! I have created two documents for you.
>
> The first is your chapter settings file, which contains all of the information you provided during our conversation, including your city, your name, your send day of Thursday and weekly cadence, your scope rule covering Denver, Boulder, Golden and Aurora, your preferred web address, your sign-off, and your timezone. It also contains a section for things to fill in later, such as your Substack URL, reply-to email, and source list file, once those exist.
>
> The second is your two week plan, which walks you through the logo and asking for your Substack in week one, then your source list, subscriber list, and first issue in week two, followed by the ongoing weekly cycle of harvest, cut, draft and send, the monthly opportunities run, the quarterly source refresh, and partner outreach once the newsletter is running...

That version is not wrong. It is a summary of two documents the lead is holding, and it buries the context file instruction in the middle of a paragraph. The lead reads the message instead of the plan, and the plan is better.
