#!/usr/bin/env node
/**
 * Build the two chapter setup documents from a chapter data file.
 *
 *   node build_chapter_docs.js chapter_data_<city>.json
 *
 * Writes to /mnt/user-data/outputs/:
 *   Chapter_Settings_<City>.docx   the settings file, added to the Claude project as a context file.
 *                                  Three sections: 1. Identity, 2. Newsletter, 3. To update later.
 *   Chapter_Plan_<City>.docx       the two week launch plan, with real dates
 *
 * Both are Word documents on US Letter. No em dashes anywhere.
 * cadence must be exactly "weekly" or "every two weeks". Weekly is the CTC standard.
 */

const fs = require('fs');
const path = require('path');

let docxLib;
try {
  docxLib = require('docx');
} catch (e) {
  console.error('The "docx" package is not available in this environment.');
  console.error('Install it and rerun:  npm install docx');
  console.error('If npm is unavailable, code execution may be switched off for this account.');
  process.exit(1);
}

const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  LevelFormat, PageOrientation,
} = docxLib;

const OUT_DIR = '/mnt/user-data/outputs';
const TEAL = '0F6E6E';
const LIGHT = 'DCE6F1';
const HEAD = 'D9E2E1';
const GREY = '555555';

const LETTER = { size: { width: 12240, height: 15840 } };
const MARGIN = { top: 1080, right: 1080, bottom: 1080, left: 1080 };

const VERSION = 'v1.5.0';
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const CADENCES = ['weekly', 'every two weeks'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December'];

// ---------------------------------------------------------------- helpers

function parseDate(s) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

function addDays(date, n) {
  const d = new Date(date.getTime());
  d.setUTCDate(d.getUTCDate() + n);
  return d;
}

function fmt(date) {
  return `${MONTHS[date.getUTCMonth()]} ${date.getUTCDate()}`;
}

function fmtLong(date) {
  return `${DAYS[date.getUTCDay()]}, ${MONTHS[date.getUTCMonth()]} ${date.getUTCDate()}, ${date.getUTCFullYear()}`;
}

/** Inclusive range label for the 7 days beginning at `date`. */
function weekRange(date) {
  return `${fmt(date)} to ${fmt(addDays(date, 6))}`;
}

/** "every Thursday" or "every other Thursday", depending on cadence. */
function everyLabel(d) {
  return d.cadence === 'every two weeks' ? `every other ${d.sendDay}` : `every ${d.sendDay}`;
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** First send day falling on or after day 8, so week 1 is clear. */
function firstSendDay(start, sendDay) {
  const target = DAYS.indexOf(sendDay);
  if (target < 0) return addDays(start, 13);
  let d = addDays(start, 7);
  while (d.getUTCDay() !== target) d = addDays(d, 1);
  return d;
}

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { after: opts.after === undefined ? 120 : opts.after },
    alignment: opts.align,
    children: [new TextRun({
      text,
      bold: opts.bold,
      italics: opts.italics,
      size: opts.size || 21,
      color: opts.color,
      font: 'Calibri',
    })],
  });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 320, after: 160 },
    children: [new TextRun({ text, bold: true, size: 30, color: TEAL, font: 'Calibri' })],
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 260, after: 120 },
    children: [new TextRun({ text, bold: true, size: 24, color: TEAL, font: 'Calibri' })],
  });
}

function bullet(text) {
  return new Paragraph({
    numbering: { reference: 'ctc-bullets', level: 0 },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 21, font: 'Calibri' })],
  });
}

function cell(text, { bold, shade, width, italics, color } = {}) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: shade ? { type: ShadingType.CLEAR, fill: shade, color: 'auto' } : undefined,
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    children: [new Paragraph({
      spacing: { after: 0 },
      children: [new TextRun({
        text: text === null || text === undefined ? '' : String(text),
        bold, italics, size: 20, color, font: 'Calibri',
      })],
    })],
  });
}

function table(widths, rows) {
  const total = widths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({
      tableHeader: i === 0,
      children: r.map((c, j) => cell(c, {
        width: widths[j],
        bold: i === 0,
        shade: i === 0 ? HEAD : LIGHT,
      })),
    })),
  });
}

/** Two-column settings block: label, value. */
function settings(pairs) {
  return table([2600, 6400], [['Setting', 'Value'], ...pairs]);
}

function scaffold(text) {
  return new Paragraph({
    spacing: { after: 120 },
    border: { left: { style: BorderStyle.SINGLE, size: 12, color: TEAL, space: 8 } },
    indent: { left: 160 },
    children: [new TextRun({ text, italics: true, size: 20, color: GREY, font: 'Calibri' })],
  });
}

const NUMBERING = {
  config: [{
    reference: 'ctc-bullets',
    levels: [{
      level: 0,
      format: LevelFormat.BULLET,
      text: '\u2022',
      alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 420, hanging: 220 } } },
    }],
  }],
};

function doc(children) {
  return new Document({
    numbering: NUMBERING,
    sections: [{
      properties: { page: { size: LETTER.size, orientation: PageOrientation.PORTRAIT, margin: MARGIN } },
      children,
    }],
  });
}

// ---------------------------------------------------------------- validate

function validate(d) {
  const required = ['city', 'chapterName', 'leadName', 'timezone',
    'startDate', 'sendDay', 'cadence', 'scopeRule', 'webAddress', 'signOff'];
  const errs = [];
  for (const k of required) {
    if (!d[k] || !String(d[k]).trim()) errs.push(`missing required field: ${k}`);
  }
  if (d.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(d.startDate)) {
    errs.push('startDate must be YYYY-MM-DD');
  }
  if (d.sendDay && !DAYS.includes(d.sendDay)) {
    errs.push(`sendDay must be one of: ${DAYS.join(', ')}`);
  }
  if (d.cadence && !CADENCES.includes(d.cadence)) {
    errs.push(`cadence must be exactly "weekly" or "every two weeks" (weekly is the CTC standard); got "${d.cadence}"`);
  }
  const blob = Object.values(d).filter(v => typeof v === 'string').join(' ');
  if (blob.includes('\u2014') || blob.includes('\u2013')) {
    errs.push('em dash or en dash found in the data file');
  }
  return errs;
}

// ---------------------------------------------------------------- settings

function buildSettings(d) {
  const kids = [];

  kids.push(new Paragraph({
    spacing: { after: 60 },
    children: [new TextRun({ text: `${d.chapterName}`, bold: true, size: 36, color: TEAL, font: 'Calibri' })],
  }));
  kids.push(p('Chapter settings', { size: 24, color: GREY, after: 40 }));
  kids.push(p(`Created ${fmtLong(parseDate(d.startDate))}  ·  ctc-chapter-setup ${VERSION}`,
    { size: 18, color: GREY, italics: true, after: 200 }));

  kids.push(p('HOW TO USE THIS FILE', { bold: true, size: 19, color: TEAL, after: 60 }));
  kids.push(bullet('Create a project in Claude.'));
  kids.push(bullet('Open the project settings and add this file as a context file.'));
  kids.push(bullet('Do not attach it to a chat. A file attached to one conversation is not available in the next one.'));
  kids.push(p(''));
  kids.push(scaffold('Every skill in the toolkit reads this file from the project. Nothing else works until it is added.'));
  kids.push(p('', { after: 120 }));

  kids.push(h1('1. Identity'));
  kids.push(settings([
    ['City', d.city],
    ['Chapter name', d.chapterName],
    ['Chapter lead', d.leadName],
    ['Timezone', d.timezone],
    ['Started', fmtLong(parseDate(d.startDate))],
  ]));
  if (d.cityNotes && d.cityNotes.trim()) {
    kids.push(p(''));
    kids.push(p('Notes on this city', { bold: true, after: 60 }));
    kids.push(p(d.cityNotes));
  }

  kids.push(h1('2. Newsletter'));
  kids.push(settings([
    ['Send day', d.sendDay],
    ['Cadence', capitalize(d.cadence)],
    ['Scope rule', d.scopeRule],
    ['Grouping', 'Day headers for this week. Flat chronological for upcoming. No topic categories.'],
    ['Web address', d.webAddress],
    ['Sender name', d.leadName],
    ['Sign-off', d.signOff],
    ['Reporting', 'After each send, note four numbers: issues sent on schedule, subscriber count, open rate, and events received through the submission form that week.'],
  ]));

  if (!d.webAddressConfirmed) {
    kids.push(p(''));
    kids.push(scaffold('This web address is your preference, not yet confirmed. The Climate Tech Cities founders settle it when they create your publication. Two patterns are in use across chapters and there is no published rule. Changing it later breaks links other chapters have shared.'));
  }

  kids.push(h1('3. To update later'));
  kids.push(p('Edit this file and add it to your project again when any of these change. The source list file is named by ctc-source-map when you run it.', { after: 140 }));
  kids.push(settings([
    ['Substack URL', ''],
    ['Reply-to email', ''],
    ['Source list file', ''],
  ]));

  return doc(kids);
}

// ---------------------------------------------------------------- plan

function buildPlan(d) {
  const start = parseDate(d.startDate);
  const w1 = start;
  const w2 = addDays(start, 7);
  const send1 = firstSendDay(start, d.sendDay);
  const day14 = addDays(start, 13);
  const kids = [];

  kids.push(new Paragraph({
    spacing: { after: 60 },
    children: [new TextRun({ text: `${d.chapterName}`, bold: true, size: 36, color: TEAL, font: 'Calibri' })],
  }));
  kids.push(p('Launch plan', { size: 24, color: GREY, after: 40 }));
  kids.push(p(`${fmtLong(start)} to ${fmtLong(day14)}`, { size: 18, color: GREY, italics: true, after: 220 }));

  kids.push(h2('Before you start'));
  kids.push(bullet('Create a project in Claude.'));
  kids.push(bullet(`Add Chapter_Settings_${d.city}.docx to that project as a context file. Every skill reads it from there.`));
  kids.push(bullet('Install the toolkit: ctc-chapter-setup, ctc-newsletter, ctc-partner-map.'));
  kids.push(bullet('Install the Claude Chrome extension. Some event sites require it.'));
  kids.push(bullet('Turn on code execution in Settings, Capabilities.'));
  kids.push(p(''));
  kids.push(scaffold('Add the settings file to the project, not to a single conversation. A file attached to one conversation is not available in the next one.'));

  kids.push(h2('Schedule'));
  kids.push(table([1300, 2200, 4500], [
    ['', 'When', 'What'],
    ['Week 1', weekRange(w1), 'Logo, then ask the founders for your Substack.'],
    ['Week 2', weekRange(w2), 'Source list, subscriber list, first issue.'],
    ['Ongoing', capitalize(everyLabel(d)), 'Harvest, cut, draft, send.'],
    ['Monthly', 'First week of the month', 'Run ctc-opportunities.'],
    ['Quarterly', 'Once every three months', 'Re-run ctc-source-map.'],
    ['Later', 'Once the newsletter is running', 'Run ctc-partner-map.'],
  ]));

  kids.push(h1('Week 1'));
  kids.push(p(weekRange(w1), { italics: true, color: GREY, after: 140 }));

  kids.push(h2('Logo'));
  kids.push(bullet('Open the chapter launch site and enter your city. The logo prompt fills in.'));
  kids.push(bullet('Paste the prompt into ChatGPT with the five reference images attached. Ask for ten concepts.'));
  kids.push(bullet('Review the concepts at icon size.'));
  kids.push(bullet('Send your chosen concept to the Climate Tech Cities founders and wait for approval.'));
  kids.push(bullet('Export SVG and transparent PNG at three sizes.'));
  kids.push(p(''));
  kids.push(scaffold('Do not publish the logo anywhere until it is approved.'));

  kids.push(h2('Substack'));
  kids.push(bullet(`Once the logo is approved, send the Climate Tech Cities founders four things: the approved logo, the chapter name (${d.chapterName}), your name (${d.leadName}), and your web address preference (${d.webAddress}).`));
  kids.push(bullet('They create the publication and send you the publication and your login. You do not create it yourself.'));
  kids.push(bullet(`Set the sender name to ${d.leadName}.`));
  kids.push(bullet('Write the welcome email. Substack sends it to every new subscriber.'));
  kids.push(bullet('Add the one-line description, and turn off pledges and recommendations.'));
  kids.push(p(''));
  kids.push(scaffold('For any of these steps, ask Claude in your project: "walk me through Substack setup", "draft my welcome email", "how do I build my list". Each reads your settings file.'));

  kids.push(h1('Week 2'));
  kids.push(p(weekRange(w2), { italics: true, color: GREY, after: 140 }));

  kids.push(h2('Source list'));
  kids.push(bullet('Run ctc-source-map.'));
  kids.push(bullet('It offers three options: paste your own calendar links, paste some and let it research the rest, or let it research everything.'));
  kids.push(bullet('Review the source list it returns and add anything it missed.'));
  kids.push(bullet('Target 25 to 30 verified sources.'));
  kids.push(bullet('Add the file it makes to your project as a context file, and write its name under Source list file in section 3 of your settings file.'));
  kids.push(bullet('Re-run it once every three months. Refreshing the sources is a quarterly task, not a monthly one.'));

  kids.push(h2('Subscriber list'));
  kids.push(bullet('Add only people who gave you their email where a newsletter was implied: event RSVPs, sign-up forms, direct requests.'));
  kids.push(bullet('Do not import conference lists, scraped lists, or contacts who have not been asked.'));
  kids.push(bullet('Ask your own network individually.'));

  kids.push(h2('First issue'));
  kids.push(p(fmtLong(send1), { italics: true, color: GREY, after: 140 }));
  kids.push(bullet('Say "run the newsletter" in your project.'));
  kids.push(bullet('In the opening note, say what the chapter is, who runs it, when it arrives, and how to submit an event.'));
  kids.push(bullet('A new chapter runs 8 to 15 events an issue.'));
  kids.push(bullet('Every issue ends with the Join the Fun! block, which links the Climate Tech Cities event submission form and the volunteer form. Readers submit events through that form and the harvest picks them up.'));

  kids.push(h1(d.cadence === 'every two weeks' ? 'Every other week' : 'Every week'));
  kids.push(p(`The issue goes out ${everyLabel(d)}. Run the four steps in one sitting or spread them across the week.`, { after: 140 }));
  kids.push(table([1700, 6300], [
    ['Step', 'What happens'],
    ['Harvest', 'ctc-harvest sweeps your sources and the submission form into a spreadsheet.'],
    ['Cut', 'You delete rows and flag your picks.'],
    ['Draft', 'ctc-assemble builds all ten blocks. The opening note, the picks, and the housekeeping arrive drafted, each with a yellow line above it. You rewrite those three in your own words and delete the yellow lines.'],
    ['Send', 'Check the issue, paste into Substack, send. Then note the four reporting numbers listed in your settings file.'],
  ]));
  kids.push(p(''));
  kids.push(p('Say "run the newsletter" and the toolkit sequences these and stops where your input is needed.', { after: 160 }));

  kids.push(h1('Every month'));
  kids.push(bullet('In the first week of the month, run ctc-opportunities.'));
  kids.push(bullet(`Add Opportunities_${d.city}.xlsx to your project as a context file, replacing the previous version.`));
  kids.push(bullet('ctc-assemble reads it for every issue, so the opportunities block has something in it all month.'));

  kids.push(h1('Every quarter'));
  kids.push(bullet('Re-run ctc-source-map once every three months. Not monthly.'));
  kids.push(bullet('Sources die quietly. The quarterly refresh is what catches a dead calendar before it thins out an issue.'));
  kids.push(bullet('Nothing else in the toolkit runs on a quarterly cadence.'));

  kids.push(h1('Once the newsletter is running'));
  kids.push(bullet('Run ctc-partner-map. It researches your city, tiers the organizations to approach, and drafts outreach messages.'));
  kids.push(bullet('Work the Tier 1 list first.'));

  kids.push(h1('If you miss a week'));
  kids.push(bullet('Send the next issue on your usual send day.'));
  kids.push(bullet('Do not include an apology or an explanation.'));
  kids.push(bullet('The target is weeks covered over a quarter, not consecutive weeks.'));
  kids.push(bullet('A missed week is not a reason to change your cadence. The newsletter cycle revisits cadence after your first few harvests, based on how many events your city produces.'));

  kids.push(h1('Files'));
  kids.push(p('Three of these go in your Claude project as context files.', { after: 140 }));
  kids.push(table([3000, 5000], [
    ['File', 'What it is'],
    [`Chapter_Settings_${d.city}.docx`, 'Your settings. Add to the project as a context file.'],
    ['Your source list', 'Created by ctc-source-map, which tells you the file name. Add to the project as a context file.'],
    [`Opportunities_${d.city}.xlsx`, 'Created monthly by ctc-opportunities. Add to the project as a context file.'],
    [`Chapter_Plan_${d.city}.docx`, 'This document. For reference, not needed in the project.'],
  ]));

  return doc(kids);
}

// ---------------------------------------------------------------- main

async function main() {
  const src = process.argv[2];
  if (!src) {
    console.error('usage: node build_chapter_docs.js chapter_data_<city>.json');
    process.exit(1);
  }
  const d = JSON.parse(fs.readFileSync(src, 'utf8'));

  const errs = validate(d);
  if (errs.length) {
    console.error('DATA FILE FAILURES, fix before building:');
    errs.forEach(e => console.error('  X ' + e));
    process.exit(1);
  }

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const safe = d.city.replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, '');

  const a = path.join(OUT_DIR, `Chapter_Settings_${safe}.docx`);
  const b = path.join(OUT_DIR, `Chapter_Plan_${safe}.docx`);

  fs.writeFileSync(a, await Packer.toBuffer(buildSettings(d)));
  fs.writeFileSync(b, await Packer.toBuffer(buildPlan(d)));

  const start = parseDate(d.startDate);
  console.log(`wrote ${a}`);
  console.log(`wrote ${b}`);
  console.log('');
  console.log(`  chapter    ${d.chapterName}`);
  console.log(`  lead       ${d.leadName}`);
  console.log(`  send day   ${d.sendDay}`);
  console.log(`  cadence    ${d.cadence}`);
  console.log(`  starts     ${fmtLong(start)}`);
  console.log(`  first send ${fmtLong(firstSendDay(start, d.sendDay))}`);
  console.log(`  day 14     ${fmtLong(addDays(start, 13))}`);
  console.log('');
  if (!d.webAddressConfirmed) {
    console.log('  ! Web address is marked unconfirmed. The settings file flags it.');
  }
  console.log('QA: data file passed. Open both documents before delivering.');
  console.log('');
  console.log('SAY THIS WHEN YOU DELIVER, do not shorten it to "upload this":');
  console.log(`  Create a project in Claude, then add Chapter_Settings_${safe}.docx to that`);
  console.log('  project as a context file, in project settings under add files. Not attached');
  console.log('  to a chat. Every skill in the toolkit reads it from there.');
}

main().catch(e => { console.error(e); process.exit(1); });
