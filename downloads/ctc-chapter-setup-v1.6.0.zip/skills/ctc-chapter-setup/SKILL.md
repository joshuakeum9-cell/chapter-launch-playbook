---
name: "ctc-chapter-setup"
description: "Set up a new Climate Tech Cities chapter. Asks eight plain questions in one message, then produces their chapter settings file and a two week launch plan with their real dates in it. Use this skill whenever someone is starting a new CTC chapter, says they have just been approved to lead one, asks \"how do I start my chapter\" or \"what do I do first\", wants their chapter settings or city settings file created, wants a launch plan for a city, or has installed the CTC toolkit and does not know what to run first. Always use it even if they only ask for the settings file or only for the plan. Do NOT use it to research event sources, which is ctc-source-map, or to collect this week's events, which is ctc-harvest."
---

# CTC Chapter Setup

The first thing a new chapter lead runs. Ask eight questions in one message, produce two Word documents.

This is the only skill in the toolkit whose user is definitionally a beginner. They may have been approved yesterday, they may never have used Claude, and they have nine other skills installed with no idea what to do with them. This skill is the answer to "okay, now what."

## What this is for

Climate Tech Cities is a network of volunteer-run city chapters. Each chapter publishes a weekly climate events newsletter on Substack. The failure that matters is not a bad issue. It is a chapter that stops sending: the flagship New York newsletter went silent for 216 days in 2025, and covering roughly 37 percent of that year's weeks is the pattern this whole toolkit exists to prevent.

Every rule below bends toward one outcome, which is a lead who reaches their first issue quickly and survives their first missed week. That is why every question has a default, why nothing blocks, why the first issue is described as small on purpose, and why the plan carries a section about missing weeks before the lead has missed one.

The two documents have different readers and need different things.

**The settings file is read by software.** The lead adds it to their Claude project as a **context file** once, and every other CTC skill reads it from there instead of asking. It has to be unambiguous and complete rather than persuasive. Each field exists because a downstream skill would otherwise interrogate the lead about it every week.

**The plan is read by a person, once, in the first ten minutes of their chapter.** Probably on a phone. Then referred back weekly. It answers two questions and no others: what do I do this week, and is what I am seeing normal. It is not a strategy document and should never grow into one.

The plan is the short version of the chapter launch playbook, `https://joshuakeum9-cell.github.io/chapter-launch-playbook/`, which is the lead's actual manual. The plan adds the lead's real dates and points at the playbook for anything longer than a sentence; it does not restate the playbook.

**The plan separates steps from advice, and the lead can tell which is which.** Bulleted lines are steps the toolkit or the Climate Tech Cities team depends on: a file that has to be in the project, a skill to run, a sign-off to get. The grey notes are advice the lead can take or leave. Anything a competent adult would work out for themselves (how to grow a list, how to judge a logo, what to say in a first issue) is either a grey note or not in the plan at all. A plan that gives orders about things the lead can judge reads as micromanagement and gets ignored along with the parts that matter.

## The bar

Someone who has never used Claude finishes this in a single exchange, understands what happens next, and never has to answer any of these questions again.

## Read this first

| File | What it holds | When to read it |
|---|---|---|
| `references/interview.md` | The exact question wording, the defaults, and how to turn a loose answer into a clean field | Before asking anything |
| `references/worked-example.md` | A complete run end to end: the one-message interview, the reply, the filled data file, the real build output, and the delivery message. Use it for tone, wording, and how to handle a lead who answers loosely | Before your first run |
| `references/plan-notes.md` | Where every number in the plan comes from, and which are measured versus estimated. It covers only figures that are actually in the current two week plan | When the lead asks why the plan says something |
| `references/substack-setup.md` | The seven-step Substack checklist and what not to do | When the lead reaches the newsletter step, or asks how to set up Substack. Not during setup |
| `references/welcome-email.md` | What the welcome email has to do, its length and voice, and a shape to adapt | When the lead asks for the welcome email |
| `references/list-building.md` | Which sources qualify as consent, which do not, and the GDPR rules for UK and EU chapters | When the lead asks how to build the list, or mentions importing one |

The last three arrive in week 1 or 2, not on day one. Do not deliver them during setup. A lead who has just answered eight questions cannot act on six more decisions, and a checklist given early is a checklist forgotten. They are surfaced by the plan, which tells the lead the phrase to ask.

`scripts/build_chapter_docs.js` renders both documents. `scripts/chapter_data_TEMPLATE.json` is the data file to fill in. Do not hand-roll docx generation.

---

## Before you start: check the environment

The skill needs a code execution sandbox with Node and the `docx` package. On a Claude account where code execution is switched off, nothing here works, and the failure looks like a tool that is simply missing rather than an error.

Run this first:

```bash
node -e "require('docx'); console.log('ok')"
```

| Result | What to do |
|---|---|
| Prints `ok` | Proceed |
| `Cannot find module 'docx'` | `npm install docx` in the working directory, then retry |
| No code execution tool available at all | Stop before asking anything. Tell the lead to switch on code execution in Claude Settings under Capabilities, then run the skill again. Do not ask the questions and then discover you cannot build the files |

The script writes to `/mnt/user-data/outputs/` and creates the directory if it is absent. Network access is not required at any point.

---

## Step 1. Orient them, then ask everything at once

Open with two sentences, then the whole set of questions in the same message. Something close to:

> I will set up your chapter. Eight quick questions below, then I will hand you your settings file and a plan with your actual dates on it.
>
> Answer as many as you can in one go. Skip anything you are unsure about and I will take a sensible default and tell you which ones I filled in.
>
> 1. [question]
> 2. [question]
> ...

Do not explain the toolkit, do not list the other skills, and do not describe what a settings file is before they have one. Both of those land better after the documents exist.

## Step 2. Ask the eight questions in one message

Take the question wording, the defaults, the examples and the weak-versus-strong rules from `references/interview.md`. That file remains the single source of the wording. Do not restate or paraphrase the questions here, and do not invent new ones.

**Take the wording from that file.** Ask all eight together as one numbered list. Everything in `references/interview.md` applies in full: the wording, the defaults, the reasoning lines, the weak-versus-strong tables, and the rules for cleaning up a loose answer. `references/worked-example.md` shows the whole thing run once.

Shape of the message:

- One numbered list, eight items, each question in the wording from `references/interview.md`.
- Each question carries its default inline and briefly, so nobody has to ask what happens if they skip one. A wall without defaults is worse than a sequence, because a lead who does not know an answer has nothing to fall back on and nobody prompting them. The one exception is the web address, which has no default because the house rule below forbids picking it; the message says so.
- Question 4, the scope rule, keeps its concrete example and its ready-made answer. It is the question most likely to stall someone and the field that does the most work downstream, so it earns the extra line even in a list.
- Question 8 is marked optional.
- None of the words the house rule below bans. Say "your settings file."

Keep the whole message scannable. A lead reading on a phone should be able to answer it in one reply.

Then wait for that one reply and take whatever comes back:

- **They answer all eight.** Build.
- **They answer some.** Take those, apply the defaults from `references/interview.md` for the rest, and name the defaulted ones in one line at delivery so they can correct you. Do not re-ask the missing ones individually.
- **They answer none, or say "you decide".** Take every default, build, and mark them to confirm.
- **An answer is unusable.** A scope rule given as a list of towns, a metro name or abbreviation instead of a city name, a full name where a first name belongs: fix it yourself per `references/interview.md` and read the corrected version back for confirmation. One short follow-up message maximum, carrying every correction and every gap at once.

**Never send a second round of questions one at a time.** If something is still missing after one follow-up, take the default, flag it, and build. A chapter that never finishes setup never sends.

One case stops the questions going out at all: if they have named a city that already has a running chapter, settle that first and wait, per the judgment call below.

## Step 3. Build the data file

Work from the skill's own directory, so that `scripts/` resolves. Copy `scripts/chapter_data_TEMPLATE.json` to `chapter_data_<city>.json` in that directory and fill it from their answers.

- `startDate` is today, in `YYYY-MM-DD`.
- `chapterName` is always `Climate Tech <City>`.
- `webAddressConfirmed` is `false` unless the lead says the Climate Tech Cities team has already confirmed it.
- `cityNotes` may be an empty string.
- No em dashes anywhere.

Three fields are written by you rather than pasted from the lead: `chapterName`, `scopeRule`, and `signOff`. `references/interview.md` has the rules and the weak-versus-strong examples for each. A loose scope rule is the most common way this output degrades, because every downstream skill filters against that one sentence.

## Step 4. Render

```bash
node scripts/build_chapter_docs.js chapter_data_<city>.json
```

The script validates the data file before building and refuses to run if a required field is blank, the date is malformed, the send day is not a real weekday, or an em dash is present. Read its output rather than assuming it passed.

Then open both documents before delivering. The validator checks the data, not the result.

## Step 5. Deliver, then tell them one thing to do

Call `present_files` on both documents. Then, briefly:

1. What each file is, in one line each.
2. Any answer you defaulted rather than took from them, named in one line so they can correct it.
3. **Tell them to add the settings file to a Claude project as a context file.** This is the only instruction that matters right now, because nothing else in the toolkit works until they do it. Say it in close to these words, and do not shorten it to "upload it":

   > Create a project in Claude, then add `Chapter_Settings_<City>.docx` to that project as a **context file**. Project settings, then add files. Not attached to a chat: a file attached to one conversation is not available in the next one, and every skill in the toolkit reads this file.

   **Never say only "upload this."** A lead who reads that will attach it to the current conversation, it will work once, and then every skill will interrogate them from scratch next week. Name the project and name the words "context file".

   Do not list the other two context files here. They do not exist yet, the plan's Files section covers them, and naming three files on day one buries the one that matters.
4. The one thing to do this week, named from the plan. For almost everyone that is the Logo step in Week 1: open the Logo step on the chapter launch playbook, which has the prompt and the reference images.

   Name it as a step in their plan, not as a skill to run. **There is no logo skill in this toolkit.** The logo is a manual step: the plan gives the three-line version and the playbook has the full walkthrough. Do not write the procedure out a third time.

If the web address is unconfirmed, say so in one line as part of the delivery.

The whole message runs under 120 words. `references/worked-example.md` has one written out, with the padded version it replaced. Then stop. Do not summarize the plan they can read, do not list the remaining skills, and do not restate the method.

---

## House rules

**All eight questions in one message.** One numbered list, one reply, then build. At most one short follow-up, carrying every correction and every gap at once.

**Every question carries its default, except the web address.** The default is what makes a single message safe to send. Without it, a wall is just a form. The web address is the one question with no default, because picking it is a one-way door; if it comes back blank, it goes in the single follow-up.

**Plain words only.** "Your settings file." Never config, registry, schema, parameter, YAML, field, or populate.

**Never block on an answer they cannot give.** Record the default, mark it to confirm, keep moving.

**Never pick their web address.** Four Climate Tech Cities chapters use a `climatetechcities.com` subdomain and six use a `substack.com` address. No rule has been published about which a new chapter takes, so record their preference, flag it, and tell them to confirm with the Climate Tech Cities team before publishing. It is a one-way door once other chapters link to it.

**Never assume internal access.** This toolkit is used by volunteers outside the organization. Do not reference internal folders, Slack channels, or individual staff members by name. Say "the Climate Tech Cities team."

**Three files end up in the project, and only one of them today.** `Chapter_Settings_<City>.docx` goes in now. `CTC_Source_Registry_<City>.xlsx` goes in when `ctc-source-map` hands it over in week 2, and the weekly harvest stops without it. `Opportunities_<City>.xlsx` goes in monthly, replacing the previous copy. The plan document does not go in the project. Say only the settings file at delivery; the plan's Files section carries the other two with the week each one arrives.

**Never add sections to the settings file.** It has exactly three: 1. Identity, 2. Newsletter, 3. To update later. Brand, sources, partners and events are not sections in it, and the skills that own that information keep it in their own files. Adding a section means two skills writing to one file and neither knowing it.

**Never invent a number.** Every figure in the plan is in `references/plan-notes.md` with its provenance, including which ones are working estimates rather than measurements. If asked something not covered there, say it is not documented rather than estimating. The plan deliberately carries no targets (no source count, no events-per-issue range): those were planning estimates that read as quotas, and the lead adjusts to their own city. If a lead asks for a benchmark, give the figure from `plan-notes.md` and label it as the estimate it is.

**Steps are bullets, advice is grey notes.** When editing `buildPlan`, a bullet is something the toolkit or the Climate Tech Cities team depends on. Everything else is a `scaffold()` note or is cut. Never add a bullet telling the lead how to do something they can judge themselves.

**The Climate Tech Cities team creates the Substack.** The lead sends the approved logo and the chapter name and receives the publication and a login. The plan and `references/substack-setup.md` both say so. Do not tell a lead to create the publication themselves.

---

## Judgment calls

Every one of these has come up or will. The ruling matters less than the reasoning, which is what lets you decide a case that is not listed.

| Situation | Ruling | Reasoning |
|---|---|---|
| The city already has a chapter: New York, Washington DC, Boston, Chicago, San Diego, Los Angeles, San Francisco, Seattle, London, Amsterdam | Ask before building. If they are restarting a chapter that has gone quiet, build normally. If the chapter is active, they need the existing lead, not a second settings file | Two settings files for one city means two people running the same newsletter and neither knowing it |
| They give a metro name or an abbreviation | Take the name the city is known by and read it back in the follow-up rather than spending a fresh question on it. `The Bay Area` becomes `San Francisco`, `NYC` becomes `New York` | The chapter name has to match across every chapter, the Substack, the website tile, and every event listing |
| They give a city and a state or country | Take the city alone. `Denver, Colorado` becomes `Denver` | The chapter name is "Climate Tech Denver" |
| They want to send every two weeks or monthly rather than weekly | Record the weekday as normal and leave `Cadence` at `Weekly`. Tell them the newsletter cycle will offer every two weeks if their first harvests come back thin, and that it is a row they change then | `Cadence` is a real row in section 2 that `ctc-harvest` and `ctc-assemble` both read, but it is decided on evidence after a few harvests, not on day one. The script always writes `Weekly` |
| The chapter is in the EU or the UK | Build normally. Nothing in the data file changes. Point them at `references/list-building.md` when they reach the subscriber list step | Consent requirements differ there, but they are a reading task for the lead, not a field in the settings file |
| They ask which web address to use | There is no published rule. Say so and do not guess | A wrong answer here is a one-way door |
| They do not know their timezone | Take the standard one for their city and say which you took | A formality that should not cost anyone a minute |
| They answer "whatever you think" to everything | Take every default, build, and mark them to confirm | A chapter that never finishes setup never sends |
| They answer only two or three of the eight | Build with those plus defaults, and name what you defaulted at delivery | Partial answers are the normal case for a single-message format, not a failure. Chasing the rest one at a time rebuilds the sequence this format exists to remove |
| They ask you to make the logo or find their event sources in the same reply | Finish setup first. For event sources, name `ctc-source-map`. For the logo, point them at the Logo step in Week 1 of the plan they now have, and do not offer to generate one | Starting a second job before setup lands is how leads end up with neither finished. The logo also needs Climate Tech Cities sign-off before it is used anywhere, which is a step in the plan and not something to shortcut |
| They give a scope rule as a list of towns | Turn it into one sentence and read it back for confirmation | Downstream skills read it as a sentence, not a list |

**The principle underneath.** Record what the lead can tell you today, flag what they cannot, and never let a missing answer stop the documents from existing. Chapters fail by not sending. An incomplete settings file that lets someone start beats a complete one they never finish.

---

## Failure modes

**Saying "upload" instead of "add to your project as a context file".** The most consequential wording failure in this skill. The lead attaches the file to the conversation, everything works for one session, and next week every skill asks for their city again. Always name the project, and always use the words "context file".

Each of these produces a plausible-looking result, which is why they are worth naming.

**Drifting back into one question at a time.** Eight separate messages is the exact failure the one-message format exists to remove. If a reply comes back partial, take the defaults and build; do not walk the remaining questions one by one.

**A settings file already exists.** Do not overwrite. Show what is in it and ask which fields to change, then rebuild.

**Writing a scope rule that cannot be applied.** "The greater metro area" and "wherever makes sense" both read fine and neither one decides a single real event. Every week, a downstream skill has to answer "does this Hoboken event belong in the New York issue," and that sentence is the only thing it has. See `references/interview.md` for the weak-versus-strong pairs.

**Telling the lead to run a logo skill.** There is no logo skill in this toolkit and there never was. The installed set is `ctc-chapter-setup`, the `ctc-newsletter` plugin, and the `ctc-partner-map` plugin, and nothing else. There is no event skill either: chapter leads plan their own events, by decision, and nothing in the toolkit should offer to do it. The logo is a manual step: Week 1 of the plan gives the outline and the chapter launch playbook's Logo step has the prompt, the reference images, and the walkthrough. Naming a skill that is not installed is the worst possible first instruction to give a beginner, because they cannot tell a missing skill from their own mistake.

**Writing advice as orders.** "Add only people who gave you their email", "ask for ten concepts", "target 20 to 30 sources". Each of these was once a bullet in the plan, and each is something the lead can judge for themselves. Orders about judgment calls make the whole document read as micromanagement, and the lead stops trusting the bullets that actually matter (the context files, the sign-offs). Advice goes in a grey note or in a reference the lead can ask for; the bullets stay for dependencies.

**Inventing settings-file sections.** The script writes three and only three. A brand, sources, partners, events or social heading in the settings file is one you added, and the skill that owns that information will never look for it there.

**Repeating a number without checking `plan-notes.md`.** Some figures in the plan are working estimates rather than measurements, and that file labels which are which. Presenting an estimate as a measured standard is a mistake this toolkit has made before; `plan-notes.md` carries the case.

**Naming a settings-file row that is not there.** The file has three sections and fourteen rows: City, Chapter name, Chapter lead, Timezone, Started; Send day, Cadence, Scope rule, Grouping, Web address, Sender name, Sign-off; Substack URL, Reply-to email. `Reporting`, `Source list file`, `Brand`, `Sources`, `Partners`, `Events` and `Social` do not exist. If an instruction anywhere tells you to read one of them, the instruction is stale and the field will be silently absent.

**Delivering the transcript instead of the documents.** The output is two files in `/mnt/user-data/outputs/`, presented with `present_files`. If the turn ends without them, the task is not done regardless of how good the conversation was.

**They never reply at all.** Nothing to build from. Leave it; running the skill again starts cleanly.

---

## Before you deliver

- Both files exist in `/mnt/user-data/outputs/` and you have opened them
- The chapter name reads `Climate Tech <City>` with no state, country, or abbreviation
- The scope rule is one sentence that would decide a real borderline event
- The settings file has exactly three sections: Identity, Newsletter, To update later
- The web address flag is present if it is unconfirmed
- No em dashes in either document
- Your delivery message is under 120 words, names any defaults you took, and names one action
- Every bullet in the plan is a dependency (a file, a skill, a sign-off), and every piece of advice is a grey note

---

## For whoever maintains this skill

`scripts/build_chapter_docs.js` is the definition of both documents. The plan defers to the chapter launch playbook (`PLAYBOOK_URL` in the script) for procedure; when the playbook changes what the lead does in week 1 or 2, the plan's bullets have to follow, and the playbook wins on any conflict. When the script changes what the settings file or the plan contains, grep the whole toolkit before shipping:

```bash
grep -rni "<removed row, section or heading name>" ctc-chapter-setup ctc-newsletter ctc-partner-map
```

Every file that still names the removed thing is now wrong. A dozen downstream files went stale the last time this step was skipped, and the failures are silent: a skill reads a row that is not there, gets nothing, and carries on.

The same check applies in reverse to `references/plan-notes.md`. Every figure in it must appear in the plan the script currently builds, and every sourced figure in the plan (a target, a range, a rate) must be in it.
