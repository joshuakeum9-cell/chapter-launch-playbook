#!/usr/bin/env node
/**
 * Build the two chapter setup documents from a chapter data file.
 *
 *   node build_chapter_docs.js chapter_data_<city>.json
 *
 * Writes to /mnt/user-data/outputs/:
 *   Chapter_Settings_<City>.docx   the settings file, added to the Claude project as a context file
 *   Chapter_Plan_<City>.docx       the two week launch plan, with real dates
 *
 * In the plan, bullets are steps the toolkit or the Climate Tech Cities team depends on;
 * scaffold() notes are advice the lead can take or leave. Keep that split when editing.
 * The plan points at the chapter launch playbook (PLAYBOOK_URL) rather than restating it.
 *
 * Three files end up in the lead's project over time: the settings file on day one,
 * CTC_Source_Registry_<City>.xlsx in week 2, and Opportunities_<City>.xlsx monthly.
 * The plan document itself is reference only. Keep the Files section in buildPlan in
 * step with that list.
 *
 * Both are Word documents on US Letter. No em dashes anywhere.
 */

const fs = require('fs');
const path = require('path');

let docxLib;
try {
  docxLib = require('docx');
} catch (e) {
  console.error('The "docx" package is not available in this environment.');
  console.error('Install it and rerun:  npm install docx');
  console.error('If npm is unavailable, code execution may be switched off for this account.');
  process.exit(1);
}

const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  LevelFormat, PageOrientation,
} = docxLib;

const OUT_DIR = '/mnt/user-data/outputs';
const TEAL = '0F6E6E';
const LIGHT = 'DCE6F1';
const HEAD = 'D9E2E1';
const GREY = '555555';
const PLAYBOOK_URL = 'https://joshuakeum9-cell.github.io/chapter-launch-playbook/';

const LETTER = { size: { width: 12240, height: 15840 } };
const MARGIN = { top: 1080, right: 1080, bottom: 1080, left: 1080 };

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December'];

// ---------------------------------------------------------------- helpers

function parseDate(s) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

function addDays(date, n) {
  const d = new Date(date.getTime());
  d.setUTCDate(d.getUTCDate() + n);
  return d;
}

function fmt(date) {
  return `${MONTHS[date.getUTCMonth()]} ${date.getUTCDate()}`;
}

function fmtLong(date) {
  return `${DAYS[date.getUTCDay()]}, ${MONTHS[date.getUTCMonth()]} ${date.getUTCDate()}, ${date.getUTCFullYear()}`;
}

/** Inclusive range label for the 7 days beginning at `date`. */
function weekRange(date) {
  return `${fmt(date)} to ${fmt(addDays(date, 6))}`;
}

/** First send day falling on or after day 8, so week 1 is clear. */
function firstSendDay(start, sendDay) {
  const target = DAYS.indexOf(sendDay);
  if (target < 0) return addDays(start, 13);
  let d = addDays(start, 7);
  while (d.getUTCDay() !== target) d = addDays(d, 1);
  return d;
}

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { after: opts.after === undefined ? 120 : opts.after },
    alignment: opts.align,
    children: [new TextRun({
      text,
      bold: opts.bold,
      italics: opts.italics,
      size: opts.size || 21,
      color: opts.color,
      font: 'Calibri',
    })],
  });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 320, after: 160 },
    children: [new TextRun({ text, bold: true, size: 30, color: TEAL, font: 'Calibri' })],
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 260, after: 120 },
    children: [new TextRun({ text, bold: true, size: 24, color: TEAL, font: 'Calibri' })],
  });
}

function bullet(text) {
  return new Paragraph({
    numbering: { reference: 'ctc-bullets', level: 0 },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 21, font: 'Calibri' })],
  });
}

function cell(text, { bold, shade, width, italics, color } = {}) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: shade ? { type: ShadingType.CLEAR, fill: shade, color: 'auto' } : undefined,
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    children: [new Paragraph({
      spacing: { after: 0 },
      children: [new TextRun({
        text: text === null || text === undefined ? '' : String(text),
        bold, italics, size: 20, color, font: 'Calibri',
      })],
    })],
  });
}

function table(widths, rows) {
  const total = widths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({
      tableHeader: i === 0,
      children: r.map((c, j) => cell(c, {
        width: widths[j],
        bold: i === 0,
        shade: i === 0 ? HEAD : LIGHT,
      })),
    })),
  });
}

/** Two-column settings block: label, value. */
function settings(pairs) {
  return table([2600, 6400], [['Setting', 'Value'], ...pairs]);
}

function scaffold(text) {
  return new Paragraph({
    spacing: { after: 120 },
    border: { left: { style: BorderStyle.SINGLE, size: 12, color: TEAL, space: 8 } },
    indent: { left: 160 },
    children: [new TextRun({ text, italics: true, size: 20, color: GREY, font: 'Calibri' })],
  });
}

const NUMBERING = {
  config: [{
    reference: 'ctc-bullets',
    levels: [{
      level: 0,
      format: LevelFormat.BULLET,
      text: '\u2022',
      alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 420, hanging: 220 } } },
    }],
  }],
};

function doc(children) {
  return new Document({
    numbering: NUMBERING,
    sections: [{
      properties: { page: { size: LETTER.size, orientation: PageOrientation.PORTRAIT, margin: MARGIN } },
      children,
    }],
  });
}

// ---------------------------------------------------------------- validate

function validate(d) {
  const required = ['city', 'chapterName', 'leadName', 'timezone',
    'startDate', 'sendDay', 'scopeRule', 'webAddress', 'signOff'];
  const errs = [];
  for (const k of required) {
    if (!d[k] || !String(d[k]).trim()) errs.push(`missing required field: ${k}`);
  }
  if (d.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(d.startDate)) {
    errs.push('startDate must be YYYY-MM-DD');
  }
  if (d.sendDay && !DAYS.includes(d.sendDay)) {
    errs.push(`sendDay must be one of: ${DAYS.join(', ')}`);
  }
  const blob = Object.values(d).filter(v => typeof v === 'string').join(' ');
  if (blob.includes('\u2014') || blob.includes('\u2013')) {
    errs.push('em dash or en dash found in the data file');
  }
  return errs;
}

// ---------------------------------------------------------------- settings

function buildSettings(d) {
  const kids = [];

  kids.push(new Paragraph({
    spacing: { after: 60 },
    children: [new TextRun({ text: `${d.chapterName}`, bold: true, size: 36, color: TEAL, font: 'Calibri' })],
  }));
  kids.push(p('Chapter settings', { size: 24, color: GREY, after: 40 }));
  kids.push(p(`Created ${fmtLong(parseDate(d.startDate))}  ·  ctc-chapter-setup v1.6.0`,
    { size: 18, color: GREY, italics: true, after: 200 }));

  kids.push(p('HOW TO USE THIS FILE', { bold: true, size: 19, color: TEAL, after: 60 }));
  kids.push(bullet('Create a project in Claude.'));
  kids.push(bullet('Open the project settings and add this file as a context file.'));
  kids.push(bullet('Do not attach it to a chat. A file attached to one conversation is not available in the next one.'));
  kids.push(p(''));
  kids.push(scaffold('Every skill in the toolkit reads this file from the project. Nothing else works until it is added.'));
  kids.push(p('', { after: 120 }));

  kids.push(h1('1. Identity'));
  kids.push(settings([
    ['City', d.city],
    ['Chapter name', d.chapterName],
    ['Chapter lead', d.leadName],
    ['Timezone', d.timezone],
    ['Started', fmtLong(parseDate(d.startDate))],
  ]));
  if (d.cityNotes && d.cityNotes.trim()) {
    kids.push(p(''));
    kids.push(p('Notes on this city', { bold: true, after: 60 }));
    kids.push(p(d.cityNotes));
  }

  kids.push(h1('2. Newsletter'));
  kids.push(settings([
    ['Send day', d.sendDay],
    ['Cadence', 'Weekly'],
    ['Scope rule', d.scopeRule],
    ['Grouping', 'Day headers for this week. Flat chronological for upcoming. No topic categories.'],
    ['Web address', d.webAddress],
    ['Sender name', d.leadName],
    ['Sign-off', d.signOff],
  ]));

  kids.push(p(''));
  kids.push(scaffold('Cadence stays Weekly unless the newsletter cycle offers every two weeks after your first few harvests come back thin. If that happens, change the word here to Every two weeks and add this file to your project again.'));

  if (!d.webAddressConfirmed) {
    kids.push(p(''));
    kids.push(scaffold('Confirm this web address with the Climate Tech Cities team before publishing. Two patterns are in use across chapters and there is no published rule. Changing it later breaks links other chapters have shared.'));
  }

  kids.push(h1('3. To update later'));
  kids.push(p('Edit this file and add it to your project again when any of these change.', { after: 140 }));
  kids.push(settings([
    ['Substack URL', ''],
    ['Reply-to email', ''],
  ]));

  return doc(kids);
}

// ---------------------------------------------------------------- plan

function buildPlan(d) {
  const start = parseDate(d.startDate);
  const w1 = start;
  const w2 = addDays(start, 7);
  const send1 = firstSendDay(start, d.sendDay);
  const day14 = addDays(start, 13);
  const kids = [];

  kids.push(new Paragraph({
    spacing: { after: 60 },
    children: [new TextRun({ text: `${d.chapterName}`, bold: true, size: 36, color: TEAL, font: 'Calibri' })],
  }));
  kids.push(p('Launch plan', { size: 24, color: GREY, after: 40 }));
  kids.push(p(`${fmtLong(start)} to ${fmtLong(day14)}`, { size: 18, color: GREY, italics: true, after: 200 }));

  kids.push(p('Bulleted lines are the steps the toolkit and the Climate Tech Cities team depend on. The grey notes are advice: take what is useful and skip the rest. You know your city better than this document does.', { after: 100 }));
  kids.push(p(`The full manual is the chapter launch playbook: ${PLAYBOOK_URL}. This plan is the short version with your dates in it.`, { after: 160 }));

  kids.push(h2('Before you start'));
  kids.push(bullet(`Create a project in Claude and name it ${d.chapterName}.`));
  kids.push(bullet(`Add Chapter_Settings_${d.city}.docx to that project as a context file, in project settings under add files, not attached to a chat. Every skill reads it from there, so nothing else in the toolkit works until it is in.`));
  kids.push(bullet('Install the toolkit: ctc-chapter-setup, ctc-newsletter, ctc-partner-map.'));
  kids.push(bullet('Install the Claude in Chrome extension. The weekly harvest needs it to read Luma and Eventbrite.'));
  kids.push(bullet('Turn on code execution in Settings, Capabilities.'));
  kids.push(p(''));
  kids.push(scaffold('The playbook\'s Install page has these in order with links. Skills only appear in a fresh conversation, so start a new one after installing.'));

  kids.push(h2('Schedule'));
  kids.push(table([1300, 2200, 4500], [
    ['', 'When', 'What'],
    ['Week 1', weekRange(w1), 'Logo, then Substack.'],
    ['Week 2', weekRange(w2), 'Source list, subscriber list, first issue.'],
    ['Ongoing', `Every ${d.sendDay}`, 'Harvest, cut, draft, send.'],
    ['Monthly', 'First week of the month', 'Run ctc-opportunities.'],
    ['Quarterly', 'Once every three months', 'Re-run ctc-source-map.'],
    ['Later', 'Once the newsletter is running', 'Partners, if you want them.'],
  ]));

  kids.push(h1('Week 1'));
  kids.push(p(weekRange(w1), { italics: true, color: GREY, after: 140 }));

  kids.push(h2('Logo'));
  kids.push(bullet('Open the Logo step on the chapter launch playbook. It has the prompt with your city in it, the reference images to attach, and the full walkthrough.'));
  kids.push(bullet('Generate concepts in ChatGPT and pick one.'));
  kids.push(bullet('Send your pick to the Climate Tech Cities team for sign-off. Nothing with the logo on it goes public until it is approved: it ends up on the Substack, the website, and every event graphic, so changing it later means changing it everywhere.'));
  kids.push(p(''));
  kids.push(scaffold('Judge concepts at icon size. That is the size most people will ever see it at.'));

  kids.push(h2('Substack'));
  kids.push(bullet(`Once the logo is approved, send it and your chapter name (${d.chapterName}) to the Climate Tech Cities team. They create the Substack publication and send you the login.`));
  kids.push(bullet(`Confirm the web address with them at the same time. Your settings file records ${d.webAddress}, but there is no fixed rule yet, and once other chapters link to the address it cannot change quietly.`));
  kids.push(bullet('When you have the login, ask Claude in your project: "walk me through Substack setup" and "draft my welcome email". Both read your settings file.'));
  kids.push(p(''));
  kids.push(scaffold(`Two settings worth doing early: the sender name as ${d.leadName} rather than the chapter, because email from a person gets opened more often, and the welcome email, because Substack sends it to every new subscriber automatically and it is otherwise blank.`));

  kids.push(h1('Week 2'));
  kids.push(p(weekRange(w2), { italics: true, color: GREY, after: 140 }));

  kids.push(h2('Source list'));
  kids.push(bullet('Run ctc-source-map in your project. It asks whether you have calendar links of your own, researches the rest, and hands back your source list to review.'));
  kids.push(bullet(`When it looks right, add CTC_Source_Registry_${d.city}.xlsx to your project as a context file. The weekly harvest reads it and stops without it.`));
  kids.push(p(''));
  kids.push(scaffold('Every future issue is built from this list, so it is worth an hour now. Sources go quiet without telling anyone, which is why the schedule has a refresh every three months.'));

  kids.push(h2('Subscriber list'));
  kids.push(bullet('Add your first subscribers in Substack and start with whoever you have. A first issue going to a few dozen people is normal.'));
  kids.push(p(''));
  kids.push(scaffold('Your own network, asked one by one, is usually most of the early list and converts better than a public post. If you are thinking of importing a list from somewhere, ask Claude "how do I build my list" first: there are consent rules, and stricter ones for chapters in the UK and EU.'));

  kids.push(h2('First issue'));
  kids.push(p(fmtLong(send1), { italics: true, color: GREY, after: 140 }));
  kids.push(bullet('Say "run the newsletter" in your project. The toolkit runs the harvest, hands you the cut, drafts the issue, and stops wherever your input is needed.'));
  kids.push(p(''));
  kids.push(scaffold('A first issue is small and mostly a note about why the newsletter exists. That is the right shape, not a failure. Do not wait until there are more events.'));

  kids.push(h1('Every week'));
  kids.push(p(`The issue goes out every ${d.sendDay}. Run the four steps in one sitting or spread them across the week.`, { after: 140 }));
  kids.push(table([1700, 6300], [
    ['Step', 'What happens'],
    ['Harvest', 'ctc-harvest sweeps your sources and the reader submission form into a spreadsheet.'],
    ['Cut', 'You delete rows and flag your picks.'],
    ['Draft', 'ctc-assemble builds the issue. You rewrite the opening note and picks in your own words.'],
    ['Send', 'Check the issue, paste into Substack, send.'],
  ]));
  kids.push(p(''));
  kids.push(p('Say "run the newsletter" and the toolkit sequences these and stops where your input is needed.', { after: 160 }));

  kids.push(h1('Every month'));
  kids.push(bullet('In the first week of the month, run ctc-opportunities.'));
  kids.push(bullet(`Add Opportunities_${d.city}.xlsx to your project as a context file, replacing last month's copy. ctc-assemble reads it every week, so the opportunities block has something in it in every issue.`));

  kids.push(h1('Every quarter'));
  kids.push(bullet(`Re-run ctc-source-map once every three months and replace CTC_Source_Registry_${d.city}.xlsx in your project. Sources go quiet without telling anyone, and the refresh catches a dead calendar before it thins out an issue.`));

  kids.push(h1('Once the newsletter is running'));
  kids.push(bullet('Run ctc-city-resources and name your city. It researches the ecosystem and builds your resource workbook.'));
  kids.push(bullet('Then ctc-partner-list turns that workbook into a tiered list of who to approach and what to ask each one for.'));
  kids.push(bullet('Then ctc-partner-outreach drafts the messages in your own voice.'));
  kids.push(p(''));
  kids.push(scaffold('Partners are optional and have no deadline. Starting them before the newsletter is running is how leads end up finishing neither.'));

  kids.push(h1('If you miss a week'));
  kids.push(bullet('Send the next issue on your usual send day. No apology or explanation needed. The target is weeks covered over a quarter, not consecutive weeks.'));

  kids.push(h1('Files'));
  kids.push(p('Three files go in your Claude project as context files. Add the settings file now. Add the other two when the skills that create them hand them over.', { after: 140 }));
  kids.push(table([2900, 1400, 3700], [
    ['File', 'Add it', 'What it is'],
    [`Chapter_Settings_${d.city}.docx`, 'Now', 'Your settings. Every skill reads it. Nothing else works until it is in the project.'],
    [`CTC_Source_Registry_${d.city}.xlsx`, 'Week 2', 'Created by ctc-source-map. The weekly harvest reads it. Replace it at each quarterly refresh.'],
    [`Opportunities_${d.city}.xlsx`, 'Monthly', 'Created by ctc-opportunities. Replace last month\'s copy each time.'],
  ]));
  kids.push(p(''));
  kids.push(scaffold(`Keep Chapter_Plan_${d.city}.docx for reference. It is the only one of the four that does not go in the project.`));

  return doc(kids);
}

// ---------------------------------------------------------------- main

async function main() {
  const src = process.argv[2];
  if (!src) {
    console.error('usage: node build_chapter_docs.js chapter_data_<city>.json');
    process.exit(1);
  }
  const d = JSON.parse(fs.readFileSync(src, 'utf8'));

  const errs = validate(d);
  if (errs.length) {
    console.error('DATA FILE FAILURES, fix before building:');
    errs.forEach(e => console.error('  X ' + e));
    process.exit(1);
  }

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const safe = d.city.replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, '');

  const a = path.join(OUT_DIR, `Chapter_Settings_${safe}.docx`);
  const b = path.join(OUT_DIR, `Chapter_Plan_${safe}.docx`);

  fs.writeFileSync(a, await Packer.toBuffer(buildSettings(d)));
  fs.writeFileSync(b, await Packer.toBuffer(buildPlan(d)));

  const start = parseDate(d.startDate);
  console.log(`wrote ${a}`);
  console.log(`wrote ${b}`);
  console.log('');
  console.log(`  chapter    ${d.chapterName}`);
  console.log(`  lead       ${d.leadName}`);
  console.log(`  send day   ${d.sendDay}`);
  console.log(`  starts     ${fmtLong(start)}`);
  console.log(`  first send ${fmtLong(firstSendDay(start, d.sendDay))}`);
  console.log(`  day 14     ${fmtLong(addDays(start, 13))}`);
  console.log('');
  if (!d.webAddressConfirmed) {
    console.log('  ! Web address is marked unconfirmed. The settings file flags it.');
  }
  console.log('QA: data file passed. Open both documents before delivering.');
  console.log('');
  console.log('SAY THIS WHEN YOU DELIVER, do not shorten it to "upload this":');
  console.log(`  Create a project in Claude, then add Chapter_Settings_${safe}.docx to that`);
  console.log('  project as a context file, in project settings under add files. Not attached');
  console.log('  to a chat. Every skill in the toolkit reads it from there.');
}

main().catch(e => { console.error(e); process.exit(1); });
