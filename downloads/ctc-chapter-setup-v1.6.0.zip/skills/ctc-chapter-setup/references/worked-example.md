# A complete run

One full run of this skill, from the first message to the delivered files. Denver, fictional lead, fictional answers.

**This is illustrative, not data.** The city, the person, and the notes are invented. Do not copy any of it into a real settings file. What it exists to calibrate is the shape of the one-message interview, the handling of a lead who answers loosely, and the length of the delivery message.

It demonstrates, in order: eight questions in one message with defaults inline (and the one question that deliberately has none), a reply that answers six of eight, a city given with its state attached, a scope rule that arrives too loose, a question the lead asks back that has no answer, one default taken and named, and an optional answer worth recording.

---

## The message out

> **Claude:** I will set up your chapter. Eight quick questions below, then I will hand you your settings file and a plan with your actual dates on it.
>
> Answer as many as you can in one go. Skip anything you are unsure about and I will take a sensible default and tell you which ones I filled in.
>
> 1. **Which city is your chapter in?** Use the name the city is known by rather than the metro region or an abbreviation. Chapters are named "Climate Tech [City]".
> 2. **What is your name?** It goes on every issue as the sender, because email from a person gets opened more often than email from an organization.
> 3. **Which day of the week do you want to send?** Pick one and never move it. Default: Tuesday, because most events fall Wednesday to Saturday and a Tuesday send gives readers time to plan.
> 4. **Which events count as local for your chapter?** Most chapters use the city plus anywhere a subscriber would travel on a weeknight, which usually means a few neighboring towns. New York counts Hoboken and Jersey City, for example. Default: that rule, with your city's name in it. Happy to use it, or write your own.
> 5. **Which web address do you want?** Chapters currently use two patterns, `denver.climatetechcities.com` or `denverclimatetech.substack.com`. There is no published rule about which a new chapter takes, so this one has no default: write down whichever you prefer for now and I will flag it as needing confirmation from the Climate Tech Cities team either way.
> 6. **How do you want to close each issue?** Default: "[your first name] and the Climate Tech Denver team".
> 7. **What timezone are you in?** Default: the standard one for your city.
> 8. **Optional: anything unusual about your city a tool should know?** A second cluster somewhere, a university that dominates, a season when everything stops.

## The reply back

> **Lead:** Denver, Colorado. Priya Raman. Thursday, I have more time Thursday mornings. scope is basically the metro area. which web address should I use? sign-off default is fine. most stuff is in RiNo and downtown, Boulder has its own separate scene like 30 min away, and the university calendar drives a lot in fall, July is dead

Six of eight answered, one unusable, one skipped, and a question back. That is the normal case, not a failure.

## The single follow-up

> **Claude:** Two things and then I will build.
>
> Your scope rule needs to be specific enough to settle a real case. Boulder is 30 miles out. In or out?
>
> On the web address, I cannot tell you. Four chapters are on the subdomain and six are on substack.com, and no rule has been published about which a new chapter takes. Pick whichever you prefer and I will flag it as needing confirmation before you publish.
>
> I am taking America/Denver for your timezone since you did not say.

> **Lead:** Boulder in for sure. Boulder, Golden, Aurora. not Colorado Springs or Fort Collins, those are their own thing. substack one

> **Claude:** Building your files now.

One follow-up, carrying every correction and every gap at once. The scope rule pushes once with a concrete case rather than explaining why the rule matters. The web address question gets a plain "I cannot tell you" rather than a guess.

---

## The data file

```json
{
  "city": "Denver",
  "chapterName": "Climate Tech Denver",
  "leadName": "Priya Raman",
  "timezone": "America/Denver",
  "startDate": "2026-08-11",
  "sendDay": "Thursday",
  "scopeRule": "Denver, Boulder, Golden, and Aurora, plus anywhere else a subscriber would travel to on a weeknight.",
  "webAddress": "denverclimatetech.substack.com",
  "webAddressConfirmed": false,
  "signOff": "Priya and the Climate Tech Denver team",
  "cityNotes": "Most events happen in RiNo and downtown. Boulder has its own separate meetup scene about 30 minutes away. The university calendar drives a lot of the fall and it goes quiet in July."
}
```

Note what happened to the raw answers. `Denver, Colorado` lost its state. The sign-off uses `Priya`, not `Priya Raman`. The timezone became IANA form even though the lead never gave one. The loose scope rule became a sentence that decides a real case. The city notes keep the lead's own observations rather than being tidied into corporate phrasing, because a downstream skill reading "July is dead" gets more from it than from "seasonal variance in event volume".

There is no `replyEmail` field and no email question. Substack sets the sending address when the publication is created. `Reply-to email` is a blank row in section 3 of the settings file that the lead fills in themselves later.

---

## Building

```bash
node scripts/build_chapter_docs.js chapter_data_denver.json
```

```
wrote /mnt/user-data/outputs/Chapter_Settings_Denver.docx
wrote /mnt/user-data/outputs/Chapter_Plan_Denver.docx

  chapter    Climate Tech Denver
  lead       Priya Raman
  send day   Thursday
  starts     Tuesday, August 11, 2026
  first send Thursday, August 20, 2026
  day 14     Monday, August 24, 2026

  ! Web address is marked unconfirmed. The settings file flags it.
QA: data file passed. Open both documents before delivering.

SAY THIS WHEN YOU DELIVER, do not shorten it to "upload this":
  Create a project in Claude, then add Chapter_Settings_Denver.docx to that
  project as a context file, in project settings under add files. Not attached
  to a chat. Every skill in the toolkit reads it from there.
```

Read that block rather than skipping it. The first send date is the one to sanity check, because it is computed rather than given: the script takes the start date, moves a week out, then finds the next matching weekday.

---

## What the two documents contain

**`Chapter_Settings_Denver.docx`.** A how-to-use block at the top, then three numbered sections and nothing else. 1. Identity: city, chapter name, chapter lead, timezone, started. 2. Newsletter: send day, cadence (always Weekly at setup), scope rule, grouping, web address, sender name, sign-off, plus the note on when to change the cadence and the flagged note about the unconfirmed address. 3. To update later: two blank rows, Substack URL and Reply-to email, for the lead to fill in once Substack exists. The city notes appear under section 1 when they are given.

**`Chapter_Plan_Denver.docx`.** Two weeks with real dates. An opening line that says bullets are steps and grey notes are advice, with a link to the chapter launch playbook, then a before-you-start block, a schedule table, Week 1 (logo, then Substack, which the Climate Tech Cities team creates), Week 2 (source list, subscriber list, first issue on Thursday August 20), then the recurring sections: every week, every month, every quarter, once the newsletter is running, if you miss a week, and Files. About twenty bullets in all; everything else is a grey note.

Both are fully generated. Nothing in them is written by hand at delivery time.

---

## The delivery message

> Two files.
>
> **Chapter_Settings_Denver.docx** holds your answers. **Create a project in Claude and add this file to it as a context file**, in project settings under add files. Not attached to a chat: a file attached to one conversation is not there next time, and every skill reads this one from the project.
>
> **Chapter_Plan_Denver.docx** is your first two weeks with real dates. First issue lands Thursday, August 20.
>
> I took America/Denver for your timezone; say if that is wrong.
>
> One thing this week: the Logo step in Week 1. Open the Logo step on the chapter launch playbook; it has the prompt and the reference images.
>
> Your web address is marked unconfirmed. Check it with the Climate Tech Cities team before you publish anything.

115 words. One instruction in bold, one default named, one action, one flag.

Note what it does not do. It does not name a skill to run, because the logo is a manual step and there is no logo skill in this toolkit. It does not tell them to create a Substack, because the Climate Tech Cities team does that once the logo is approved. It does not mention the source list or the opportunities queue, because neither exists yet and the plan's Files section carries them with the week each one arrives. It does not summarize the plan.

### What this replaced

> Congratulations on launching Climate Tech Denver! I have created two documents for you.
>
> The first is your chapter settings file, which contains all of the information you provided during our conversation, including your city, your name, your send day of Thursday, your scope rule covering Denver, Boulder, Golden and Aurora, your preferred web address, your sign-off, and your timezone.
>
> The second is your launch plan, which walks you through branding in week one, newsletter setup in weeks one and two, and your first issue, followed by the ongoing weekly cycle of harvest, cut, draft and send...

That version is not wrong. It is a summary of two documents the lead is holding, and it buries the context file instruction in the middle of a paragraph. The lead reads the message instead of the plan, and the plan is better.
