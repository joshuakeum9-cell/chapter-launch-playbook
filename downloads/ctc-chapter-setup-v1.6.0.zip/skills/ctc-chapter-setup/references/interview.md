# The interview

Eight questions, all in one message. One reply, then build.

The person answering has just been approved to run a chapter and may have never used Claude before. They do not know what a scope rule is, they do not know why the send day matters, and they should not have to. Every question supplies the concept, one line of reasoning, and a default they can accept.

A complete run is in `worked-example.md`. Read that alongside this file. This one has the wording and the rules; that one has the calibration.

---

## How to run it

**One message, one numbered list of eight, one reply.** Never send them one at a time. A lead reading on a phone should be able to answer the whole thing in a single reply.

**Every question carries its default inline, briefly, with one exception.** The default is what makes a single message safe to send. Without it, a wall of eight questions is just a form, and a lead who does not know an answer has nothing to fall back on and nobody prompting them. They can reply "default" to any of them. The exception is question 5, the web address, which has no default on purpose: see the rule under that question.

**Never use these words with them:** config, registry, schema, parameter, YAML, field, populate. Say "your settings file."

**If they do not know, take the default and mark it.** Record what you took and name it in one line at delivery so they can correct you. Never block on an answer they cannot give today.

**At most one follow-up, carrying everything at once.** If answers are missing or unusable, send one short message with every correction and every gap in it. Then take defaults for whatever is still open and build.

**Keep the framing short.** Two sentences before the list, nothing after it. The questions below are already written; do not introduce each one.

| Weak | Why | Strong |
|---|---|---|
| A paragraph of context before the list explaining what a settings file is and what the toolkit does | They have not got one yet, so none of it lands. Both explanations work better after the documents exist | Two sentences, then the eight questions |
| Numbering the list but dropping the defaults to keep it short | A default-free wall is a form. This is the failure that sends leads back into a turn-by-turn interview | Every item carries its default in the same line |
| Re-asking the three they skipped as a second numbered list | Rebuilds the sequence the one-message format exists to remove | Take the defaults, name them at delivery, build |

---

## The eight questions

### 1. City

> Which city is your chapter in?
>
> Use the name the city is known by rather than the metro region or an abbreviation. Chapters are named "Climate Tech [City]", so this becomes your chapter's name everywhere it appears.

Confirm the chapter name back to them. `Boston` becomes `Climate Tech Boston`.

If they give a metro name or an abbreviation, take the common name and read it back in the single follow-up. `The Bay Area` becomes `San Francisco`. `NYC` becomes `New York`. If they give a city with a state or country attached, take the city alone without asking. `Denver, Colorado` becomes `Denver`.

If they name a city that already has a chapter, stop and ask before continuing. The ten are New York, Washington DC, Boston, Chicago, San Diego, Los Angeles, San Francisco, Seattle, London, and Amsterdam. Restarting a chapter that has gone quiet is a normal reason to be here. Setting up a second copy of a chapter that is already running is not.

### 2. Name

> What is your name?
>
> Your name goes on every issue as the sender. Email from a person gets opened more often than email from an organization, so the chapter name does not go here.

Do not ask for an email address. Substack sets the sending address when the publication is created. The Reply-to email row in section 3 of the settings file is left blank for the lead to fill in once Substack exists. No skill requires it; `ctc-partner-outreach` uses it only if it has been filled in.

### 3. Send day

> Which day of the week do you want to send?
>
> Pick one and never move it. Readers learn the rhythm, and a newsletter that arrives on a different day each week stops feeling like a habit.

Default: whichever day suits them. If they have no view, suggest Tuesday or Wednesday, and say why in one line, which is that most events fall Wednesday to Saturday so a Tuesday send gives readers time to plan.

If they say they want to send every two weeks or once a month, take the weekday as normal and leave the `Cadence` row at `Weekly`. Tell them the newsletter cycle offers every two weeks only after a few harvests come back thin, and that the row is theirs to change then. You can note their preference in `cityNotes` so the cycle sees it.

### 4. Scope rule

> Which events count as local for your chapter?
>
> Most chapters use the city plus anywhere a subscriber would travel on a weeknight, which usually means a few neighboring towns. New York counts Hoboken and Jersey City, for example.
>
> Want to use that as your rule, or write your own?

This is the question most likely to stall someone, which is why it comes with a concrete example and a ready-made answer.

Write their answer as one sentence. If they list towns, turn it into a sentence and read it back.

**This sentence does more work than any other field.** Every week, a downstream skill has to decide whether a given event belongs in the issue, and this is the only instruction it gets. A rule that cannot settle a real borderline case is a rule that gets ignored.

| Weak | Why it fails | Strong |
|---|---|---|
| The greater Denver metro area. | Does not name a boundary. Boulder is 30 miles out and reasonable people disagree | Denver, Boulder, Golden, and Aurora, plus anywhere else a subscriber would travel to on a weeknight. |
| Anything relevant to our community. | Decides nothing at all | Amsterdam and anywhere reachable within an hour by train, which includes Utrecht and Haarlem. |
| Denver. | Excludes the suburbs where a third of the events happen, probably by accident rather than intent | Denver and the immediate suburbs, excluding Colorado Springs and Fort Collins, which are their own scenes. |

Two tests before you write it down. Could someone apply it to an event 25 miles out and get a definite answer? Does it name at least one place, or one measure of distance or travel time?

### 5. Newsletter web address

> Your newsletter needs a web address. Climate Tech Cities chapters currently use two patterns:
>
> boston.climatetechcities.com
> bostonclimatetech.substack.com
>
> There is no published rule about which one a new chapter takes, so confirm this with the Climate Tech Cities team before you publish anything. Changing it later breaks every link other chapters have shared.
>
> Which would you like me to write down for now?

Record their answer and mark it unconfirmed. Set `webAddressConfirmed` to false unless they say the team already told them.

**Do not pick for them and do not present one as correct.** There is no rule yet. Pretending otherwise would put a wrong address into a one-way door. This is the one question in the eight that carries no default; say so in the message, and if they skip it, ask for it in the single follow-up rather than filling it in.

### 6. Sign-off

> How do you want to close each issue?
>
> The default is "[your first name] and the Climate Tech [City] team". Chapters with more than one lead list the first names, then the team.

Default: `[First name] and the Climate Tech [City] team`.

Use the first name alone, not the full name. "Sam and the Climate Tech Denver team", not "Sam Rivera and the Climate Tech Denver team". This is a sign-off, not a byline.

### 7. Timezone

> What timezone are you in?

Offer the obvious one for their city and let them confirm. This is a formality for most people, so keep it to one line.

Write it in IANA form, such as `America/Denver` or `Europe/Amsterdam`, because that is what a tool can use. Say it in plain words when you ask.

### 8. Anything unusual about the city

> Last one, and it is optional. Anything unusual about your city that a tool should know? A second cluster somewhere, a university that dominates, a season when everything stops.

Skippable. If they say no, move straight to building.

Useful answers look like: "everything happens in RiNo and downtown, nothing in the south suburbs", "the university drives half the calendar and it empties out in July", "there is a second cluster in Boulder that has its own meetup scene". Record it close to how they said it.

---

## What this interview never asks

Do not ask about the logo, partners, events, social handles, the source map, or a reply-to email. None of them is a settings-file field, and asking now gives a new lead six questions they cannot answer yet.

The settings file has three sections and fourteen rows. It does not carry brand, sources, partners, events or social, and it does not create scaffold headings for them. The skills that own that information keep it in their own files. Section 3 holds two blank rows, Substack URL and Reply-to email, which the lead fills in themselves once Substack exists.

---

## Interruptions

**If they answer some and not others,** take what came back, apply the defaults for the rest, and name the defaulted ones in one line at delivery. Do not re-ask the missing ones individually.

**If they never reply at all,** there is nothing to build from. Leave it. Running the skill again starts cleanly.

**If a settings file already exists,** do not overwrite it. Show what is in it and ask which fields to update.

**If an answer is unusable,** a scope rule given as a list of towns, a metro name instead of a city name, a full name where a first name belongs: fix it yourself per the rules above and read the corrected version back in the single follow-up.

**If they ask you to also do the logo or find their event sources,** say you will finish setup first and carry on. For event sources, name `ctc-source-map`. For the logo, point them at the Logo step in Week 1 of the plan they are about to receive, and do not offer to generate one: there is no logo skill in this toolkit. Both jobs get done and neither gets half done.


---

## The closing instruction

However the interview went, it ends the same way. The lead has to be told, in these words, what to do with the settings file:

> Create a project in Claude, then add this settings file to the project as a **context file**. Not to a chat. Every skill in the toolkit reads it from there, so you never answer these questions again.

Never compress this to "upload it to Claude". A file attached to a single conversation is gone the next time they start one, and the failure is silent: everything works once, then quietly stops.
