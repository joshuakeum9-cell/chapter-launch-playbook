# Editorial style

Two kinds of prose live in this workbook: the organization descriptions in column D, and the city narrative. They share a voice and differ in shape.

The voice is warm, high-signal, operator-oriented and founder-first. It reads like a well-informed person telling a founder something useful, not like a directory entry and not like a consultant's deck.

---

## Rules that apply to everything

**No em dashes.** Anywhere. Not in descriptions, not in the narrative, not in reviewer notes. This has been enforced programmatically on every past build and the build script checks it.

**Timeless copy.** Nothing that goes stale. Specifically banned from published copy:

- Fund sizes, assets under management, any dollar or euro amount
- Cohort headcounts, "over 200 startups supported", portfolio counts
- Percentages and statistics
- Current policy numbers, emissions targets with dates, current programme deadlines
- Founding years where the point is recency rather than heritage

The reason is maintenance. A workbook full of figures needs revisiting every few months; a timeless one does not. Research may surface these numbers and should, as verification evidence. They just do not reach the page.

**No invented specifics.** If the research did not establish something, do not write it. A vague true sentence beats a precise false one.

---

## Organization descriptions

Three to four sentences. Six is the hard ceiling and should be rare.

**Shape:**

1. What it is and where, in one sentence. Name the actual municipality when it differs from the city brand.
2. What it operationally provides a founder: capital, space, non-dilutive money, lab access, pilots, mentorship, customer introductions. Be concrete about the mechanism.
3. What distinguishes it, or what a founder should understand before approaching. Sector focus, selection criteria, stage.
4. A closer, always in this form: `Suits [founder type].`

**The `Suits` closer** is the most useful line in the entry. It does routing work: it tells a reader scanning forty rows which three are for them. Make it specific.

Weak: `Suits climate founders.`
Strong: `Suits scientist-founders commercializing lab research who need non-dilutive runway before raising.`
Strong: `Suits hardware founders who need prototyping space more than they need a check.`
Strong: `Suits Pacific Northwest climate-software founders at the earliest stages.`

**Non-programs get flagged plainly.** When an ecosystem anchor does not run a startup vehicle, say so directly and name the adjacent vehicle. This is a service to the reader, not a disclaimer.

> The Institute is a research center rather than a startup program, and it does not run cohorts or write checks. Founders looking to commercialize work from it should approach the university's technology licensing office instead.

**Generalist investors get flagged too.** Where a fund is local and early-stage but not climate-dedicated, say so rather than implying a focus it lacks: `It is not climate-dedicated, with climate fitting only incidentally.`

**Worked example:**

> Greentown Labs is a climate tech incubator in Somerville offering prototyping space, wet labs, machine shops and office space alongside a community of hardware-focused climate startups. Membership brings access to a corporate partner network that opens pilot conversations, plus programming on manufacturing, fundraising and hiring. It leans hard toward physical products rather than software, and the value is as much the neighbours as the facilities. Suits hardware founders who need real prototyping infrastructure and peers who have solved the same problems.

Four sentences. Concrete about the mechanism. No figures. Honest about what it is not for. Routes the reader.

---

## The city narrative

300 to 500 words on what makes this city distinctive for climate tech.

**Research it independently.** Do not summarize the roster. The narrative is about industrial DNA, anchor institutions, ecosystem character and honest gaps, not about which accelerators exist.

**Show, do not announce.** This is the note the project pushed back on hardest, and it applies throughout, not just to openers.

Announcing:
> What makes Houston distinctive is its industrial depth and proximity to energy infrastructure.

Showing:
> A founder building industrial heat electrification in Houston can drive forty minutes to a refinery that might pilot it, and hire a process engineer who has run one for twenty years.

The second does not say "distinctive". It puts the reader somewhere and lets them conclude it. Watch for and rewrite: "What makes X distinctive is", "X is unique in that", "The key thing about X is", "X stands out because".

**Structure**, loosely, over three or four paragraphs:

- Open on something concrete and specific to the place. Not a thesis statement.
- The industrial and institutional substrate: what the city already does at scale, who anchors it, what infrastructure sits nearby.
- What that means for a founder building there: which sectors have unfair advantages, where the customers and the talent are.
- Close on the honest gap. Every city has one. Naming it earns the rest of the piece its credibility, and CTC readers are operators who can tell when they are being sold to.

**Tone check.** It should read like someone who has spent time there, not like a chamber of commerce page and not like a consultant's market brief.
