# Research brief

Two passes minimum before the build, plus the post-build audit in `audit-pass.md`. Pass one discovers, pass two verifies and deepens. Run a third when a block is still thinner than the ecosystem should support.

Use `launch_extended_search_task` where available - standing permission exists, so do not stop to ask. Where it is not available, run the same brief as thirty or more `web_search` and `web_fetch` calls. The characteristic failure is running five searches and calling it done.

---

## Pass one: discovery

Substitute `<CITY>` and `<METRO SCOPE>`, then send verbatim.

```
Research the climate tech ecosystem of <CITY> and return a comprehensive, structured
inventory of organizations that support EARLY-STAGE CLIMATE STARTUPS there.

METRO SCOPE: <METRO SCOPE>

Organize findings into these five blocks:

1. UNIVERSITIES & RESEARCH INSTITUTIONS - PROGRAMS & CENTERS
   Grouped by institution. For each university in the metro, list its SPECIFIC climate,
   energy and sustainability programs, research centers, institutes, commercialization
   and tech-transfer vehicles, student venture funds, university-run accelerators, and
   relevant degree or certificate programs. The unit is the PROGRAM, not the university.

2. INCUBATORS & ACCELERATORS
   Cohort programs, venture builders, climate-specific incubators, hardware and
   lab-access programs based in the metro.

3. STARTUP RESOURCES & PUBLIC PROGRAMS
   City, state, regional and national agencies; economic development bodies; public
   innovation programs; non-profit support organizations. Each must run something a
   startup can actually apply to or enter.

4. INDUSTRY PARTNERS
   Corporates, utilities and industrials based in the metro that run a DEDICATED
   program for early-stage climate startups: pilot programs, demonstration
   partnerships, innovation challenges, or a corporate venture arm operating locally.

5. CAPITAL PARTNERS
   Venture firms based in the metro that invest in climate at early stage. Be
   exhaustive. Work from climate VC directories such as CTVC / Sightline Climate as
   well as open search. Include corporate venture arms, angel groups with a genuine
   climate thesis, and catalytic capital, provided each has a real local base and its
   primary business is writing venture checks.

FOR EVERY ORGANIZATION, REPORT:
- Exact official name
- Type: a short label, e.g. "Accelerator", "Venture capital", "University program",
  "Corporate VC", "Utility", "Public agency", "Research institute"
- Focus area: a short phrase
- The exact canonical working URL, corrected if it redirects or is stale
- PHYSICAL HEADQUARTERS: the actual street address, or at minimum the municipality and
  neighbourhood. Name the real municipality even when it differs from the city brand,
  e.g. Evanston, Cambridge, Lemont, Naperville, Haarlem, Amstelveen, Arlington, Bethesda.
- DATED EVIDENCE OF ACTIVITY: the most recent cohort, portfolio investment, news post,
  live application page, fund close, annual report or LinkedIn activity, WITH THE DATE.
  If you cannot find dated evidence within roughly 18 months, say so explicitly.
- QUALIFICATION: confirm it supports early-stage climate startups through a DEDICATED
  vehicle - accelerator, incubator, corporate venture arm, fund, fellowship,
  non-dilutive grant program, structured mentorship, or a university commercialization
  or venture program. General business support, generic procurement, a corporate
  net-zero pledge, pure research, pure convening, pure consultancy, or a growth-only
  investor DOES NOT QUALIFY. If an organization is worth listing as an ecosystem anchor
  but is not a dedicated startup vehicle, say so plainly and name the correct adjacent
  vehicle a founder should approach instead.
- STAGE: whether it actually reaches pre-seed and seed founders, or is growth-only.
  Flag growth-only investors explicitly.
- 3 to 6 substantive factual notes usable for writing a founder-facing description:
  what it actually does, who it selects, how founders enter, what it operationally
  provides (capital, space, non-dilutive money, pilots, lab access, mentorship), what
  makes it distinctive, and notable local portfolio companies or alumni.

DO NOT report fund sizes, assets under management, dollar or euro amounts raised,
cohort headcounts, or "over X companies supported" figures as descriptive material,
because the published copy must stay timeless. Report those separately and clearly
labelled as activity evidence for verification only.

Honest gaps are strongly preferred over padding. Do not propose organizations on the
strength of reputation alone. Do not invent organizations, URLs, founders or programs.
If you cannot verify something, say "not publicly available" rather than filling it in.

Also gather material for a 300-500 word CITY NARRATIVE about what makes <CITY>
distinctive for climate tech: its industrial DNA, anchor institutions, sector
strengths, ecosystem character, and its honest gaps. Focus on durable characteristics
rather than current figures, recent funding rounds or present policy numbers.
```

---

## Pass two: verification and deepening

Substitute the city, metro scope, the full pass-one list, and the thin blocks.

```
VERIFICATION AND DEEPENING TASK for the <CITY> climate tech ecosystem.

PART A - VERIFY. For every organization listed below, verify four things and give a
clear verdict of KEEP, KEEP-WITH-CAVEAT or REMOVE:

(A) EXISTS AND IS ACTIVE. Does it still exist as an independent operating entity? Is
    the specific named program still running, not paused, wound down, sunsetted,
    rebranded out of existence, acquired or merged? Give the single most recent piece
    of DATED evidence. If the most recent evidence is older than roughly 18 months, say
    so explicitly and recommend REMOVE or FLAG.
(B) WEBSITE. Confirm the exact working canonical URL. Correct anything that redirects,
    404s or is not canonical. Flag dead sites.
(C) LOCAL PRESENCE. Confirm the physical headquarters or a genuinely staffed office in
    <METRO SCOPE>. Name the actual municipality. If the organization is NOT genuinely
    based in the metro, say so plainly and recommend removal. A partner who lives there,
    a mailing address, a coworking membership, or "serves the region" does not count.
(D) BLOCK FIT AND QUALIFICATION. Confirm it belongs in its assigned block, and confirm
    it supports early-stage climate startups through a dedicated vehicle. Recommend a
    move if misfiled. Flag anything that fails the bar and name the correct adjacent
    vehicle a founder should approach instead.

LIST TO VERIFY:
<full pass-one list, grouped by block>

PART B - DEEPEN. These blocks came back thinner than the ecosystem should support:
<thin blocks>

Hunt specifically for the categories generalist searches miss:
- Corporate venture arms of locally headquartered industrials, utilities and energy
  companies
- University commercialization funds, student venture funds, and tech-transfer
  spinout programs
- City, county, state and regional agency startup programs, including economic
  development bodies and green banks that run an actual startup vehicle
- Sector-specific funds: water, agrifood, mobility, built environment, industrial
  decarbonization, grid
- Angel groups and syndicates with a genuine, stated climate thesis
- National lab, research institute and hospital-system spinout or commercialization
  programs
- Climate-specific coworking, prototyping and lab-access facilities
- Recently launched programs from the last two years that older directories miss

Apply the same verification standard to every new candidate: dated evidence, canonical
URL, physical headquarters with the municipality named, block, qualification, stage, and
3 to 6 factual notes for description writing. Same timeless-copy rule: no fund sizes,
amounts, headcounts or percentages as descriptive material.

Honest gaps are strongly preferred over padding. If a block genuinely has only four
qualifying organizations in this city, report four and say so.
```

---

## After the passes

1. Apply `inclusion-rules.md` strictly. Cut hard.
2. Write down every cut with its reason. These become the section-header column F notes.
3. Where a block is still thin after deepening, that is the answer. Note it on the section header and move on.
4. Sanity-check the URLs you are about to publish. Fetch the ones you did not see returned directly in search results. URLs reconstructed from memory have been wrong before - Halcyon shipped with a wrong domain, mHUB shipped with a stale one.
