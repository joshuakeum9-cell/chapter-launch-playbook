# Inclusion rules

Three tests. An organization must pass all three to appear in the workbook. Most candidates that surface in research fail at least one.

1. **Local** - genuinely physically based in the city or its metro
2. **Qualifying** - runs a dedicated vehicle for early-stage climate startups
3. **Active** - operating now, with dated evidence

---

## Test 1: Local

> Would a founder who lives in this city say "yes, they're here"?

The organization must have its headquarters, or a real staffed office where people go to work, inside the city or its metro. Nothing weaker counts.

**Fails the test:**

- A national program available identically to founders in every city
- A fund with a partner who lives there but no office
- A registered address, a coworking mailbox, a "presence"
- An organization whose local involvement is a partnership with a local body
- A regional office of a body headquartered elsewhere, unless that office independently runs the startup vehicle being listed

**A useful diagnostic:** if the entry would be equally true written under three different city tabs, it does not belong under any of them.

**Where this has bitten before:**

| Organization | City it was listed under | What research found |
|---|---|---|
| SJF Ventures | Washington DC | No genuine DMV base. Removed |
| Elemental Impact | Washington DC | No genuine DMV base. Removed |
| Carbon13 | US tabs | UK venture builder, no US operations. Removed |
| 8090 Industries | Los Angeles | Headquartered in New York. Removed |
| Aera VC | Los Angeles | Headquartered in Singapore. Removed |
| Osage University Partners | Boston | Not Boston-based. Removed |
| Material Impact | Boston | Confirmed genuinely Boston. Kept |

**Naming municipalities.** When an entry sits in the metro but not the city proper, name the actual municipality in the Focus Area or Description. Evanston, Cambridge, Lemont, Naperville, Haarlem, Amstelveen, Arlington, Bethesda. The reader deserves to know where they are actually going.

---

## Test 2: Qualifying

> Can an early-stage climate founder walk through a door here?

The organization must run a **dedicated vehicle** for early-stage climate startups. A vehicle is a specific, named, enterable thing:

- An accelerator or incubator with cohorts
- A fund or corporate venture arm that writes early checks
- A fellowship or residency
- A non-dilutive grant program
- A structured mentorship program
- A university commercialization or venture program
- A pilot or demonstration program startups can formally apply to

**Does not qualify:**

- General business support not specific to climate or not specific to startups
- A corporate net-zero pledge or sustainability report
- Procurement, or informal willingness to talk to startups
- A pure research center with no commercialization pathway
- A pure convening body, industry association, or policy shop
- A consultancy
- A growth-stage-only investor
- A project-finance lender or green bank

**Where this has bitten before:** applying this test strictly removed SCE, LADWP, SoCalGas, PG&E, SDG&E, PSE, PACCAR and Boeing from Industry Partners, and Tech Coast Angels, Correlation Ventures, Revolution, Madrona and Qualcomm Ventures from Capital Partners. Several cities turned out to genuinely lack five qualifying organizations in a block. That was the correct finding, not a research failure.

**The ecosystem-anchor exception.** Some organizations matter enormously to a city's climate scene without running a startup vehicle. A national lab. A major research institute. A green bank. These may be listed, but the description must say plainly what it is not, and name the adjacent vehicle a founder should actually approach instead.

The New York tab does this for seven entries - Lamont-Doherty, CUSP, Cornell Tech Urban Tech Hub, CUNY ASRC, Empire State Development, NY Green Bank, NYCEEC - because founders routinely mistake them for startup programs. Being useful about the distinction is better than either listing them misleadingly or omitting them.

---

## Test 3: Active

Operating now, with dated evidence from roughly the last 18 months. Acceptable evidence: a recent cohort, a dated portfolio investment, a news post, a live application page, a recent fund close, recent LinkedIn activity.

Reputation is not evidence. Startupbootcamp Amsterdam had an excellent reputation and was bankrupt. Smart City Works looked established and had been dormant since 2021.

If the most recent evidence is older than 18 months, exclude, or include with a `VERIFY BEFORE PUBLISH` flag in column F.

---

## The five blocks

Order is fixed. Blocks are not interchangeable, and misfiling is a real defect - it sends founders to the wrong kind of door.

### 1. Universities & Research Institutions - Programs & Centers

Grouped by institution: a sub-header row carrying the institution name, then that institution's specific programs and centers beneath it. The entry is the **program**, not the university. "MIT" is not an entry; "MIT delta v" is.

Include climate and energy research centers, sustainability institutes, commercialization and tech-transfer vehicles, student venture funds, accelerators run by the university, relevant degree and certificate programs.

Column A header for this block is `Program / Center`, not `Organization`.

### 2. Incubators & Accelerators

Cohort-based programs, venture builders, climate-specific incubators, hardware and lab-access programs. The defining feature is a structured program founders apply to and enter.

### 3. Startup Resources & Public Programs

City, state, regional and national agencies; economic development bodies; public innovation programs; non-profit support organizations. All must run something a startup can actually apply to or enter.

This is where founders wrongly expect green banks and project lenders to sit. They can be listed here with the non-program caveat, but say so plainly.

### 4. Industry Partners

Corporates, utilities and industrials that run a **dedicated** program for early-stage climate startups: a pilot program, a demonstration partnership, an innovation challenge, a corporate venture arm operating from that city.

The hardest block to fill honestly. Most large companies have sustainability commitments and no door. Leave it short rather than admitting a utility because it is big and local.

### 5. Capital Partners

Firms whose **primary business is writing venture checks**, based in the city, investing in climate at early stage.

Not accelerators that also invest, not state agencies, not green banks, not project lenders, not fund-of-funds. Carbon Equity was excluded as a fund-of-funds. MEIA's Climate Technology Founders Fund was excluded as an accelerator vehicle rather than a venture firm.

Generalist funds only qualify with a genuine, stated climate thesis. Where a fund is local and early-stage but not climate-dedicated, say so in the description rather than implying a focus it does not have.

Be comprehensive here. The original workbook cherry-picked five firms per city and the manager pushed back specifically on that. Work from a climate VC directory such as CTVC / Sightline Climate as well as open search, and list every qualifying firm.

---

## Reviewer notes: column F

Column F carries notes for the manager reviewing before publication. Yellow fill `FFFFFF00` on column F only - never on columns A through E, which stay standard blue.

Three things go in column F:

1. **Exclusions**, on the relevant section header row. Every organization considered and cut, with the reason. Silent omission leaves the reviewer unable to tell research from judgment. Format: `Excluded: <Org> (<reason>); <Org> (<reason>).`
2. **`VERIFY BEFORE PUBLISH`**, on any row whose details could not be fully confirmed, naming what needs confirming.
3. **Editorial rationale**, on any row where the judgment call was close enough that the reviewer would otherwise wonder.

Section headers on deliberately short blocks should say so and say why, rather than leaving the reviewer to guess whether the block was finished.
