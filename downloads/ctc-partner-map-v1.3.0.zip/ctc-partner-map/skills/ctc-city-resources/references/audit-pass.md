# Audit pass

The final stage. Run after the workbook is built, against the workbook itself.

## Why this exists and why it reads from the file

The research passes verified *candidates*. This pass verifies *what shipped*. Those are different things, and the gap between them is where errors live: a URL retyped with a typo, an organization that survived a cut list it should not have, a description that drifted from what research actually established, a row that landed in the wrong block during the build.

So do not audit the data module or your earlier research notes. Extract the roster from the `.xlsx` and audit that. The file is the deliverable; the file is what gets checked.

## The confirmation-bias problem

You researched these organizations. You will be tempted to confirm your own earlier conclusions rather than test them, and that tendency is exactly what an audit is supposed to defeat.

Approach every entry as though a stranger compiled it and you have been asked to find what is wrong with it. The question is not "can I find support for this?" It is "what would make this entry wrong?" An audit that changes nothing is more likely to have been performed badly than to have found a perfect file.

## Step 1 - Extract the roster

```bash
python3 scripts/extract_for_audit.py /mnt/user-data/outputs/CTC_City_Resources_<City>.xlsx
```

This prints every data row with its block, name, type, focus, URL and a compressed description, formatted as a numbered checklist. Feed that list into the audit prompt.

## Step 2 - Run the audit research

Use `launch_extended_search_task` where available. This is a fresh research task, not a continuation of the earlier ones.

```
INDEPENDENT AUDIT of a published resource list. Assume nothing in this list is
correct. Your job is to find what is wrong with it, not to confirm it.

For EVERY numbered entry below, run these five checks and return a verdict of
PASS, FIX or REMOVE, with evidence:

(1) EXISTS AND STILL OPERATES. Does this organization exist right now as an
    independent operating entity? Give the most recent DATED evidence you can
    find: latest cohort, latest portfolio investment, latest news post, live
    application page, latest fund close, recent LinkedIn activity. State the
    date. If the newest evidence you can find is older than roughly 18 months,
    the verdict is REMOVE or FIX-with-flag. Check specifically for: bankruptcy,
    wind-down, acquisition, merger, rebrand, and programs quietly discontinued
    while the parent organization continues.

(2) THE NAMED PROGRAM STILL RUNS. The entry may name a specific program, fund,
    centre or vehicle rather than the parent body. Confirm THAT SPECIFIC THING is
    still running. A university whose sustainability institute was renamed, or a
    corporate whose accelerator quietly closed while the company thrives, both
    fail this check even though the parent is healthy.

(3) URL IS LIVE AND CANONICAL. Open the URL. Confirm it resolves, is not a 404,
    is not a parked or expired domain, does not redirect somewhere unrelated, and
    is the organization's canonical domain rather than a stale one. Give the
    corrected URL if it is wrong. Report the actual HTTP outcome you observed
    rather than assuming a plausible-looking URL works.

(4) PHYSICAL BASE IN <CITY> / <METRO SCOPE>. Confirm a headquarters or a genuinely
    staffed office inside the metro. Give the address or at minimum the
    municipality and neighbourhood, and name the real municipality even when it
    differs from the city brand. These DO NOT count as a local base: a mailing
    address, a coworking membership, a partner or investor who lives locally, a
    "we serve this region" claim, a national program with a local landing page, or
    a regional office that does not itself run the vehicle being listed. If the
    organization is not genuinely based in the metro, the verdict is REMOVE.

(5) DESCRIPTION IS ACCURATE. Read the description supplied with each entry.
    Flag anything factually wrong or no longer true: a stage focus that has moved,
    a sector claim not supported by the portfolio, a program structure that has
    changed, a facility it no longer has, a claim it invests when it does not.
    Also flag anything that reads as a specific factual claim you cannot verify at
    all, since unverifiable specifics are how invented detail survives.

FORMAT each verdict as:
  <number>. <Organization> - PASS | FIX | REMOVE
     Evidence: <most recent dated evidence, with date>
     URL: <confirmed or corrected>
     Base: <municipality, and how confirmed>
     Issue: <what is wrong, if anything>

Also report, separately: any organization you encountered during this audit that
genuinely belongs on this list and is missing from it.

ENTRIES TO AUDIT:
<paste the numbered checklist from extract_for_audit.py>
```

## Step 3 - Spot-check the URLs directly

Do not rely solely on the research task for link checking. Fetch a sample yourself with `web_fetch`, and fetch every URL the audit flagged.

`bash` cannot reach arbitrary domains in this environment, so `curl` and `requests` will fail on organization websites. Use `web_fetch`. A URL that has never been observed resolving has not been checked.

Prioritise: every Capital Partners URL (fund websites go stale and get parked more than any other category), anything the audit flagged, and anything whose URL was constructed rather than seen in a search result. Halcyon and mHUB both shipped with wrong domains on earlier chapters, which is why this check is here.

## Step 4 - Apply the findings

- **REMOVE** - delete the row from the data module. Record it in the block's `SECTION_NOTES` entry with the reason, so the reviewer sees the judgment rather than an unexplained absence.
- **FIX** - correct the URL, description, type, focus or block placement in the data module. Add a column F note on the row saying what changed and why.
- **Unverifiable** - keep the row but add `VERIFY BEFORE PUBLISH: <what needs confirming>` to column F.
- **Missing** - if the audit surfaced a qualifying organization that was missed, research it to the normal standard and add it.

Then rebuild:

```bash
python3 scripts/build_city.py city_data_<city>.py
```

Update `TAB_NOTE` with the audit date so the reviewer knows when the file was last verified.

## Step 5 - Report

Tell the user plainly what the audit changed: rows removed and why, URLs corrected, descriptions fixed, anything still carrying a flag. If the audit found nothing, say so, but treat that as a reason to double-check rather than a clean bill of health.
