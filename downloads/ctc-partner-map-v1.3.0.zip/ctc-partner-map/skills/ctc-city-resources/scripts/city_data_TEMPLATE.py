# -*- coding: utf-8 -*-
"""
City data module for the CTC city resource workbook.

Copy to city_data_<city>.py, fill in, then:
    python3 build_city.py city_data_<city>.py

Entry format for every data row, as a tuple:
    (Organization, Type, Focus Area, Description, Website)
or, when the row needs a reviewer note in column F:
    (Organization, Type, Focus Area, Description, Website, "reviewer note")

All five of the first fields are required. A blank one is a defect and the QA
step will catch it.

No em dashes anywhere. No fund sizes, dollar amounts, percentages, cohort
counts, or "over N companies" figures in any description - the copy has to stay
timeless so the workbook does not need maintenance.

Every description: 3 to 4 sentences, warm and operator-oriented, closing on
"Suits [founder type]."
"""

CITY = "Houston"

# One line under the title. Optional but keep it if there is anything worth saying
# about scope.
SUBTITLE = ("Organizations based in the Houston metro that support early-stage "
            "climate startups.")

# Optional note pinned to the title row in column F, for the reviewer.
TAB_NOTE = ("NEW TAB. Metro scope: Houston city proper plus Harris and Fort Bend "
            "counties. All entries verified active with dated evidence.")

# Optional per-block reviewer notes, keyed by block name. This is where excluded
# organizations get documented so the reviewer can see judgment, not just results.
SECTION_NOTES = {
    # "CAPITAL": "Excluded: Example Fund (growth-stage only); Other Fund (HQ Austin, no Houston office).",
    # "INDUSTRY_PARTNERS": "Short by design. Most local majors have sustainability commitments but no startup vehicle. Pending a later pass.",
}


# ---------------------------------------------------------------------------
# Block 1: Universities & Research Institutions - Programs & Centers
# Grouped by institution. The entry is the PROGRAM, not the university.
# ---------------------------------------------------------------------------
UNIVERSITIES = [
    {
        "group": "Rice University",
        "rows": [
            # ("Rice Alliance for Technology and Entrepreneurship",
            #  "University program",
            #  "Energy and climate venture support",
            #  "Three to four sentences. ... Suits [founder type].",
            #  "https://example.edu/program"),
        ],
    },
]


# ---------------------------------------------------------------------------
# Block 2: Incubators & Accelerators
# Cohort programs, venture builders, lab-access programs.
# ---------------------------------------------------------------------------
INCUBATORS = [
    # ("Org name", "Accelerator", "Focus phrase",
    #  "Three to four sentences. ... Suits [founder type].",
    #  "https://example.org"),
]


# ---------------------------------------------------------------------------
# Block 3: Startup Resources & Public Programs
# Agencies, economic development bodies, non-profit support organizations.
# Each must run something a startup can actually apply to or enter.
# ---------------------------------------------------------------------------
STARTUP_RESOURCES = [
]


# ---------------------------------------------------------------------------
# Block 4: Industry Partners
# Corporates and utilities running a DEDICATED early-stage climate startup
# vehicle. Usually the hardest block to fill honestly. Leave it short rather
# than admitting a large local company that has no actual door.
# ---------------------------------------------------------------------------
INDUSTRY_PARTNERS = [
]


# ---------------------------------------------------------------------------
# Block 5: Capital Partners
# Firms whose PRIMARY business is writing venture checks, based in the metro,
# investing in climate at early stage. Not accelerators, not agencies, not
# green banks, not project lenders, not fund-of-funds. Be comprehensive.
# ---------------------------------------------------------------------------
CAPITAL = [
]


# ---------------------------------------------------------------------------
# City narrative: 300 to 500 words.
# Researched independently, not a summary of the roster above. Show rather than
# announce. No em dashes, no volatile figures. Close on the honest gap.
# Separate paragraphs with a blank line.
# ---------------------------------------------------------------------------
NARRATIVE = """First paragraph opens on something concrete and specific to the place.

Second paragraph covers the industrial and institutional substrate.

Third paragraph covers what that means for a founder building there.

Closing paragraph names the honest gap."""
