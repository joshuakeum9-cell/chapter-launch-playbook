#!/usr/bin/env python3
"""
Extract the roster from a built CTC city workbook as a numbered audit checklist.

Usage:
    python3 extract_for_audit.py /mnt/user-data/outputs/CTC_City_Resources_Houston.xlsx

Reads back from the SHIPPED FILE rather than from the data module, so the audit
tests what actually got written. Paste the output into the audit prompt in
references/audit-pass.md.
"""

import sys
import re
from collections import Counter

import openpyxl

SECTION = 'FF0F6E6E'
SUBHEAD = 'FFBBD3D1'
COLHDR = 'FFD9E2E1'
DATA = 'FFDCE6F1'


def fill_of(cell):
    try:
        return cell.fill.fgColor.rgb if cell.fill.fill_type else None
    except Exception:
        return None


def main(path):
    wb = openpyxl.load_workbook(path)
    city = wb.sheetnames[0]
    ws = wb[city]

    rows = []
    block = None
    institution = None

    for r in range(1, ws.max_row + 1):
        a = ws.cell(r, 1)
        if a.value is None:
            continue
        f = fill_of(a)
        if f == SECTION:
            block = re.sub(r'\s*\(.*?\)\s*$', '', str(a.value)).strip()
            institution = None
            continue
        if f == SUBHEAD:
            institution = str(a.value).strip()
            continue
        if f == COLHDR or str(a.value) in ('Organization', 'Program / Center'):
            continue
        if f != DATA:
            continue
        rows.append({
            'row': r,
            'block': block,
            'institution': institution,
            'org': str(a.value).strip(),
            'type': ws.cell(r, 2).value,
            'focus': ws.cell(r, 3).value,
            'desc': str(ws.cell(r, 4).value or '').strip(),
            'url': ws.cell(r, 5).value,
        })

    print(f'AUDIT CHECKLIST - {city}')
    print(f'source file: {path}')
    print(f'{len(rows)} entries\n')

    for i, e in enumerate(rows, start=1):
        loc = f"{e['block']}" + (f" / {e['institution']}" if e['institution'] else '')
        print(f"{i}. {e['org']}")
        print(f"   Block: {loc}")
        print(f"   Type: {e['type']}  |  Focus: {e['focus']}")
        print(f"   URL: {e['url']}")
        print(f"   Description as published: {e['desc']}")
        print()

    print('-' * 62)
    per_block = Counter(e['block'] for e in rows)
    for b, n in per_block.items():
        print(f'  {b:<52} {n:>3}')
    print(f'  {"TOTAL":<52} {len(rows):>3}')

    # cheap structural sanity checks worth surfacing before the audit runs
    flags = []
    seen = {}
    for e in rows:
        key = (e['block'], e['org'].lower())
        if key in seen:
            flags.append(f"duplicate in block: {e['org']} (rows {seen[key]}, {e['row']})")
        seen[key] = e['row']
        if not e['url'] or not str(e['url']).startswith('https://'):
            flags.append(f"URL not https: {e['org']} -> {e['url']}")
        if not e['desc']:
            flags.append(f"blank description: {e['org']}")

    domains = Counter()
    for e in rows:
        m = re.match(r'https?://([^/]+)', str(e['url'] or ''))
        if m:
            domains[m.group(1).lower().replace('www.', '')] += 1
    for d, n in domains.items():
        if n > 3:
            flags.append(f"{n} entries share domain {d} - confirm these are distinct vehicles")

    if flags:
        print('\nPre-audit flags:')
        for f in flags:
            print(f'  ! {f}')
    print('\nPaste the numbered list above into the audit prompt in '
          'references/audit-pass.md.')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit('usage: extract_for_audit.py <workbook.xlsx>')
    main(sys.argv[1])
