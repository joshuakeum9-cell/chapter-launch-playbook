---
name: ctc-city-resources
description: Research a city's climate tech ecosystem and produce the standard Climate Tech Cities resource workbook for it - a formatted .xlsx with the five-block city tab (Universities & Research Institutions, Incubators & Accelerators, Startup Resources & Public Programs, Industry Partners, Capital Partners) plus a City Narratives sheet. Use this skill whenever the user names a city and wants its resources, chapter resources, ecosystem list, or resource spreadsheet built - including bare invocations like "Houston", "do Berlin", "add Toronto", "new chapter for Denver", or any request to research climate orgs, accelerators, incubators, universities, industry partners, or capital partners for a city page or Squarespace chapter page. Always use this skill even if the user only asks for one section, one block, or "just a quick list". Do NOT use it for events, calendars, or newsletters - those belong to the harvest and source-map skills.
---

# CTC City Resources

Produce the Climate Tech Cities resource workbook for one city: a researched, verified, founder-facing roster of the organizations that actually help early-stage climate startups there, rendered as a formatted `.xlsx`.

## Input

A city name. That is all that is required. `Houston`, `Berlin`, `Toronto`, `Singapore`.

Nothing is uploaded. The user does not hand over a workbook, a source list, or prior research. Everything in the output comes from research run inside this skill.

## Output

One standalone `.xlsx` named `CTC_City_Resources_<City>.xlsx`, containing exactly two sheets:

1. **`<City>`** - the five-block resource tab
2. **`City Narratives`** - the 300 to 500 word city narrative

Always deliver the actual file. Research notes, markdown summaries, and tables in chat are inputs to the job, not the job. Historically the single most common failure on this project was producing beautiful research and never writing the spreadsheet. If the turn ends without an `.xlsx` in `/mnt/user-data/outputs/` presented via `present_files`, the task is not done.

---

## The bar

The workbook is finished when a founder who has built in that city could read it without naming an obvious omission, and without spotting a single entry that does not belong.

Both halves matter equally. A missing organization costs the reader one opportunity. A wrong organization costs the workbook its credibility, because the reader who spots one assumes the rest are unchecked too.

---

## Read these first

Three reference files carry the detail. Read all three before starting - they are short, and each one encodes corrections that cost real rework to learn.

| File | What it holds | When |
|---|---|---|
| `references/inclusion-rules.md` | The locality rule, the qualification bar, block definitions, worked examples of what was cut and why | Before research. This is the most important file |
| `references/research-brief.md` | The exact research prompts for both passes, and the verification standard | Before launching research |
| `references/editorial-style.md` | Description voice and shape, narrative voice, the banned constructions | Before writing any prose |
| `references/audit-pass.md` | The post-build re-verification stage and its prompt | At Step 8, after the file exists |

`scripts/build_city.py` renders the workbook. `scripts/city_data_TEMPLATE.py` is the data file to fill in. `scripts/extract_for_audit.py` reads a built workbook back out as an audit checklist. Do not hand-roll openpyxl formatting - the build script already encodes the fills, widths, merges, freeze panes, and row-height math that match the existing chapters.

---

## Step 0 - Ask how they want to start

**Always ask this first. Never start researching without it.**

The user may already know organizations that belong here. A name a real person vouched for is better than anything research returns, and skipping this question is how a skill produces a list that misses the obvious.

Ask in one message and wait:

> Before I start, how do you want to do this?
>
> **A. You give me some, then I research too.** Paste anything you already know and I verify it, then run the full search on top. Best coverage, and what I would recommend.
>
> **B. You give me all of them.** I verify what you paste and stop there. Fastest, and a fair choice if you already know the scene.
>
> **C. I research everything.** Nothing needed from you. I find them and bring back a verified list to review.
>
> Paste what you have straight into your reply and I will take that as option A, or just tell me which you want.

**If they paste names or links in their first message, take that as A and get on with it.** Do not make someone pick from a menu when they have already answered.

**Whatever they give you is a candidate, not an entry.** It goes through the same verification as anything found by research. When one fails a check, name the check it failed rather than dropping it silently, and let them decide whether to keep it anyway. They know the place and the research does not.

On option B, verify and stop. Do not quietly run the research pass anyway.

## Step 1 - Fix the metro scope

Before searching, decide out loud what counts as "in the city", and say so to the user in one line.

The rule is a genuine physical base: headquarters, or a real staffed office where people go to work. Not a mailing address, not a partner firm, not "serves the region", not a national organization with a local chapter page.

Metro areas count when the ecosystem genuinely functions as one, but name the actual municipality in the entry so nobody is misled. Precedents from existing chapters:

- **Washington DC** = DC proper + Northern Virginia + suburban Maryland. Deliberate, after the DMV question was settled explicitly.
- **Chicago** = Chicagoland, with Evanston, Lemont, Naperville named as such.
- **Amsterdam** = Amsterdam Metropolitan Area, with Haarlem, Haarlemmermeer, Amstelveen named as such.
- **Boston** = Greater Boston, which is how MIT and Cambridge organizations qualify.

Do not silently widen scope to fill a thin block. A short honest roster is the correct output when the city is genuinely thin; padding is not.

## Step 2 - Research pass one: discovery

Use an extended or deep research tool if the session has one. It is the right instrument for this, and it does not need asking about first: it is doing the job that was requested, not a new one. Where none is available, run the equivalent as a long series of `web_search` and `web_fetch` calls, twenty-five or more, not five.

Two environment notes. `openpyxl` is required by the build and audit scripts, and `pip install openpyxl --break-system-packages -q` installs it. The sandbox reaches an allowlist of package registries only, so `curl` and `requests` fail on arbitrary sites and fail in ways that look like the site being down. Use the fetch tool for anything on the open web.

Use the discovery prompt in `references/research-brief.md` verbatim, substituting the city and metro scope. It is written to return the fields the data file needs, with dated evidence attached to every candidate.

Cast wide here. Over-collect deliberately, because pass two is where things get cut, and it is far easier to reject a candidate than to notice an absence.

## Step 3 - Research pass two: verification and deepening

Never skip this. Two passes is the floor, not the target.

Pass two does two jobs at once, and the prompt in `references/research-brief.md` covers both:

- **Verify** every candidate from pass one against the four checks: still active with dated evidence, canonical working URL, genuine local physical base, correct block placement and qualification.
- **Deepen** the blocks that came back thin, hunting specifically for the categories generalist searches miss: corporate venture arms of local industrials, university commercialization and venture funds, city and state agency startup programs, sector-specific funds, angel groups with a real climate thesis, national lab or research institute spinout programs.

Run a third pass when pass two leaves a block visibly thinner than the ecosystem should support. The instruction is exhaustive within the constraints, so keep going until the searches stop returning new qualifying names.

Then apply `references/inclusion-rules.md` strictly and cut. Expect to cut a lot. Record every cut with its reason - those become the section-header reviewer notes.

## Step 4 - Build the data file

Copy `scripts/city_data_TEMPLATE.py`, fill it in, and keep it as a real Python module. The modular pattern of data file plus shared renderer is what makes revisions cheap; monolithic build scripts have repeatedly proved painful on this project.

Every entry needs all five fields populated. A row with a website and no description, or a name and nothing else, is a defect - a past workbook shipped with orphaned URL-only rows and it was noticed immediately.

Write descriptions per `references/editorial-style.md`. Three to four sentences, warm and operator-oriented, no em dashes, no volatile figures, closing on `Suits [founder type].`

## Step 5 - Write the narrative

A 300 to 500 word narrative for the city, per the voice rules in `references/editorial-style.md`. Research it independently rather than summarizing the roster - the narrative is about the city's industrial DNA and character, not a list of its accelerators.

Timeless. No funding figures, no dated statistics, no current policy numbers. Show rather than announce.

## Step 6 - Render

```bash
cd <workdir> && python3 scripts/build_city.py city_data_<city>.py
```

The script writes to `/mnt/user-data/outputs/CTC_City_Resources_<City>.xlsx` and prints a structural summary plus a QA report.

## Step 7 - QA gate

The build script runs these automatically and prints failures. Read the output rather than assuming it passed.

- Zero blank cells in columns A through E on any data row
- Zero em dashes anywhere in the workbook
- Zero volatile figures in descriptions (currency amounts, percentages, "over N companies", fund sizes, AUM, cohort counts)
- Every description ends with a `Suits ...` sentence
- Every description is three to six sentences
- Every URL is well-formed and starts with `https://`
- No duplicate organization within a block
- Narrative is 300 to 500 words

Two checks the script cannot make, so make them by hand before delivering:

- **Locality.** Walk the roster and ask of each entry: would a local say this organization is based here? This is the check that has failed most often.
- **Qualification.** Ask of each: does this run a dedicated vehicle for early-stage climate startups, or did it get in on reputation?

## Step 8 - Audit the built workbook

A full re-verification pass, run against the file rather than against the research notes, and treated as adversarial. Read `references/audit-pass.md` and follow it.

This is not optional and it is not a formality. The earlier passes verified candidates; this one verifies what actually shipped, which is where transcription errors, stale URLs and quietly-closed programs survive. Every entry gets five checks: does the organization still exist, does the specific named program still run, does the URL resolve to the canonical site, is there a genuine physical base in the metro, and is the published description still accurate.

The sequence:

```bash
python3 scripts/extract_for_audit.py /mnt/user-data/outputs/CTC_City_Resources_<City>.xlsx
```

Feed that checklist into the audit prompt, spot-check URLs directly with `web_fetch` (`bash` cannot reach arbitrary domains, so `curl` will fail), apply removals and fixes to the data module, then rebuild with `build_city.py`.

Approach it as though someone else compiled the list and you have been asked to find what is wrong with it. An audit that changes nothing usually means the audit was weak, not that the file was perfect.

## Step 9 - Deliver

Call `present_files` on the `.xlsx`. Then, in a few lines: the row count per block, what the audit changed, anything cut and why, and anything carrying a `VERIFY BEFORE PUBLISH` flag.

Keep it short. No preamble, no restating the method.

## Step 10 - Hand off to the partner map

This skill ships inside the `ctc-partner-map` plugin. The workbook is the input to the second stage, so do not end the turn without offering the handoff.

Say, in about this shape:

> That is the resource workbook. Next it becomes a partner outreach plan: who to approach, what to ask for first, and in what order.
>
> You know this city better than the research does. Open the workbook and change whatever is wrong. Cut anything that has quietly closed or that a local would not recognize. Add anything obvious that is missing. Then upload the edited file back here and say `/ctc-partner-list`.
>
> If you would rather not edit it, say "use it as is" and I will run on this version.

Three rules for the handoff:

**The edit is optional and must never block.** If the user says use it as is, proceed on the unedited file immediately. Do not ask twice.

**Say what to look for, not just "edit this."** A lead who has lived in the city for five years will cut two organizations that closed and add three that no search surfaces. Naming that is what gets the edit done.

**Never revise the workbook conversationally on their behalf.** If they describe changes in chat instead of editing the file, make the changes in the data module and rebuild with `build_city.py` so the shipped file and the roster never disagree.

---

## Common failure modes

These are the specific mistakes this project has actually made. Each one shipped and had to be corrected.

**Listing organizations that serve everywhere.** The original workbook was full of national programs with no particular tie to the city. If it is equally available to a founder in Denver and a founder in Atlanta, it is not a city resource. Removed on these grounds: SJF Ventures and Elemental Impact from DC, Carbon13 from US tabs, 8090 Industries and Aera VC from LA, Osage University Partners from Boston.

**Admitting organizations on reputation.** A famous utility, a famous university, a famous VC. The question is never prominence, it is whether a founder can walk through a door. Removed on these grounds: SCE, LADWP, SoCalGas, PG&E, SDG&E, PSE, PACCAR, Boeing, Madrona, Tech Coast Angels, Correlation Ventures, Revolution, Qualcomm Ventures.

**Padding to hit a number.** Chicago Capital Partners stopped at six because six were real. Reaching eight would have meant admitting two that did not belong. Honest gaps beat filler, always.

**Confusing Capital Partners with everything financial.** Capital Partners means firms whose primary business is writing venture checks. Not accelerators that also invest, not state agencies, not green banks, not project lenders. MEIA's Climate Technology Founders Fund was rejected on exactly this ground.

**Shipping research instead of the file.** Covered above, and worth repeating because it happened more than once.

**Volatile copy.** Fund sizes and cohort counts read as authoritative and go stale within months, at which point every entry needs revisiting. Keep the copy timeless so the workbook does not require maintenance.

**Declarative narrative prose.** "What makes Houston distinctive is its industrial depth" announces the point instead of making it. Show the reader the refineries and the port and let them arrive at it.
