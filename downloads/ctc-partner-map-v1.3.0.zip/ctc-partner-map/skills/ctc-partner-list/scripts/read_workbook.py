#!/usr/bin/env python3
"""
Read a CTC city resource workbook back out as a partner-map working roster.

Usage:
    python3 read_workbook.py /path/to/CTC_City_Resources_<City>.xlsx

Reads the SHIPPED FILE, not a data module, so it picks up whatever the chapter
lead edited by hand. Three things come out:

1. The roster. Every organization, with its block, type, focus, URL, and the
   description as published.
2. Rows the lead appears to have ADDED by hand. These do not carry the
   renderer's fill color, so they are detected structurally and reported
   separately. They must never be dropped. See the never-drop rule in
   references/gap-research.md.
3. The reviewer notes in column F. This is where ctc-city-resources records the
   organizations it EXCLUDED and why. Those exclusions are the most valuable
   input the partner map gets, because a resource workbook and a partner list
   apply different bars, and several organizations cut from one belong in the
   other.

Nothing here decides anything. It reads.

WHY THE FALLBACK EXISTS
Detection was originally by fill color alone. That breaks silently whenever the
lead round-trips the file through Google Sheets, saves it from a different Excel
build, or adds rows by typing into the sheet, because none of those carry the
renderer's exact ARGB fills. The failure looked like a clean run returning an
empty roster. Now: color first, structure second, and the script says which
path it used and refuses to look successful when it found nothing.
"""

import sys
import re
from collections import Counter

import openpyxl

SECTION = 'FF0F6E6E'
SUBHEAD = 'FFBBD3D1'
COLHDR = 'FFD9E2E1'
DATA = 'FFDCE6F1'

HEADER_WORDS = {'organization', 'program / center', 'program/center', 'type',
                'focus', 'description', 'website', 'reviewer notes', 'notes'}


def fill_of(cell):
    try:
        return cell.fill.fgColor.rgb if cell.fill.fill_type else None
    except Exception:
        return None


def looks_like_data(ws, r):
    """Structural test, used for rows the renderer did not fill.

    A data row has a name in column A and content in at least two of the type,
    focus, description, website columns. Section headers and column headers
    fail both halves.
    """
    a = ws.cell(r, 1).value
    if a is None or not str(a).strip():
        return False
    if str(a).strip().lower() in HEADER_WORDS:
        return False
    filled = sum(1 for c in (2, 3, 4, 5)
                 if ws.cell(r, c).value not in (None, ''))
    return filled >= 2


def main(path):
    wb = openpyxl.load_workbook(path)
    city = wb.sheetnames[0]
    ws = wb[city]

    rows = []
    notes = []
    unformatted = []
    block = None
    institution = None

    for r in range(1, ws.max_row + 1):
        a = ws.cell(r, 1)
        note = ws.cell(r, 6).value
        if note and str(note).strip():
            notes.append((block or 'TITLE', str(note).strip()))
        if a.value is None:
            continue
        f = fill_of(a)
        if f == SECTION:
            block = re.sub(r'\s*\(.*?\)\s*$', '', str(a.value)).strip()
            institution = None
            continue
        if f == SUBHEAD:
            institution = str(a.value).strip()
            continue
        if f == COLHDR or str(a.value) in ('Organization', 'Program / Center'):
            continue

        origin = None
        if f == DATA:
            origin = 'workbook'
        elif looks_like_data(ws, r):
            # No renderer fill but the row is shaped like data. Either the lead
            # typed it in, or the file lost its formatting in a round trip.
            origin = 'unformatted'
        if origin is None:
            continue

        entry = {
            'row': r,
            'block': block,
            'institution': institution,
            'org': str(a.value).strip(),
            'type': ws.cell(r, 2).value,
            'focus': ws.cell(r, 3).value,
            'desc': str(ws.cell(r, 4).value or '').strip(),
            'url': ws.cell(r, 5).value,
            'origin': origin,
        }
        rows.append(entry)
        if origin != 'workbook':
            unformatted.append(entry)

    print(f'PARTNER MAP INPUT - {city}')
    print(f'source file: {path}')
    print(f'{len(rows)} organizations on the roster')
    if unformatted:
        print(f'{len(unformatted)} of them carry no renderer formatting')
    print()

    for i, e in enumerate(rows, start=1):
        loc = f"{e['block']}" + (f" / {e['institution']}" if e['institution'] else '')
        flag = '   <- NO RENDERER FORMATTING' if e['origin'] != 'workbook' else ''
        print(f"{i}. {e['org']}{flag}")
        print(f"   Block: {loc}")
        print(f"   Type: {e['type']}  |  Focus: {e['focus']}")
        print(f"   URL: {e['url']}")
        print(f"   Published description: {e['desc']}")
        print()

    print('-' * 62)
    per_block = Counter(str(e['block']) for e in rows)
    for b, n in per_block.items():
        print(f'  {b:<52} {n:>3}')
    print(f'  {"TOTAL":<52} {len(rows):>3}')

    if not rows:
        print()
        print('=' * 62)
        print('NO ROWS FOUND. DO NOT PROCEED AS THOUGH THE CITY IS THIN.')
        print('=' * 62)
        print('This almost always means the file is not a CTC resource workbook,')
        print('or the first sheet is not the city tab. Check, in this order:')
        print('  1. Is sheet one the city tab rather than City Narratives?')
        print('  2. Was the file exported from Google Sheets or another tool?')
        print('  3. Open it and confirm there are organizations in it at all.')
        print('Ask the user before doing anything else. Never fill the gap with')
        print('research of your own, and never report a small map as a finding')
        print('about the ecosystem when the reader is what failed.')
        sys.exit(2)

    if unformatted:
        print()
        print('=' * 62)
        print('ROWS WITHOUT RENDERER FORMATTING')
        print('=' * 62)
        print('Most likely typed in by the chapter lead, which makes them the')
        print('highest-signal entries in the file. They live in that city and')
        print('the research does not.')
        print('Check them like anything else, and NEVER drop one silently. If a')
        print('check fails, keep the entry, name the failed check in its note,')
        print('and say so at delivery.')
        print('If EVERY row is unformatted, the file was round tripped through')
        print('another tool and none of this indicates lead edits.')
        for e in unformatted:
            print(f"  row {e['row']}: {e['org']}")

    if notes:
        print()
        print('=' * 62)
        print('REVIEWER NOTES AND RECORDED EXCLUSIONS')
        print('Reconsider every excluded organization against the PARTNER bar')
        print('in references/partner-bar.md. The resource bar asks whether a')
        print('founder can walk through the door. The partner bar asks whether')
        print('they would co-host, host, or send their people. Organizations')
        print('cut for being national, or for getting in on reputation, very')
        print('often pass the second test.')
        print('=' * 62)
        for blk, n in notes:
            print(f'\n[{blk}]\n  {n}')
    else:
        print()
        print('No reviewer notes found. Either the workbook predates the notes')
        print('convention or nothing was recorded as excluded. Say which you')
        print('think it is at delivery, because Step 2 is the cheapest yield in')
        print('this skill and running without it changes what the map can claim.')

    print('\nNext: read references/partner-bar.md, then run the gap research '
          'for the four categories a resource workbook does not cover.')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit('usage: read_workbook.py <workbook.xlsx>')
    main(sys.argv[1])
