# -*- coding: utf-8 -*-
"""
WORKED EXAMPLE. Illustrative only. NOT verified data.

This is a filled-in partner data module for Houston, written to show density,
voice, and the shape of every field. It is here to calibrate against, not to
copy into a live deliverable.

The organizations are real and the categories and routes are plausible. Nothing
in it has been through the four checks in references/partner-bar.md, so the
asks, contact routes, and tier placements are invented for illustration. If you
are actually building the Houston map, research it and throw this away.

Run it to see what the renderer produces and what the QA gate says:

    python3 build_partners.py partner_data_EXAMPLE.py

The commentary on why each entry is written the way it is lives in
references/worked-example.md. Read that alongside this file.
"""

CITY = "Houston"

SUBTITLE = ("Organizations to approach for the Climate Tech Houston chapter, "
            "ordered by when to approach them.")

TAB_NOTE = ("WORKED EXAMPLE, not verified data. Built from "
            "CTC_City_Resources_Houston.xlsx as edited by the chapter lead, "
            "plus gap research on the four categories a resource workbook does "
            "not cover.")

CATEGORIES = [
    "Accelerators and incubators",
    "Universities and research centers",
    "Capital",
    "Civic and government",
    "Corporates and industry",
    "Coworking and innovation districts",
    "Professional and affinity groups",
    "Nonprofits and advocacy",
    "Arts, culture, and civic venues",
]

# ---------------------------------------------------------------------------
# TIER 1 - approach in the first 30 days.
# Can host or co-host now, audience overlaps directly, contact route is visible.
# Nine here. Every one of the four gap categories is represented, which is the
# test that Step 3 was actually run.
# ---------------------------------------------------------------------------
TIER_1 = [
    {
        "org": "Greentown Labs Houston",
        "category": "Accelerators and incubators",
        "why": "Their member companies are the founders we want in the room, "
               "and the building has event space they already open to outside "
               "groups.",
        "ask": "Co-host our launch mixer in your event space on a weeknight in "
               "October.",
        "contact": "Community or events team, via the contact form on the "
                   "Houston page",
        "url": "https://greentownlabs.com/houston/",
        "source": "workbook",
        "note": "",
    },
    {
        "org": "Ion District",
        "category": "Coworking and innovation districts",
        "why": "They publish a public events calendar with an open submission "
               "form, so they are set up to carry our listings from week one.",
        "ask": "Add our monthly meetup to the Ion events calendar and let us "
               "book a room for the first one.",
        "contact": "Calendar submission form on the events page",
        "url": "https://iondistrict.com/",
        "source": "gap research",
        "note": "Submission form is for listings, not room booking. Two "
                "separate asks in one email.",
    },
    {
        "org": "Rice Alliance for Technology and Entrepreneurship",
        "category": "Universities and research centers",
        "why": "They convene the founder and investor side of this city on a "
               "recurring basis and their audience is ours a year earlier.",
        "ask": "Put our chapter lead on a panel at your next energy venture "
               "event.",
        "contact": "Named program director listed on the Rice Alliance team "
                   "page",
        "url": "https://alliance.rice.edu/",
        "source": "workbook",
        "note": "",
    },
    {
        "org": "Houston Renewable Energy Group",
        "category": "Professional and affinity groups",
        "why": "They already assemble the exact audience we want on a "
               "recurring meeting schedule, and they meet at rotating venues "
               "rather than defending one of their own.",
        "ask": "Co-host one of your monthly meetings as a joint session with "
               "our chapter.",
        "contact": "Contact form on the site. Do not use the published inbox "
                   "address",
        "url": "https://houstonrenewableenergy.org/",
        "source": "gap research",
        "note": "",
    },
    {
        "org": "CenterPoint Energy",
        "category": "Corporates and industry",
        "why": "A founder cannot raise from a utility, which is why the "
               "workbook cut them, but they will put a grid person on a panel "
               "and that is the talk this city turns out for.",
        "ask": "Provide a speaker on grid interconnection for our first "
               "quarterly panel.",
        "contact": "Community relations, via the corporate responsibility page",
        "url": "https://www.centerpointenergy.com/",
        "source": "reconsidered",
        "note": "Cut upstream as reputation-only admission. Passes the partner "
                "bar on speaker access.",
    },
    {
        "org": "Bayou City Waterkeeper",
        "category": "Nonprofits and advocacy",
        "why": "Water and flooding is the climate conversation this city "
               "actually has, and their members show up for it in numbers "
               "climate tech events do not reach.",
        "ask": "Send a speaker to our first event and share the launch issue "
               "with your list.",
        "contact": "General contact form on the site",
        "url": "https://bayoucitywaterkeeper.org/",
        "source": "gap research",
        "note": "",
    },
    {
        "org": "Houston Public Library",
        "category": "Arts, culture, and civic venues",
        "why": "Free meeting rooms across the city and a walk-in audience that "
               "is exactly the readers who are curious about climate work but "
               "not yet in it.",
        "ask": "Book a meeting room for a free introductory climate careers "
               "evening.",
        "contact": "Meeting room reservation form on the library site",
        "url": "https://houstonlibrary.org/",
        "source": "gap research",
        "note": "",
    },
    {
        "org": "Houston Advanced Research Center",
        "category": "Universities and research centers",
        "why": "Independent research shop with its own convening habit, and "
               "its staff are the people our readers most want to hear from.",
        "ask": "Host a joint evening session at your campus in The Woodlands.",
        "contact": "Events contact listed on the HARC site",
        "url": "https://harcresearch.org/",
        "source": "workbook",
        "note": "Based in The Woodlands, not Houston proper. Inside the metro "
                "scope, named so nobody is misled.",
    },
    {
        "org": "Cup of Joey",
        "category": "Professional and affinity groups",
        "why": "A standing weekly founder gathering the lead already attends, "
               "and a warm room to make the chapter's first introductions in.",
        "ask": "Introduce the chapter from the front at one Friday session.",
        "contact": "Warm path. The lead already attends",
        "url": "https://www.cupofjoey.com/",
        "source": "lead added",
        "note": "KEPT DESPITE A FAILED CHECK. No published partnerships route, "
                "so check four fails on the research. The lead knows the "
                "organizer personally and asked to keep it.",
    },
]

# ---------------------------------------------------------------------------
# TIER 2 - approach at 60 to 90 days.
# Useful, but wants a warm introduction or a track record first.
# ---------------------------------------------------------------------------
TIER_2 = [
    {
        "org": "Houston Museum of Natural Science",
        "category": "Arts, culture, and civic venues",
        "why": "Their public programming reaches the general-audience readers "
               "no climate tech event reaches, and one joint night would be "
               "the chapter's widest room of the year.",
        "ask": "Co-present one evening in your public lecture series.",
        "contact": "Public programs team, via the education contact page",
        "url": "https://www.hmns.org/",
        "source": "gap research",
        "note": "Programs are planned far ahead. Approach early even though "
                "the event lands late.",
    },
    {
        "org": "Halliburton Labs",
        "category": "Corporates and industry",
        "why": "Their cohort founders are ours, but a corporate program will "
               "want to see the chapter running before it lends its name.",
        "ask": "Send your cohort founders to our monthly meetup, then talk "
               "about co-hosting a demo night.",
        "contact": "Program contact listed on the Halliburton Labs site",
        "url": "https://halliburtonlabs.com/",
        "source": "workbook",
        "note": "",
    },
    {
        "org": "Houston Parks Board",
        "category": "Civic and government",
        "why": "Bayou infrastructure is the most legible climate adaptation "
               "story in the city and a walking tour would be our most "
               "distinctive listing.",
        "ask": "Lead a bayou resilience walking tour for our members in "
               "spring.",
        "contact": "Community engagement, via the contact page",
        "url": "https://houstonparksboard.org/",
        "source": "gap research",
        "note": "",
    },
    {
        "org": "Rice University Office of Innovation",
        "category": "Universities and research centers",
        "why": "Campus access needs a sponsor inside the university, and Rice "
               "Alliance is the introduction that gets us one.",
        "ask": "Introduce us to the student sustainability groups you work "
               "with.",
        "contact": "Warm path via Rice Alliance",
        "url": "https://innovation.rice.edu/",
        "source": "gap research",
        "note": "",
    },
]

# ---------------------------------------------------------------------------
# TIER 3 - later.
# Real, but slow, large, or currently out of reach. Kept short on purpose.
# ---------------------------------------------------------------------------
TIER_3 = [
    {
        "org": "Port Houston",
        "category": "Civic and government",
        "why": "The single most interesting site visit in the region, and the "
               "one that will take a year of relationship to earn.",
        "ask": "Explore a member site visit once the chapter has a track "
               "record.",
        "contact": "Community relations, via the public affairs page",
        "url": "https://porthouston.com/",
        "source": "gap research",
        "note": "Public agency. Expect a long approval path.",
    },
    {
        "org": "City of Houston Mayor's Office of Sustainability",
        "category": "Civic and government",
        "why": "City endorsement would carry weight with every other partner, "
               "and city offices answer chapters that already exist.",
        "ask": "Have a staff member speak once the chapter has published for a "
               "quarter.",
        "contact": "General office contact on the city site",
        "url": "https://www.houstontx.gov/",
        "source": "workbook",
        "note": "",
    },
]

# ---------------------------------------------------------------------------
# NOT APPROACHING - considered and set aside, with the reason.
# This sheet is why the lead trusts the other three. Format:
#     ("Organization", "Reason in one line")
# ---------------------------------------------------------------------------
NOT_APPROACHING = [
    ("Houston Botanic Garden",
     "Event spaces are rental only with a minimum spend. A venue option, not a "
     "partner. Revisit if a sponsor covers the room."),
    ("Elemental Impact",
     "National program with no Houston staffed presence. Correctly cut "
     "upstream and it does not flip under the partner bar."),
    ("WeWork Houston locations",
     "Space is bookable but there is no local programming counterpart, so the "
     "realistic outcome is a room invoice."),
    ("Texas Energy Founders Meetup",
     "Runs the same weeknight slot and has no reason to send people to us. "
     "Worth registering as an event source, not as a partner."),
    ("Regional office of a national engineering firm",
     "Would be a logo on a slide and nothing else. No public programming, no "
     "member list, no venue."),
]
