# -*- coding: utf-8 -*-
"""
Partner data module for the CTC partner map.

Copy to partner_data_<city>.py, fill in, then:
    python3 build_partners.py partner_data_<city>.py

BEFORE FILLING THIS IN, read references/worked-example.md and look at
partner_data_EXAMPLE.py, which is this file filled in for one city and passes
the QA gate. An empty template plus a field name is not enough to write a good
entry from, and the example carries weak-against-strong versions of every field.
The example is illustrative and unverified. Never carry its content into a real
city.

Entry format for every partner, as a dict. All eight keys are required.

    {
      "org":      "Organization name",
      "category": "One of the CATEGORIES list below",
      "why":      "One line. Why this organization, for this chapter.",
      "ask":      "What to ask for FIRST. One concrete thing.",
      "contact":  "A publicly findable named person or role, OR a general "
                  "route such as 'events form on site', OR 'warm intro via X'. "
                  "NEVER an invented name and NEVER an email address.",
      "url":      "https://...",
      "source":   "workbook" | "reconsidered" | "gap research" | "lead added",
      "note":     "Optional. Reviewer note, or the check that failed if this "
                  "entry was kept anyway. Use empty string when there is none.",
    }

No em dashes anywhere. No fund sizes, dollar amounts, percentages, cohort
counts, or "over N companies" figures, so the file stays timeless.

"why" is one sentence and it is about THIS CHAPTER, not about the organization
in general. "Runs the largest climate founder community in the metro" is a
description. "Their monthly founder breakfast is the audience we want in the
room, and they have hosted outside groups before" is a reason.

"ask" is one concrete thing that can be said yes to in a single email. "Host
our first event" is concrete. "Explore ways to collaborate" is not.
"""

CITY = "Houston"

# One line under the title.
SUBTITLE = ("Organizations to approach for the Climate Tech Houston chapter, "
            "ordered by when to approach them.")

# Optional note pinned to the title row.
TAB_NOTE = ("Built from CTC_City_Resources_Houston.xlsx as edited by the "
            "chapter lead, plus gap research on the four categories a resource "
            "workbook does not cover.")

CATEGORIES = [
    "Accelerators and incubators",
    "Universities and research centers",
    "Capital",
    "Civic and government",
    "Corporates and industry",
    "Coworking and innovation districts",
    "Professional and affinity groups",
    "Nonprofits and advocacy",
    "Arts, culture, and civic venues",
]

# ---------------------------------------------------------------------------
# TIER 1 - approach in the first 30 days.
# Can host or co-host now, audience overlaps directly, contact route is visible.
# This is where the weight goes. Aim for 8 to 12.
# ---------------------------------------------------------------------------
TIER_1 = [
    # {
    #   "org": "", "category": "", "why": "", "ask": "",
    #   "contact": "", "url": "https://", "source": "workbook", "note": "",
    # },
]

# ---------------------------------------------------------------------------
# TIER 2 - approach at 60 to 90 days.
# Useful, but wants a warm introduction or a track record first.
# ---------------------------------------------------------------------------
TIER_2 = []

# ---------------------------------------------------------------------------
# TIER 3 - later.
# Aspirational, large, or slow moving. Real, but not a first-quarter target.
# ---------------------------------------------------------------------------
TIER_3 = []

# ---------------------------------------------------------------------------
# NOT APPROACHING - organizations considered and set aside, with the reason.
# This sheet is why the lead trusts the other three. Format:
#     ("Organization", "Reason in one line")
# ---------------------------------------------------------------------------
NOT_APPROACHING = [
    # ("Example Org", "No local staffed presence. National program only."),
]
