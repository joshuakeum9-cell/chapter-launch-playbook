---
name: ctc-partner-list
description: Turn a Climate Tech Cities city resource workbook into a partner outreach plan - a tiered list of who a chapter lead should approach, what to ask each for first, and in what order, plus the four categories a resource workbook deliberately leaves out. Use this skill whenever the user has a CTC_City_Resources workbook and wants partners, a partner map, an outreach plan, or "who should I contact in this city", or says a phrase like "now do the partner map" after the resource workbook was built. Also use it when a user asks for chapter partners, venue partners, event co-hosts, or a launch outreach list for a city. Always use it even if the user only wants one category or "just a few names to start". Do NOT use it to research a city's resources from scratch - that is ctc-city-resources, stage one of this plugin. Do NOT use it to find event calendars - that is ctc-source-map.
---

# CTC Partner List

Stage two of the `ctc-partner-map` plugin. Takes the resource workbook produced
by `ctc-city-resources`, as edited by the chapter lead, and turns it into a
partner outreach plan: who to approach, what to ask for first, and in what
order.

## What this is for

Climate Tech Cities is a network of volunteer-run city chapters. A new chapter
becomes real when it runs events and publishes a newsletter, and both depend on
partners: someone with a room, someone with an audience, someone who will put a
speaker on a panel.

The person who reads this file is a volunteer chapter lead, usually in their
first month, with a full-time job elsewhere and no background in partnerships.
The map works when they open it on a Tuesday morning, read one row, and send
that email in four minutes without having to decide anything.

That is where every rule here comes from. Tier 1 is capped because their month
is capped. Asks are concrete because a vague ask makes them compose an email
from scratch. Contact routes are researched because hunting for one is the step
where an evening dies. When you hit a case this skill does not cover, reason
from that person and that Tuesday morning.

## Input

One `.xlsx`, the resource workbook for the city, ideally edited by the lead.
Nothing else is required.

If no workbook is supplied, see Step 0. Do not start researching from scratch
here.

## Output

One standalone `.xlsx` named `CTC_Partner_Map_<City>.xlsx`, containing two
sheets:

1. **`Partners`** - three tiers, nine columns
2. **`Not approaching`** - everything considered and set aside, with the reason

**This is a separate file from the resource workbook, deliberately.** The
resource workbook is public facing and feeds the chapter page. This one carries
contact routes, approach order, and status, which is internal working state.
Never merge them and never write a partner tab into the resource file.

Always deliver the actual file. Research notes and tables in chat are inputs to
the job, not the job. If the turn ends without an `.xlsx` in
`/mnt/user-data/outputs/` presented via `present_files`, the task is not done.

---

## The bar

The map is finished when the chapter lead could send ten emails from it tomorrow
morning without having to think, and when a local reading it would not name an
obvious omission or spot a name that does not belong.

`references/worked-example.md` closes with a description of what a bad map looks
like. Read it before you deliver, not after.

---

## Read these first

All three are short and each encodes judgment that is expensive to rediscover.

| File | What it holds | When |
|---|---|---|
| `references/partner-bar.md` | The inclusion test, why it differs from the resource bar, the ruled cases, the nine categories, the workbook block mapping, tiering, asks, contacts | Before anything else. This is the most important file |
| `references/worked-example.md` | A complete filled-in map, annotated, with weak and strong versions of every field | Before writing any entry |
| `references/gap-research.md` | The research prompt for the four uncovered categories, search calibration, and the standard for verifying what the lead added | Before researching |

`scripts/read_workbook.py` reads the resource workbook back out.
`scripts/partner_data_TEMPLATE.py` is the data file to fill in.
`scripts/partner_data_EXAMPLE.py` is the same file filled in, runnable, and it
passes the QA gate. `scripts/build_partners.py` renders the workbook and runs
the gate. Do not hand-roll openpyxl formatting.

## Environment

- **Where the scripts are.** This skill installs as part of the
  `ctc-partner-map` plugin, and the install path differs between accounts. Do
  not assume one. Locate it once at the start and reuse it:

  ```bash
  SKILL=$(dirname $(find /mnt/skills -name read_workbook.py 2>/dev/null | head -1))
  echo $SKILL
  ```

- **Work in a writable directory.** The skill directory is read only. Copy the
  template out before filling it in:

  ```bash
  mkdir -p /home/claude/work && cd /home/claude/work
  cp $SKILL/partner_data_TEMPLATE.py partner_data_<city>.py
  ```

- **openpyxl** is required by both scripts. If the import fails:
  `pip install openpyxl --break-system-packages -q`
- **An extended or deep research tool**, if the session has one, is the right
  instrument for Step 3. Without one, run fifteen or more distinct searches.
- **`curl` and `requests` cannot reach arbitrary domains** from the sandbox.
  Use the fetch tool for anything on the open web. A URL never observed
  resolving has not been checked.
- **Outputs go to `/mnt/user-data/outputs/`.** The build script writes there
  already.

---

## Step 0 - Intake

Chapters are not required. This plugin runs for any city, including one with no
chapter and no lead yet, because a city profile is often what central wants
before recruiting anyone. Never ask for a chapter config and never block on one.

Three cases.

**A workbook was attached.** Confirm the city and go to Step 1.

**No workbook, but the resource workbook exists from earlier in this
conversation.** Offer it: "I can run on the workbook from earlier, or you can
upload an edited version." Wait once, then proceed on whichever they choose.

**No workbook at all.** Say plainly that stage one comes first, and offer to run
it: "The partner map is built from the resource workbook. I can run
`ctc-city-resources` for [city] first, which takes a while, then come back to
this. Or upload an existing workbook."

Do not research a city from scratch inside this skill. That duplicates two
verification passes and an audit that already exist upstream.

## Step 1 - Read the workbook

```bash
python3 $SKILL/read_workbook.py <path to workbook>
```

Three things come back and all three matter.

**The roster.** Every organization with its block, type, focus, URL, and
published description. These have already passed two research passes and an
adversarial audit, so carry them forward without re-verifying.

**Rows carrying no renderer formatting.** Usually organizations the lead typed
in by hand, which makes them the highest-signal entries in the file. Occasionally
it means the whole file was round tripped through another tool, which the script
will make obvious because every row will be flagged.

**The reviewer notes.** This is where `ctc-city-resources` recorded what it
excluded and why. Treat this as the highest-yield input in the whole skill.

**If the script returns no rows, stop.** It exits with an error and says why.
That is a wrong file or a wrong sheet, never a finding about the city. Ask the
user before doing anything else, and never quietly replace the missing roster
with research of your own.

## Step 2 - Reconsider the exclusions

Before searching for anything new, walk every excluded organization against the
partner bar.

The resource bar asks whether a founder can walk through the door. The partner
bar asks whether they would co-host, host, promote, or send their people. The
two most common exclusion reasons upstream are national scope and admission on
reputation, and both routinely flip.

A utility a founder cannot raise from will put a speaker on a panel. A national
nonprofit with a named local organizer is not a city resource but is a strong
week-two conversation.

Say out loud how many came back in. Somewhere between a fifth and a half of a
recorded exclusion list is the rough expectation. Zero across a substantial list
means the partner bar is being applied as a copy of the resource bar. Go back to
`references/partner-bar.md`.

## Step 3 - Research the gap

**Ask how they want to do it first.** The lead may already know organizations in these categories, and a name they vouch for beats anything research returns.

> Four categories are missing from the resource workbook: coworking and innovation districts, professional and affinity groups, nonprofits and advocacy, and arts and civic venues. How do you want to fill them?
>
> **A. You name some, then I research too.** Best coverage, and what I would recommend.
>
> **B. You name all of them.** I verify what you give me and stop there.
>
> **C. I research everything.** Nothing needed from you.
>
> Names or links in your reply and I will take that as option A.

Anything they give goes through the same four checks as anything researched, and a failed check is named rather than dropped.


The workbook covers five categories. Four are missing and they are missing on
purpose, because a founder resource page has no reason to list a botanical
garden.

6. Coworking and innovation districts
7. Professional and affinity groups
8. Nonprofits and advocacy
9. Arts, culture, and civic venues

Use the prompt in `references/gap-research.md` verbatim, substituting the city
and the metro scope already fixed upstream. Run category 9 as its own pass,
searching venue types by name rather than searching for climate organizations,
because a climate search never returns a library.

Also seed CTC's own partners wherever they have local presence: My Climate
Journey, Women and Climate, Climatebase, SOSV, Climate Draft, Newlab,
ClimateRaise. An existing organizational relationship is the warmest path a new
lead has.

## Step 4 - Verify additions

Everything from Steps 2 and 3 gets the four checks in
`references/partner-bar.md`: real and local, active in the last twelve months,
real audience overlap, a visible route in.

Anything the **lead** added to the workbook by hand gets checked too, and never
gets dropped silently. If a check fails on one of theirs, keep it, name the
failed check in the note field, and say so at delivery. They live in that city
and the research does not.

## Step 5 - Tier and write the asks

Tiering is about when to approach, not how good the organization is.

- **Tier 1**, first 30 days. Could host or co-host now, direct audience overlap,
  visible route in. Usually 8 to 12.
- **Tier 2**, 60 to 90 days. Wants a warm introduction or wants the chapter to
  exist first. Usually 6 to 10.
- **Tier 3**, later. Usually 3 to 6. Keep it short.

**Those are distributions, not quotas.** The count is an output of what the city
has. A target of ten reliably produces ten, two of which should not be there,
and those two cost the lead an afternoon and cost the map its credibility. Five
honest Tier 1 partners, shipped as five with the reason stated, is the correct
output for a thin city.

Every entry gets one concrete first ask that can be said yes to in a single
email reply. "Host our first event in your space on a weeknight in October"
passes. "Explore ways to collaborate" does not.

Every entry gets a contact route, which is a publicly findable name, a role, a
general form, or a warm path. **Never invent a name, title, email, or phone
number, and never write an email address into the file at all.**

Record everything set aside on the Not approaching sheet with its reason.

The weak and strong versions of every field are in
`references/worked-example.md`. Write against those, not against the field names.

## Step 6 - Build the data file

Copy `partner_data_TEMPLATE.py` into the working directory, fill it in, and keep
it as a real Python module. The data-module plus shared-renderer pattern is what makes
revisions cheap.

Every entry needs all seven required fields. Write the `why` as one sentence
about this chapter, not a description of the organization. No em dashes, no
dollar amounts, no percentages, no cohort counts, so the file stays timeless.

`scripts/partner_data_EXAMPLE.py` is a filled-in version to calibrate density
and voice against. It is illustrative, not verified data, and nothing in it
should be carried into a real city.

## Step 7 - Render and QA

```bash
cd /home/claude/work && python3 $SKILL/build_partners.py partner_data_<city>.py
```

The script writes to `/mnt/user-data/outputs/CTC_Partner_Map_<City>.xlsx` and
prints a summary plus a QA report. Read the output rather than assuming it
passed. It enforces:

- No blank required fields
- Every URL https and well formed
- Every category drawn from the declared list
- No duplicate organization across tiers
- No em dashes or en dashes in copy
- No volatile figures
- No email address in the contact route
- Tier 1 within 6 to 14, with a warning either side
- Not approaching is not empty

Warnings are judgment calls, not failures. Decide each one and say which way you
went at delivery. A Tier 1 of five in a genuinely thin city is a correct output
and the warning exists to make you state that rather than pad.

Two checks the script cannot make. Make them by hand:

- **Recognition.** Would a local recognize every Tier 1 name?
- **The single-email test.** Could each ask be said yes to in one reply?

## Step 8 - Ask once for what is missing

Present the map, then ask one question: is anything obvious missing.

A lead who has lived there five years will name two or three organizations no
search returns. Add what they give you, run the same checks, apply the same
never-drop-silently rule, and rebuild.

Ask once. If they say no or say nothing, deliver and stop.

## Step 9 - Deliver

Call `present_files` on the `.xlsx`. Then in a few lines: the count per tier, how
many came back in from the resource workbook's exclusions, what the gap research
added per category, anything empty and why, and anything kept despite a failed
check.

Keep it short. No preamble, no restating the method.

## Step 10 - Hand off to outreach

The map is a list of names until someone writes to them. Offer the next stage:

> That is who to approach and in what order. When you are ready to write to any of them, say `/ctc-partner-outreach` and name the organization. It reads this map, asks you a few questions, and drafts the message in your own voice.
>
> Start with two or three from Tier 1 rather than working down the whole list.

Offer once. Do not chain into it.

---

## What this skill never does

- Never sends anything, and never drafts a message claiming a relationship that
  does not exist.
- Never invents a contact name, title, email address, or phone number.
- Never writes into the resource workbook. Separate file, always.
- Never registers CTC's own properties, other chapters, or Streetlife Ventures
  as partners.
- Never pads a tier or a category to hit a number.

## Common failure modes

**Applying the resource bar again.** The most likely failure by far. It looks
like diligence and produces the resource workbook re-sorted. Symptom: nothing
came back in from the exclusions, and categories 6 to 9 are thin or empty.

**A twenty-name Tier 1.** A new lead has time for about ten conversations. A
Tier 1 they cannot finish is one they never start.

**Vague asks.** "Discuss a partnership" in the ask column means Step 5 was
skipped.

**Descriptions in the `why` column.** Read that column on its own. If it reads
like a directory of local organizations rather than a set of reasons, it was
written about the organizations instead of about the chapter.

**Skipping category 9.** It reads as the least serious category and it serves
the roughly 40 percent of readers not yet working in climate, which is the
audience a new chapter grows fastest from.

**Dropping the lead's own additions.** They know the city. A failed check on
their entry is information for them, not a decision for the skill.

**Treating an empty read as a thin city.** If `read_workbook.py` returns
nothing, the file or the sheet is wrong. Ask.

**Shipping research instead of the file.** The resource skill made this mistake
more than once. The turn is not done until the workbook exists and is presented.
