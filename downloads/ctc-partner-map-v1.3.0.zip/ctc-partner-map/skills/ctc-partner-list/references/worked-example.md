# Worked example

A finished partner map, annotated. Read this before writing a single entry.

**This is illustrative, not data.** The organizations are real Houston ones and
the shape of every field is exactly right. The asks, contact routes, tier
placements, and notes were written to demonstrate patterns and have not been
through the four checks. Nobody should copy these into a live deliverable. If
you are actually building Houston, research it and discard this.

The runnable version is `scripts/partner_data_EXAMPLE.py`. Build it and look at
the workbook:

```bash
python3 build_partners.py partner_data_EXAMPLE.py
```

It passes the QA gate with no failures and no warnings, which is the bar a real
one has to clear too.

---

## What the example demonstrates

| Pattern | Where to look |
|---|---|
| An entry from each of the four `source` values | Tier 1 |
| All four gap categories present in Tier 1 | Ion District, HREG, Bayou City Waterkeeper, Houston Public Library |
| An exclusion that came back in under the partner bar | CenterPoint Energy |
| A lead addition kept despite a failed check | Cup of Joey |
| A metro-scope entry naming its actual municipality | Houston Advanced Research Center |
| A category honestly absent from Tier 1 | Capital |
| A strong candidate that is a venue and not a partner | Houston Botanic Garden, on Not approaching |
| Reasons on Not approaching that a reader can check | All five |

---

## The shape of a Tier 1 entry

```
org      Greentown Labs Houston
category Accelerators and incubators
why      Their member companies are the founders we want in the room, and the
         building has event space they already open to outside groups.
ask      Co-host our launch mixer in your event space on a weeknight in October.
contact  Community or events team, via the contact form on the Houston page
url      https://greentownlabs.com/houston/
source   workbook
note     (empty)
```

Four things to copy from it.

**`why` is one sentence about this chapter.** It names what the chapter gets and
it is checkable. It is not a description of the organization, which is what the
resource workbook already carries.

**`ask` is a single decidable thing.** Someone can reply yes to it. It names a
format, a place, and a rough when.

**`contact` is a route, never a person invented to fill the field.** A team plus
where the form lives is a complete answer.

**`note` is empty when there is nothing to say.** Most notes are empty. A note
exists to carry a failed check, a scope caveat, or a warning about the approach.
It is not a second description.

---

## Field by field, weak against strong

### `why`

| Weak | Why it fails | Strong |
|---|---|---|
| Runs the largest climate founder community in the metro. | A description. True of the organization whether or not we exist. | Their member companies are the founders we want in the room, and the building has event space they already open to outside groups. |
| Great fit for our audience. | Says nothing a reader can check. | They already assemble the exact audience we want on a recurring meeting schedule, and they meet at rotating venues rather than defending one of their own. |
| Prominent institution with deep local roots and a strong reputation in the energy transition. | Prominence is not a reason. This is the reputation admission the workbook exists to refuse. | A founder cannot raise from a utility, which is why the workbook cut them, but they will put a grid person on a panel and that is the talk this city turns out for. |
| Their sustainability mission aligns closely with ours. | Thematic overlap, not audience overlap. | Water and flooding is the climate conversation this city actually has, and their members show up for it in numbers climate tech events do not reach. |

The test: does the sentence say what this chapter gets, in a way the lead could
disagree with?

### `ask`

| Weak | Why it fails | Strong |
|---|---|---|
| Explore ways to collaborate. | Nothing to say yes to. | Co-host our launch mixer in your event space on a weeknight in October. |
| Discuss a potential partnership. | Same, dressed up. | Add our monthly meetup to the Ion events calendar and let us book a room for the first one. |
| Get them involved with the chapter. | An intention, not a request. | Provide a speaker on grid interconnection for our first quarterly panel. |
| Build a long-term strategic relationship across events, content, and community. | Four asks, so it is none. | Send a speaker to our first event and share the launch issue with your list. |

The test: could the recipient reply with one word and have answered?

Match the ask to the tier. Tier 1 asks for a room or a co-host. Tier 2 asks for
an introduction or a newsletter share. Tier 3 asks for a conversation later.

### `contact`

| Weak | Why it fails | Strong |
|---|---|---|
| partnerships@example.org | Never write an email address into the file. | Community relations, via the corporate responsibility page |
| Sarah, Director of Partnerships | If the name was not published, this is invented, and inventing a contact is the one unrecoverable error in this skill. | Named program director listed on the Rice Alliance team page |
| Website | Not a route. Everything has a website. | Calendar submission form on the events page |
| Reach out via LinkedIn. | A method, not a route, and it puts the lead in a cold DM. | Warm path. The lead already attends |

Four acceptable forms, and nothing else: a publicly findable named person with
their public role, a role with no name where only the role is published, a
general route such as a named form or page, or a warm path where a real
connection exists.

### `note`

Empty by default. Use it for exactly four things.

| Situation | Note |
|---|---|
| A check failed and the entry was kept anyway | KEPT DESPITE A FAILED CHECK. No published partnerships route, so check four fails on the research. The lead knows the organizer personally and asked to keep it. |
| The entry sits outside the city proper but inside the metro scope | Based in The Woodlands, not Houston proper. Inside the metro scope, named so nobody is misled. |
| Something about the approach the lead would otherwise learn the hard way | Programs are planned far ahead. Approach early even though the event lands late. |
| Why an organization moved between bars | Cut upstream as reputation-only admission. Passes the partner bar on speaker access. |

### Not approaching reasons

| Weak | Strong |
|---|---|
| Not a good fit. | Event spaces are rental only with a minimum spend. A venue option, not a partner. Revisit if a sponsor covers the room. |
| Too big. | Would be a logo on a slide and nothing else. No public programming, no member list, no venue. |
| National organization. | National program with no Houston staffed presence. Correctly cut upstream and it does not flip under the partner bar. |

A reader should be able to check the reason and either agree or overturn it. A
reason nobody can act on is the same as no sheet.

---

## What a bad map looks like

Recognize these in your own draft before the lead does.

**The resource workbook re-sorted.** Every entry has `source: workbook`,
categories 6 to 9 are empty or hold one entry each, and nothing came back in
from the exclusions. This is the most common failure and it looks like careful
work.

**Twenty-two entries in Tier 1.** Every one defensible, the set unusable. A new
lead has time for roughly ten conversations in a month. A Tier 1 they cannot
finish is one they never start.

**Every `why` is a description.** Read the column on its own. If it reads like a
directory of local organizations rather than a set of reasons, it was written
about the organizations instead of about the chapter.

**Contact routes that are all "website".** The route was not researched. Half of
those organizations publish a named events or partnerships contact.

**An empty Not approaching sheet.** Means nothing was refused, which means the
bar was never applied. Even a thin city produces refusals.

**No arts, culture, or civic venues anywhere.** Category 9 was skipped. It
serves the roughly 40 percent of the audience not yet working in climate, which
is the group a new chapter grows fastest from, and a search for climate
organizations never returns a library.
