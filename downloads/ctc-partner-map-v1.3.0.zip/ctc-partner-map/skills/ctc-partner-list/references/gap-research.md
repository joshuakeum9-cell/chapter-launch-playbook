# Gap research

The resource workbook already covers five categories. This file covers the four
it does not, plus the verification standard for anything the lead adds by hand.

---

## Before searching

Read the roster from `read_workbook.py` first. Two things come out of it that
shape the search.

**What is already covered.** Do not re-research categories 1 to 5. They have
been through two research passes and an adversarial audit. Carry them across,
apply the partner bar, and tier them.

**What was excluded and why.** The reviewer notes hold the organizations the
resource pass cut. Reconsider each one against the partner bar before searching
for anything new. This is cheaper than research and it usually yields more,
because the two most common exclusion reasons, national scope and reputation-only
admission, are exactly the ones the partner bar treats differently.

State out loud how many reconsidered organizations came back in. As a rough
expectation, somewhere between a fifth and a half of a recorded exclusion list
flips, because those two reasons dominate the notes. Zero across a substantial
exclusion list means the partner bar is being applied as a copy of the resource
bar. All of them coming back means no bar is being applied at all.

---

## Tools and what to do when they are missing

**Extended or deep research tool.** Use it if the session has one. This is what
it is for, and one call replaces most of the search volume below.

**No research tool.** Run the equivalent by hand: fifteen or more distinct
`web_search` calls plus page fetches, not five. Four categories, four or more
angles each. If a category has returned nothing after three differently phrased
searches, that is a finding about the city. If it has returned nothing after one
search, that is a finding about the search.

**Fetching pages.** Use the fetch tool. The sandbox reaches an allowlist of
package registries only, so `curl` and `requests` fail on arbitrary sites and
they fail in ways that look like the site being down. A URL never observed
resolving has not been checked.

**openpyxl.** Both scripts need it. If the import fails:

```bash
pip install openpyxl --break-system-packages -q
```

---

## The gap prompt

Substitute the city and the metro scope already fixed by the resource pass.

```
Find organizations in the {CITY} metro area ({SCOPE}) that would plausibly
host, co-host, promote, or send their members to a climate tech community
event. Not funders and not startup support programs, which are already
covered. Specifically:

1. COWORKING AND INNOVATION DISTRICTS
   Coworking spaces, innovation districts, maker spaces, and hardware or
   climate-focused workspaces that host public community events on weeknights.
   Note capacity and whether they host outside groups.

2. PROFESSIONAL AND AFFINITY GROUPS
   Local chapters of energy, sustainability, engineering, and built-environment
   professional associations. Women in energy or climate groups. Young
   professionals groups. University alumni climate or sustainability groups.
   Anything that already assembles this audience on a recurring basis.

3. NONPROFITS AND ADVOCACY
   Environmental, energy, transportation, environmental justice, and urban
   sustainability organizations with a staffed local presence and a record of
   public programming.

4. ARTS, CULTURE, AND CIVIC VENUES
   Museums, science centers, libraries, botanical gardens, aquariums,
   community centers, and civic venues that have run climate, sustainability,
   energy, or environment programming. Include venues that host outside groups
   even where the climate angle is occasional.

For every candidate return: name, category, canonical URL, a local physical
address or the named local chapter, dated evidence of activity in the last
twelve months, whether they visibly host outside organizations, and any
publicly listed contact route such as a partnerships or events page. Do not
return contact email addresses.

Do not return national organizations with no local staffed presence or named
local chapter. Do not return organizations whose last visible activity is
more than twelve months old.
```

Over-collect here. Cutting is cheap and noticing an absence is not. Expect to
collect roughly twice what survives.

### What each category usually returns

A sense of scale, not a quota. Any of these can be honestly zero in a small
metro, and a zero that is stated is fine.

| Category | Usual survivors in a mid-size metro | If you get zero |
|---|---|---|
| Coworking and innovation districts | 2 to 5 | Unlikely in any city with a startup scene. Search the district by name, not by climate |
| Professional and affinity groups | 3 to 6 | Almost certainly a search failure. Try association names directly |
| Nonprofits and advocacy | 3 to 6 | Try the local environmental coalition or resource guide, which most metros have |
| Arts, culture, and civic venues | 2 to 5 | See below. This is the category a climate search cannot find |

## Category 9 needs its own pass

A generalist search for climate organizations will not surface a botanical
garden, and that is exactly the failure this category exists to prevent. Search
venue types directly by name, city by city: museum, science center, library
system, botanical garden, aquarium, nature center, community center, maker
space, historic site, public park conservancy.

Then check each for public programming rather than for a climate mission. A
venue with no climate mission that has run one climate talk is a better partner
than a climate organization that has never opened a room.

Check the room terms while you are there, because it decides the ruling. Free or
waivable community rooms qualify. Rental with a minimum spend does not, and goes
to Not approaching with the reason recorded, because a first event is free and
partner hosted.

---

## Verifying what the lead added

The chapter lead edits the resource workbook before this skill runs, and they
may add organizations. `read_workbook.py` reports rows carrying no renderer
formatting, which is usually what a hand-typed addition looks like.

**Check them.** Same four checks as anything else: real and local, active in the
last twelve months, real audience overlap, a visible route in.

**Never drop them quietly.** If a check fails, keep the entry, name the failed
check in the note field, and tell the lead in the delivery summary. They live
there and the research does not. An organization with a bad website that a local
knows is thriving is a research failure, not a partner failure.

**Ask once for more.** After presenting the map, ask whether anything obvious is
missing. A lead who has been in the city five years will name two or three
organizations no search returns. Add what they give you, run the same checks,
apply the same never-drop-silently rule.

**Do not ask twice.** One invitation. If they say no or say nothing, deliver.

---

## Failure modes

These are worth stating because the resource skill learned several of them the
expensive way and the same traps apply here.

**Copying the resource bar.** The most likely failure. It looks like diligence
and it produces a partner list that is just the resource workbook re-sorted.
Symptom: nothing came back in from the exclusions, and categories 6 to 9 are
empty or thin.

**Padding Tier 1.** Fourteen is where the QA gate warns. A Tier 1 of twenty is a
research dump, not a plan, and the lead will work through none of it.

**Vague asks.** "Explore collaboration" in the ask column means the bar was not
applied. Every ask survives the single-email test or it gets rewritten.

**Inventing a contact.** Never. A general route is a complete and acceptable
answer.

**Skipping category 9.** It reads as the least serious category and it serves
the largest underserved slice of the audience.

**Trusting a zero from the reader.** If `read_workbook.py` returns no rows, the
file or the sheet is wrong. It is never a finding about the city. Ask before
doing anything else.

**Shipping research instead of the file.** The turn is not done until
`CTC_Partner_Map_<City>.xlsx` is in `/mnt/user-data/outputs/` and presented.
