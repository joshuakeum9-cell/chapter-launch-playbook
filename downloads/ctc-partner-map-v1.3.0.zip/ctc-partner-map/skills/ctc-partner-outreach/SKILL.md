---
name: ctc-partner-outreach
description: Draft partner outreach messages for a Climate Tech Cities chapter lead, in their own voice, by walking them through the seven elements a partner email needs. Use this skill whenever someone wants to write to a partner, venue, sponsor, or co-host, asks for an outreach email or a cold email, says "help me write to [organization]", has a partner map and wants to start contacting people, asks how to ask for a venue or a co-host, or wants a template for partner outreach. Always use it even if they only want one message or say they just need a quick draft. Do NOT use it to research who to approach, which is ctc-partner-list, or to write newsletter copy, which is ctc-assemble.
---

# CTC Partner Outreach

Stage three of the `ctc-partner-map` plugin. Turns a name on the partner list into a message the lead can actually send.

The message goes out under their name, from their address, and they have to have the conversation it starts. So this skill drafts, and they edit. It never sends.

## Input

An organization to write to. Everything else comes from the interview, the settings file, or the partner map if one exists.

## Output

The message, in chat, ready to copy. Plus the four question test answered back to the lead.

No document unless they ask for several at once, in which case one `.docx` with all of them.

---

## The bar

The lead reads it, changes a line or two, and sends it without rewriting. If they would rewrite it from scratch, the voice work failed.

---

## Read this first

`references/seven-elements.md` holds the seven elements, the failure each one prevents, worked weak-versus-strong examples, and the four question test. Read it before drafting anything.

---

## Step 1. Work out what you already know

Do not ask for anything you can find.

**From the chapter settings file:** city, chapter name, lead name, reply address, send day, sign off.

**From a partner map workbook, if one is in the project or the conversation:** the organization's category, tier, why-them line, the suggested first ask, and the contact route. That is four of the seven elements already half answered, so read it before the interview and confirm rather than ask.

**From the conversation itself:** if the lead has already described the organization or what they want, take it.

Say in one line what you picked up, then start.

## Step 2. Get a writing sample

Ask once, early, because it changes every draft after it:

> Before I draft anything: paste an email you have written recently, to anyone, about anything. It does not have to be a good one. I will match how you actually write rather than guessing.
>
> If you would rather skip it, say skip and I will write plainly, and you can adjust the voice yourself.

If they paste one, read for sentence length, greeting, sign off, contraction use, formality, and how they open and close. Match those. Do not copy typos or filler.

If they skip, write plainly and warmly, and say once in the delivery that the voice is generic and worth a pass.

If past conversations are searchable and the lead has written outreach before, you may look there instead. Never say you did unless asked, and never rely on it in place of asking.

## Step 3. The interview

Seven questions, **one per message**, in the order of `references/seven-elements.md`. Never a wall.

Each question does three things: names what it is for, gives an example, and offers a way out for a lead who does not know.

1. **Who are you writing to, and what do you know about them?**
   Anything specific and true. A program they run, a cohort, an event, a mutual connection. If they do not know, offer to research the organization and come back with two or three concrete things to choose from.

2. **What kind of partnership?**
   Venue host, event co-host, speaker, cross-promotion, newsletter share, community partner. If the partner map has a suggested first ask, propose that and let them confirm.

3. **What do they get out of it?**
   The hardest question and the most important. Prompt with the honest currencies: reach to a local audience, programming they do not have to produce, a filled room on a night they were not using, association with a ten city network, access to people they want to hire or fund. Push back if the answer is really about what the chapter gets.

4. **Why should they believe you?**
   One or two proof points. If the chapter is new and has none of its own, use the network: ten cities, the New York newsletter publishing since 2021, a community spanning founders, investors, researchers, and policy people. Never invent a number, and if they give one, use theirs.

5. **What exactly would you do together?**
   Concrete enough to picture. A month, a rough size, who does the work. "Our October meetup in your space, about forty people, a Tuesday, we handle everything."

6. **What are you asking for in this email?**
   Default to a fifteen or twenty minute call. Offer the lower friction alternative, which is a single qualifying question such as whether they ever open the space to outside groups on weeknights.

7. **Email, LinkedIn, or a warm introduction?**
   Changes length and opening. LinkedIn runs shorter and drops the subject line. A warm intro names the person connecting them in the first sentence.

**If they answer several at once, take them all and skip ahead.** If they say "you decide" on any question, make the call, draft it, and mark that line as the one to check.

## Step 4. Draft

Build in the order in `references/seven-elements.md`: personalization, opportunity, their benefit, proof, specific collaboration, ask.

**Lead with the opportunity you are creating for them, never with what you want.** This is the single highest-leverage rule in the skill.

100 to 175 words. Count them. Over 175 is not a stronger pitch, it is one with a lower chance of being finished.

Write a subject line for email. Six words or fewer, specific, no clickbait.

## Step 5. Deliver

Give the message, then, in a few lines:

- **The four question test, answered.** Why them, why now, what is in it for them, what exactly is being asked. If any answer is thin, say which and why.
- **The word count.**
- **One line naming what to check.** Usually the personalization, since it is the line most likely to be slightly wrong and the most damaging when it is.
- **That it is a draft and should go out in their words.**

Then stop.

## Step 6. Offer the follow up, once

After the first message, offer a follow up for no reply after a week or ten days. Three sentences, no guilt, one new piece of information, an easier ask than the first.

Offer once. If they say no, drop it.

---

## House rules

**Never send anything.** This skill writes. The lead sends.

**Never invent a fact, a number, a name, or a relationship.** No made up subscriber counts, no attendance figures that have not happened, no claiming a connection that does not exist. If the lead supplies a number, use theirs. If nobody has one, use the network's existence instead.

**Never claim a warm introduction that has not been offered.** "[Name] suggested I reach out" is only written when [Name] actually did.

**Never exceed 175 words.**

**Never write "I came across your organization."** If there is no real personalization, go back to question one.

**Always say it is a draft.** Every delivery, every time. A partner email that sounds like software is worse than a shorter one that sounds like a person.

---

## Failure modes

**The lead does not know anything about the organization.** Offer to research it and come back with two or three specific true things. Do not write around it with vague flattery.

**The value proposition is really about the chapter.** The most common failure. "It would help us grow" is not their benefit. Ask again, from their side: what does this organization want more of, and can the chapter supply any of it.

**They want to skip the interview and get a template.** Give them the shape from `references/seven-elements.md` and say plainly that a template with the personalization missing is the thing that gets ignored. Then offer to run the interview in two minutes.

**They ask for twenty messages at once.** Run the interview once for the shared parts, which are elements 3, 4, and 6, then ask only the personalization question per organization. Deliver as one document. Never reuse one personalization across two organizations.

**No writing sample and the draft sounds generic.** Say so yourself before they do, and offer to try again with a sample.
