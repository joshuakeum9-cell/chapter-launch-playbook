# The seven elements

Every message this skill produces has all seven. A message missing any one of them is the reason partner outreach usually fails, and each element below names the specific failure it prevents.

**The order matters:** personalization, then the opportunity, then their benefit, then proof, then the specific collaboration, then the ask.

**The rule underneath the order:** lead with the opportunity you are creating for them, never with what you want from them. That single shift is worth more than everything else on this page.

---

## 1. Personalized opening

Show you know who they are and what they do. Reference a recent initiative, program, cohort, event, or a shared connection.

**Prevents:** the message reading like it was sent to forty organizations, because it was.

Never use "I came across your company" or "I've been following your work" with nothing behind it. Both are worse than no personalization, because they announce that personalization was attempted and abandoned.

| Weak | Strong |
|---|---|
| I came across your organization and was impressed | I saw you ran the fall hardware cohort out of the Ion, and three of those founders are exactly who our readers are trying to meet |

If the lead cannot name one specific true thing about the organization, that is a signal to research it rather than a signal to write around it.

## 2. Clear reason for reaching out

One or two sentences naming the partnership type: venue host, event co-host, speaker, cross-promotion, newsletter share, community partner.

**Prevents:** the recipient finishing the email unsure what kind of relationship is being proposed, which reads as unserious.

## 3. Partner-specific value proposition

The most important element. Answer the question they are actually asking, which is "why should I care."

**Prevents:** the message being about the chapter instead of about them.

Frame everything as their upside. For a chapter partnership the honest currencies are: reach to a defined local audience, programming they do not have to produce, association with a national network, a filled room on a night they were not using, and access to people they want to recruit or fund.

| Weak | Strong |
|---|---|
| We would love your support as we launch | Your space gets forty climate people in it on a Tuesday, and you do not have to organize anything |

Do not overstate. A new chapter with two hundred subscribers should say two hundred, or say nothing, and never imply thousands.

## 4. Credibility

One or two proof points. Not a history.

**Prevents:** the recipient having no reason to believe the event will actually happen or the audience actually exists.

For a new chapter the honest proof points are the network rather than the chapter: Climate Tech Cities runs chapters in ten cities, the New York newsletter has been publishing since 2021, and the community spans founders, investors, researchers, and policy people. If the chapter has its own numbers, use those instead, because local beats national.

**Never invent a number.** If the lead does not have one, use the network's existence rather than a metric.

## 5. The proposed collaboration

Make it concrete enough to picture.

**Prevents:** a yes that means nothing, because neither side knows what was agreed.

"We could host our October meetup in your space, forty people, a Tuesday evening, we handle everything" is concrete. "Explore ways our organizations might work together" is not.

## 6. Low friction call to action

Ask for something small. Fifteen or twenty minutes, or a single qualifying question.

**Prevents:** a no that is really a not-right-now, because the ask was too big to say yes to on first contact.

Never ask them to commit to the partnership in the first email. The ask is the conversation, not the outcome.

| Weak | Strong |
|---|---|
| Let us know if you would like to become a partner | Would you be open to a fifteen minute call in the next couple of weeks to see if it fits? |

A qualifying question also works, and is lower friction still: "Do you ever open the space to outside groups on weeknights?"

## 7. Brevity

100 to 175 words. The whole pitch understood in 20 to 30 seconds.

**Prevents:** the message not being read at all.

The build script enforces this range. A message over 175 words is not a stronger pitch, it is a pitch with a lower chance of being finished.

---

## The four question test

Before any message ships, it answers all four. If it cannot, it is not ready.

| Question | Which element carries it |
|---|---|
| Why them? | 1, personalization |
| Why now? | 2, the reason for reaching out |
| What is in it for them? | 3, their value proposition |
| What exactly am I asking for? | 6, the call to action |

State the four answers back to the lead when delivering. If any one of them is thin, say so plainly rather than shipping a message that will not land.

---

## Voice

The message goes out under the lead's name, from their address, and they will have to have the conversation it starts. It has to sound like them.

**With a writing sample:** match sentence length, greeting, sign off, contraction use, and formality. Do not match typos or filler.

**Without one:** write plainly and warmly, contractions on, no corporate stack, and tell the lead explicitly that the voice is generic and worth a pass.

**Always tell the lead to read it before sending.** These are drafts. A partner email that sounds like software is worse than a shorter one that sounds like a person.
