# Example issue

A complete published issue, start to finish, so you can see how the nine blocks fit together and what the proportions look like. This is the 21 July 2026 issue of NY Climate Tech.

**Read it for shape, never for wording.** Every issue is written fresh.

Two things to notice before you start:

- **The sign-off sits in the middle**, not at the end. Note → picks → housekeeping → "Til next week!" → *then* Opportunities and the listing blocks.
- **Roughly 80 words of this are human prose.** The rest is listings. Those 80 words are why people subscribe.

---

**Title:** NY Climate Tech: July 21 - July 28

**Subtitle:** Offshore wind, hours of action, sustainable investment in the park, climate conversations, climate innovation, City of Water Day, and more upcoming events

---

Hi all,

Last week we pulled out our N95s once again as wildfire smoke subsumed the summer. The brown-orange skies, torrential rain, and tornado warnings have been stark reminders that climate change is here and now.

For such a global problem, we continually find hope and inspiration in local community. While the summer is a lot quieter (including on the newsletter), there's still plenty of ways to connect. Here are our picks for the week:

- **Tomorrow** embrace the tides at the 🌊 2026 Offshore Wind Innovator Program: Q&A Social Hour or make calls (and friends!) at the ⏳ Manhattan Climate Changemakers Hour of Action or ⏰ Brooklyn Hour of Action
- **Thursday** talk sustainable finance in Sheep's Meadow at the 🧺 BASIC NY Summer Social or join Climatebase in Midtown for 💬 Climate Conversations NYC
- **Friday** head to the Climate Imaginarium on Governor's Island for the 💡 GIVE Venture Lab: Community Climate Innovation Challenge
- **Saturday** is 💧 City of Water Day with events throughout the five boroughs

We've postponed Wednesday's **Other Intelligence** summit until later this year (too many people were out of town!) but are still looking forward to it in the Fall.

Also, Climate Week is around the corner! Keep your eyes peeled for our first guide, and **if you're planning any events for Climate Week NYC, send them our way by replying to this email.**

Til next week!
Alec, Sonam, and the Climate Tech Cities team

---

### Opportunities:

### 💡 New York Climate Exchange Climate Tech Fellowship

> The Climate Tech Fellowship is a six-month hybrid program that combines expert-led curriculum, 1:1 mentorship, non-dilutive funding, and access to The Exchange's global partner ecosystem. Fellows leave with a clearer commercialization roadmap, stronger fundraising readiness, and a network of mentors, peers, and potential investors. **Applications Due August 1.**

### 🤖 Climate Change AI Summer School

> Registration is open for the Climate Change AI Virtual Summer School 2026! This year's program will take place from July 19 - August 22, 2026, and will be hosted fully online.

---

## This Week's Events

#### Wednesday, Jul 22

- 🌊 2026 Offshore Wind Innovator Program: Q&A Social Hour
- ⏳ Manhattan Climate Changemakers Hour of Action
- ☀️ Solarpunk, Communes, & Co-Living Dinner Series: NYC Edition
- 🌱 Hoboken Climate Changemakers!
- 🧪 One Year of Science Tonight!
- 🌱 Brooklyn Hour of Action

#### Thursday, Jul 23

- 📊 Summer 2026 Lecture in Climate Data Science: ANN LEE
- 💨 YPE Tour with WindScape Brooklyn
- 🧺 BASIC NY Summer Social
- 💬 Climate Conversations NYC

#### Saturday, Jul 25

- 💡 GIVE Venture Lab: Community Climate Innovation Challenge
- 🌱🎨 ClimART Cafe & LMCC Artist Studio Tour
- 💧 City of Water Day with Hila the Earth

#### Sunday, Jul 26

- 💧 City of Water Day

#### Monday, Jul 27

- ✍️ Climate & Environmental Science Bootcamp

*Every title is a live link. Titles only, no times and no venues. The day header carries the date.*

---

## Upcoming Events

- 🫖 Rare Tea From Unexpected Regions: Tasting With Anna Ye: Jul 29
- ♻️ The Circular Economists Meet-up: New York City: Jul 29
- 🍹 Net Impact NYC July Social Hour: Jul 29
- 🎻 Wreathed in blossom: chamber music on Governors Island: Aug 1
- ⚡ [INFRASTRUCTOURS] Midtown East / LIC - Power Plants, Tunnels, Ferry Rides: Aug 1
- 🏢 Retrofit NYC (Commercial): Aug 6
- 🦪 Volunteering Untapped NYC: Billion Oyster Project: Aug 8
- 🍯 Perfect Days: Intro to Beekeeping: Aug 8
- 🌿 WiC Summer Mixer: Aug 12
- 🚢 Energy Infrastructure Boat Tour: Aug 19

*Flat, chronological, date appended. Runs six to eight weeks out. The real issue carried 28 of these.*

---

## Events in Detail

*Optional. This issue omitted it; the 7 July issue included it. Format when used:*

### 🎴 Climate Fresk at Anew

**When:** Tuesday, Jul 7

**Where:** 526 Hudson St, New York

> Climate Fresk is an interactive, collaborative workshop that teaches the science of climate change through a serious game format in just 3 hours. Participants will explore the causes and effects of climate change while developing actionable strategies for personal impact. Hosted by Anew, a social impact community hub in New York, this free event combines team building with climate literacy and empowerment for environmental action.

---

## 🌎 Climate Tech Cities and Streetlife Ventures Startup and Talent Platforms

Climate Tech Cities and Streetlife Ventures are launching new platforms to support climate founders, funders, and career transitioners! There is no shortage of great companies raising money for their groundbreaking ideas, great investors looking to support with capital, and great talent living the mantra that every job is a climate job. We can't wait to hear from you!

- Climate startups looking to raise
- Climate talent looking to transition

---

## What a first issue looks like instead

Do not aim at the above in week one. The very first issue of this newsletter, in October 2021, carried **three events and no emoji system at all**. It opened by saying plainly that there was no single place to check what was happening in the city, so the author had started one, and asked readers to send things in.

That is the correct shape for a launch. A handful of events, a longer personal note, and an explicit ask. The machinery above accumulated over four years.
