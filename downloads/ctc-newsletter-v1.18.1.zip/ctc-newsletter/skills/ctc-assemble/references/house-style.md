# House style reference

Everything the assemble skill needs to produce output in the right voice and format, without relying on external context. Derived from 190 published issues of the NY Climate Tech newsletter, Oct 2021 – Jul 2026.

---

## 1. Formatting spec

Measured from the live Substack DOM. **The base font is reader-configurable** (17px and 19px both observed), so the ratios are the spec, not absolute sizes.

| Element | Size | Font | Notes |
|---|---|---|---|
| Body | 1.0× | serif (Spectral) | line-height 1.6, margin-bottom 20px |
| Title | ~2.2× | sans (SF Pro Display) | bold |
| Subtitle | ~1.25× | sans | grey `#5f5f5f`, regular weight |
| `h2` | 1.625× | sans, bold | This Week's Events · Upcoming Events · Events in Detail · footer |
| `h3` | 1.375× | sans, bold | **Opportunities:** and individual event/opportunity titles |
| `h4` | 1.125× | sans, bold | Day headers, "Wednesday, Jul 22" |
| List item | 1.0× | serif | indent 32px, margin-top 8px |
| Blockquote | 1.0× | serif | 4px left border, used for descriptions |

**Two things people get wrong:**

- Body is **serif**, headers are **sans**. Not one font throughout.
- **"Opportunities:" is `h3`**, a level below "This Week's Events" and "Events in Detail" which are `h2`.

**The indent** on opportunity descriptions and Events in Detail descriptions is a blockquote with a left border, not a margin and not a nested list.

---

## 2. Worked examples

These are real published blocks. Imitate the shape, never the wording.

### Opening note: topical hook

> Hi all,
>
> Last week we pulled out our N95s once again as wildfire smoke subsumed the summer. The brown-orange skies, torrential rain, and tornado warnings have been stark reminders that climate change is here and now.
>
> For such a global problem, we continually find hope and inspiration in local community. While the summer is a lot quieter (including on the newsletter), there's still plenty of ways to connect. Here are our picks for the week:

Two moves: something true about the city this week, then the turn toward local community. Note the parenthetical admitting the newsletter itself has been quiet. Self-aware, not apologetic. That is house voice.

### Opening note: own-event lead

> Hi all,
>
> Our big summer event is around the corner! Join us on Wednesday July 22nd for Other Intelligence and meet the people doing some of the most interesting, exciting work out there on things like bioacoustics, new materials, nonhuman design, world models, and more.
>
> Here are our picks for the week:

### Picks

> **Tomorrow** embrace the tides at the 🌊 2026 Offshore Wind Innovator Program: Q&A Social Hour or make calls (and friends!) at the ⏳ Manhattan Climate Changemakers Hour of Action or ⏰ Brooklyn Hour of Action
>
> **Thursday** talk sustainable finance in Sheep's Meadow at the 🧺 BASIC NY Summer Social or join Climatebase in Midtown for 💬 Climate Conversations NYC
>
> **Friday** head to the Climate Imaginarium on Governor's Island for the 💡 GIVE Venture Lab: Community Climate Innovation Challenge
>
> **Saturday** is 💧 City of Water Day with events throughout the five boroughs

Another week, same shape:

> **Today** talk 🏞️ The Nexus of Transport Infrastructure and Biodiversity, learn about climate through a game at 🎴 Climate Fresk, or 💨 What Are We Breathing on the NYC Subway?
>
> **Saturday** head to the Bronx for an infrastructure tour on wheels at the 🚴‍♂️ Hunts Point Bike Tour then swing by the ⚖️ Bronx Environmental Justice Arts Festival

**The pattern:** bold day → verb → place or reason → linked title with emoji. Events joined with `or`, never `and`. Day words: `Today`, `Tomorrow`, weekday names, `Next Tuesday` for just past the window.

**The asides are the voice.** "make calls (and friends!)", "an infrastructure tour on wheels", "learn about climate through a game". A tool cannot generate these. Leave them for the human.

### Housekeeping and sign-off

> We've postponed Wednesday's **Other Intelligence** summit until later this year (too many people were out of town!) but are still looking forward to it in the Fall.
>
> Also, Climate Week is around the corner! Keep your eyes peeled for our first guide, and **if you're planning any events for Climate Week NYC, send them our way by replying to this email.**
>
> Til next week!
> Alec, Sonam, and the Climate Tech Cities team

Reader asks bolded inline. Sign-off variant: `As always,` instead of `Til next week!`. Greeting variant: `Hi friends,`.

### Opportunities

> ### 💡 New York Climate Exchange Climate Tech Fellowship
> > The Climate Tech Fellowship is a six-month hybrid program that combines expert-led curriculum, 1:1 mentorship, non-dilutive funding, and access to The Exchange's global partner ecosystem. Fellows leave with a clearer commercialization roadmap, stronger fundraising readiness, and a network of mentors, peers, and potential investors. **Applications Due August 1.**

Shorter variant puts the deadline in the heading: `🗽 NYCEDC Founder Fellowship: Due 12/31`.

### Events in Detail

> ### 🎴 Climate Fresk at Anew
> **When:** Tuesday, Jul 7
>
> **Where:** 526 Hudson St, New York
>
> > Climate Fresk is an interactive, collaborative workshop that teaches the science of climate change through a serious game format in just 3 hours. Participants will explore the causes and effects of climate change while developing actionable strategies for personal impact. Hosted by Anew, a social impact community hub in New York, this free event combines team building with climate literacy and empowerment for environmental action.

Three sentences, moving what-it-is → who-hosts-it → why-attend. Roughly 50–70 words.

---

## 3. Weak and strong

The voice rules in section 5 are adjectives. These pairs are the actual instruction. The gap between the columns is what a tool cannot produce and a person can.

### Pick bullets

| Weak | Why it fails | Strong |
|---|---|---|
| **Thursday** BASIC NY Summer Social, Climate Conversations NYC | A list of names. Nothing helps a reader choose | **Thursday** talk sustainable finance in Sheep's Meadow at the 🧺 BASIC NY Summer Social or join Climatebase in Midtown for 💬 Climate Conversations NYC |
| **Saturday** don't miss the exciting Hunts Point Bike Tour! | Marketing register, and the enthusiasm is unearned | **Saturday** head to the Bronx for an infrastructure tour on wheels at the 🚴‍♂️ Hunts Point Bike Tour |
| **Wednesday** attend a networking event and a panel discussion | Describes a category, not an evening | **Wednesday** get into the weeds on interconnection queues at ⚡ Grid Interconnection 101 or talk buildings over a beer at 🍻 Mass Timber Happy Hour |
| **Tomorrow** join us as we explore climate solutions | Could be any week in any city | **Tomorrow** embrace the tides at the 🌊 2026 Offshore Wind Innovator Program: Q&A Social Hour or make calls (and friends!) at the ⏳ Manhattan Climate Changemakers Hour of Action |

The move in every strong version: a verb, then a place or a reason, then the linked title. The aside in brackets, the phrase "on wheels", the word "beer", are the parts that sound like a person went.

### Opening notes

| Weak | Why it fails | Strong |
|---|---|---|
| It's a slow week but we've still curated an exciting lineup! | Inflates a quiet week, which readers can see through | While the summer is a lot quieter (including on the newsletter), there's still plenty of ways to connect. |
| Climate change is an urgent global challenge requiring collective action. | True of every week, so it says nothing about this one | Last week we pulled out our N95s once again as wildfire smoke subsumed the summer. |
| We apologize for the gap in newsletters over the past few months. | An apology tour. The house answer is to resume without ceremony | Hi friends, |

### Banned outright

`don't miss` · `exciting opportunity` · `dive deep` · `game-changing` · `curated` · `unmissable` · `join us as we explore` · `in today's fast-paced world` · title case in headings · exclamation marks stacked more than one per issue

---

## 4. Emoji

**251 distinct emoji** across the archive, a per-event thematic choice rather than a fixed vocabulary. Propose semantically from the title and category, let the human override, fall back to 🌱 or 🌍.

Most frequent, with counts:
🌱 313 · 🌍 241 · 🌊 104 · ♻️ 104 · ⚡ 104 · 🎨 101 · 🌿 83 · 🍻 77 · 📊 70 · 🌳 66 · 🏗️ 54 · 📚 54 · 🏙️ 50 · 🤖 45 · ☀️ 45 · 💧 44 · 🍹 41

Observed mapping:

| Topic | Emoji |
|---|---|
| Social, drinks, happy hour | 🍻 🍹 🥂 |
| Data, lectures, research | 📊 📈 🔬 |
| Arts, design, galleries | 🎨 🎬 🧵 |
| Buildings, urbanism | 🏗️ 🏙️ 🏢 |
| Energy, grid | ⚡ 🔌 ☀️ |
| Water, ocean | 💧 🌊 |
| Nature, trees, biodiversity | 🌳 🌿 🍄 🦅 |
| Circular economy, waste | ♻️ 🔄 |
| AI, tech | 🤖 |
| Volunteering, restoration | 🦪 🌱 |
| Policy, advocacy | ⏰ ⏳ 🗽 ⚖️ |
| Food, agriculture | 🌾 🍽️ |
| General default | 🌱 🌍 |

Roughly 40% of real listings use one of the top ten. Reusing the same emoji within an issue is normal.

---

## 5. Voice rules

- **Sentence case.** Never title case, never all caps.
- **Contractions** throughout: "we've", "there's", "you're".
- **Acknowledge quiet weeks** plainly rather than inflating them.
- **No marketing register.** No "don't miss", "exciting opportunity", "dive deep", "game-changing".
- **Concrete over abstract.** A venue name and a neighborhood beat an adjective.
- **Never invent** an event, time, venue, quote, or reason for excitement.

---

## 6. Scale expectations

Per-issue volume is an **output**, not a target. The source registry sets the ceiling and human triage sets the final count. For calibration only:

| Year | Avg events | Peak |
|---|---|---|
| 2021 (launch) | 1 | 4 |
| 2022 | 10 | 24 |
| 2023 | 29 | 63 |
| 2024 | 32 | 59 |
| 2025 | 56 | 82 |
| 2026 | 56 | 98 |

A launch city looks like 2021: a handful of events and a long personal note. That is correct, not a failure.

The opening note has gone the other way: 178 words average in 2021, 427 in 2022, 80 now. A mature issue is ~3,000 words of which roughly 80 are human prose. **Those 80 words are the product.**

---

## 7. City configuration

Everything below differs per chapter and must be supplied, not assumed:

- **Chapter name** for the title: "NY Climate Tech", "Boston Climate Tech"
- **Sign-off names.** Who signs the issue
- **Footer block.** Heading, body text, and link URLs. The CTC default is the Climate Tech Cities and Streetlife Ventures startup and talent platform block with two Typeform links, but a non-CTC newsletter needs its own
- **Geographic scope rule.** New York's is roughly 95% the city proper, though published issues carry Jersey City and Hoboken
- **Timezone** for the events sheet headers
- **Category vocabulary.** The CTC set is 22 categories; a smaller or differently focused newsletter should use its own

If any of these are unknown, ask rather than inventing. A wrong footer ships every week until someone notices.

Where the chapter has run `ctc-chapter-setup`, all of this is in the settings file: section 1 for chapter name and timezone, section 2 for scope rule and sign-off. Read it rather than asking again.

`example-issue.json` alongside this file is a complete valid input for the build scripts, showing all of the above filled in for a fictional launch chapter.
