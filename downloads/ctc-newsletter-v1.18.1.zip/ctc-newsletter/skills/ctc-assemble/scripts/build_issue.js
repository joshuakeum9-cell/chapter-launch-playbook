#!/usr/bin/env node
/**
 * Render an assembled CTC newsletter issue as a formatted .docx with embedded
 * hyperlinks, ready to paste straight into the Substack editor.
 *
 *   node build_issue.js issue.json out.docx
 *
 * See SKILL.md for the issue.json contract.
 */

const {
  Document, Packer, Paragraph, TextRun, ExternalHyperlink,
  HeadingLevel, AlignmentType, LevelFormat, BorderStyle,
} = require('docx');
const fs = require('fs');

// The two CTC Typeform links are identical for every chapter and must never
// ship as placeholders. A wrong footer repeats every week and readers rarely
// mention it, so this is a hard stop rather than a warning.
const CTC_TYPEFORM = {
  raise: 'https://gccht82e8mz.typeform.com/to/fLp65vtz?typeform-source=www.climatetechcities.com',
  talent: 'https://gccht82e8mz.typeform.com/to/Rk2roZac?typeform-source=www.climatetechcities.com',
};

function checkFooter(issue) {
  const links = (issue.footer && issue.footer.links) || [];
  const bad = [];
  links.forEach(l => {
    const u = String(l.url || '');
    if (!u || /example\.typeform|PLACEHOLDER|replace before sending|TYPEFORM_.*_URL|^#$/i.test(u)) {
      bad.push(`  X footer link "${l.text}" is a placeholder: ${u || '(empty)'}`);
    }
  });
  if (bad.length) {
    console.error('FOOTER NOT READY. The CTC Typeform URLs are fixed and the same for every chapter:');
    bad.forEach(b => console.error(b));
    console.error(`  Use:\n    raise:  ${CTC_TYPEFORM.raise}\n    talent: ${CTC_TYPEFORM.talent}`);
    process.exit(1);
  }
}


// Measured from the live NY Climate Tech DOM. Substack's base font is
// reader-configurable (17px / 19px observed) but the ratios are stable:
// h2 1.625x, h3 1.375x, h4 1.125x. Body is serif, headers are sans.
const BODY = 26;            // half-points -> 13pt, matches 17px base
const H2 = 42;              // 1.625x
const H3 = 36;              // 1.375x
const H4 = 29;              // 1.125x
const FONT = 'Georgia';     // stand-in for Spectral
const HFONT = 'Helvetica';  // stand-in for SF Pro Display

/** Turn a segment array into runs. A segment is {text} or {text, link}. */
function runs(segments) {
  const out = [];
  for (const seg of segments) {
    const bold = !!seg.bold;
    const italics = !!seg.italics;
    if (seg.link) {
      out.push(new ExternalHyperlink({
        link: seg.link,
        children: [new TextRun({
          text: seg.text, bold, italics, font: FONT, size: BODY,
          style: 'Hyperlink',
        })],
      }));
    } else {
      out.push(new TextRun({ text: seg.text, bold, italics, font: FONT, size: BODY }));
    }
  }
  return out;
}

const para = (segments, opts = {}) => new Paragraph({
  children: runs(segments),
  spacing: { after: 200, line: 300 },
  ...opts,
});

const plain = (text, opts = {}) => para([{ text }], opts);

const bullet = (segments) => new Paragraph({
  children: runs(segments),
  numbering: { reference: 'b', level: 0 },
  spacing: { after: 140, line: 300 },
});

function h(text, level, size) {
  return new Paragraph({
    heading: level,
    spacing: { before: 360, after: 160 },
    children: [new TextRun({ text, bold: true, font: HFONT, size })],
  });
}

/** Indented, left-bordered block. Substack renders descriptions as blockquotes. */
function quote(segments) {
  return new Paragraph({
    children: runs(segments),
    indent: { left: 340 },
    spacing: { after: 200, line: 300 },
    border: { left: { style: BorderStyle.SINGLE, size: 12, color: 'E0E0E0', space: 8 } },
  });
}

/** Linked heading: emoji + title that is itself a hyperlink. */
function hLink(text, url, level, size) {
  return new Paragraph({
    heading: level,
    spacing: { before: 320, after: 120 },
    children: [new ExternalHyperlink({
      link: url,
      children: [new TextRun({ text, bold: true, font: HFONT, size, style: 'Hyperlink' })],
    })],
  });
}

const rule = () => new Paragraph({
  text: '',
  spacing: { before: 240, after: 240 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'D8D8D8', space: 1 } },
});

function build(issue) {
  const body = [];

  body.push(new Paragraph({
    spacing: { after: 120 },
    children: [new TextRun({ text: issue.title, bold: true, font: FONT, size: 56 })],
  }));

  if (issue.subtitle) {
    body.push(new Paragraph({
      spacing: { after: 320 },
      children: [new TextRun({
        text: issue.subtitle, font: HFONT, size: 32, color: '5F5F5F',
      })],
    }));
  }

  (issue.opening_note || []).forEach(p => body.push(plain(p)));

  if (issue.picks && issue.picks.length) {
    if (issue.picks_intro) body.push(plain(issue.picks_intro));
    issue.picks.forEach(pick => {
      const segs = [{ text: pick.day + ' ', bold: true }].concat(pick.segments || []);
      body.push(bullet(segs));
    });
  }

  (issue.housekeeping || []).forEach(p => body.push(plain(p)));

  (issue.signoff || []).forEach(line => body.push(
    new Paragraph({
      spacing: { after: 60, line: 300 },
      children: [new TextRun({ text: line, font: FONT, size: BODY })],
    })
  ));

  if (issue.opportunities && issue.opportunities.length) {
    body.push(rule());
    body.push(h('Opportunities:', HeadingLevel.HEADING_3, H3));
    issue.opportunities.forEach(o => {
      body.push(hLink(o.title, o.url, HeadingLevel.HEADING_3, H3));
      const segs = [{ text: o.description }];
      if (o.deadline) segs.push({ text: ' ' + o.deadline, bold: true });
      body.push(quote(segs));
    });
  }

  if (issue.this_week && issue.this_week.length) {
    body.push(rule());
    body.push(h("This Week's Events", HeadingLevel.HEADING_2, H2));
    issue.this_week.forEach(day => {
      body.push(h(day.day, HeadingLevel.HEADING_4, H4));
      (day.events || []).forEach(e =>
        body.push(bullet([{ text: e.title, link: e.url }])));
    });
  }

  if (issue.upcoming && issue.upcoming.length) {
    body.push(rule());
    body.push(h('Upcoming Events', HeadingLevel.HEADING_2, H2));
    issue.upcoming.forEach(e =>
      body.push(bullet([{ text: e.title, link: e.url }, { text: ': ' + e.date }])));
  }

  if (issue.events_in_detail && issue.events_in_detail.length) {
    body.push(rule());
    body.push(h('Events in Detail', HeadingLevel.HEADING_2, H2));
    issue.events_in_detail.forEach(e => {
      body.push(hLink(e.title, e.url, HeadingLevel.HEADING_3, H3));
      body.push(para([{ text: 'When: ', bold: true }, { text: e.when }],
        { spacing: { after: 80, line: 300 } }));
      body.push(para([{ text: 'Where: ', bold: true }, { text: e.where }],
        { spacing: { after: 120, line: 300 } }));
      body.push(quote([{ text: e.description }]));
    });
  }

  checkFooter(issue);
  if (issue.footer) {
    body.push(rule());
    body.push(h(issue.footer.heading, HeadingLevel.HEADING_2, H2));
    body.push(plain(issue.footer.body));
    (issue.footer.links || []).forEach(l =>
      body.push(bullet([{ text: l.text, link: l.url }])));
  }

  return new Document({
    creator: 'Climate Tech Cities',
    title: issue.title,
    styles: {
      default: { document: { run: { font: FONT, size: BODY, color: '1A1A1A' } } },
    },
    numbering: {
      config: [{
        reference: 'b',
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: '\u2022',
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 480, hanging: 240 } } },
        }],
      }],
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },
        },
      },
      children: body,
    }],
  });
}

const [, , inPath, outPath] = process.argv;
if (!inPath || !outPath) {
  console.error('usage: node build_issue.js issue.json out.docx');
  process.exit(1);
}
const issue = JSON.parse(fs.readFileSync(inPath, 'utf8'));
Packer.toBuffer(build(issue)).then(buf => {
  fs.writeFileSync(outPath, buf);
  console.log('wrote ' + outPath);
});
