#!/usr/bin/env node
/**
 * Render an assembled CTC issue as a Substack-styled HTML article.
 *
 *   node build_issue_html.js issue.json out.html
 *
 * Styling mirrors nyc.climatetechcities.com exactly, measured from the live
 * DOM: body serif at 17px, headers sans, h2 1.625x, h3 1.375x, h4 1.125x,
 * list items indented 32px, descriptions in a left-bordered blockquote.
 *
 * Select all in the rendered page and paste straight into the Substack editor.
 */

const fs = require('fs');

// Same hard stop as build_issue.js. The CTC Typeform URLs are fixed for every
// chapter and a placeholder in the footer repeats every week unnoticed.
function checkFooter(d) {
  const bad = ((d.footer && d.footer.links) || []).filter(l =>
    !l.url || /example\.typeform|PLACEHOLDER|replace before sending|TYPEFORM_.*_URL/i.test(String(l.url)));
  if (bad.length) {
    console.error('FOOTER NOT READY. Placeholder URLs in the footer:');
    bad.forEach(l => console.error(`  X ${l.text}: ${l.url || '(empty)'}`));
    console.error('  raise:  https://gccht82e8mz.typeform.com/to/fLp65vtz?typeform-source=www.climatetechcities.com');
    console.error('  talent: https://gccht82e8mz.typeform.com/to/Rk2roZac?typeform-source=www.climatetechcities.com');
    process.exit(1);
  }
}


const esc = s => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const link = (text, url) => `<a href="${esc(url)}">${esc(text)}</a>`;

function segs(list) {
  return (list || []).map(s => {
    const t = s.bold ? `<strong>${esc(s.text)}</strong>` : esc(s.text);
    return s.link ? `<a href="${esc(s.link)}">${t}</a>` : t;
  }).join('');
}

const CSS = `
:root { --base: 17px; }
body { margin: 0; padding: 40px 20px; background: #fff; }
.post { max-width: 620px; margin: 0 auto; color: #1a1a1a;
  font-family: Spectral, Georgia, Cambria, serif; font-size: var(--base); line-height: 1.6; }
.post h1, .post h2, .post h3, .post h4 {
  font-family: "SF Pro Display", -apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif;
  font-weight: 700; line-height: 1.16; }
.post h1 { font-size: 2.2em; margin: 0 0 .3em; letter-spacing: -.02em; }
.post .subtitle { font-size: 1.25em; color: #5f5f5f; margin: 0 0 1.6em;
  font-family: "SF Pro Display", -apple-system, Helvetica, Arial, sans-serif; font-weight: 400; }
.post h2 { font-size: 1.625em; margin: 1em 0 .625em; }
.post h3 { font-size: 1.375em; margin: 1em 0 .625em; }
.post h4 { font-size: 1.125em; margin: 1em 0 .625em; }
.post p { margin: 0 0 20px; }
.post ul { margin: 0 0 17px; padding: 0; list-style: disc; }
.post li { margin: 8px 0 0 32px; }
.post blockquote { margin: 20px 0; padding-left: 16px; border-left: 4px solid #e0e0e0; color: #333; }
.post a { color: #1a1a1a; text-decoration: underline; text-underline-offset: 2px; }
.post hr { border: 0; border-top: 1px solid #e6e6e6; margin: 32px 0; }
.draft { background: #fff6d9; border-left: 4px solid #e0b000; padding: 8px 12px;
  font-family: -apple-system, Helvetica, Arial, sans-serif; font-size: 13px; color: #6b5200; margin: 0 0 12px; }
`;

function build(d) {
  const h = [];
  h.push(`<h1>${esc(d.title)}</h1>`);
  if (d.subtitle) h.push(`<p class="subtitle">${esc(d.subtitle)}</p>`);

  (d.opening_note || []).forEach(p => h.push(`<p>${esc(p)}</p>`));
  if (d.picks_intro) h.push(`<p>${esc(d.picks_intro)}</p>`);

  if ((d.picks || []).length) {
    h.push('<ul>');
    d.picks.forEach(p =>
      h.push(`<li><strong>${esc(p.day)}</strong> ${segs(p.segments)}</li>`));
    h.push('</ul>');
  }

  (d.housekeeping || []).forEach(p => h.push(`<p>${esc(p)}</p>`));
  (d.signoff || []).forEach(l => h.push(`<p style="margin-bottom:4px">${esc(l)}</p>`));

  if ((d.opportunities || []).length) {
    h.push('<hr>');
    h.push('<h3>Opportunities:</h3>');
    d.opportunities.forEach(o => {
      h.push(`<h3>${link(o.title, o.url)}</h3>`);
      const dl = o.deadline ? ` <strong>${esc(o.deadline)}</strong>` : '';
      h.push(`<blockquote>${esc(o.description)}${dl}</blockquote>`);
    });
  }

  if ((d.this_week || []).length) {
    h.push('<hr>');
    h.push("<h2>This Week's Events</h2>");
    d.this_week.forEach(day => {
      h.push(`<h4>${esc(day.day)}</h4><ul>`);
      (day.events || []).forEach(e => h.push(`<li>${link(e.title, e.url)}</li>`));
      h.push('</ul>');
    });
  }

  if ((d.upcoming || []).length) {
    h.push('<hr>');
    h.push('<h2>Upcoming Events</h2><ul>');
    d.upcoming.forEach(e => h.push(`<li>${link(e.title, e.url)}: ${esc(e.date)}</li>`));
    h.push('</ul>');
  }

  if ((d.events_in_detail || []).length) {
    h.push('<hr>');
    h.push('<h2>Events in Detail</h2>');
    d.events_in_detail.forEach(e => {
      h.push(`<h3>${link(e.title, e.url)}</h3>`);
      h.push(`<p><strong>When:</strong> ${esc(e.when)}</p>`);
      h.push(`<p><strong>Where:</strong> ${esc(e.where)}</p>`);
      h.push(`<blockquote>${esc(e.description)}</blockquote>`);
    });
  }

  checkFooter(d);
  if (d.footer) {
    h.push('<hr>');
    h.push(`<h2>${esc(d.footer.heading)}</h2>`);
    h.push(`<p>${esc(d.footer.body)}</p><ul>`);
    (d.footer.links || []).forEach(l => h.push(`<li>${link(l.text, l.url)}</li>`));
    h.push('</ul>');
  }

  return `<!DOCTYPE html><html><head><meta charset="utf-8">
<title>${esc(d.title)}</title>
<link href="https://fonts.googleapis.com/css2?family=Spectral:wght@400;700&display=swap" rel="stylesheet">
<style>${CSS}</style></head><body><div class="post">
${h.join('\n')}
</div></body></html>`;
}

const [, , inPath, outPath] = process.argv;
if (!inPath || !outPath) {
  console.error('usage: node build_issue_html.js issue.json out.html');
  process.exit(1);
}
fs.writeFileSync(outPath, build(JSON.parse(fs.readFileSync(inPath, 'utf8'))));
console.log('wrote ' + outPath);
