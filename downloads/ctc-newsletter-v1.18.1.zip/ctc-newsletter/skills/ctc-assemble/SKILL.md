---
name: ctc-assemble
description: Assemble a Climate Tech Cities weekly newsletter draft from the events spreadsheet, building all nine blocks in house style, ready to paste into Substack. Use this skill whenever the user wants to build, assemble, draft, or write a city newsletter issue, has an events sheet and wants the newsletter made from it, asks for "this week's issue", wants the picks or opportunities or event listings written up, or is at the drafting stage of the weekly newsletter cycle. Always use this skill even if the user only wants one block, such as just the picks or just the listings. Do NOT use it to collect events, which is the harvest skill's job.
---

# CTC Assemble

Turn the events sheet into a complete newsletter draft in house style. Output is a formatted Word document and a matching HTML file, ready to paste into the Substack editor.

## What this is for

The issue goes to a few hundred to a few thousand people in one city, by email, on the morning of the send day. Most of them scan it in under a minute looking for one thing: is there anything on this week I should go to?

Roughly 40% of the audience does not yet work in climate. That single fact decides more than anything else here. It is why the picks name a neighborhood, why free and newcomer-friendly events win ties, and why the arts and volunteering listings are not filler.

A mature issue runs about 3,000 words, of which roughly 80 are human prose. **Those 80 words are the product.** Everything a reader could have got from a calendar is the other 2,920. The tool's job is to make the 2,920 free so the 80 get written.

## Read this first

Three bundled references. Read the first two before producing any output. They are what make the difference between structurally correct and actually in voice.

- `references/house-style.md`, the formatting spec, worked examples of each block, weak and strong prose pairs, emoji vocabulary, scale expectations, and the per-city configuration list.
- `references/example-issue.md`, one complete published issue end to end, so the assembly order and proportions are concrete. Also shows what a launch issue looks like instead.
- `references/example-issue.json`, a complete valid input file for the build scripts, at launch-chapter scale with a quiet-week note. Read it when writing the JSON, particularly for how a pick bullet interleaves plain prose and linked titles. It is illustrative and its links are placeholders. Never send it.

## Environment

| Dependency | Needed for | If it is missing |
|---|---|---|
| Node.js | Both build scripts | Without it, output the issue as markdown and say the .docx step was skipped. The lead then re-attaches links by hand, which is the tedium this skill exists to remove, so flag it as degraded rather than normal |
| `docx` npm package | `build_issue.js` | `npm install docx` from the scripts directory |
| Code execution enabled | Running either script | Ask the user to enable it in Claude settings |

`build_issue_html.js` has no dependencies beyond Node itself, so if `npm install` fails, the HTML output still works and is a perfectly good paste target.

## Input

- **The events sheet** from `ctc-harvest`, the 14-column format, with a `Block` column marking `this_week` or `upcoming`.
- **The city** and its chapter name.
- **The date window**, for example "July 21 - July 28".
- **Anything the sheet cannot know**: the chapter's own upcoming event, a postponement, a call for submissions, something notable that happened locally this week.
- **The city configuration**: chapter name, sign-off names, footer block and its links, timezone, geographic scope rule. These differ per chapter and per organization.

If the chapter has a settings file (produced by `ctc-chapter-setup`), the configuration is in it: section 1 for city, chapter name, and timezone; section 2 for send day, scope rule, and sign-off. Read it rather than asking. If there is no settings file, ask. **Do not assume a footer.** A wrong footer ships every week until someone notices, and nobody notices for months. The full configuration list is in `references/house-style.md`.

## Before you build anything: ask

Three things are not in the spreadsheet and cannot be inferred from it. Read the sheet first so the questions are specific, then ask all three in one message and wait for the answer. Do not start assembling until you have it.

**1. Which events are the picks?**

List the `this_week` events in date order, numbered, with day, name, and neighborhood, so the user can answer with numbers. Keep it scannable, one line each.

Offer a suggestion, but do not decide. Propose four to six ranked on: the chapter's own and partner events first, then free and open to newcomers, then things a reader could not easily have found alone, then in-person and local over generic webinars. Say plainly that these are a starting point.

Accept anything back: numbers, names, "your list is fine", or picks that were not on your shortlist. Aim for four to six, roughly one per day that has events. More than six and the block stops being a recommendation and turns into a second listing.

**2. Opportunities.**

Fellowships, accelerators, grants, calls for applications, program intakes. These never come from the events sheet.

**Check for an opportunities queue first.** `ctc-opportunities` writes `Opportunities_<City>.xlsx` and the lead keeps it in the project. If it is there, read it and present rather than ask blind:

> Five in your queue are still open:
>
> 1. [Name] closes Nov 14, not used yet
> 2. [Name] closes Dec 1, not used yet
> 3. [Name] closes Nov 30, ran in the issue of Oct 7
>
> Two dropped off since last month, both past deadline.
>
> Which do you want in this issue? I would suggest 1 and 2, they close soonest and have not run.

Suggest two to four, favouring the nearest deadline that has not run yet. **Never present anything past its deadline**, and say how many were dropped so the lead knows the queue was pruned rather than thin.

The lead can also do two other things at this point, so offer both when relevant:

- **Add one of their own.** Somebody emailed them about a fellowship, or a partner asked to be listed. Take the name, link, and deadline, draft it, and write it into the queue so later issues have it too.
- **Ask you to go and find some.** Only on request. Run the research pass from `ctc-opportunities`, then add what it finds to the queue rather than using it once and losing it.

**Never research automatically.** Assembly is a twenty minute step and an unrequested research pass turns it into an hour, every week. The monthly run is where collection belongs.

If there is no queue file, ask as before: two to four, each with a name, a link, and a deadline, and remind the lead to drop anything past its deadline. Mention once that `ctc-opportunities` would keep a running list for them.

If there is nothing either way, the block is omitted rather than padded.

**After the issue is drafted, mark what ran.** Update the queue's status and last-used columns so next week does not offer the same fellowship again.

**3. Anything the sheet cannot know?**

The chapter's own upcoming event, a postponement, a call for submissions, something notable that happened in the city this week. This is what the opening note and housekeeping are built from. If the user has nothing, say so and leave those blocks as marked scaffolds.

Ask once, in one message. If the user does not answer part of it, proceed with what you have and mark the gap clearly rather than asking again.

**Why the intake is a conversation rather than a spreadsheet column.** An earlier version of this toolkit had `ctc-harvest` write a `Pick` column that the lead filled in before assembly. It was removed. Asking three questions in one message is less work for a volunteer than editing an extra column, and it also collects the opportunities and the local news, which no column could hold. Do not reintroduce a pick column.

## The division that matters

Six blocks are mechanical: the tool builds them completely and they need only a check. Three are editorial: the tool drafts a scaffold, and a person makes it real.

This is not a limitation to work around. Generated text in those blocks reads like a computer, and the house position is that it does not ship.

The skill still drafts them, because a scaffold beats a blank page. It marks them clearly so nothing generated reaches readers unrevised.

**The marker is a square bracket**, on its own line at the top of each editorial block:

```
[DRAFT - rewrite in your own voice before sending]
```

Square brackets rather than an HTML comment, because the pre-send check is "search the document for a square bracket, nothing in brackets ships". A marker the check cannot find is not a marker.

---

## The nine blocks, in publication order

### 1. Title and subtitle: mechanical

**Title:** `[Chapter name]: [Month D] - [Month D]`, the seven-day window. Never an issue number.

> NY Climate Tech: July 21 - July 28

**Subtitle:** comma-separated topics drawn from the picks and opportunities, closing with `and more upcoming events`. Doubles as the email subject line, so front-load the most interesting item.

> Offshore wind, hours of action, sustainable investment in the park, climate conversations, climate innovation, City of Water Day, and more upcoming events

Six or seven topics. Lowercase except proper nouns. Build it *after* the picks are settled, since it summarizes them.

### 2. Opening note: editorial, scaffold only

Greeting: `Hi all,` (most common) or `Hi friends,`.

Then one or two short paragraphs, roughly 60 to 90 words total, doing one of two things:

- **A topical or seasonal hook** that turns toward local community. The 21 July issue opens on wildfire smoke and tornado warnings, then pivots: *for such a global problem, we continually find hope and inspiration in local community.*
- **The chapter's own upcoming event**, plugged first. The 7 July issue leads with its summer summit before the picks.

Close with `Here are our picks for the week:`

**What the tool cannot know**, and must therefore mark rather than invent: the weather, local news, how a past event went, why the chapter is excited about something. Generate the shape and leave a marked gap:

```
Hi all,

[DRAFT - rewrite in your own voice before sending]

[HOOK - 2 to 3 sentences. Something true about the city this week, turning toward
local community. Cannot be generated: needs what actually happened.]

Here are our picks for the week:
```

If the user supplies the hook material, draft it, but flag it for rewriting in their own words.

### 3. Picks of the week: editorial, strong scaffold

One bullet per day. Day in **bold**. Prose, not a list of names. Four to six bullets.

Pattern: **day** → verb → place or reason → linked event title with its emoji.

> **Thursday** talk sustainable finance in Sheep's Meadow at the 🧺 BASIC NY Summer Social or join Climatebase in Midtown for 💬 Climate Conversations NYC

Rules drawn from the archive:

- **Day words:** `Today`, `Tomorrow`, weekday names, and `Next Tuesday` for something just past the window
- **Multiple events in one day** are joined with `or`, never `and`
- **Verb first** after the day: *head to*, *talk*, *catch*, *embrace*, *celebrate*, *learn*, *polish up*, *make calls*
- **Neighborhood or venue** earns its place, "in Sheep's Meadow", "on Governor's Island", "in Midtown", because it helps a reader decide
- Every event named here must also appear in the listings, in This Week's Events or in Upcoming

**Selection comes from the user's answer to question 1**, not from your own ranking. Build only what they chose.

One bullet per day that has picks, in date order. All of that day's picks go in a single bullet, joined with `or`.

A `Next Tuesday` pick is legitimate and it sits in `upcoming`, not `this_week`, because it is past the seven-day window. That is the one case where a pick is not in This Week's Events, and it is correct. Confirm with the user rather than assuming, then leave the event in Upcoming.

Any other pick drawn from `upcoming` should be flagged before building. Picks are for the coming week.

**The gap to mark.** The tool can produce correct structure. It cannot produce *"make calls (and friends!)"* or *"an infrastructure tour on wheels"*, the small asides that make it sound like a person. Draft the bullets, then note that the asides need adding. The weak and strong pairs in `references/house-style.md` show the difference.

### 4. Housekeeping and sign-off: editorial, template

Comes *before* Opportunities in the published issue, not at the end. This trips people up.

Housekeeping covers postponements, calls for submissions, anything the chapter needs to say. Reader asks are **bolded inline**.

> We've postponed Wednesday's **Other Intelligence** summit until later this year (too many people were out of town!) but are still looking forward to it in the Fall.
>
> Also, Climate Week is around the corner! Keep your eyes peeled for our first guide, and **if you're planning any events for Climate Week NYC, send them our way by replying to this email.**

Sign-off, then a horizontal rule:

> Til next week!
> [Names], and the Climate Tech Cities team

The variant `As always,` also appears. Only include housekeeping if the user supplied something. Never invent an announcement.

### 5. Opportunities: editorial, needs a source

Two to four items: fellowships, accelerators, grants, calls for applications.

Format is a linked emoji heading, then the description, with the deadline bolded at the end.

> ### 💡 New York Climate Exchange Climate Tech Fellowship
> The Climate Tech Fellowship is a six-month hybrid program that combines expert-led curriculum, 1:1 mentorship, non-dilutive funding, and access to The Exchange's global partner ecosystem. **Applications Due August 1.**

A shorter variant puts the deadline in the heading itself: `🗽 NYCEDC Founder Fellowship: Due 12/31`.

Build from the user's answer to question 2. Items recur across consecutive issues until they close, which is correct rather than lazy. **Drop anything past its deadline.** A dead deadline erodes trust faster than anything else in the issue.

If the user gave a name and link but no description, draft one from the program page and mark it for review. If they had no opportunities this week, omit the block rather than padding it.

### 6. This Week's Events: mechanical, build completely

Every row where `Block = this_week`, grouped under day headers, chronological.

```
#### Wednesday, Jul 22
[emoji] [Event Name](Registration Link)
[emoji] [Event Name](Registration Link)

#### Thursday, Jul 23
[emoji] [Event Name](Registration Link)
```

Titles only, no times, no venues, no descriptions. The day header carries the date.

Use the event name exactly as harvested. Do not shorten or editorialize.

### 7. Upcoming Events: mechanical, build completely

Every row where `Block = upcoming`. Flat, chronological, no day headers, date appended after the link.

```
[emoji] [Event Name](Registration Link): Aug 6
```

Runs six to eight weeks out. Date format `Mon D`.

### 8. Events in Detail: mechanical, optional

Present in some issues, absent from others; the governing rule is undocumented. Ask whether to include it. Default to omitting on a heavy week, since it is the block that makes a long issue longer.

Per event: linked emoji heading, then When, Where, description.

```
### [emoji] [Event Name](Registration Link)

**When:** Tuesday, Jul 7

**Where:** 526 Hudson St, New York

[Three sentences from the sheet's Description column.]
```

Three sentences, roughly 50 to 70 words, moving from what-it-is to who-hosts-it to why-attend. Use the sheet's description, condensed. Do not rewrite freely or embellish.

### 9. Standing footer: mechanical, boilerplate

Unchanged every issue. **The two Typeform URLs below are the real, live Climate Tech Cities links and are identical for every chapter.** Copy them exactly. They are not placeholders, they are not per-city, and they do not need to be looked up or asked about.

```
## 🌎 Climate Tech Cities and Streetlife Ventures Startup and Talent Platforms

Climate Tech Cities and Streetlife Ventures are launching new platforms to support
climate founders, funders, and career transitioners! There is no shortage of great
companies raising money for their groundbreaking ideas, great investors looking to
support with capital, and great talent living the mantra that every job is a climate job.
We can't wait to hear from you!

- [Climate startups looking to raise](https://gccht82e8mz.typeform.com/to/fLp65vtz?typeform-source=www.climatetechcities.com)
- [Climate talent looking to transition](https://gccht82e8mz.typeform.com/to/Rk2roZac?typeform-source=www.climatetechcities.com)
```

Never rewrite this, and never substitute a placeholder. A footer that ships with `[PLACEHOLDER URL - replace before sending]` or an `example.typeform.com` address in it is a defect, not a prompt for the lead. The correct URLs are written above: use them.

---

## Emoji

Every event in every listing block gets one, placed before the title and **inside the link**, so the emoji is part of the clickable text rather than orphaned beside it.

There are 251 distinct emoji across the archive, so a lookup table will not work. **Propose semantically from the event title and topic, then let the human override.**

Observed mapping: 🍻 🍹 social and drinks · 📊 📈 data and lectures · 🎨 arts · 🏗️ 🏙️ buildings and urbanism · ⚡ 🔌 energy and grid · 💧 🌊 water · 🌳 🌿 nature and trees · ♻️ circular economy and waste · 🤖 AI and tech · ☀️ solar · 📚 education · 🦪 volunteering and restoration

Fallback: 🌱 or 🌍. Roughly 40% of real listings use one of the top ten, so a small default set plus overrides covers most of the work.

Reuse of the same emoji within an issue is fine and happens constantly.

---

## Voice rules

- **Sentence case.** Never title case, never all caps.
- **Contractions throughout.** "We've", "there's", "you're".
- **Acknowledge quiet weeks** rather than inflating them. *"While the summer is a lot quieter (including on the newsletter)"* is house voice: self-aware, not apologetic.
- **No marketing register.** No "don't miss", "exciting opportunity", "dive deep", "game-changing", "curated", "unmissable", "join us as we explore".
- **Concrete over abstract.** A venue name and a neighborhood beat an adjective.
- **Never invent** an event, time, venue, quote, or reason for excitement.

Paired weak and strong examples are in `references/house-style.md`. Read them before writing any pick bullet.

---

## Output

**Two deliverables, and only two: a formatted `.docx` and an `.html` file.** Both carry embedded hyperlinks and both paste straight into the Substack editor.

**The JSON is scratch, not a deliverable.** Write it, run the scripts, and leave it behind. Never call `present_files` on it and never hand it to the lead. It is the script's input format and it means nothing to the person receiving the issue.

The `.docx` is the primary. Rich-text paste preserves headings, bold, bullets, and links, so the lead never re-attaches 40 to 55 links by hand. That re-linking is the tedious part the automation exists to remove.

Build both by writing the issue as JSON in your working directory and running the two bundled scripts:

```
node scripts/build_issue.js issue.json out.docx
node scripts/build_issue_html.js issue.json out.html
```

Then present the `.docx` and the `.html`. Nothing else.

**issue.json contract:**

```json
{
  "title": "NY Climate Tech: July 21 - July 28",
  "subtitle": "topics, comma separated, and more upcoming events",
  "opening_note": ["Hi all,", "paragraph"],
  "picks_intro": "Here are our picks for the week:",
  "picks": [
    {"day": "Tomorrow", "segments": [
      {"text": "embrace the tides at the "},
      {"text": "🌊 Event Name", "link": "https://..."}
    ]}
  ],
  "housekeeping": ["paragraph"],
  "signoff": ["Til next week!", "Names, and the Climate Tech Cities team"],
  "opportunities": [
    {"title": "💡 Name", "url": "https://...", "description": "...", "deadline": "Applications Due August 1."}
  ],
  "this_week": [
    {"day": "Wednesday, Jul 22", "events": [{"title": "🌊 Name", "url": "https://..."}]}
  ],
  "upcoming": [{"title": "♻️ Name", "url": "https://...", "date": "Jul 29"}],
  "events_in_detail": [
    {"title": "🌊 Name", "url": "https://...", "when": "Wednesday, Jul 22", "where": "Address", "description": "Three sentences."}
  ],
  "footer": {"heading": "🌎 ...", "body": "...", "links": [{"text": "...", "url": "..."}]}
}
```

A segment is `{text}` for plain runs or `{text, link}` for hyperlinked ones, so a pick bullet interleaves prose and linked event titles the way the house style does. **The segment array is the part people get wrong**, usually by putting a whole bullet in one segment and losing the links. `references/example-issue.json` is a complete valid file; read its `picks` array before writing your own.

Omit any block that has no content and it is skipped entirely. Keys beginning with an underscore are ignored, which is how the example file carries its own annotations.

**Also emit an HTML version**, the same issue, styled to match Substack:

```
node scripts/build_issue_html.js issue.json out.html
```

This renders as a readable article the user can select-all and paste directly into the Substack editor. Some people prefer it to Word; produce both and let them choose.

**Formatting is measured, not guessed.** Body is serif, headers are sans, `h2` is 1.625x body, `h3` is 1.375x, `h4` is 1.125x, list items indent 32px, and descriptions sit in a blockquote with a 4px left border. Both scripts already implement this. See `references/house-style.md` for the full table and the two details people get wrong.

Then report in chat:

- Blocks built completely versus scaffolded
- Event counts per listing block
- Events named in the picks but missing from both listing blocks
- Picks the user named that could not be matched to a row in the sheet
- Opportunities carried forward, and any past their deadline
- Emoji assigned by fallback rather than by topic, since these are the ones worth a glance
- Anything in the sheet that could not be placed

## Pre-send checks

Run these before handing over:

- Every listing has an emoji and a working link
- No event appears in both This Week's and Upcoming
- No event dated before the send date
- Every pick appears in the listings, in This Week's Events or in Upcoming
- Subtitle matches what the picks actually cover
- Footer intact with both links
- Every deadline in Opportunities is still in the future
- Every square bracket left in the document is a deliberate scaffold marker

---

## Failure modes

**Filling a scaffold to be helpful.** The largest one. The brackets are load-bearing, and generated prose in the note or picks is the failure this whole pipeline is arranged to prevent. If the lead asks for the note to be written, decline once and offer the thing that helps instead: ask what happened in the city this week and reflect it back as raw material.

**Pick bullets as a list of names.** `**Thursday** BASIC NY Summer Social, Climate Conversations NYC` is structurally correct and dead. The bullet is prose: a verb, a place, then the linked title.

**Joining same-day events with "and".** It is always `or`. The reader is choosing one, not attending both.

**A pick that is not in the listings.** The reader reads the recommendation, scrolls down to find the details, and it is not there. Every pick appears in one of the two listing blocks. A `Next Tuesday` pick belongs in Upcoming; everything else belongs in This Week's Events.

**Sign-off at the bottom.** It sits in the middle, after housekeeping and before Opportunities. Every issue in the archive does this and it looks like an error to anyone reading the format fresh.

**Padding Opportunities.** Two real ones beat four with filler, and a lapsed deadline is worse than an empty block.

**Shipping a link that was never opened.** Assembly reproduces whatever is in the sheet, so a wrong link in the spreadsheet becomes a wrong link in the issue. If `ctc-harvest` reported link defects and they were not fixed, say so before building rather than after.

**A stale or placeholder footer.** The two Typeform URLs are hardcoded in block 9 above and are the same for every chapter. Never emit a placeholder, an `example.typeform.com` address, or a bracketed "replace before sending" note. A wrong footer ships every week until a reader mentions it, and readers rarely mention it.

**Shipping markdown instead of the document.** The deliverable is the .docx and the .html. Markdown in chat means the lead re-attaches every link by hand, which is exactly the work this skill exists to remove.
