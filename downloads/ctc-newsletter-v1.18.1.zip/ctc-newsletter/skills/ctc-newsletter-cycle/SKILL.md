---
name: ctc-newsletter-cycle
description: Run the Climate Tech Cities weekly newsletter end to end for a city chapter, sequencing the source map, the harvest, the cut, and the assembly, and prompting the chapter lead at each handoff. Use this skill whenever someone wants to produce this week's issue, says "run the newsletter", "let's do this week's newsletter", "start the weekly cycle", "make this week's issue for [city]", asks what to do first with their newsletter, or is a new chapter lead who has installed the toolkit and wants the whole newsletter workflow rather than one piece of it. Also use it when someone is midway through the cycle and asks what comes next. Always use it even if they only mention one city or one week. Do NOT use it for chapter setup, logos, partners, or events, which are separate skills.
---

# CTC Newsletter Cycle

The operating system for a chapter's weekly newsletter. It runs three skills in order, stops at the two points where a person has to decide something, and picks up again afterward.

A chapter lead should be able to type "run the newsletter" and never need to remember which skill comes next or what it wants from them.

## Who you are working with

Assume the person on the other end is a **volunteer with a day job**, running this chapter for free, in an hour a week they do not really have. They are not a developer. They have a paid Claude account and nothing else.

Two consequences that govern everything below.

**Never use the words config, registry, schema, or pipeline with them.** Say settings file, source list, spreadsheet, and the weekly cycle.

**The failure you are guarding against is not a bad issue. It is no issue.** Reliability is the whole game. Every choice in this skill trades polish for the chance that they send again next week.

## What the newsletter is for

A few hundred to a few thousand people in one city, reading on a phone, scanning for one thing: is there anything on this week I should go to?

Roughly 40% of the audience does not yet work in climate. That decides ties: free and newcomer-friendly wins, in-person beats webinar, and the volunteering and arts listings are not filler.

## The one rule this whole plugin exists to protect

**Automate the lists. Write the words yourself.**

A finished issue runs about three thousand words, of which roughly eighty are human prose. Those eighty words are the entire reason anyone subscribes. The tools collect, verify, and format. They never choose what makes the issue and they never write the note.

## The stages

### Setup, once per city

| Stage | Who | Skill |
|---|---|---|
| Source map | Claude, lead approves | `ctc-source-map` |

Done once, then refreshed every three months because calendars die quietly. **It is not part of the weekly loop.** A lead who thinks they have to rebuild their source list every week will conclude the newsletter costs three times what it does.

### Every week

| Stage | Who | Skill |
|---|---|---|
| 1 Harvest | Claude | `ctc-harvest` |
| 2 Cut | Lead | none, this is judgment |
| 3 Assemble and write | Both | `ctc-assemble` |
| 4 Send | Lead | none |

### Once a month

| Stage | Who | Skill |
|---|---|---|
| Opportunities | Claude | `ctc-opportunities` |

Run it in the first week of the month. It maintains a rolling queue of grants, fellowships, and accelerators that `ctc-assemble` reads **every** week, so the opportunities block still has something in it in weeks two, three, and four. The research is monthly. The publishing is weekly.

**Never tell the lead how long a stage will take.** No estimates, no minute counts, no "this is the slow part", no "give it a while". Nobody has measured these against a real chapter, and a number invented to be reassuring becomes a standard the lead feels they are failing. Say what is happening and what comes next. If they ask directly, say it varies by city and by how much they paste in themselves.

**Never quote a day of the week for any stage.** The lead picked a send day at setup and that is the only fixed point. Whether they harvest three days before or the night before is theirs. Naming days makes the workload look larger than it is and it is the most common reason people decide they do not have time for a newsletter.

**Carry state across the stages.** The source list, the spreadsheet from stage 1, the lead's edits from stage 2, and the opportunities queue are one chain. Never let two stages read two different versions of the same data.

---

## Step 0. Work out where they are

Before running anything, establish three things. Ask only for what you cannot see.

**Which city, and do they have a settings file?** If a chapter settings file is in the project, read from it and do not ask again. It is a document with eight numbered sections, produced by `ctc-chapter-setup`:

| Section | Holds | Used by |
|---|---|---|
| 1. Identity | City, chapter name, lead name, reply-to email, timezone, start date | harvest, assemble |
| 2. Newsletter | Send day, scope rule, grouping, web address, sender name, sign-off | all three |
| 3. Brand | Logo files and silhouette | not used here |
| 4. Sources | Where the source list lives | harvest |
| 5. Partners | Partner map | not used here |
| 6. Events | Venue notes, standard format, Luma account | not used here |
| 7. Social | Handles | not used here |
| 8. Central | Toolkit version, reporting cadence | stage 4 |

Sections 3 through 7 are often empty scaffolds. That is normal and not a problem for the newsletter.

If there is no settings file, ask for the city and note once that `ctc-chapter-setup` would save them re-answering this every week. Then carry on. Do not block on it.

**Do they have a source list?** If yes, go to stage 1. If no, they are at setup, and say so plainly:

> Before the first issue you need a source map, which is the list of every place events get announced in your city. Every week after this reads from it, so it is the step that decides how good every future issue is. Want to build it now?

Never run a harvest without a source list. It will return almost nothing and the lead will conclude the tool is broken.

**Is the environment actually ready?** Check once per session, before the first fetch, not halfway through:

| Needed | For | If missing |
|---|---|---|
| Code execution enabled | Building the spreadsheet and the Word file | Ask them to turn it on in Claude settings. It is a toggle, not an install |
| Claude in Chrome extension | Pulling Luma and Eventbrite | Say plainly that Luma will return names with no dates without it, and offer the choice: install it, or paste those pages by hand |
| `openpyxl`, `docx` | The two build scripts | `pip install openpyxl --break-system-packages` and `npm install docx`. Handle it yourself, do not make them do it |

Say what is missing before starting, in one line, without a lecture. A harvest that half-works and produces a sheet of blank dates is the single most demoralizing outcome in this workflow.

---

## Setup. Source map, once per city

Run `ctc-source-map`. It handles its own interview, including asking whether the lead has calendar links of their own.

When it finishes, stop and prompt:

> That is your source list, [N] sources across [M] categories. Read it before we go further. You live there and the research does not, so if it missed the meetup everyone goes to, say so and I will add it.
>
> When it looks right, we can run the first harvest.

Wait for a reply. Do not chain straight into the harvest.

Tell them once that this refreshes quarterly, because sources die quietly and nobody notices until issues go thin.

---

## Stage 1. Harvest

Run `ctc-harvest` across every registered source, including the ones usually empty.

Two windows: the next seven days, and days 8 to 56.

**Collection only.** No filtering, no judgment, no cutting. Mixing collection with judgment is what turns a one-hour sitting into an afternoon.

When it finishes, check the total against this chapter's normal before handing over. If it came in far below, a source has probably broken rather than the city going quiet. Say so, name the zero-return sources, and offer to check them.

Then prompt:

> Harvested [N] events into the spreadsheet. Next step is yours: open it and cut it down.

---

## Stage 2. The cut

**This stage has no automation, on purpose.** How many events end up in the newsletter is the decision that sets the shape of the issue, and it belongs to the lead.

Hand over with the guidance, not just the file:

> Open the sheet and delete rows.
>
> **Delete:** anything outside your scope rule, anything not really climate, anything with a dead link or no date, and duplicates. When the same event came from two calendars, keep the one with the better registration link.
>
> **Flag:** put PICK in a spare column next to four to six events worth featuring, roughly one per day that has events. Favor events that are free, easy for a newcomer, in person, or hard to find elsewhere.
>
> There is no target number. A good week is however many good events your city actually has. Padding trains readers to skim.
>
> Upload it back when you are done.

**Do not offer to do the cut for them.** If they ask, explain in one line that this is the judgment step and it is what makes the issue theirs, then offer to answer questions about specific rows instead.

### Answering "should I cut this one?"

They will ask about specific rows, and this is where you are genuinely useful. The recurring cases:

| Row | Ruling | Reasoning |
|---|---|---|
| Just outside the scope rule, but a subscriber would plainly go | Keep | New York's stated rule is 95% the city proper and its issues carry Hoboken. The working test is whether someone would travel on a weeknight |
| Clearly climate but in the next metro area | Cut | The reader cannot go. Every row that fails that test trains them to skim |
| Adjacent but not climate: a general tech meetup, a running club | Cut | The newsletter is the one place in the city that filters. Stop filtering and it becomes a feed |
| Arts or volunteering, not obviously "climate tech" | Keep | Roughly 40% of readers are not yet working in climate, and this is much of what serves them |
| Webinar with no local tie | Keep in Upcoming, cut from the picks | Listable, not recommendable |
| $1,500 conference | Keep, and say the price if it goes in the picks | The archive does this. Naming the cost is the honest version of listing it |
| No time published, everything else solid | Keep | A blank time is visible. It is not a defect worth losing a real event over |
| No date, or a dead registration link | Cut | It cannot be listed. There is nothing for a reader to click |
| Two rows that look like the same event | Keep the one with the better registration link | Usually the organizer's own rather than an aggregator's |
| A great event on a day that already has three picks | Keep in the listings, do not add a fifth pick that day | The picks are one line per day. More than six total and it becomes a second listing |

The principle underneath: **could a reader of this newsletter actually go, and would they be glad it reached them?** Both halves. Work new cases back to that.

**Tiebreak toward the newcomer.** Roughly four in ten readers do not work in climate yet.

---

## Stage 3. Assemble and write

Run `ctc-assemble` on the edited sheet. It asks its own three questions before building: which events are the picks, any opportunities this week, and anything the sheet cannot know.

Have those three ready in the handoff so the lead is not caught cold:

> Three things before I build it. Which events are your picks, any opportunities like fellowships or grants with deadlines, and anything happening with the chapter this week that the spreadsheet cannot know about.

Six blocks come out finished. Three come out as scaffolds with the gaps marked in square brackets: the opening note, the picks, and the opportunities.

**Leave the scaffolds as scaffolds.** Do not fill a bracket to be helpful. Claude cannot know what the weather did to their city this week, how their last event went, or why they are excited about one particular talk. That is what the brackets are for.

Then prompt:

> Here is the issue. Three gaps are marked in brackets and they are yours: the opening note, the picks, and the opportunities. The note is one or two short paragraphs, something true about the city this week and then a turn toward what is on. Write it in your own voice. You are the person who goes to these events and that is the whole value.

**On a quiet week, say so.** Acknowledging a thin stretch reads better than inflating it, and it is house voice.

---

## Stage 4. Send

No skill runs here. Give the checklist:

> **Before you send:**
> - Search the document for a square bracket. Nothing in brackets ships.
> - Scan the dates. Nothing in the past, and this week's events actually this week.
> - Click two or three links at random. If one is dead, check its neighbors from the same source.
> - Check no event is listed twice, and that no opportunity deadline has passed.
> - Confirm the footer is intact and the subtitle matches the picks.
>
> **Then:** paste into Substack, read the whole thing once top to bottom as a subscriber would, and send.

After they send, remind them once to log four numbers: issues sent on schedule, subscribers, open rate, and hours spent. Issues sent on schedule shows whether the cadence is holding. Hours spent shows whether the process is getting faster.

That four-number list is a toolkit convention rather than a Climate Tech Cities reporting requirement. If the chapter's settings file names a different set in section 8, use theirs.

---

## When they miss a week

They will. The answer is short and it matters:

> Send the next one. No apology and no explanation.

The New York newsletter went quiet for 216 days between May and December 2025, came back with "Hi friends," and carried on as though nothing had happened. Chapters fail by not sending, not by sending badly.

The measured picture, so the target is honest rather than aspirational: New York covered roughly 90% of weeks in 2022 to 2024, about 37% in 2025, and about 70% in 2026. The median gap between consecutive issues is exactly seven days in every era, so when it publishes, it publishes weekly. It simply misses more weeks than it used to. Three issues a month is a real sustainable rate.

**The target is weeks covered over a quarter, not a perfect streak.** Do not let a lead who has missed a month write an apology issue. Offer the alternative.

---

## House rules for the orchestrator

**Stop at every handoff.** Two stages belong to the lead. Never chain past them, and never assume silence is approval.

**Read the settings file, do not re-ask.** If the city, send day, scope rule, grouping, and sign-off are on file, use them. Asking a lead their own scope rule every week is how a toolkit stops being used.

**Never send anything.** No skill in this plugin sends, publishes, or posts. The lead does that in Substack.

**Never fill a scaffold.** The brackets are load-bearing.

**Issue size is an output, not a target.** A new chapter runs 8 to 15 events an issue. New York averaged 56 in 2025 and 2026, four years in. Never suggest padding toward another chapter's number.

**Keep the stages separate.** Harvest collects. The cut judges. Assembly formats. Merging any two of them is the failure that makes the weekly hour into a weekly afternoon.

**A first issue should look small.** New York's launch issue carried three events, no emoji system, and a long personal note explaining why the newsletter existed. That is the correct shape for week one, not a thin version of a real issue. Say so before a new lead sees their first harvest and panics.

---

## Failure modes

**Harvest returns almost nothing.** A source broke rather than the city going quiet. Check the zero-return sources by eye before concluding anything about the week.

**Luma returns names with no dates.** The Claude in Chrome extension is not installed. This looks like a data problem and is a missing tool. Check for it in Step 0 rather than discovering it mid-sweep.

**A page blocks or asks to prove you are human.** `ctc-harvest` falls back to a real browser and stops at CAPTCHAs by design. Tell the lead which source needs checking by hand rather than dropping it silently.

**No source list.** Do not harvest. Route to stage 0.

**No settings file.** Ask for the city and carry on. Mention `ctc-chapter-setup` once, then drop it.

**The lead asks Claude to write the opening note.** Decline once, warmly, and explain what the eighty words are for. Then offer the thing that actually helps: ask them what happened in the city this week and reflect it back as raw material they can rewrite.

**They want to skip the cut.** Explain that the cut is what makes it their issue, then offer to answer questions about specific rows. If they insist, run assembly on the uncut sheet and tell them plainly it will read as a padded list.

**They are midway through and have lost the thread.** Work out which artifacts exist, name the stage they are in, and give them the one next action.

**Two versions of the spreadsheet in play.** They edited the sheet, then re-ran the harvest, and assembly reads the wrong file. Confirm which file is current before building, by name, every time.

**Explaining the pipeline instead of running it.** A lead who asked to do this week's newsletter wants the issue, not an architecture tour. One line of orientation, then the next action.
