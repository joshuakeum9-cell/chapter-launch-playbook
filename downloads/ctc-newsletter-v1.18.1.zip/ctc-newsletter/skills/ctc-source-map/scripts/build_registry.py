#!/usr/bin/env python3
"""
Write the source registry as a formatted workbook.

    python3 build_registry.py sources.json CTC_Source_Registry_<City>.xlsx

Layout matches the events sheet produced by ctc-harvest, so the two files feel
like one product, with one deliberate difference: the header band is TEAL here
and GREEN there. A lead with both files open can tell at a glance which is the
list of places events come from and which is the list of events.

sources.json is a list of objects keyed by the column names below, plus a
top-level "city". Same shape as the CSV the skill used to write, so nothing
upstream changes except the call at the end.
"""

import json
import re
import sys
from collections import Counter

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

# Teal. The events sheet uses 2E7D32 green. Do not make these the same.
HEAD_FILL = PatternFill("solid", fgColor="0F6E6E")
UNVERIFIED_FILL = PatternFill("solid", fgColor="FDF0E3")
GAP_FILL = PatternFill("solid", fgColor="F8CBCB")
HEAD_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
BODY_FONT = Font(name="Arial", size=10)

REQUIRED = ["name", "url", "platform", "method", "tier", "category",
            "cadence", "last_event", "confidence", "origin"]


def row_gaps(e):
    """Required fields this source is missing."""
    return [k for k in REQUIRED if not str(e.get(k, "") or "").strip()]


COLUMNS = [
    ("name", "Source Name", 34),
    ("url", "URL", 44),
    ("platform", "Platform", 12),
    ("method", "Method", 10),
    ("tier", "Tier", 10),
    ("category", "Category", 18),
    ("cadence", "Cadence", 22),
    ("last_event", "Last Event", 13),
    ("confidence", "Confidence", 13),
    ("origin", "Origin", 11),
    ("notes", "Notes", 60),
    ("_gaps", "Missing Info", 30),
]

CATEGORIES = [
    "luma", "eventbrite", "university", "incubator", "government",
    "professional", "newsletter", "climate org", "arts",
]


def main(src, out):
    data = json.load(open(src))
    city = data.get("city", "City")
    rows = data.get("sources", data if isinstance(data, list) else [])

    wb = Workbook()
    ws = wb.active
    ws.title = "Sources"

    for i, (_, header, width) in enumerate(COLUMNS, start=1):
        c = ws.cell(1, i, header)
        c.fill = HEAD_FILL
        c.font = HEAD_FONT
        c.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[1].height = 27.75

    label = {k: h for k, h, _ in COLUMNS}
    for r, e in enumerate(rows, start=2):
        unverified = str(e.get("confidence", "")).strip().lower() == "unverified"
        gaps = row_gaps(e)
        gap_cols = {k for k in gaps}
        for i, (key, _, _) in enumerate(COLUMNS, start=1):
            if key == "_gaps":
                val = ", ".join(label[k] for k in gaps)
            else:
                val = e.get(key, "")
            c = ws.cell(r, i, val)
            c.font = BODY_FONT
            c.alignment = Alignment(vertical="top",
                                    wrap_text=(key in ("notes", "_gaps")))
            # Only the empty cell goes red, plus the note that names it.
            # Shading a whole row buries the one field that needs attention.
            if key in gap_cols or (key == "_gaps" and gaps):
                c.fill = GAP_FILL
            elif unverified:
                c.fill = UNVERIFIED_FILL

    ws.freeze_panes = "A2"
    wb.save(out)

    # ---- report, read this rather than assuming it passed
    print(f"wrote {out}")
    print(f"  {len(rows)} sources for {city}\n")

    per_cat = Counter(str(e.get("category", "")).strip().lower() for e in rows)
    for cat in CATEGORIES:
        n = per_cat.get(cat, 0)
        flag = "" if n else "   <- empty"
        print(f"  {cat:<14} {n:>3}{flag}")
    other = {k: v for k, v in per_cat.items() if k not in CATEGORIES and k}
    for k, v in other.items():
        print(f"  {k:<14} {v:>3}   <- not a standard category")

    print()
    warns = []
    failures = []
    if len(rows) < 25:
        failures.append(
            f"{len(rows)} sources. The floor is 25. THIS REGISTRY IS NOT READY. "
            f"Go back to Step 2 and work the empty categories until you reach 25. "
            f"Do not pad: every source must still pass all five gates.")
    if len(rows) > 35:
        warns.append(f"{len(rows)} sources. Over about 35 the weekly sweep gets slow.")
    empty = [c for c in CATEGORIES if not per_cat.get(c)]
    if empty:
        warns.append(f"empty categories: {', '.join(empty)}. Say why each is empty "
                     f"rather than leaving the gap unexplained.")
    incomplete = [(e, row_gaps(e)) for e in rows if row_gaps(e)]
    if incomplete:
        print(f"  {len(incomplete)} source(s) missing required info, shaded red "
              f"and named in the Missing Info column:")
        for e, g in incomplete:
            print(f"    {str(e.get('name'))[:40]:42s} {', '.join(label[k] for k in g)}")
        print()
    for e in rows:
        u = str(e.get("url", ""))
        if u and not u.startswith("http"):
            warns.append(f"{e.get('name')}: URL is not a link -> {u}")
    unv = [e for e in rows if str(e.get("confidence", "")).lower() == "unverified"]
    if unv:
        print(f"  {len(unv)} unverified, shaded in the file:")
        for e in unv:
            print(f"    {e.get('name')}")
        print()

    if failures:
        print("NOT READY. Fix before delivering:")
        for f in failures:
            print(f"  X {f}")
        print()
    if warns:
        print("CHECK THESE:")
        for w in warns:
            print(f"  ! {w}")
    elif not failures:
        print("No warnings.")

    print("\nThis file lists WHERE events are announced. It is not the events "
          "themselves.\nRun ctc-harvest next to sweep these sources into the events sheet.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit("usage: build_registry.py sources.json out.xlsx")
    main(sys.argv[1], sys.argv[2])
