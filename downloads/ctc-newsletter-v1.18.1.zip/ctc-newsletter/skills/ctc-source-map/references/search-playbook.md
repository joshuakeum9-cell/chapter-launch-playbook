# Search playbook

Concrete queries and checks for each of the nine source categories. Work all nine, every time, and report the empty ones. An empty category is a finding, not a gap to hide.

Substitute the city name and its neighboring place names throughout. For New York that means Brooklyn, Queens, Jersey City, Hoboken. For Boston, Cambridge, Somerville, Medford.

**Effort per category.** Three to six queries each, plus a page open for every candidate that looks live. Across nine categories that lands around 30 to 50 searches for a cold start, which is what it takes to reach the 25 to 30 verified sources a new city needs. One query per category is a tour of the playbook, not a search.

`references/example-registry.csv` shows what the finished result looks like, including how the `notes` column is used.

---

## 1. Luma calendars: start here, highest yield

**Discovery pages first.** `luma.com/{city}` and `luma.com/climate` are curated by Luma and surface calendars no keyword search reaches.

**Then keyword search:**
- `site:lu.ma {city} climate`
- `site:luma.com {city} climate tech`
- `{city} climate luma calendar`
- `{city} cleantech events luma`
- `{city} energy meetup luma`

**Then follow cross-links.** Calendars list co-hosts and sibling calendars. A well-connected calendar often yields four more. This is the highest-yield step and the one most often skipped.

---

## 2. Eventbrite organizers: largest volume in mature chapters

- `site:eventbrite.com {city} climate organizer`
- `{city} sustainability events eventbrite`
- `{city} clean energy eventbrite organizer`
- Browse by location plus category as well as keyword

Register the **organizer page**, not an individual event.

---

## 3. Universities and research centers

Search each major institution by name plus "climate center events" or "energy institute calendar". Include large public systems, not only the famous private ones. CUNY enrolls more students than every other school in New York combined.

- `{university} climate center events calendar`
- `{city} university sustainability institute events`

Note that these are **seasonal**. An empty calendar in July is term break, not death. Check the previous spring before judging.

---

## 4. Incubators, accelerators, coworking

- `{city} climate tech incubator events`
- `{city} cleantech accelerator calendar`
- `{city} startup coworking climate events`

Climate-focused first, general tech second.

---

## 5. City government and utilities

- `{city} sustainability office events`
- `{state} clean energy center events`
- `{city} economic development climate program events`
- `{utility name} community events`

Often the least glamorous and most reliable sources.

---

## 6. Professional and affinity groups

Reliably recurring, easy to miss:

- `young professionals in energy {city}`
- `women in renewable energy {city} events`
- `green building council {city} events`
- `{city} climate professionals meetup`
- LGBTQ+, BIPOC, and student climate networks in the city

---

## 7. Adjacent newsletters and meetups

Including ones that compete with you. Reading the competition is the cheapest completeness check available.

- `{city} climate newsletter`
- `{city} sustainability meetup group`
- `site:meetup.com {city} climate`

---

## 8. Climate community organizations with local presence

Check whether each has a local chapter or program: My Climate Journey, Work on Climate, Climatebase, Climate Changemakers, Climate Draft, Newlab, SOSV, Women and Climate, ClimateRaise.

- `{organization} {city} chapter events`

---

## 9. Arts, culture, civic venues

A tech-focused search will never surface these, and roughly 40% of a typical climate newsletter's audience is not yet working in climate, and this category is much of what serves them.

- `{city} museum climate programming`
- `{city} botanical garden events`
- `{city} library climate series`
- `{city} parks conservancy events`

---

## Verification: run all five gates

For every candidate, open it and check:

1. **It loads.** Never register a page you could not open. Behind a login → record `unverified` with a note.
2. **Active.** At least one event in the last 90 days.
3. **Consistent.** Look at *past* events, not just upcoming. You want a repeating pattern: a monthly meetup, a weekly series, a seasonal program. Four events in three years is a manual check at best. Record the observed cadence.
4. **Reputable and relevant.** A real named organization, events that actually happen, genuinely climate-adjacent. Reject syndicated commercial training spam aggressively. It is the most common junk source and recurs forever once registered. The ruled cases for the hard calls are in the Gate 4 table in SKILL.md.
5. **Stable URL.** An organizer or calendar page, not a filtered search result. Will it work in six months?

---

## Coverage check before finishing

- Did every one of the nine categories get worked, including the ones that came back empty?
- Are there at least a few `core` sources, or is the registry all `occasional`?
- Did you follow cross-links from the calendars you found?
- Would someone who lives in this city and works in climate name an obvious omission?

If the answer to the last one is yes, keep going. Two searches is not a source map.

---

## If the user supplied their own links

Sort them into the nine categories before searching so you can see what is already covered and where the gaps are.

Two things to check specifically on pasted links, because they are the common mistakes:

- **An individual event page instead of the organizer or calendar page.** Register the organizer. One event is not a source.
- **A calendar that turns out to be a CTC property**, another chapter's Substack, or the chapter's own newsletter. Excluded, per the Exclusions section of the skill. Say why rather than dropping it quietly. Confirm who runs it before excluding: a name resembling a chapter's is not evidence, and excluding a real source is a permanent invisible loss.

Then use their Luma calendars as cross-link seeds. Co-hosts and sibling calendars listed on a calendar a local lead already trusts are the best leads available in this whole process.
