---
name: ctc-source-map
description: Build the event source registry for a Climate Tech Cities chapter in a given city, either from calendar links the user already has, from online research, or both. Finds the Luma calendars, Eventbrite organizers, university calendars, and local organizations that consistently post climate tech events there, and verifies every one before registering it. Use this skill whenever the user names a city and wants event sources, has their own list of calendars they want registered, asks to build or refresh a source map or source registry, asks "where should we pull events from" or "what climate calendars exist in [city]", is launching a newsletter for a new chapter, or says the weekly harvest keeps missing events. Always use this skill even if the user only names one city or asks for "just a few calendars to start". Do NOT use it to collect this week's events, which is the harvest skill's job.
---

# CTC Source Map

Research a city online and return a verified list of places its climate tech events get announced. The weekly harvest reads that list, so it is only ever as good as this registry.

## What this is for

The registry is read by two parties, and they want different things.

**A machine reads it every week.** `ctc-harvest` walks the rows and fetches each one. That is why `url`, `platform`, and `method` have to be accurate rather than optimistic: an overclaimed `auto` source fails silently in the weekly sweep, the issue comes out thin, and nobody works out why.

**A person reads it about four times a year.** The chapter lead, on the quarterly refresh, deciding what died and what to add. That is why `cadence`, `last_event`, `origin`, and `notes` exist. A row they cannot evaluate is a row they will never prune.

The registry is finished when someone who lives in that city and works in climate could read it without naming an obvious omission.

**Prefer 25 verified sources to 60 guesses.** A missing source is invisible: the newsletter simply never carries those events. A bad source is worse, because it silently pollutes every future issue with junk listings.

## Input

A city name. That is all that is required, for example "New York", "Seattle", "Amsterdam".

Optionally, a list of calendar links the user already has. Step 0 asks for these. They are never required, and the skill works from the city name alone.

If the user gives a metro boundary or a scope rule alongside it, use theirs. If the chapter has a settings file (produced by `ctc-chapter-setup`), the scope rule is in section 2. Otherwise establish it in Step 1.

## What this is and is not

**This is a one-time-per-city research job**, rerun quarterly. It finds *which calendars exist*. The harvest skill pulls *this week's events* from them.

Never use open web search to collect a week's events. Search offers no completeness guarantee. If it returns eleven events you cannot tell whether that is all of them or half, and the same query returns different results week to week. A registered Luma calendar returns everything on it, every time. That difference is the entire reason this registry exists.

---

## Exclusions

**Never register Climate Tech Cities' own properties.** The registry lists where *other people* announce events. Exclude without exception:

- `climatetechcities.com` and every chapter subdomain
- Any chapter's Substack, including the one you are building this registry for. Registering your own newsletter as a source is circular and would re-harvest last week's listings forever
- Other chapters' newsletters. A London event is not a New York event
- Typeform, Google Docs, Airtable, Drive, and social links

**Do not assume a calendar belongs to CTC because its name resembles a chapter's.** This has been got wrong: a Luma calendar named "Seattle Climate Tech" was treated as the Seattle chapter's own calendar and excluded, when it was in fact run by Work on Climate, My Climate Journey, and Climate Changemakers. Excluding a real source is a permanent, invisible loss. Check who actually runs it, and if it is independent, treat it as a normal external candidate.

**CTC partner organizations are external sources.** My Climate Journey, Women and Climate, Climatebase, SOSV, Climate Draft, Newlab, and ClimateRaise are independent organizations running their own events. Being a partner does not make them internal.

---

## Read this first

- `references/search-playbook.md` holds concrete queries for all nine categories, the verification checks, and a coverage check to run before you finish. Use it. The most common failure of this skill is running two searches and stopping.
- `references/example-registry.csv` is a complete, valid fourteen-row registry covering all nine categories, all three tiers, all three pull methods, and one `unverified` row. Read it to see what a finished registry looks like and what belongs in `notes`. It is illustrative data for a fictional chapter, not real sources.

## Environment

Web search and page fetching are required. The browser (Claude in Chrome) is helpful for verifying Luma and Eventbrite pages, which often return an empty shell to a plain fetch, and a page that would not load in the shell has not been verified.

The sandbox usually restricts outbound network access from `bash` to a package-manager allowlist, so `curl` will fail on event sites that are perfectly healthy. Use the fetch tool or the browser, and never record a source as dead because a shell command could not reach it.

## Step 0: Ask for the user's own sources first

Before any searching, ask whether they already have calendar links they want registered. A city lead usually knows five or ten calendars off the top of their head, and those are the highest-quality rows in the registry because a real person already vouched for them.

**Present all three options in full, every time. Three, not two.** Never collapse them, never merge A and C into "I can research for you", and never drop B because their first message did not include links. Do not ask a yes or no question. The user needs to see what happens either way before choosing, because a volunteer running this for the first time has no idea what "online research" means here. Ask once, in plain language, roughly like this:

> Before I start, do you already have event calendars you want in the registry? Luma calendars, Eventbrite organizer pages, university calendars, anything you already check by hand.
>
> Either way works:
>
> **A. Paste your links, then I research too.** I verify yours, follow their cross-links, and work the full nine-category search on top. Best coverage. This is what I'd recommend for a new chapter.
>
> **B. Paste your links only.** I verify what you give me and stop there. Fastest, and a good choice if you already know your city's scene and just want the registry file built.
>
> **C. I research from scratch.** No links needed. I go find them and bring back a verified list for you to review.
>
> Paste your links, or just say which option you want.

Then follow the choice:

- **Option A**, take the links into Step 1, verify them in Step 3, and run the full Step 2 research pass. Treat their Luma calendars as cross-link seeds; that is the single highest-yield move available.
- **Option B**, verify their links and produce the registry from those alone. Say plainly in the summary how many verified sources that came to and what the nine-category coverage looks like, so the gap is visible. If it lands under about 15, say the registry is thin and offer to run the research pass later. Do not run it anyway.
- **Option C**, straight to Step 1 and the full research pass.

**Skip the question only when the answer is already in front of you.** If the user opened with a list of links, or already said "just research it, I don't have anything", do not make them answer a menu they have already answered. Confirm the read in one line and get on with it.

**A user-supplied link is a candidate, not a registered source.** It still goes through all five gates in Step 3. Leads paste dead calendars, one-off event pages instead of organizer pages, and calendars that turn out to belong to another chapter. When one fails a gate, say which gate and why rather than dropping it silently, and register it `unverified` with a note if it is worth keeping anyway.

## Step 1: Scope the city

Establish and write down before searching:

- **Geographic boundary.** Ask if unclear. New York's stated rule is roughly 95% the city proper, but its published issues carry Jersey City and Hoboken, so the working rule is closer to "anywhere a subscriber would travel on a weeknight." The answer governs every future week.
- **Neighboring place names** that count as local. These become search terms.

## Step 2: Research the taxonomy

**Run this as extended research, not as ordinary searching.** This applies on options A and C, and it is the default rather than a preference.

An ordinary search finds the obvious calendars and stops, which is how a registry comes back at ten or thirteen sources instead of twenty-five to thirty. Extended research runs many more searches, follows leads between them, and cross-references what it finds, which is what a nine-category sweep actually requires.

**Do not tell the user how long anything will take.** No estimates, no "this is the slow part", no "give it a while", no minute counts, anywhere in this skill. State what is happening, not how long it takes.

**Twenty-five is a hard floor.** Fewer than twenty-five verified sources means the sweep is not finished, not that the registry is ready with a caveat. Go back and work the categories that came back empty or thin, and keep going until you reach twenty-five. In particular:

- **Eventbrite** is the largest source by volume in most cities. A registry with zero Eventbrite organizers means the search was not run properly, not that the city has none.
- **Universities** almost always have several separate calendars: the sustainability office, the engineering school, the business school's entrepreneurship centre, and any energy or environment institute. One university can legitimately produce three or four rows.
- **Professional and affinity groups** recur reliably and are easy to miss. Look for local chapters of energy, engineering, and built-environment associations, women in energy or climate groups, and young professionals groups.
- **Adjacent newsletters and meetups**, including ones that compete with the chapter. The cheapest completeness check there is.
- **Arts, culture, and civic venues.** A tech-focused search never surfaces these and they serve the readers who are not working in climate yet.

**Reaching twenty-five means finding twenty-five real sources, not writing twenty-five rows.** Every one still passes all five verification gates. Never pad with syndicated commercial listings, national sites with no local presence, dead calendars, or CTC's own properties. One bad source pollutes every issue from now on, and by the time anyone notices, nobody can trace it back here.

If the count is genuinely stuck below twenty-five after all nine categories have been worked properly, do not deliver a short file silently. Say which categories are empty, what was searched, and what the count is, and let the lead decide whether to add sources they know about or accept a smaller registry.


Skip this step only under Option B.

If the user supplied links in Step 0, sort them into the nine categories first and see what is already covered. That tells you where to spend the search effort, and it usually exposes a lean: leads tend to know the Luma and meetup scene well and the government, university, and arts categories barely at all.

Work every category below, every time, and **report the empty ones**. An empty category is a finding, not a gap to hide. It either means the city genuinely lacks that source type or the search terms were wrong, and the user needs to judge which.

**1. Luma calendars.** Structured, machine-readable, complete. Start here, highest yield by a wide margin.

Three entry points, in order:

- **Luma's own discovery pages.** `luma.com/{city}` lists popular local events; `luma.com/climate` filters by topic. Curated by Luma, these surface calendars no keyword search reaches. Use them to find calendars, never as a source in their own right.
- **Keyword search.** `site:lu.ma` and `site:luma.com` with the city plus climate, energy, sustainability, cleantech, greentech.
- **Cross-links.** Calendars routinely link to sibling calendars and co-hosts. Follow every one. A well-connected calendar often yields four more.

**2. Eventbrite organizers.** The largest single source by volume in mature chapters, roughly half of all event links in New York's published issues. Search organizer pages, not individual events: an organizer is a durable source, one event is not. Browse by location plus category as well as by keyword.

**3. Universities and research centers.** Climate, energy, environment, and sustainability institutes with public calendars. Include large public systems, not only famous private ones. CUNY enrolls more students than every other school in New York combined.

**4. Incubators, accelerators, coworking spaces.** Climate-focused first, general tech second.

**5. City government and utilities.** Sustainability offices, economic development corporations, energy authorities, utility program pages.

**6. Professional and affinity groups.** Young professionals in energy, women in renewables, LGBTQ+ climate networks, engineering societies, green building councils. Reliably recurring and easy to miss.

**7. Adjacent newsletters and meetups**, including ones that compete. Reading the competition is the cheapest completeness check available.

**8. Climate community organizations with local presence.** Including CTC's partner organizations where they run local programming.

**9. Arts, culture, civic venues.** Museums, galleries, botanical gardens, libraries, parks organizations. A tech-focused search will never surface these, and roughly 40% of CTC's audience is not yet working in climate. This category is much of what serves them.

### How much research is enough

The floor is 25 verified sources and the working range is 25 to 30. Reaching that from scratch is not a two-search job.

- **Roughly 30 to 50 searches** across the nine categories, plus a page open for every candidate that survives. A first pass that returns a dozen candidates has not finished; it has finished category one.
- **Every category gets worked**, including the ones you expect to be empty. Arts and government are the two most often skipped and the two that most change what a registry covers.
- **Cross-links get followed.** This is the step most often skipped and the highest-yielding one in the whole process.

These are effort figures, not quotas. If a mid-sized city genuinely yields 18 verified sources after all nine categories and the cross-links, 18 is the answer and it should be reported as such.

## Step 3: Verification gates

This is where "consistent" and "reputable" become concrete. Open every candidate and check all five. A source failing any gate does not go in as `auto`.

**This applies to user-supplied links too.** No exceptions and no softening because someone you are talking to handed it over. A dead calendar registered out of politeness costs the chapter a source slot and looks fine in the file forever.

**Gate 1. It loads.** Never register a page you could not open. If it is behind a login, record it `unverified` with a note rather than silently including or dropping it.

**Gate 2. It is active.** At least one event in the last 90 days. A calendar whose most recent event is from 2023 is dead. Say so and drop it. The exception is a term-time source checked in July, which is a season rather than a death; check whether it was active in the previous spring.

**Gate 3. It is consistent.** Look at past events, not just upcoming. You want a repeating pattern: a monthly meetup, a weekly series, a seasonal program. Four events in three years is a manual check at best. Record the observed cadence, because you are estimating how much this source contributes every week.

**Gate 4. It is reputable and relevant.** A real named organization behind it. Events that actually happen rather than perpetual "registration open" listings. Genuinely climate-adjacent rather than one green-themed event a year.

This is the hardest call in the skill, so here are the ones that recur:

| Situation | Ruling | Reasoning |
|---|---|---|
| Reseller running generic "ESG & Sustainability Strategy: 1 Day Training" listings across dozens of cities | Reject | Syndicated commercial spam. Approve one and it recurs in every issue forever. New York's own archive contains at least one that slipped through |
| Museum or library whose calendar is 95% non-climate but carries four or five climate events a year | Register as `occasional` and `manual` | Real local programming, and it serves the 40% of readers not yet working in climate. A human picks the climate items out each week |
| A competing local climate newsletter | Register as `occasional`, method `email` | It is a completeness check, not a feed. Read it, do not copy from it |
| National organization with a genuine local chapter running local events | Register the local chapter page | The events are here and a reader can attend them |
| National organization with a local landing page and no local events | Reject | Nothing to attend |
| A single recurring event with its own page, no organizer page | Register the event page, `occasional`, note why | A durable URL for a real recurring event is a source. A one-off event page is not |
| An organization with strong climate work whose calendar is entirely webinars | Register as `secondary` | Online events are listable. They just rank below in-person ones at the picks stage |
| Calendar named like a CTC chapter, run by someone else | Register it normally | See Exclusions. Getting this wrong loses a real source permanently |
| Corporate marketing calendar with one greenwashed event a year | Reject | One green-themed event a year is not a climate source |

The principle underneath: **would a subscriber be glad this event reached them, and does this URL produce such events on a repeating pattern?** Both halves have to be true. Work new cases back to that.

**Gate 5. Stable URL.** Prefer an organizer or calendar page over a filtered search result. Ask whether this URL still works in six months.

## Step 4: Tier and classify

**Tier** by expected weekly contribution:

- **Core**, several events most weeks. The registry is built on these.
- **Secondary**, a few events a month.
- **Occasional**, worth checking, rarely fires.

**Pull method**, which is what makes the harvest skill possible, so be accurate rather than optimistic:

- **`auto`**, structured and machine-readable. Luma calendars, Eventbrite organizer pages, server-rendered listing pages.
- **`manual`**, a human checks it. JavaScript-rendered calendars, PDF listings, events announced in prose, whole-venue calendars needing a human to pick out the climate items.
- **`email`**, arrives in the lead's inbox from a named contact. Record the contact.

When unsure, mark `manual`. An overclaimed `auto` source fails silently in the weekly harvest, which is the worst failure mode in the pipeline: the issue is thin and nobody knows why.

---

## Output

**Before writing anything, count the verified sources.** Under twenty-five means Step 2 is not finished. Go back and work the empty categories rather than delivering a short registry and noting it in the summary. The script warns about this, but by then the file is already in the lead's hands and they have to ask for a re-run.

Write a formatted workbook with the bundled script, plus a summary in chat. See `references/example-registry.csv` for the fields and what belongs in `notes`.

```bash
python3 scripts/build_registry.py sources.json CTC_Source_Registry_<City>.xlsx
```

`sources.json` is `{"city": "...", "sources": [ ... ]}` with one object per source keyed by the column names in the example file.

**Do not hand-write a CSV.** The script exists for three reasons: the columns come out identical every time so `ctc-harvest` can read them, unverified rows get shaded so they are visible rather than buried in a column, and it runs a QA pass that catches the two failures this skill actually has, which are a registry under twenty-five sources and empty categories nobody explained.

Read the script's output before delivering. It reports the count per category, names every empty one, and flags any source with no `last_event` date, since staleness cannot be judged without it.

### Missing information is marked, never left silent

The build script writes a `Missing Info` column naming any required field a row is missing, and shades **only the empty cells** red, plus the note that names them.

Cell-level, not row-level, on purpose. Shading a whole row buries the one field that needs attention among a dozen that do not, and large blocks of red read as broken rather than as a few cells to fill.

Read the script's output before delivering. It names every incomplete row and the exact field. Fix them and re-run rather than handing over a file with red in it.

**The header band is teal here and green in the events sheet.** That is deliberate. A lead with both files open needs to tell at a glance which is the list of places events are announced and which is the list of events.

| Column | Contents |
|---|---|
| `name` | Organization or calendar name |
| `url` | Stable page URL |
| `platform` | `luma` / `eventbrite` / `web` / `email` |
| `method` | `auto` / `manual` / `email` |
| `tier` | `core` / `secondary` / `occasional` |
| `category` | Which taxonomy category |
| `cadence` | Observed, for example "monthly meetup", "weekly" |
| `last_event` | Date of the most recent event seen |
| `confidence` | `verified` / `unverified` |
| `origin` | `user` / `research`, who put this row forward |
| `notes` | Who runs it, contact name, scope caveats, term-time only |

`origin` is the last column so it does not disturb anything reading the file by position. It earns its place on the quarterly refresh: a `user` row that has gone quiet is worth asking the lead about before deleting, because they had a reason for it. A `research` row that has gone quiet can just go.

**`notes` is the column that decays fastest if written lazily.** Write what a person would need in three months to decide whether to keep the row: who runs it, why it is `manual`, whether it is term-time only, what makes it worth the slot. "Good calendar" is not a note.

**Summary in chat covers:**

- Which option was run, and how many sources came from the user versus from research
- Any user-supplied link that failed a gate, with the gate named
- Total verified sources, split by method and tier
- Count per category, **including the empty ones**
- Candidates rejected and why, especially anything caught by Gate 4
- Which sources will carry the most volume
- What a local person should check

## Targets

**25 to 30 verified sources** before a new city launches, weighted toward `core`. Twenty-five is a hard floor, not a soft target.

This figure is a working default rather than a measured standard. It is the number carried in the CTC playbook and it has not been validated against a chapter launch. Treat it as an expectation to report against, not a bar to clear.

Below about 15, say so plainly. The city may not yet have the volume for a weekly cadence, and fortnightly is the honest recommendation. **Never pad the registry to hit a number.** Padding shows up later as thin issues and junk listings, months after anyone can trace the cause.

Under Option B the count will often land below that on its own. That is a choice the user made, not a failure. Report the number, name the categories with nothing in them, and offer the research pass as a next step. Do not run it uninvited.

## Refresh

Rerun quarterly. Sources die quietly and nobody notices until the newsletter has been thin for two months.

Run Step 0 on a refresh as well. The lead has been reading the scene for three months and will have picked up calendars the last pass missed. Ask what they have found before searching.

On a refresh, **re-verify existing rows before hunting for new ones**. A dead core source costs more than a missing new one. Report both what died and what is new.

---

## Failure modes

**Two searches and a stop.** The single most common failure. A registry built from one category is worse than no registry, because it looks finished and the gaps are invisible forever after.

**Excluding a real source on a name match.** "Seattle Climate Tech" on Luma was assumed to be the chapter's own calendar and set aside. It belonged to Work on Climate, My Climate Journey, and Climate Changemakers. Check who runs a calendar before excluding it, not after.

**Registering an individual event page as a source.** It fires once and then returns nothing forever, and looks like a live row in the file. Register the organizer.

**Optimistic `auto` classification.** A JavaScript calendar recorded as `auto` returns nothing in the weekly harvest without erroring. The lead sees a thin issue and blames the city. Mark `manual` when unsure.

**Syndicated training spam accepted.** It passes a naive relevance check, and once registered it recurs weekly forever. If the same title appears in three cities, it is a reseller.

**Arts, government, and utility categories skipped.** They are the least glamorous searches and among the most reliable sources, and arts is much of what serves readers not yet working in climate.

**Reporting only what was found.** The empty categories, the rejections, and the unverifiable candidates are half the value of the summary. A registry handed over as a bare list gives the lead nothing to check.
