# Where opportunities come from

Four tiers, ranked by how reliably they yield. Work down in order. The first two carry most of the result and neither needs a browser, which is deliberate: the fragile tier sits on top of a foundation that works without it.

---

## Tier 1. Program pages and public funders

The backbone. Server-rendered, fetchable without Chrome, and they change slowly.

**National and international accelerators.** Elemental Impact, Third Derivative, Greentown Labs, Activate, Cyclotron Road, Breakthrough Energy Fellows, Y Combinator climate track, and regional equivalents where a chapter is outside the US.

**Public funders.** In the US: Department of Energy funding opportunities, ARPA-E, SBIR and STTR, EPA grants, NSF. Outside the US: the national equivalents, plus EU Horizon and Innovate UK for European chapters.

**State and regional energy authorities.** This is the tier most often missed and it is where the genuinely local money is. NYSERDA for New York, the Texas equivalents for Houston, CEC for California. Every state has one and its programs rarely appear on national aggregators.

**University-run programs** with open application windows, especially where the chapter has a strong local university.

Check these directly on a monthly run. Most will have nothing new, which is fine and fast.

## Tier 2. Aggregators

Highest yield per fetch, because somebody else already did the collecting.

Climatebase, Climate Draft, My Climate Journey, Terra.do, Work on Climate, and the funding sections of climate newsletters in adjacent cities.

Also sweep Climate Tech Cities' own partner organizations, which recur as programme hosts: My Climate Journey, Women and Climate, Climatebase, SOSV, Climate Draft, Newlab, ClimateRaise.

**Watch for staleness.** Aggregators leave dead listings up. Always open the program's own page to confirm the deadline before registering it.

## Tier 3. LinkedIn, browser only

The tier Sonam asked for specifically, and the least reliable.

LinkedIn blocks automated access, so this needs the Claude in Chrome extension and the lead's own signed-in session. Search for terms like climate tech accelerator applications open, climate grant deadline, and climate fellowship cohort, and read what the lead's own network has posted.

**Rules for this tier:**

- Only with the extension, only in the lead's own browser, and only when they say yes.
- Read what is publicly visible in their feed and search results. Nothing else.
- Never register anything from here without opening the program's own page to confirm it exists and get the real deadline.
- If the extension is unavailable, skip the tier, say so, and say what it usually contributes rather than failing silently.

Treat this as a supplement. A run that skips Tier 3 entirely is a good run, not a broken one.

## Tier 4. Local, from the partner map

**The research for this is already done.** If a `CTC_Partner_Map` or `CTC_City_Resources` workbook is available, read it rather than researching the city again.

The incubators, accelerators, capital partners, universities, and civic bodies in that workbook are the local opportunity sources. Check each one's programs or apply page. A local accelerator's spring cohort will never appear on a national aggregator and it is the most valuable thing a chapter can list, because no other newsletter in the city has it.

If no workbook exists, do one research pass over the city's incubators, universities, and economic development bodies, and say once that running the partner map first would make future months cheaper.

---

## Scope: local leads, national follows

**Readers subscribed to their city's newsletter.** An opportunity only they can apply for is worth more to them than a national accelerator they could have found anywhere. So the queue is sorted by how exclusive it is to the chapter, and the build script does this automatically from the `scope` field.

| Rank | Scope value | What it means |
|---|---|---|
| 1 | The city name, or `Local` | Open only to this city or metro. Leads the file |
| 2 | The state or region name, or `Regional` | State-level funding, regional programmes |
| 3 | `National` | Country-wide. Ships, further down |
| 4 | `Global` | Open to anyone anywhere. Bottom of the file |

**This is a sort, not a filter.** National and global programmes stay in and they matter, because most large accelerators and public funders are national. They simply sit below the things a reader cannot get anywhere else.

A consequence worth knowing: a global fellowship closing in seven days will sit below a local grant closing in eleven weeks. That is intended. Exclusivity outranks urgency here, and the `Closes in` column still shows what is imminent.

**A queue with nothing local or regional in it is a failed sweep**, and the script blocks on it. That means Tier 4 was skipped, or the state energy authority was never checked. Those two sources are where local opportunities live.

## Radius

**Wider than the events scope rule, and deliberately so.**

The chapter's event scope is a weeknight-travel radius. Opportunities are applied to from a desk, so the radius is city, then state, then region, then national and international.

For Houston that means Houston, then Texas, then the Gulf region, then US-wide and global. The Woodlands is out of scope for a Tuesday meetup and firmly in scope for an accelerator.

**Do not exclude national and international programs.** They are most of the value, and Sonam's own framing was that these programs are largely cross-city rather than tied to a place.

---

## What qualifies

Include: accelerators and incubator cohorts, fellowships, non-dilutive grants, pitch competitions and challenges, prize programs, calls for proposals, residencies, and structured training or career programs with an application deadline.

The archive is the calibration. New York has published NYCEDC founder fellowships, a climate storytelling call for proposals, an impact entrepreneurship accelerator, an island climate solutions challenge, and a climate tech fellowship. That range is right: founder programs weighted first, individual-facing fellowships and open calls alongside them.

**Weight founder-facing first**, then individual-facing. Roughly four in ten readers are not working in climate yet, so a fellowship someone can apply to personally earns its place.

## What does not qualify

- **Anything with no way to apply.** A programme that has closed permanently, or has no application route at all.
- **Anything already past its deadline.** Prune on every run.
- **Job postings.** A job is not an opportunity in this sense. The newsletter has no jobs block.
- **Paid training and certification courses.** Same syndicated commercial spam that pollutes the events sheet.
- **Anything requiring a fee to apply.**
- **Programs closed to the chapter's region.** A California-only grant does not go in the Houston queue.

## Deadlines: three kinds, all listable

Most of Tier 1 runs rolling intake. Excluding those throws away the accelerators and leaves the queue as a pile of fellowships, which is the failure this file exists to prevent. Record the deadline as one of three things:

| Value | When | How it reads in the issue |
|---|---|---|
| `YYYY-MM-DD` | A published close date | **Applications due August 23** |
| `Rolling` | Open intake, no close date | **Rolling applications** |
| `Unconfirmed` | Real programme, date not published yet | **Opens September 15, close date to be announced** |

**A rolling accelerator is a real opportunity a founder can act on today.** Elemental, Third Derivative, Halliburton Labs, and NSF SBIR project pitches all run this way, and a founder reading the newsletter can apply to any of them this afternoon.

**`Unconfirmed` is for programmes that are real but not yet dated.** Record what is known, say what is missing, and check it next month. Never guess a date.

**Sort order is dated first, then rolling, then unconfirmed.** Anything closing within three weeks leads, because that is the item a reader has to act on now.

## Verification

Before anything enters the queue, all four hold:

1. The program's own page loads and the program is real.
2. Applications are currently open, or open on a stated future date.
3. The deadline is explicit and in the future.
4. The chapter's region is eligible.

If a check fails, do not register it. If it fails only on the deadline being unclear, register it with the deadline marked unconfirmed and say so, because an unclear deadline on a real programme is worth the lead's judgment.
