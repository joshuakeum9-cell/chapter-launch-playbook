#!/usr/bin/env python3
"""
Build or refresh the rolling opportunities queue.

    python3 build_queue.py opportunities_<city>.json [--existing Opportunities_<City>.xlsx]

Writes /mnt/user-data/outputs/Opportunities_<City>.xlsx

The queue is a ROLLING file, not a fresh list each month. When an existing
workbook is passed in, this script:

  * keeps every entry that is still open, preserving its Status and Last used
  * moves anything past its deadline to the Closed sheet, with the date it closed
  * merges the new findings, skipping anything already present by URL
  * never silently drops a lead-added row

That is what makes run two take fifteen minutes instead of an hour.

The JSON is a list of objects:
  name, org, type, deadline (YYYY-MM-DD), url, who, scope, description
"""

import json
import os
import re
import sys
from collections import Counter
from datetime import date, datetime

import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

OUT_DIR = '/mnt/user-data/outputs'
TITLE_FILL = PatternFill('solid', fgColor='0F6E6E')
HDR_FILL = PatternFill('solid', fgColor='D9E2E1')
DATA_FILL = PatternFill('solid', fgColor='DCE6F1')
SOON_FILL = PatternFill('solid', fgColor='FDF0E3')
GAP_FILL = PatternFill('solid', fgColor='F8CBCB')
CLOSED_FILL = PatternFill('solid', fgColor='F2F2F2')
THIN = Side(style='thin', color='9AB3B2')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

COLUMNS = [
    ('Opportunity', 34), ('Organization', 24), ('Type', 18),
    ('Deadline', 13), ('Closes in', 11), ('Who it is for', 18),
    ('Scope', 14), ('Description', 52), ('URL', 34),
    ('Status', 14), ('Last used', 14), ('Missing Info', 28),
]

# key -> the column header it appears under
REQUIRED = {
    'name': 'Opportunity', 'org': 'Organization', 'type': 'Type',
    'deadline': 'Deadline', 'who': 'Who it is for', 'scope': 'Scope',
    'description': 'Description', 'url': 'URL',
}


def row_gaps(e):
    """Required fields this opportunity is missing, by column header."""
    return [h for k, h in REQUIRED.items() if not str(e.get(k, '') or '').strip()]

TYPES = {'Accelerator', 'Incubator', 'Fellowship', 'Grant', 'Competition',
         'Challenge', 'Call for proposals', 'Residency', 'Program'}

VOLATILE = re.compile(r'(\$\s?\d|\d+\s?%|\bover \d+\b|\bup to \$)', re.I)


def parse(d):
    return datetime.strptime(d, '%Y-%m-%d').date()


def load_existing(path):
    """Return list of dicts from a prior queue, both sheets."""
    if not path or not os.path.exists(path):
        return []
    wb = openpyxl.load_workbook(path)
    out = []
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        headers = [c.value for c in ws[2]] if ws.max_row >= 2 else []
        if 'Opportunity' not in (headers or []):
            headers = [c.value for c in ws[1]]
            start = 2
        else:
            start = 3
        idx = {h: i for i, h in enumerate(headers) if h}
        for r in range(start, ws.max_row + 1):
            row = [c.value for c in ws[r]]
            if not row or not row[0]:
                continue
            def g(k):
                i = idx.get(k)
                return row[i] if i is not None and i < len(row) else ''
            dl = g('Deadline')
            if hasattr(dl, 'date'):
                dl = dl.date().isoformat()
            out.append({
                'name': g('Opportunity'), 'org': g('Organization'),
                'type': g('Type'), 'deadline': str(dl or ''),
                'who': g('Who it is for'), 'scope': g('Scope'),
                'description': g('Description'), 'url': g('URL'),
                'status': g('Status') or 'Not used',
                'last_used': g('Last used') or '',
            })
    return out


def merge(existing, new):
    """Merge by URL. Existing rows win on Status and Last used."""
    by_url = {}
    order = []
    for e in existing:
        k = str(e.get('url', '')).strip().lower()
        if not k:
            continue
        by_url[k] = e
        order.append(k)
    added = 0
    for n in new:
        k = str(n.get('url', '')).strip().lower()
        if not k:
            continue
        if k in by_url:
            # refresh the mutable fields, keep the lead's state
            for f in ('deadline', 'description', 'name', 'org', 'type', 'who', 'scope'):
                if n.get(f):
                    by_url[k][f] = n[f]
        else:
            n.setdefault('status', 'Not used')
            n.setdefault('last_used', '')
            by_url[k] = n
            order.append(k)
            added += 1
    return [by_url[k] for k in order], added


SPECIAL = ('rolling', 'unconfirmed', 'tbc')

# Tier the queue by how exclusive an opportunity is to this chapter's readers.
SCOPE_TIERS = [
    ('Local', 0),      # this city and its metro only
    ('Regional', 1),   # state, province, or multi-city region
    ('National', 2),
    ('Global', 3),
]


def _scope_rank(scope, city=''):
    """0 for city-exclusive, 3 for open-to-anyone.

    A subscriber opened their city's newsletter. A grant only they can apply
    for is worth more to them than a national accelerator open to everyone,
    so it leads the file. National programmes still ship, further down.
    """
    v = str(scope or '').strip().lower()
    if not v:
        return 2
    if city and city.strip().lower() in v:
        return 0
    if v.startswith('local') or v.startswith('city') or v.startswith('metro'):
        return 0
    if v.startswith(('regional', 'state', 'province')):
        return 1
    if v.startswith(('national', 'federal', 'countrywide')):
        return 2
    if v.startswith(('global', 'international', 'worldwide')):
        return 3
    # A bare place name that is not this city is a region.
    return 1


def _kind(d):
    """'date', 'rolling', 'unconfirmed', or 'bad'."""
    d = str(d or '').strip().lower()
    if re.match(r'^\d{4}-\d{2}-\d{2}$', d):
        return 'date'
    for k in SPECIAL:
        if d.startswith(k):
            return 'rolling' if k == 'rolling' else 'unconfirmed'
    return 'bad'


def split_open_closed(rows, today, city=''):
    """Open rows sort by deadline, with rolling and unconfirmed after dates.

    A rolling accelerator is a real opportunity a founder can act on today.
    Excluding it because it has no bolded date threw away most of Tier 1 and
    left the queue as a pile of fellowships.
    """
    open_rows, closed_rows, bad = [], [], []
    for r in rows:
        k = _kind(r.get('deadline'))
        if k == 'bad':
            bad.append(r)
        elif k == 'date':
            (closed_rows if parse(r['deadline']) < today else open_rows).append(r)
        else:
            open_rows.append(r)
    # Scope first, deadline second. A reader subscribes to their city's
    # newsletter, so a local grant outranks a national accelerator even when
    # the national one closes sooner. National still ships, lower down.
    order = {'date': 0, 'rolling': 1, 'unconfirmed': 2}
    open_rows.sort(key=lambda r: (_scope_rank(r.get('scope'), city),
                                  order[_kind(r['deadline'])],
                                  str(r['deadline'])))
    closed_rows.sort(key=lambda r: r['deadline'], reverse=True)
    return open_rows, closed_rows, bad


def cell(ws, r, c, v, fill, bold=False, wrap=True):
    x = ws.cell(r, c, v)
    x.fill = fill
    x.border = BORDER
    x.alignment = Alignment(vertical='top', wrap_text=wrap)
    x.font = Font(bold=bold, size=10, name='Calibri')
    return x


def write_sheet(ws, title, rows, today, closed=False):
    for i, (_, w) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(COLUMNS))
    t = ws.cell(1, 1, title)
    t.fill = TITLE_FILL
    t.font = Font(bold=True, size=12, color='FFFFFF', name='Calibri')
    t.alignment = Alignment(vertical='center')
    ws.row_dimensions[1].height = 22
    for i, (h, _) in enumerate(COLUMNS, start=1):
        cell(ws, 2, i, h, HDR_FILL, bold=True, wrap=False)
    for j, e in enumerate(rows, start=3):
        k = _kind(e.get('deadline'))
        if k == 'date':
            days = (parse(e['deadline']) - today).days
            closes = 'closed' if closed else str(days) + ' days'
            base = CLOSED_FILL if closed else (SOON_FILL if days <= 21 else DATA_FILL)
        elif k == 'rolling':
            closes, base = 'rolling', DATA_FILL
        else:
            closes, base = 'confirm date', SOON_FILL
        gaps = row_gaps(e)
        vals = [e.get('name'), e.get('org'), e.get('type'), e['deadline'],
                closes,
                e.get('who'), e.get('scope'), e.get('description'),
                e.get('url'), e.get('status', 'Not used'), e.get('last_used', ''),
                ', '.join(gaps)]
        for i, v in enumerate(vals, start=1):
            header = COLUMNS[i - 1][0]
            # Only the empty cell goes red, plus the note that names it.
            fill = GAP_FILL if (header in gaps or
                                (header == 'Missing Info' and gaps)) else base
            cell(ws, j, i, v, fill)
        ws.row_dimensions[j].height = max(16, 13 * (len(str(e.get('description') or '')) // 52 + 1))
    ws.freeze_panes = 'A3'


def qa(rows, today):
    fails, warns = [], []
    seen = set()
    for e in rows:
        n = e.get('name', '<unnamed>')
        for k in ('name', 'org', 'type', 'deadline', 'url', 'description'):
            if not str(e.get(k, '') or '').strip():
                fails.append(f'{n}: blank required field "{k}"')
        u = str(e.get('url', '') or '')
        if not u.startswith('https://'):
            fails.append(f'{n}: URL not https -> {u}')
        if u.lower() in seen:
            fails.append(f'{n}: duplicate URL')
        seen.add(u.lower())
        if e.get('type') and e['type'] not in TYPES:
            warns.append(f'{n}: type "{e["type"]}" is not one of {sorted(TYPES)}')
        blob = f"{e.get('name','')} {e.get('description','')}"
        if '\u2014' in blob or '\u2013' in blob:
            fails.append(f'{n}: em dash or en dash in copy')
        if VOLATILE.search(blob):
            warns.append(f'{n}: dollar figure in copy, it will go stale')
        w = len(str(e.get('description', '') or '').split())
        if w > 45:
            warns.append(f'{n}: description is {w} words, aim for 25 to 40')
    return fails, warns


def main():
    args = [a for a in sys.argv[1:]]
    existing_path = None
    if '--existing' in args:
        i = args.index('--existing')
        existing_path = args[i + 1]
        args = args[:i] + args[i + 2:]
    if not args:
        sys.exit('usage: build_queue.py opportunities_<city>.json [--existing <xlsx>]')

    data = json.load(open(args[0]))
    city = data.get('city', 'City')
    new = data.get('opportunities', [])
    today = date.today()

    existing = load_existing(existing_path)
    merged, added = merge(existing, new)
    open_rows, closed_rows, bad = split_open_closed(merged, today, city)

    wb = Workbook()
    write_sheet(wb.active, f'{city} - Open opportunities', open_rows, today)
    wb.active.title = 'Open'
    if closed_rows:
        ws2 = wb.create_sheet('Closed')
        write_sheet(ws2, f'{city} - Closed, kept for reference', closed_rows, today, closed=True)

    os.makedirs(OUT_DIR, exist_ok=True)
    safe = re.sub(r'[^A-Za-z0-9]+', '_', city).strip('_')
    out = os.path.join(OUT_DIR, f'Opportunities_{safe}.xlsx')
    wb.save(out)

    print(f'wrote {out}\n')
    print(f'  open        {len(open_rows)}')
    print(f'  new         {added}')
    print(f'  closed      {len(closed_rows)}')
    if existing:
        print(f'  carried     {len(existing)} read from the previous queue')
    soon = [e for e in open_rows if _kind(e['deadline']) == 'date'
            and (parse(e['deadline']) - today).days <= 21]
    if soon:
        print(f'\n  closing within three weeks ({len(soon)}):')
        for e in soon:
            print(f"    {e['deadline']}  {e['name']}")
    unused = [e for e in open_rows if str(e.get('status', 'Not used')).startswith('Not used')]
    print(f'\n  not yet used in an issue: {len(unused)}')

    if bad:
        print('\n  ! dropped, unparseable deadline:')
        for e in bad:
            print(f"    {e.get('name')}  deadline={e.get('deadline')!r}")

    fails, warns = qa(open_rows, today)

    # ---- hard floor and balance --------------------------------------
    blocking = []
    if len(open_rows) < 15:
        blocking.append(
            f"{len(open_rows)} open opportunities. The floor is 15. THIS QUEUE IS "
            f"NOT READY. Go back and work the tiers that were skipped. Tier 1 "
            f"alone (accelerators, public funders, state energy authorities) "
            f"should produce most of this on its own.")

    tiers = Counter(_scope_rank(e.get('scope'), city) for e in open_rows)
    label = {0: 'Local', 1: 'Regional', 2: 'National', 3: 'Global'}
    print('  by scope, in file order:')
    for t in (0, 1, 2, 3):
        print(f'    {label[t]:<10} {tiers.get(t, 0):>3}')
    print()

    local_n = tiers.get(0, 0) + tiers.get(1, 0)
    if open_rows and local_n == 0:
        blocking.append(
            f"nothing local or regional in the queue. Readers subscribed to "
            f"{city}'s newsletter, and a queue of national programmes they could "
            f"have found anywhere is the least valuable version of this block. "
            f"Work Tier 4 from the partner map, plus the state energy authority.")

    kinds = Counter(str(e.get('type', '')).strip() for e in open_rows)
    if open_rows:
        top, top_n = kinds.most_common(1)[0]
        if top_n / len(open_rows) > 0.5 and len(open_rows) >= 4:
            blocking.append(
                f"{top_n} of {len(open_rows)} are '{top}'. One type over half the "
                f"queue means the other tiers were not worked. Accelerators, "
                f"grants, competitions, and calls for proposals should all appear.")
    missing_kinds = [k for k in ('Accelerator', 'Grant', 'Fellowship')
                     if not kinds.get(k)]
    if missing_kinds and len(open_rows) >= 4:
        blocking.append(
            f"no {', '.join(missing_kinds)} in the queue. Each of these exists in "
            f"every month of the year at national level. Their absence means a "
            f"tier was skipped, not that none are open.")

    if blocking:
        print("NOT READY. Fix before delivering:")
        for b in blocking:
            print(f"  X {b}")
        print()

    print()
    incomplete = [(e, row_gaps(e)) for e in open_rows if row_gaps(e)]
    if incomplete:
        print(f'{len(incomplete)} entr(ies) missing required info, shaded red '
              f'and named in the Missing Info column:')
        for e, g in incomplete:
            print(f"    {str(e.get('name'))[:40]:42s} {', '.join(g)}")
        print()

    if fails:
        print('QA FAILURES, fix before delivering:')
        for f in fails:
            print(f'  X {f}')
    else:
        print('QA: no failures.')
    if warns:
        print('\nQA warnings:')
        for w in warns:
            print(f'  ! {w}')
    print('\nOne check this script cannot make: open two program pages at random '
          'and confirm the deadline matches.')


if __name__ == '__main__':
    main()
