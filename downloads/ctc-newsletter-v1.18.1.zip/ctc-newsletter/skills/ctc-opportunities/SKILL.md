---
name: ctc-opportunities
description: Find grants, fellowships, accelerators, and calls for applications for a Climate Tech Cities chapter newsletter, and keep them in a rolling monthly queue. Use this skill whenever the user wants opportunities for their newsletter, asks for grants, fellowships, accelerators, incubators, funding, or calls for applications, says "run the monthly opportunities" or "refresh the opportunities", asks what to put in the opportunities block, or is starting a new month of the newsletter cycle. Always use it even if they only want one or two to fill a gap. Do NOT use it to find events, which is ctc-harvest, or to find partner organizations, which is the ctc-partner-map plugin.
---

# CTC Opportunities

Runs once a month. Finds grants, fellowships, accelerators, and open calls, and keeps them in a rolling queue the newsletter draws on every week.

The opportunities block is why founders stay subscribed through a quiet week. It is also the block that gets skipped, because nothing collects it. This is what collects it.

## Input

The city, read from the chapter settings file. Optionally the previous month's queue, which makes the run much shorter.

## Output

One `.xlsx` in `/mnt/user-data/outputs/`, named `Opportunities_<City>.xlsx`, with an Open sheet and a Closed sheet.

**The lead uploads it to their Claude project once a month.** `ctc-assemble` reads it every week from there. That upload is the entire mechanism, so never end a run without saying it.

---

## The bar

The lead opens the file, picks two, and pastes them into the issue without checking anything. Which means every deadline in it has to be right.

---

## Read this first

`references/sources.md` holds the four source tiers, the scope rule, what qualifies, and the four verification checks. Read it before searching.

`scripts/build_queue.py` builds and prunes the queue. Do not hand-roll the spreadsheet, and never rebuild the queue from scratch when a previous one exists.

---

## Step 0 - Ask how they want to start

**Always ask this first. Never start researching without it.**

The user may already know programs that belong here. A name a real person vouched for is better than anything research returns, and skipping this question is how a skill produces a list that misses the obvious.

Ask in one message and wait:

> Before I start, how do you want to do this?
>
> **A. You give me some, then I research too.** Paste any grants or programs you already know and I verify each one, then run the full search on top. Best coverage, and what I would recommend.
>
> **B. You give me all of them.** I verify what you paste and stop there. Fastest, and a fair choice if you already have the list you want.
>
> **C. I research everything.** Nothing needed from you. I sweep the sources and bring back a verified list to review.
>
> Paste what you have straight into your reply and I will take that as option A, or just tell me which you want.

**If they paste names or links in their first message, take that as A and get on with it.** Do not make someone pick from a menu when they have already answered.

**Whatever they give you is a candidate, not an entry.** It goes through the same verification as anything found by research. When one fails a check, name the check it failed rather than dropping it silently, and let them decide whether to keep it anyway. They know the place and the research does not.

On option B, verify and stop. Do not quietly run the research pass anyway.

## Step 1. Find the previous queue

Ask for it, or look in the project and the conversation.

**With a previous queue this run is short.** Most entries carry over untouched, a few close, and you are looking for what is new since last month. Twenty minutes rather than an hour.

**Without one**, this is the first run and it is the long one. Say so, so the lead is not surprised.

Never rebuild from scratch when a previous file exists. The lead's Status and Last used columns live in that file and they are what stops the same fellowship running four weeks in a row.

## Step 2. Sweep the four tiers

**Fifteen open opportunities is a hard floor.** Not a target, not a guideline. Under fifteen means the sweep is unfinished, and the script refuses to call the queue ready. Keep working the tiers until you clear it.

**Most of Tier 1 runs rolling intake, and rolling programmes count.** Elemental, Third Derivative, Halliburton Labs, and NSF SBIR project pitches are all listable with `Rolling` as the deadline. Excluding them is what produces a queue of five fellowships.

**Tier 1 alone should produce most of that.** These programs run every year and their pages are public and stable. A queue that does not include several of them means Tier 1 was skimmed rather than worked:

Elemental Impact, Third Derivative, Greentown Labs, Activate, Cyclotron Road, Breakthrough Energy Fellows, plus DOE funding opportunities, ARPA-E, SBIR and STTR, EPA grants, and the state energy authority for the chapter's state.

**A queue of one type is a failed sweep.** Five fellowships and nothing else is not a month with no accelerators open, it is a search that stopped at the first source type. Accelerators, grants, competitions, and calls for proposals all exist in every month of the year at national level. The script blocks on any single type exceeding half the queue, and on Accelerator, Grant, or Fellowship being entirely absent.

**Scope mix is the other check.** A healthy queue leads with local and regional programmes and carries national and global ones below them. All four tiers contribute, and the file is sorted so the most exclusive opportunities are the first thing the lead sees.



Work down `references/sources.md` in order.

1. **Program pages and public funders.** The backbone. No browser needed.
2. **Aggregators.** Highest yield per fetch. Always confirm the deadline on the program's own page, because aggregators leave dead listings up.
3. **LinkedIn.** Browser only, only with the extension, only if the lead says yes. Skipping this tier is a good run, not a broken one. If the extension is unavailable, say so and say what the tier usually contributes.
4. **Local, from the partner map.** If a `CTC_Partner_Map` or `CTC_City_Resources` workbook exists, read it and check each organization's programs page rather than researching the city again. This tier produces the entries no other newsletter in the city has.

Scope is city, then state, then region, then national and international. Wider than the events scope rule on purpose: people apply to these from a desk, not on a weeknight.

**Set the `scope` field precisely, because it decides the order of the file.** Use the city name for anything open only to that city, the state or region name for state-level programmes, then `National` or `Global`. Local entries lead the file, national ones sit below. Readers subscribed to their city's newsletter, and an opportunity only they can apply for is the one thing this block offers that a national list cannot.

**A queue with nothing local or regional in it means Tier 4 was skipped.** The script blocks on it. Work the partner map and the state energy authority.

## Step 3. Verify

Four checks, all four, before anything enters the queue:

1. The program's own page loads and the program is real.
2. Applications are open, or open on a stated future date.
3. The deadline is a future date, or `Rolling`, or `Unconfirmed` with what is known recorded. A rolling programme is listable and most of Tier 1 runs that way.
4. The chapter's region is eligible.

**The deadline is the field that matters.** Everything else is description. A wrong deadline in a newsletter is the error readers actually notice, and it is the one that costs someone an application.

Never take a deadline from an aggregator. Open the program page.

## Step 4. Build the queue

Write the findings as JSON, then:

```bash
python3 scripts/build_queue.py opportunities_<city>.json --existing <previous file>
```

Omit `--existing` only on a first run.

The script merges by URL, keeps the lead's Status and Last used, moves anything past its deadline to the Closed sheet, flags what closes within three weeks, and refuses to build on a blank required field, a non-https URL, a duplicate, or an em dash.

Read its output. It reports how many carried, how many are new, how many closed, and how many have not yet run in an issue.

### Missing information is marked, never left silent

The build script writes a `Missing Info` column naming any required field a row is missing, and shades **only the empty cells** red, plus the note that names them.

Cell-level, not row-level, on purpose. Shading a whole row buries the one field that needs attention among a dozen that do not, and large blocks of red read as broken rather than as a few cells to fill.

Read the script's output before delivering. It names every incomplete row and the exact field. Fix them and re-run rather than handing over a file with red in it.


## Step 5. Deliver

Call `present_files`, then in a few lines:

- How many are open, how many are new this month, how many closed.
- What is closing within three weeks, by name. This is the useful part.
- Anything registered with an unconfirmed deadline.
- Which tiers were skipped and why, particularly if the browser was unavailable.
- **Upload this to your Claude project, replacing last month's.** Say it every time. Nothing works if they do not.

Then stop.

---

## House rules

**Never invent a deadline.** If the programme's own page does not publish one, record `Rolling` when intake is open, or `Unconfirmed` when it is dated but not yet announced. Both are supported by the build script and both list fine in the issue. Never guess a date.

**Never carry a closed opportunity into the Open sheet.** The script prunes by date, so do not work around it.

**Never drop a lead-added entry.** If the lead added something by hand and it fails a check, keep it, name the failed check, and tell them.

**Never list a job posting.** A job is not an opportunity here and the newsletter has no jobs block.

**Never list anything with an application fee.**

**No dollar figures in descriptions.** Award sizes change and the file is meant to survive a year.

**Descriptions run 25 to 40 words.** What it is, who it is for, what the applicant gets. The block in the newsletter is emoji, linked title, short description, bolded deadline.

---

## Failure modes

**A thin month.** Some months genuinely have three new things. Say that plainly rather than padding with rolling programs that have no deadline. The queue carries the rest.

**An aggregator's deadline disagrees with the program page.** The program page wins, always.

**The browser is unavailable.** Skip Tier 3, name it, carry on. The other three tiers are most of the value.

**No partner map workbook.** Do one research pass over the city's incubators, universities, and economic development bodies. Say once, at delivery, that running `ctc-partner-map` for this city first would make Tier 4 substantially cheaper every month, because most of that research is the same research.

**The lead asks mid-month for more.** Fine. Run the tiers again, then **add the findings to the queue** rather than handing over a one-off list. Anything found mid-month should be there for the following weeks too.

**Two chapters ask for the same national programs.** Expected. Most of this queue is national and will look similar across cities. The local tier is what makes each one different, which is why it is worth the effort.
