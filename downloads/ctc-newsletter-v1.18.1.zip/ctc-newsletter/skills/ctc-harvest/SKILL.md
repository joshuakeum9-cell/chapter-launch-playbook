---
name: ctc-harvest
description: Harvest this week's climate events for a Climate Tech Cities chapter. Sweep the city's source registry (Luma calendars, Eventbrite organizers, and other verified sources) and produce the standard 14-column events spreadsheet the newsletter is built from. Use this skill whenever the user wants to collect, pull, gather, or sweep events for a city's newsletter, asks "get this week's events for [city]", wants the events sheet or events spreadsheet built, or is starting the weekly newsletter cycle. Always use this skill even if the user only wants one source swept or a single day's events. Do NOT use it to find new sources, which is the source-map skill's job.
---

# CTC Harvest

Sweep a city's registered sources and produce the events spreadsheet. This is the mechanical half of the weekly newsletter cycle: collection only, no judgment, no writing.

## What this is for

The sheet is not the deliverable. It is a worksheet for one person, the chapter lead, who will spend about fifteen minutes deleting rows from it and then hand it to `ctc-assemble`.

That reader wants three things, in this order. **Every event that exists**, so nothing good is missed. **Enough detail per row to decide**, so they are not opening twenty tabs to work out whether something is worth listing. **No invented data**, because anything guessed at gets published under their name.

Every rule below follows from that. Blank cells are fine, because a blank prompts a human. A missing event is not fine, because nobody will ever know it was missing. Over-collection is cheap, because deleting a row takes two seconds. Under-collection is expensive, because it is invisible.

## Input

- **A source registry**, the CSV produced by `ctc-source-map`. If none exists, stop and say so. Harvesting without a registry means guessing at sources, and the result cannot be trusted for completeness. The file `ctc-source-map/references/example-registry.csv`, bundled with the source-map skill in this same plugin, shows the format.
- **A city**, and its timezone.
- **A date window.** Default to two: the next 7 days (`this week`) and days 8 to 56 (`upcoming`). These map to the newsletter's two listing blocks.

If the chapter has a settings file (produced by `ctc-chapter-setup`), read the city, timezone, and scope rule from it rather than asking. Section 1 holds the city and timezone, section 2 holds the scope rule.

## What this skill does not do

No filtering for quality, no cutting, no picking, no writing prose. Collection and judgment are separate stages on purpose. Mixing them is what turns a 45-minute job into a two-hour one. Harvest everything in the window and let the human cut afterward in the sheet.

---

## Read this first

- `references/platform-notes.md` holds the working techniques for each platform: how to pull structured data out of Luma reliably, what breaks on Eventbrite, and the traps that produce wrong times or out-of-scope events. Read it before the first sweep.
- `references/example-events.csv` is a complete, valid ten-row sheet. Read it to calibrate description length, how blanks are used, and what a filled row actually looks like. It is illustrative data, not real events. Do not copy rows from it into a live sheet.

## Environment

Check these before starting rather than discovering them halfway through a sweep.

| Dependency | Needed for | If it is missing |
|---|---|---|
| `openpyxl` (Python) | Writing the .xlsx | `pip install openpyxl --break-system-packages` |
| Code execution enabled | Running `build_sheet.py` | Ask the user to enable it in Claude settings. Without it, output a CSV with the same columns and say the .xlsx step was skipped |
| Claude in Chrome extension | Tier 2 fetching | See below. This is the one that quietly ruins a harvest |

**The browser is not optional for Luma, and this is the most common silent failure in the whole toolkit.** A plain fetch of a Luma calendar returns event titles and no dates, so a harvest run without the browser produces a sheet full of names with empty date cells, which reads as a data problem rather than a missing tool. If the extension is not installed, say so before sweeping and give the user the choice: install it, or accept a manual paste for every Luma source.

**The sandbox may only reach an allowlisted set of domains**, so `curl` and Python `requests` will fail on event sites even when the sites are fine. Use the fetch tool or the browser for anything on the open web, and never conclude a source is dead because a shell command could not reach it.

## Before the sweep - anything you already know

Harvest reads the registry `ctc-source-map` built, so it does not research the city. But the lead often knows about events that appear on no calendar: something a partner mentioned, an invitation forwarded to them, their own chapter event.

Ask once, in the opening message:

> Sweeping your registry now. Anything you already know about that will not be on a calendar? Paste it in and I will add it to the sheet.

Anything they add goes into the sheet with the same fourteen columns, marked as lead-supplied. **Never drop a lead-supplied event**, even when a field is missing. Name the missing field and keep the row.

If what they actually want is new *sources* rather than new events, that is `ctc-source-map`. Point them there and re-run it rather than working around it here.

## Fetching: a three-tier ladder

Work down the tiers per source. The registry's `method` column says which tier to expect, so start there rather than rediscovering it every week.

**Tier 1, plain fetch.** Fast, cheap, and sufficient for most server-rendered university, government, and utility calendars. Try this first, always.

**Tier 2, browser (Claude in Chrome).** Escalate when Tier 1 returns an empty shell, a JavaScript placeholder, a 403, or obviously truncated content. Requests then come from the user's real browser with their real session, so the page treats it as a person rather than a bot, which is the point. This is the expected path for every Luma calendar and for Eventbrite organizer pages.

Ask before opening the browser the first time in a session. It uses the user's own Chrome.

Pace the sweep. Even from a real browser, hitting thirty organizer pages in rapid succession can trip rate limiting. Work steadily rather than in a burst.

**Tier 3, paste fallback.** If a source still fails, ask the user to open it and paste the contents. Record the failure in the run report. A source needing this every week should be reclassified `manual` in the registry.

**Hard stop: CAPTCHA.** If a bot challenge appears, report it and move to the next source. Never attempt to solve or work around one. Never enter credentials. If a source requires login, skip it and note it.

### The size of a sweep

A registry of 25 to 30 sources is roughly 15 to 25 fetches once cross-linked Luma calendars are pulled in one pass. Most Luma sweeping happens in a handful of browser calls rather than one per calendar, so the cost tracks the number of platforms rather than the number of sources.

If a sweep finishes after touching four or five sources, it is not finished. Every registered source gets checked, including the ones that are usually empty, because "usually empty" is exactly the state a broken source hides in.

Do not tell the lead how long any of this will take.

---

## Sweep every source, every week

**Every registered source gets opened, every run.** Not a sample, not the ones that produced events last week, not the ones that look promising. All of them.

The sources that usually return nothing are exactly where a missed event hides. A university calendar that has been empty for a month is the one that posts the lecture everyone wanted to hear about.

**Work from the registry, and account for every row.** Before writing the sheet, confirm you have opened every source in `CTC_Source_Registry_<City>.xlsx`. If a source could not be reached, that is a fact to report, not a row to skip quietly.

**Report the sweep, not just the result.** In the delivery, say how many sources were swept out of how many registered, and name every one that returned nothing along with why:

> Swept 27 of 27 sources. 4 returned nothing this week: [names]. 2 could not be reached: [names, and what happened].

**A source returning nothing and a source failing are different things and must never be reported the same way.** The first is information about the week. The second is a broken registry row that needs fixing before next week.

**If the week's total comes in far below this chapter's normal, a source broke rather than the city going quiet.** Check the zero-return sources by eye before concluding anything about the week.

**Both windows, every run.** The next seven days, and days 8 to 56. An event 40 days out belongs in Upcoming, not dropped for being far off.

## Open the event's own page, always

**A calendar tells you an event exists. Only the event's own page tells you when and where it is.**

This is the single most common way a harvest produces an unusable sheet. The listing page gives a title and a date, those two columns fill in, and the row looks fine at a glance while time, address, and access are all blank.

**The rule: never write a row from a listing page.** Follow the title through to the event's own page and read the row from there.

**How to spot it.** A registration link ending in `/events`, `/calendar`, `/boards`, `/programs`, `/upcoming`, or `/whats-on` is an index, not an event. The build script flags these, but by then the browsing is finished and re-doing it costs a second pass. Catch it while you are on the page.

**Where it bites hardest.** Institutional calendars, not Luma or Eventbrite. City government boards and commissions, university department calendars, and museum programme pages all list events as plain text with a shared link back to the index. Those are exactly the sources that need one extra click each.

**Two or more of Start Time, Location, and Access missing on the same row means the event page was not opened.** Go back and open it.

**No registration link at all means the row does not ship.** Either find the page or drop the event. A listing a reader cannot act on is worse than one fewer listing.

## The link must be the page you landed on

**Four link defects shipped in a real issue. All four come from writing a URL that was never opened.**

The rule that prevents every one of them: **you are already required to open each event's own page. Record the address you ended up at, and nothing else.**

### Never construct a URL

Do not build a link from a pattern, a slug, an event ID, or a date. Copy the address bar after the page loads.

Constructed slugs land on the wrong event silently. In the Austin issue, `/event/bunny-run-hike/` 302-redirected to `bunny-run-hike-apr-2025`, an event from the previous April. The sheet recorded the request; the reader got 2025.

**If the address you land on differs from the link you clicked, record where you landed and note the redirect.** A redirect to a different slug usually means the event you wanted does not exist.

### Never join a title to a URL afterwards

Read the event name and its link **from the same element, in the same pass**. Do not collect titles into one list, links into another, and pair them up by position.

Two USGBC rows shipped with real event IDs attached to the wrong names: a Sep 23 online webinar linked to an in-person coffee morning in McAllen on Sep 8. A third row from the same source was correct, which is what a positional join looks like when it partly works.

### Never fall back to the listing page

When an event has no page of its own, **leave `Registration Link` empty and let the row flag red.** Do not write the calendar URL you were reading.

Two different AIA events shipped with the identical URL `calendar.aiaaustin.org/`, a rolling week view that will show neither of them by the time anyone clicks. One Solar Austin row linked to the organisation homepage, on which the event's name does not appear anywhere.

**An empty cell is recoverable. A plausible wrong link ships.**

### Check three things while you are on the page

These cost nothing, because the page is already open for the time and address:

1. **The page is about this event.** The title on the page matches the row.
2. **The date on the page matches the row.** One Austin row was four days out. Another was in Houston, outside the scope rule entirely.
3. **The page does not say the event has passed.** Five rows shipped as upcoming while their pages read "This event has passed", one of them dated the previous October.

Any of the three failing means the row does not ship as it stands. Fix the link, fix the date, or drop the event.

**Do not compare the slug to the title as a substitute for reading the page.** Slugs legitimately drift: `bat-walk-with-atx-vegans` is correctly titled "ABR Bat Walk with Planted Society". Judging links on slug similarity produced four false accusations and missed ten real failures in the same review.

### Upcoming rows are not lower priority

Every one of the fourteen failures in the Austin issue was in `upcoming`, and every `this_week` row was clean. Upcoming events are linked in the issue exactly like this week's, so a dead link there reaches a reader the same way. Give days 8 to 56 the same page visits.

## Every required field gets filled

**"I could not find it" is not a reason.** If an event is real, its details exist on its own page. An in-person event has an address. A ticketed event states a price or says free. An event happening at a time has a start time. When a field is blank it is almost always because the listing page was read instead of the event page.

**What each row needs depends on its Event Type.**

| Event Type | Required |
|---|---|
| In-person, Hybrid | Everything, including Location and Google Maps |
| Online | Everything except Location and Google Maps |

An online event with no Google Maps link is complete. Do not chase an address for a webinar, and do not leave Access blank on one, because a webinar is still free or paid.

**Required on every row regardless of type:** Event Name, Date, Start Time, Registration Link, Event Type, Access, City / Neighborhood, Format, Host Organization(s), Description, Categories.

Several of these have a valid value for the case where the organiser published nothing. See the table below rather than leaving a cell empty.

**Required additionally when there is a venue:** Location, Google Maps.

**Do not build Google Maps URLs by hand.** `build_sheet.py` derives every one of them from `Location` before anything else runs. Leave the column out of your data entirely and it fills itself.

If the completeness report says Google Maps is missing, the cause is a blank `Location` on that row, never a missing URL. Fix the address and the link appears.

**Genuinely optional:** End Time. Plenty of organisers never publish one.

### When the organiser has not published something

**A blank cell and an unpublished detail are different things, and only one of them is a problem.**

Plenty of real listings never state a price. Garden programmes, committee meetings, museum events, and library sessions routinely say nothing about cost. Some organisers withhold the address until someone registers. Some events genuinely run all day.

None of those are gaps, and none of them should go red. Record what is true:

| Situation | What goes in the cell |
|---|---|
| The page states no price anywhere | `Access` = **Not stated** |
| Address released after registration | `Location` = **Shared after registration** |
| Venue not announced yet | `Location` = **To be announced** |
| Runs all day, no start time published | `Start Time` = **All day** |

**"Not stated" is not a guess and it is not a blank.** It records that the page was read and no price was found. Never write `Free` because a page did not mention money: a listing that says free under the lead's name when it is not is worse than one that says nothing.

**When the address is withheld, Location and Google Maps are both satisfied.** The script recognises this and stops asking. Do not chase an address the organiser deliberately did not publish.

**These four values exist so the sheet can be honest and still complete.** Use them. Leaving a cell blank instead turns a known fact into a red row, and a red row that cannot be fixed teaches the lead to ignore red rows.

### Missing information is marked, never left silent

`scripts/build_sheet.py` writes a `Missing Info` column naming the missing fields, and shades **only the empty cells** red, plus the `Missing Info` cell on that row. The eye goes straight to the field that needs filling, and an event missing one detail does not look as broken as one missing five.

It then reports every incomplete row by name and field, and states the sheet is not ready.

**Red should be rare.** It is a backstop for a sweep that read a listing page instead of an event page, not a normal state for a finished sheet. Before treating a red cell as more browsing, check whether it has a resolved-unknown value: most do. A sheet handed over with red still in it is a sheet that was not finished.

**When it says the sheet is not ready, go back and fill the missing information rather than handing it over.** Open the event page for each flagged row and read the value. Re-run the script. The lead should receive a sheet with no red in it.

**If a field is genuinely unavailable on the event's own page, that is a fact worth stating rather than a blank to leave.** Say which row, which field, and what the page showed. A venue listed as "location shared after registration" is an answer, and it goes in the cell in those words, not left empty.

## Output: the events sheet

An `.xlsx` file, one sheet named `Events`, one row per event. These fourteen columns, in this exact order, with these exact headers:

| # | Column | Contents |
|---|---|---|
| 1 | `Event Name` | As the organizer wrote it. Do not editorialize or shorten |
| 2 | `Date` | `YYYY-MM-DD` |
| 3 | `Start Time (TZ)` | `HH:MM`, 24-hour. Put the city's timezone in the header: `(PDT)`, `(EDT)`, `(BST)` |
| 4 | `End Time (TZ)` | Same format. Leave blank if not published. Do not invent one |
| 5 | `Registration Link` | Where people actually register. Never a bare homepage |
| 6 | `Event Type` | `In-person` / `Hybrid` / `Online` |
| 7 | `Access` | `Free` / `Free — register to view address` / `Ticketed (Paid)` / `Ticketed (Paid) — register to view address` |
| 8 | `Location` | Full street address as published. For online events, `Online` |
| 9 | `City / Neighborhood` | The scannable geography: `Fall City`, `Vancouver, BC`, `Brooklyn` |
| 10 | `Google Maps` | Derived from the address, see below |
| 11 | `Format` | What kind of event. Comma-separated, multiple allowed |
| 12 | `Host Organization(s)` | Comma-separated. Include named individuals when the page credits them |
| 13 | `Description` | From the source page's own wording, see below |
| 14 | `Categories` | From the controlled list below. Comma-separated, one to three |

The four `Access` values are matched literally by the validator in `build_sheet.py`, punctuation included. Reproduce them exactly.

Add a `Block` column at the end (`this_week` / `upcoming`) when harvesting for a weekly newsletter, so assembly knows which listing block each event belongs to. Omit it for a climate week guide, where everything is in scope.

**Write the sheet with the bundled script**, not by hand:

```
python3 scripts/build_sheet.py events.json out.xlsx --tz EDT --block
```

`events.json` is a list of objects keyed by the column names, using `Start Time` and `End Time` without the timezone suffix. The script exists so the columns come out byte-identical every week. `ctc-assemble` reads them by name, and a header capitalized differently or a column reordered breaks assembly silently rather than loudly. The script warns rather than refusing: a warning is a prompt for the editor, not a reason to withhold the file.

### Google Maps URLs

Derive, do not look up:

```
https://www.google.com/maps/search/?api=1&query={URL-encoded Location}
```

Leave blank for online events, and blank when the address is withheld until registration.

### Descriptions

**Use the source page's own wording.** Condense and tidy, but do not rewrite from scratch and do not embellish. This keeps the data consistent across hundreds of events and stops the prose drifting into generic AI phrasing, which the house style rejects.

Length depends on the destination, so ask if unclear:

- **Weekly newsletter**, three sentences, roughly 50 to 70 words. Enough for the Events in Detail block.
- **Climate week guide**, longer, 150 to 200 words, closer to the source page's full framing.

The three-sentence shape moves from what-it-is, to who-hosts-it, to why-attend. Every row in `references/example-events.csv` follows it.

Never invent detail the page does not contain. If a page is thin, a short description is the correct output.

### Categories

Controlled vocabulary. Assign one to three per event:

`Adaptation` · `AI & Data` · `Arts & Culture` · `Biodiversity & Nature` · `Buildings` · `Circular Economy & Waste Management` · `Cities` · `Climate Tech & Startups` · `Communications` · `Corporate Sustainability` · `Energy` · `Environmental Justice` · `Finance` · `Food & Agriculture` · `Fun for Kids` · `Get Outside` · `Health` · `Mobility & Logistics` · `Philanthropy` · `Policy` · `Social` · `Water`

Do not invent new categories. If nothing fits, use the closest and flag it in the run report. A recurring misfit is a signal the vocabulary needs extending, which is a decision for the editor rather than the tool.

Smaller cities may use a subset. Ask which set applies before starting.

### Format

Freer than Categories, but stay consistent within a run. Common values observed in practice:

`Panel Session` · `Happy Hour` · `Workshop` · `Networking` · `Community Event` · `Tour` · `Field Trip` · `Outdoors` · `Volunteer` · `Talk` · `Social` · `Meetup` · `Conference` · `Fair` · `Q&A` · `Presentation` · `Webinar` · `Screening` · `Exhibition` · `Site Tour` · `Fireside Chat` · `Dinner` · `Hackathon` · `Info Session`

---

## Dedupe

The same event appears on several calendars under slightly different names. This matters more than it sounds. Duplicates are one of the two errors readers actually notice.

The mechanics: match on `Date` plus fuzzy `Event Name`, then confirm by venue. Treat two names as the same event when one contains the other, or when they agree after stripping the host name, the city name, edition numbers, and punctuation. `Green Drinks Portland` and `Green Drinks PDX #47` on the same date at the same venue are one event.

Then the judgment, which is where it goes wrong.

| Situation | Ruling | Reasoning |
|---|---|---|
| Same event, two calendars, different registration links | Merge. Keep the organizer's own link | Aggregator links break more often and cost the organizer their attendee data |
| One listing has a full description, the other has none but a better link | Merge, taking the best value per field | Fields merge independently. Do not discard good data to keep a record whole |
| Same series, different dates | Two rows | A weekly meetup is not a duplicate of itself |
| In-person and online tickets listed as separate events | One row, `Event Type` = `Hybrid` | The reader is deciding whether to go, not which ticket to buy |
| Two calendars credit different co-hosts | Merge, and merge the host list | Both are true. Dropping one erases a partner |
| Same title, same day, different venues across the metro | Two rows, and flag it | Usually a genuine multi-site event like a citywide volunteer day. Occasionally a data error. The lead can tell, you cannot |
| Genuinely uncertain whether two rows are one event | Keep both, surface the collision in the run report | An extra row costs two seconds to delete. A wrongly merged event loses a real listing silently |

The principle underneath: **merging destroys information and duplicating does not.** When unsure, duplicate and report.

## Missing data

Leave a cell blank rather than guessing. A blank is a visible prompt for a human. An invented time is a wrong listing that ships.

The one exception is derived fields, `Google Maps`, `Date` formatting, and `Block`, which are computed rather than guessed.

Never fabricate an event, a time, or a venue. If that happens it is a stop-everything defect: report it and fix the prompt before the next run.

---

## Run report

After writing the sheet, report in chat:

- Events found, split by block
- Sources swept, and which tier each needed
- Sources that failed, and why
- Duplicates merged, and collisions left for the lead to resolve
- Rows with missing required fields, by column
- Anything that could not be categorized
- Sources that returned nothing. A core source returning zero two weeks running is probably broken, not quiet

## Sanity check

Compare the count against the city's normal range before handing over.

| Chapter stage | This week | Upcoming | Where the number comes from |
|---|---|---|---|
| Launch, first few issues | 3 to 8 | 5 to 15 | Measured. New York's 2021 issues carried 1 to 4 events |
| Established, smaller city | 8 to 15 | 15 to 30 | Estimate, not measured. A rough expectation, not a standard |
| Mature, New York 2026 | 15 to 20 | 25 to 40 | Measured from published issues |

A sweep returning three events in a city that normally yields twenty means a source broke, not that the city went quiet. Say so rather than shipping a thin sheet without comment.

**These are diagnostic ranges, not targets.** Never add a marginal event to reach a number. The count is an output of what the city is doing that week, and a genuinely quiet August is a real result.

---

## Failure modes

Each of these has actually happened.

**Times off by several hours.** Luma's `start_at` is UTC. Convert to the city's timezone before writing the sheet, or every time is wrong, and wrong consistently enough to look correct. Check one event against its own page before trusting the batch.

**Out-of-town events shipped.** Multi-city organizations put every city on one calendar. Greentown Labs lists Houston alongside Boston. Filter on the event's own location against the scope rule rather than trusting the calendar's name.

**A city discovery page treated as a climate source.** `luma.com/{city}` is a general local feed. On a Boston sample it returned twenty events of which two were climate-relevant. It is a discovery aid for source-map, never an auto-pull for harvest.

**Reading a reference file as a target.** A climate week export can carry 276 rows. That is a whole festival, not a week. When a file is used to learn the column format, take the format and ignore the row count.

**Syndicated training spam.** Generic listings such as "ESG & Sustainability Strategy: 1 Day Training", republished across dozens of cities by resellers, often from an unrelated country's domain. They pass a naive relevance check and recur every week forever. If the same title appears in three cities, it is a reseller.

**A term-time calendar declared dead.** University sources empty out in July and August and again in late December. A zero return in August from a source that was weekly in April is a season, not a break.

**A registration link pointing at a homepage.** The reader clicks and lands on an organization's front page with no way to find the event. Column 5 is the registration page or nothing.

**Shipping the sheet without the report.** The counts, the failures, and the zero-return sources are how the lead knows whether to trust the file. A sheet handed over silently gets trusted when it should not be.
